package com.zarmorhud.net.client;

import net.fabricmc.api.ClientModInitializer;

public class ZArmorHudClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}