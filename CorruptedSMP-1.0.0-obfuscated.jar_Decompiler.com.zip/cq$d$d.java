public final class cq$d$d extends bK {
   // $FF: synthetic field
   final cq.d this$0;
   // $FF: synthetic field
   final boolean $clearPrevious$inlined;
   // $FF: synthetic field
   final cx $settings$inlined;

   public cq$d$d(String var1, boolean var2, cq.d var3, boolean var4, cx var5) {
      super(var1, var2);
      this.this$0 = var3;
      this.$clearPrevious$inlined = var4;
      this.$settings$inlined = var5;
   }

   public long gg() {
      boolean var1 = false;
      this.this$0.b(this.$clearPrevious$inlined, this.$settings$inlined);
      return -1L;
   }
}
