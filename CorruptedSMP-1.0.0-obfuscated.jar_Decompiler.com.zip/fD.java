import java.lang.reflect.Method;

public class fD {
   public void a(Throwable var1, Throwable var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      Method var10000 = fD.a.sI;
      if (var10000 != null) {
         Object[] var3 = new Object[]{var2};
         var10000.invoke(var1, var3);
      }

   }

   static final class a {
      public static final a sH = new a();
      public static final Method sI;
      public static final Method sJ;

      private a() {
      }

      static {
         Class var0 = Throwable.class;
         Method[] var1 = var0.getMethods();
         fR.b(var1, "");
         Method[] var2 = var1;
         int var3 = 0;
         int var4 = var1.length;

         Method var14;
         while(true) {
            if (var3 >= var4) {
               var14 = null;
               break;
            }

            Method var5;
            label36: {
               var5 = var2[var3];
               boolean var7 = false;
               if (fR.c(var5.getName(), (Object)"addSuppressed")) {
                  Class[] var10000 = var5.getParameterTypes();
                  fR.b(var10000, "");
                  if (fR.c(eI.d(var10000), (Object)var0)) {
                     var13 = true;
                     break label36;
                  }
               }

               var13 = false;
            }

            if (var13) {
               var14 = var5;
               break;
            }

            ++var3;
         }

         sI = var14;
         var2 = var1;
         var3 = 0;
         var4 = var1.length;

         while(true) {
            if (var3 >= var4) {
               var14 = null;
               break;
            }

            Method var11 = var2[var3];
            boolean var12 = false;
            if (fR.c(var11.getName(), (Object)"getSuppressed")) {
               var14 = var11;
               break;
            }

            ++var3;
         }

         sJ = var14;
      }
   }
}
