import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class D {
   private final UUID ac;
   private l ad;
   private boolean ae;
   private int af;
   private int ag;
   private long ah;
   private int ai;
   private int aj;
   private double ak;
   private boolean al;
   private Map<String, Object> am;

   public D(UUID var1) {
      this.ac = var1;
      this.ae = false;
      this.ad = null;
      this.af = 0;
      this.ag = 0;
      this.ah = 0L;
      this.ai = 0;
      this.aj = 0;
      this.ak = (double)0.0F;
      this.al = false;
      this.am = new HashMap();
   }

   public UUID z() {
      return this.ac;
   }

   public l A() {
      return this.ad;
   }

   public void g(l var1) {
      this.ad = var1;
   }

   public boolean B() {
      return this.ae;
   }

   public void a(boolean var1) {
      this.ae = var1;
   }

   public int C() {
      return this.af;
   }

   public void a(int var1) {
      this.af = var1;
   }

   public void D() {
      ++this.af;
   }

   public void E() {
      this.af = 0;
   }

   public int F() {
      return this.ag;
   }

   public void b(int var1) {
      this.ag = var1;
   }

   public void G() {
      ++this.ag;
   }

   public void H() {
      this.ag = 0;
   }

   public long I() {
      return this.ah;
   }

   public void a(long var1) {
      this.ah = var1;
   }

   public int J() {
      return this.ai;
   }

   public void K() {
      ++this.ai;
      if (this.ai > 15) {
         this.ai = 0;
      }

   }

   public void L() {
      this.ai = 0;
   }

   public int M() {
      return this.aj;
   }

   public void N() {
      ++this.aj;
      if (this.aj >= 3) {
         this.aj = 0;
      }

   }

   public void O() {
      this.aj = 0;
   }

   public double P() {
      return this.ak;
   }

   public void a(double var1) {
      this.ak = Math.min(var1, (double)520.0F);
   }

   public void b(double var1) {
      this.ak = Math.min(this.ak + var1, (double)520.0F);
   }

   public boolean Q() {
      return this.al;
   }

   public void b(boolean var1) {
      this.al = var1;
   }

   public void a(String var1, Object var2) {
      this.am.put(var1, var2);
   }

   public Object h(String var1) {
      return this.am.get(var1);
   }

   public boolean i(String var1) {
      return this.am.containsKey(var1);
   }

   public void j(String var1) {
      this.am.remove(var1);
   }

   public void R() {
      this.af = 0;
      this.ag = 0;
      this.ah = 0L;
      this.ai = 0;
      this.aj = 0;
      this.ak = (double)0.0F;
      this.al = false;
      this.am.clear();
   }
}
