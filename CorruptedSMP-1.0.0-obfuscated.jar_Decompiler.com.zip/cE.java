import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLSocket;

public final class cE extends cH {
   public static final b oJ = new b((fP)null);
   private final Method oK;
   private final Method oL;
   private final Method oM;
   private final Class<?> oN;
   private final Class<?> oO;

   public cE(Method var1, Method var2, Method var3, Class<?> var4, Class<?> var5) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      fR.c(var5, (String)"");
      super();
      this.oK = var1;
      this.oL = var2;
      this.oM = var3;
      this.oN = var4;
      this.oO = var5;
   }

   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      List var4 = cH.oU.h(var3);

      try {
         ClassLoader var10000 = cH.class.getClassLoader();
         Class[] var6 = new Class[]{this.oN, this.oO};
         Object var5 = Proxy.newProxyInstance(var10000, var6, new a(var4));
         Method var10 = this.oK;
         Object[] var9 = new Object[]{var1, var5};
         var10.invoke((Object)null, var9);
      } catch (InvocationTargetException var7) {
         throw new AssertionError("failed to set ALPN", (Throwable)var7);
      } catch (IllegalAccessException var8) {
         throw new AssertionError("failed to set ALPN", (Throwable)var8);
      }
   }

   public void e(SSLSocket var1) {
      fR.c(var1, (String)"");

      try {
         Method var10000 = this.oM;
         Object[] var2 = new Object[]{var1};
         var10000.invoke((Object)null, var2);
      } catch (IllegalAccessException var3) {
         throw new AssertionError("failed to remove ALPN", (Throwable)var3);
      } catch (InvocationTargetException var4) {
         throw new AssertionError("failed to remove ALPN", (Throwable)var4);
      }
   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");

      try {
         Method var10000 = this.oL;
         Object[] var3 = new Object[]{var1};
         InvocationHandler var6 = Proxy.getInvocationHandler(var10000.invoke((Object)null, var3));
         fR.m(var6);
         a var2 = (a)var6;
         if (!var2.jO() && var2.jP() == null) {
            cH.a(this, "ALPN callback dropped: HTTP/2 is disabled. Is alpn-boot on the boot class path?", 0, (Throwable)null, 6, (Object)null);
            return null;
         } else {
            return var2.jO() ? null : var2.jP();
         }
      } catch (InvocationTargetException var4) {
         throw new AssertionError("failed to get ALPN selected protocol", (Throwable)var4);
      } catch (IllegalAccessException var5) {
         throw new AssertionError("failed to get ALPN selected protocol", (Throwable)var5);
      }
   }

   static final class a implements InvocationHandler {
      private final List<String> protocols;
      private boolean unsupported;
      private String selected;

      public a(List<String> var1) {
         fR.c(var1, (String)"");
         super();
         this.protocols = var1;
      }

      public final boolean jO() {
         return this.unsupported;
      }

      public final String jP() {
         return this.selected;
      }

      public Object invoke(Object var1, Method var2, Object[] var3) throws Throwable {
         fR.c(var1, "");
         fR.c(var2, (String)"");
         Object var10000 = var3;
         if (var3 == null) {
            var10000 = new Object[0];
         }

         Object[] var4 = (Object[])var10000;
         String var5 = var2.getName();
         Class var6 = var2.getReturnType();
         if (fR.c(var5, (Object)"supports") && fR.c(Boolean.TYPE, (Object)var6)) {
            return true;
         } else if (fR.c(var5, (Object)"unsupported") && fR.c(Void.TYPE, (Object)var6)) {
            this.unsupported = true;
            return null;
         } else if (fR.c(var5, (Object)"protocols") && var4.length == 0) {
            return this.protocols;
         } else if ((fR.c(var5, (Object)"selectProtocol") || fR.c(var5, (Object)"select")) && fR.c(String.class, (Object)var6) && var4.length == 1 && var4[0] instanceof List) {
            var10000 = var4[0];
            fR.m(var4[0]);
            List var7 = (List)var10000;
            int var8 = 0;
            int var9 = var7.size();
            if (var8 <= var9) {
               while(true) {
                  var10000 = var7.get(var8);
                  fR.m(var10000);
                  String var10 = (String)var10000;
                  if (this.protocols.contains(var10)) {
                     this.selected = var10;
                     return this.selected;
                  }

                  if (var8 == var9) {
                     break;
                  }

                  ++var8;
               }
            }

            this.selected = (String)this.protocols.get(0);
            return this.selected;
         } else if ((fR.c(var5, (Object)"protocolSelected") || fR.c(var5, (Object)"selected")) && var4.length == 1) {
            Object var10001 = var4[0];
            fR.m(var4[0]);
            this.selected = (String)var10001;
            return null;
         } else {
            return var2.invoke(this, Arrays.copyOf(var4, var4.length));
         }
      }
   }

   public static final class b {
      private b() {
      }

      public final cH jQ() {
         String var1 = System.getProperty("java.specification.version", "unknown");

         try {
            fR.b(var1, "");
            int var2 = Integer.parseInt(var1);
            if (var2 >= 9) {
               return null;
            }
         } catch (NumberFormatException var13) {
         }

         try {
            String var14 = "org.eclipse.jetty.alpn.ALPN";
            Class var3 = Class.forName(var14, true, (ClassLoader)null);
            Class var4 = Class.forName(var14 + "$Provider", true, (ClassLoader)null);
            Class var5 = Class.forName(var14 + "$ClientProvider", true, (ClassLoader)null);
            Class var6 = Class.forName(var14 + "$ServerProvider", true, (ClassLoader)null);
            Class[] var8 = new Class[]{SSLSocket.class, var4};
            Method var7 = var3.getMethod("put", var8);
            Class[] var9 = new Class[]{SSLSocket.class};
            Method var15 = var3.getMethod("get", var9);
            Class[] var10 = new Class[]{SSLSocket.class};
            Method var16 = var3.getMethod("remove", var10);
            fR.b(var7, "");
            fR.b(var15, "");
            fR.b(var16, "");
            fR.b(var5, "");
            fR.b(var6, "");
            return new cE(var7, var15, var16, var5, var6);
         } catch (ClassNotFoundException var11) {
         } catch (NoSuchMethodException var12) {
         }

         return null;
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }
}
