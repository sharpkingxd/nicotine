import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public final class al {
   private final Map<Type, L<?>> be;
   private final boolean bf;
   private final List<Z> bg;

   public al(Map<Type, L<?>> var1, boolean var2, List<Z> var3) {
      this.be = var1;
      this.bf = var2;
      this.bg = var3;
   }

   static String d(Class<?> var0) {
      int var1 = var0.getModifiers();
      if (Modifier.isInterface(var1)) {
         return "Interfaces can't be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Interface name: " + var0.getName();
      } else {
         return Modifier.isAbstract(var1) ? "Abstract classes can't be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Class name: " + var0.getName() : null;
      }
   }

   public <T> ar<T> b(aS<T> var1) {
      final Type var2 = var1.bl();
      Class var3 = var1.bk();
      final L var4 = (L)this.be.get(var2);
      if (var4 != null) {
         return new ar<T>() {
            public T av() {
               return (T)var4.a(var2);
            }
         };
      } else {
         final L var5 = (L)this.be.get(var3);
         if (var5 != null) {
            return new ar<T>() {
               public T av() {
                  return (T)var5.a(var2);
               }
            };
         } else {
            ar var6 = c(var2, var3);
            if (var6 != null) {
               return var6;
            } else {
               Z.a var7 = au.a(this.bg, var3);
               ar var8 = a(var3, var7);
               if (var8 != null) {
                  return var8;
               } else {
                  ar var9 = d(var2, var3);
                  if (var9 != null) {
                     return var9;
                  } else {
                     final String var10 = d(var3);
                     if (var10 != null) {
                        return new ar<T>() {
                           public T av() {
                              throw new Q(var10);
                           }
                        };
                     } else if (var7 == Z.a.ALLOW) {
                        return this.<T>e(var3);
                     } else {
                        final String var11 = "Unable to create instance of " + var3 + "; ReflectionAccessFilter does not permit using reflection or Unsafe. Register an InstanceCreator or a TypeAdapter for this type or adjust the access filter to allow using reflection.";
                        return new ar<T>() {
                           public T av() {
                              throw new Q(var11);
                           }
                        };
                     }
                  }
               }
            }
         }
      }
   }

   private static <T> ar<T> c(final Type var0, Class<? super T> var1) {
      if (EnumSet.class.isAssignableFrom(var1)) {
         return new ar<T>() {
            public T av() {
               if (var0 instanceof ParameterizedType) {
                  Type var1 = ((ParameterizedType)var0).getActualTypeArguments()[0];
                  if (var1 instanceof Class) {
                     EnumSet var2 = EnumSet.noneOf((Class)var1);
                     return (T)var2;
                  } else {
                     throw new Q("Invalid EnumSet type: " + var0.toString());
                  }
               } else {
                  throw new Q("Invalid EnumSet type: " + var0.toString());
               }
            }
         };
      } else {
         return var1 == EnumMap.class ? new ar<T>() {
            public T av() {
               if (var0 instanceof ParameterizedType) {
                  Type var1 = ((ParameterizedType)var0).getActualTypeArguments()[0];
                  if (var1 instanceof Class) {
                     EnumMap var2 = new EnumMap((Class)var1);
                     return (T)var2;
                  } else {
                     throw new Q("Invalid EnumMap type: " + var0.toString());
                  }
               } else {
                  throw new Q("Invalid EnumMap type: " + var0.toString());
               }
            }
         } : null;
      }
   }

   private static <T> ar<T> a(Class<? super T> var0, Z.a var1) {
      if (Modifier.isAbstract(var0.getModifiers())) {
         return null;
      } else {
         final Constructor var2;
         try {
            var2 = var0.getDeclaredConstructor();
         } catch (NoSuchMethodException var5) {
            return null;
         }

         boolean var3 = var1 == Z.a.ALLOW || au.a(var2, (Object)null) && (var1 != Z.a.BLOCK_ALL || Modifier.isPublic(var2.getModifiers()));
         if (!var3) {
            final String var6 = "Unable to invoke no-args constructor of " + var0 + "; constructor is not accessible and ReflectionAccessFilter does not permit making it accessible. Register an InstanceCreator or a TypeAdapter for this type, change the visibility of the constructor or adjust the access filter.";
            return new ar<T>() {
               public T av() {
                  throw new Q(var6);
               }
            };
         } else {
            if (var1 == Z.a.ALLOW) {
               final String var4 = aN.b(var2);
               if (var4 != null) {
                  return new ar<T>() {
                     public T av() {
                        throw new Q(var4);
                     }
                  };
               }
            }

            return new ar<T>() {
               public T av() {
                  try {
                     Object var1 = var2.newInstance();
                     return (T)var1;
                  } catch (InstantiationException var2x) {
                     throw new RuntimeException("Failed to invoke constructor '" + aN.a(var2) + "' with no args", var2x);
                  } catch (InvocationTargetException var3) {
                     throw new RuntimeException("Failed to invoke constructor '" + aN.a(var2) + "' with no args", var3.getCause());
                  } catch (IllegalAccessException var4) {
                     throw aN.a(var4);
                  }
               }
            };
         }
      }
   }

   private static <T> ar<T> d(Type var0, Class<? super T> var1) {
      if (Collection.class.isAssignableFrom(var1)) {
         if (SortedSet.class.isAssignableFrom(var1)) {
            return new ar<T>() {
               public T av() {
                  return (T)(new TreeSet());
               }
            };
         } else if (Set.class.isAssignableFrom(var1)) {
            return new ar<T>() {
               public T av() {
                  return (T)(new LinkedHashSet());
               }
            };
         } else {
            return Queue.class.isAssignableFrom(var1) ? new ar<T>() {
               public T av() {
                  return (T)(new ArrayDeque());
               }
            } : new ar<T>() {
               public T av() {
                  return (T)(new ArrayList());
               }
            };
         }
      } else if (Map.class.isAssignableFrom(var1)) {
         if (ConcurrentNavigableMap.class.isAssignableFrom(var1)) {
            return new ar<T>() {
               public T av() {
                  return (T)(new ConcurrentSkipListMap());
               }
            };
         } else if (ConcurrentMap.class.isAssignableFrom(var1)) {
            return new ar<T>() {
               public T av() {
                  return (T)(new ConcurrentHashMap());
               }
            };
         } else if (SortedMap.class.isAssignableFrom(var1)) {
            return new ar<T>() {
               public T av() {
                  return (T)(new TreeMap());
               }
            };
         } else {
            return var0 instanceof ParameterizedType && !String.class.isAssignableFrom(aS.k(((ParameterizedType)var0).getActualTypeArguments()[0]).bk()) ? new ar<T>() {
               public T av() {
                  return (T)(new LinkedHashMap());
               }
            } : new ar<T>() {
               public T av() {
                  return (T)(new aq());
               }
            };
         }
      } else {
         return null;
      }
   }

   private <T> ar<T> e(final Class<? super T> var1) {
      if (this.bf) {
         return new ar<T>() {
            public T av() {
               try {
                  Object var1x = aw.INSTANCE.n(var1);
                  return (T)var1x;
               } catch (Exception var2) {
                  throw new RuntimeException("Unable to create instance of " + var1 + ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem.", var2);
               }
            }
         };
      } else {
         final String var2 = "Unable to create instance of " + var1 + "; usage of JDK Unsafe is disabled. Registering an InstanceCreator or a TypeAdapter for this type, adding a no-args constructor, or enabling usage of JDK Unsafe may fix this problem.";
         return new ar<T>() {
            public T av() {
               throw new Q(var2);
            }
         };
      }
   }

   public String toString() {
      return this.be.toString();
   }
}
