import java.io.IOException;

public final class cq$l extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final int $streamId$inlined;
   // $FF: synthetic field
   final long $unacknowledgedBytesRead$inlined;

   public cq$l(String var1, boolean var2, cq var3, int var4, long var5) {
      super(var1, var2);
      this.this$0 = var3;
      this.$streamId$inlined = var4;
      this.$unacknowledgedBytesRead$inlined = var5;
   }

   public long gg() {
      boolean var1 = false;

      try {
         this.this$0.iu().d(this.$streamId$inlined, this.$unacknowledgedBytesRead$inlined);
      } catch (IOException var3) {
         cq.a(this.this$0, var3);
      }

      return -1L;
   }
}
