import java.util.Arrays;

public class fR {
   private fR() {
   }

   public static void m(Object var0) {
      if (var0 == null) {
         nB();
      }

   }

   public static void a(Object var0, String var1) {
      if (var0 == null) {
         ba(var1);
      }

   }

   public static void nB() {
      throw (NullPointerException)a(new NullPointerException());
   }

   public static void ba(String var0) {
      throw (NullPointerException)a(new NullPointerException(var0));
   }

   public static void bb(String var0) {
      throw (eD)a(new eD(var0));
   }

   public static void bc(String var0) {
      bb("lateinit property " + var0 + " has not been initialized");
   }

   public static void b(Object var0, String var1) {
      if (var0 == null) {
         throw (NullPointerException)a(new NullPointerException(var1 + " must not be null"));
      }
   }

   public static void c(Object var0, String var1) {
      if (var0 == null) {
         bd(var1);
      }

   }

   private static void bd(String var0) {
      throw (NullPointerException)a(new NullPointerException(be(var0)));
   }

   private static String be(String var0) {
      StackTraceElement[] var1 = Thread.currentThread().getStackTrace();
      String var2 = fR.class.getName();

      int var3;
      for(var3 = 0; !var1[var3].getClassName().equals(var2); ++var3) {
      }

      while(var1[var3].getClassName().equals(var2)) {
         ++var3;
      }

      StackTraceElement var4 = var1[var3];
      String var5 = var4.getClassName();
      String var6 = var4.getMethodName();
      return "Parameter specified as non-null is null: method " + var5 + "." + var6 + ", parameter " + var0;
   }

   public static int j(int var0, int var1) {
      return var0 < var1 ? -1 : (var0 == var1 ? 0 : 1);
   }

   public static boolean c(Object var0, Object var1) {
      return var0 == null ? var1 == null : var0.equals(var1);
   }

   private static <T extends Throwable> T a(T var0) {
      return (T)a(var0, fR.class.getName());
   }

   static <T extends Throwable> T a(T var0, String var1) {
      StackTraceElement[] var2 = var0.getStackTrace();
      int var3 = var2.length;
      int var4 = -1;

      for(int var5 = 0; var5 < var3; ++var5) {
         if (var1.equals(var2[var5].getClassName())) {
            var4 = var5;
         }
      }

      StackTraceElement[] var6 = (StackTraceElement[])Arrays.copyOfRange(var2, var4 + 1, var3);
      var0.setStackTrace(var6);
      return (T)var0;
   }
}
