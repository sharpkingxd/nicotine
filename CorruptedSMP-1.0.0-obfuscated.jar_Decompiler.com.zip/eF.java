import java.util.Collection;
import java.util.Iterator;

public abstract class eF<E> implements fY, Collection<E> {
   protected eF() {
   }

   public abstract int getSize();

   public boolean contains(E var1) {
      Iterable var2 = (Iterable)this;
      boolean var3 = false;
      boolean var10000;
      if (var2 instanceof Collection && ((Collection)var2).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = false;
               break;
            }

            Object var5 = var4.next();
            boolean var7 = false;
            if (fR.c(var5, (Object)var1)) {
               var10000 = true;
               break;
            }
         }
      }

      return var10000;
   }

   public boolean containsAll(Collection<? extends Object> var1) {
      fR.c(var1, (String)"");
      Iterable var2 = (Iterable)var1;
      boolean var3 = false;
      boolean var10000;
      if (((Collection)var2).isEmpty()) {
         var10000 = true;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = true;
               break;
            }

            Object var5 = var4.next();
            boolean var7 = false;
            if (!this.contains(var5)) {
               var10000 = false;
               break;
            }
         }
      }

      return var10000;
   }

   public boolean isEmpty() {
      return this.size() == 0;
   }

   public String toString() {
      return eO.a((Iterable)this, (CharSequence)", ", (CharSequence)"[", (CharSequence)"]", 0, (CharSequence)null, new fK<E, CharSequence>() {
         public final CharSequence h(E var1) {
            return var1 == eF.this ? (CharSequence)"(this Collection)" : (CharSequence)String.valueOf(var1);
         }

         // $FF: synthetic method
         public Object invoke(Object var1) {
            return this.h(var1);
         }
      }, 24, (Object)null);
   }

   public Object[] toArray() {
      return fO.c(this);
   }

   public <T> T[] toArray(T[] var1) {
      fR.c(var1, (String)"");
      return (T[])fO.b(this, var1);
   }

   public boolean add(E var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(Collection<? extends E> var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void clear() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean remove(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean removeAll(Collection<? extends Object> var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean retainAll(Collection<? extends Object> var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public final int size() {
      return this.getSize();
   }
}
