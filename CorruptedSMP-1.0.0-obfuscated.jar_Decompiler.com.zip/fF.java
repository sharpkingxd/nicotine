public final class fF {
   private static final int i(int var0, int var1) {
      int var2 = var0 % var1;
      return var2 >= 0 ? var2 : var2 + var1;
   }

   private static final int h(int var0, int var1, int var2) {
      return i(i(var0, var2) - i(var1, var2), var2);
   }

   public static final int i(int var0, int var1, int var2) {
      int var10000;
      if (var2 > 0) {
         var10000 = var0 >= var1 ? var1 : var1 - h(var1, var0, var2);
      } else {
         if (var2 >= 0) {
            throw new IllegalArgumentException("Step is zero.");
         }

         var10000 = var0 <= var1 ? var1 : var1 + h(var0, var1, -var2);
      }

      return var10000;
   }
}
