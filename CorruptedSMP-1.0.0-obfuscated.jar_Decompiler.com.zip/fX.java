import java.util.List;

public class fX {
   private static <T extends Throwable> T a(T var0) {
      return (T)fR.a(var0, fX.class.getName());
   }

   public static void d(Object var0, String var1) {
      String var2 = var0 == null ? "null" : var0.getClass().getName();
      bf(var2 + " cannot be cast to " + var1);
   }

   public static void bf(String var0) {
      throw a(new ClassCastException(var0));
   }

   public static ClassCastException a(ClassCastException var0) {
      throw (ClassCastException)a(var0);
   }

   public static List n(Object var0) {
      if (var0 instanceof fY && !(var0 instanceof gc)) {
         d(var0, "kotlin.collections.MutableList");
      }

      return o(var0);
   }

   public static List o(Object var0) {
      try {
         return (List)var0;
      } catch (ClassCastException var2) {
         throw a(var2);
      }
   }
}
