public final class cf extends bz {
   private final String mb;
   private final long mc;
   private final dg md;

   public cf(String var1, long var2, dg var4) {
      fR.c(var4, (String)"");
      super();
      this.mb = var1;
      this.mc = var2;
      this.md = var4;
   }

   public long bS() {
      return this.mc;
   }

   public bt bR() {
      String var10000 = this.mb;
      return var10000 != null ? bt.ib.af(var10000) : null;
   }

   public dg bT() {
      return this.md;
   }
}
