import java.io.IOException;

public abstract class ac<T> {
   public abstract void a(aV var1, T var2) throws IOException;

   public final ac<T> an() {
      return new ac<T>() {
         public void a(aV var1, T var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               ac.this.a(var1, var2);
            }

         }

         public T b(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return (T)ac.this.b(var1);
            }
         }
      };
   }

   public final P a(T var1) {
      try {
         aD var2 = new aD();
         this.a(var2, var1);
         return var2.aY();
      } catch (IOException var3) {
         throw new Q(var3);
      }
   }

   public abstract T b(aT var1) throws IOException;
}
