import java.util.Iterator;

public abstract class fd implements fY, Iterator<Integer> {
   public abstract int aR();

   public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public Object next() {
      return this.aR();
   }
}
