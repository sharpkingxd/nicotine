import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class ec implements Listener {
   private final CorruptedSMPPlugin rz;

   public ec(CorruptedSMPPlugin var1) {
      this.rz = var1;
   }

   @EventHandler
   public void a(PlayerJoinEvent var1) {
      this.rz.f().g(var1.getPlayer().getUniqueId());
      if (this.rz.d().b(var1.getPlayer())) {
         this.rz.h().j(var1.getPlayer());
      }

      for(el var3 : this.rz.e().nc()) {
         if (!var3.mY()) {
            var3.h(var1.getPlayer());
         }
      }

   }
}
