import java.io.IOException;
import java.net.Authenticator;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.Authenticator.RequestorType;
import java.net.Proxy.Type;
import java.util.List;

public final class bE implements aY {
   private final bn jp;

   public bE(bn var1) {
      fR.c(var1, (String)"");
      super();
      this.jp = var1;
   }

   // $FF: synthetic method
   public bE(bn var1, int var2, fP var3) {
      if ((var2 & 1) != 0) {
         var1 = bn.hI;
      }

      this(var1);
   }

   public bw a(bA var1, by var2) throws IOException {
      List var3;
      bw var4;
      br var5;
      boolean var6;
      Proxy var10000;
      label48: {
         fR.c(var2, (String)"");
         var3 = var2.fi();
         var4 = var2.eT();
         var5 = var4.eI();
         var6 = var2.eW() == 407;
         if (var1 != null) {
            var10000 = var1.fp();
            if (var10000 != null) {
               break label48;
            }
         }

         var10000 = Proxy.NO_PROXY;
      }

      Proxy var7 = var10000;

      for(be var9 : var3) {
         if (gA.a("Basic", var9.cq(), true)) {
            label39: {
               if (var1 != null) {
                  aX var16 = var1.fo();
                  if (var16 != null) {
                     var17 = var16.bC();
                     if (var17 != null) {
                        break label39;
                     }
                  }
               }

               var17 = this.jp;
            }

            bn var10 = var17;
            PasswordAuthentication var20;
            if (var6) {
               SocketAddress var18 = var7.address();
               fR.m(var18);
               InetSocketAddress var12 = (InetSocketAddress)var18;
               String var19 = var12.getHostName();
               fR.b(var7, "");
               var20 = Authenticator.requestPasswordAuthentication(var19, this.a(var7, var5, var10), var12.getPort(), var5.cX(), var9.cr(), var9.cq(), var5.db(), RequestorType.PROXY);
            } else {
               String var21 = var5.cY();
               fR.b(var7, "");
               var20 = Authenticator.requestPasswordAuthentication(var21, this.a(var7, var5, var10), var5.cZ(), var5.cX(), var9.cr(), var9.cq(), var5.db(), RequestorType.SERVER);
            }

            PasswordAuthentication var11 = var20;
            if (var11 != null) {
               String var15 = var6 ? "Proxy-Authorization" : "Authorization";
               String var22 = var11.getUserName();
               fR.b(var22, "");
               char[] var10001 = var11.getPassword();
               fR.b(var10001, "");
               char[] var14 = var10001;
               String var13 = bl.a(var22, new String(var14), var9.cs());
               return var4.eO().h(var15, var13).eQ();
            }
         }
      }

      return null;
   }

   private final InetAddress a(Proxy var1, br var2, bn var3) throws IOException {
      Proxy.Type var10000 = var1.type();
      InetAddress var4;
      if ((var10000 == null ? -1 : bE.a.$EnumSwitchMapping$0[var10000.ordinal()]) == 1) {
         var4 = (InetAddress)eO.n(var3.D(var2.cY()));
      } else {
         SocketAddress var5 = var1.address();
         fR.m(var5);
         var4 = ((InetSocketAddress)var5).getAddress();
         fR.b(var4, "");
      }

      return var4;
   }

   public bE() {
      this((bn)null, 1, (fP)null);
   }

   // $FF: synthetic class
   public class a {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[Type.values().length];

         try {
            var0[Type.DIRECT.ordinal()] = 1;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$0 = var0;
      }
   }
}
