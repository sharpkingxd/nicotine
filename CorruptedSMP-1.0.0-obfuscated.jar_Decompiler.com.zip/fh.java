import java.util.LinkedHashMap;
import java.util.Map;

class fh extends fg {
   public static final <K, V> Map<K, V> nr() {
      fb var10000 = fb.sx;
      fR.m(var10000);
      return var10000;
   }

   public static final <K, V> Map<K, V> c(Map<? extends K, ? extends V> var0) {
      fR.c(var0, (String)"");
      Map var10000;
      switch (var0.size()) {
         case 0:
            var10000 = fe.nr();
            break;
         case 1:
            var10000 = fe.b(var0);
            break;
         default:
            var10000 = fe.d(var0);
      }

      return var10000;
   }

   public static final <K, V> Map<K, V> d(Map<? extends K, ? extends V> var0) {
      fR.c(var0, (String)"");
      return (Map)(new LinkedHashMap(var0));
   }
}
