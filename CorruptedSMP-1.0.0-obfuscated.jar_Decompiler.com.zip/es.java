class es {
   public static final void a(Throwable var0, Throwable var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (var0 != var1) {
         fE.sK.a(var0, var1);
      }

   }
}
