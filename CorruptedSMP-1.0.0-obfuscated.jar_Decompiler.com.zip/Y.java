public enum Y {
   DEFAULT {
   },
   STRING {
   };

   private Y() {
   }
}
