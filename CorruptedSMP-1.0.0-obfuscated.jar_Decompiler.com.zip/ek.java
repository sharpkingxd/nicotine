import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class ek implements Listener {
   private final CorruptedSMPPlugin rI;

   public ek(CorruptedSMPPlugin var1) {
      this.rI = var1;
   }

   @EventHandler
   public void a(ProjectileLaunchEvent var1) {
      ProjectileSource var3 = var1.getEntity().getShooter();
      if (var3 instanceof Player var2) {
         if (this.rI.d().b(var2)) {
            if (this.rI.d().c(var2) == l.B) {
               Vector var4 = var1.getEntity().getVelocity();
               var1.getEntity().setVelocity(var4.multiply((double)1.5F));
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = false
   )
   public void l(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof final Player var2) {
         if (this.rI.d().b(var2) && this.rI.d().c(var2) == l.B && var2.isSneaking()) {
            (new BukkitRunnable(this) {
               public void run() {
                  var2.setVelocity(new Vector((double)0.0F, var2.getVelocity().getY(), (double)0.0F));
               }
            }).runTaskLater(this.rI, 1L);
         }
      }

      var3 = var1.getDamager();
      if (var3 instanceof final Player var8) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof final Player var10) {
            if (this.rI.d().b(var8)) {
               if (this.rI.d().c(var8) == l.B) {
                  Material var11 = var8.getInventory().getItemInMainHand().getType();
                  D var5 = this.rI.f().g(var8.getUniqueId());
                  boolean var6 = var10.getInventory().getItemInMainHand().getType() == Material.SHIELD || var10.getInventory().getItemInOffHand().getType() == Material.SHIELD;
                  boolean var7 = var6 && (var10.isBlocking() || var1.getDamage() < (double)1.0F);
                  if (var7) {
                     if (!this.b(var11)) {
                        return;
                     }

                     var5.G();
                     if (var5.F() < 3) {
                        var8.sendMessage("§e§lSHIELD HIT STREAK: §f" + var5.F() + "§7/§f3");
                        var10.sendMessage("§c§lWARNING: §7Shield hit " + var5.F() + "/3 times!");
                     } else if (var5.F() == 3) {
                        (new BukkitRunnable(this) {
                           public void run() {
                              var10.setCooldown(Material.SHIELD, 300);
                              var8.sendMessage("§e§l⚡ EXTENDED STUN! §7Shield disabled for 15 seconds!");
                              var10.sendMessage("§c§l✗ Your shield has been stunned for 15 seconds!");
                              var10.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var10.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                              var10.playSound(var10.getLocation(), Sound.ITEM_SHIELD_BREAK, 1.0F, 0.8F);
                           }
                        }).runTaskLater(this.rI, 2L);
                        var5.H();
                     }
                  }

               }
            }
         }
      }
   }

   private boolean b(Material var1) {
      return var1.name().endsWith("_AXE");
   }

   @EventHandler
   public void f(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.getItem() != null && var1.getItem().getType() == Material.FEATHER) {
         if (this.rI.d().b(var2)) {
            if (this.rI.d().c(var2) == l.B) {
               var2.setVelocity(new Vector(0, 0, 0));
               var2.setFallDistance(0.0F);
               var2.sendMessage("§aVelocity reset!");
            }
         }
      }
   }
}
