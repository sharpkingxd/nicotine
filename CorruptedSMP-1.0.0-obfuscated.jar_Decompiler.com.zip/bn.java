import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

public interface bn {
   a hH = bn.a.$$INSTANCE;
   bn hI = new a.a();

   List<InetAddress> D(String var1) throws UnknownHostException;

   public static final class a {
      // $FF: synthetic field
      static final a $$INSTANCE = new a();

      private a() {
      }

      static final class a implements bn {
         public a() {
         }

         public List<InetAddress> D(String var1) {
            fR.c(var1, (String)"");

            try {
               InetAddress[] var10000 = InetAddress.getAllByName(var1);
               fR.b(var10000, "");
               return eI.g(var10000);
            } catch (NullPointerException var6) {
               UnknownHostException var3 = new UnknownHostException("Broken system behaviour for dns lookup of " + var1);
               boolean var5 = false;
               var3.initCause((Throwable)var6);
               throw (Throwable)var3;
            }
         }
      }
   }
}
