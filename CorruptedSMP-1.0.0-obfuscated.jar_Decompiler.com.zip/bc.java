import java.io.IOException;

public interface bc {
   void a(bb var1, IOException var2);

   void a(bb var1, by var2) throws IOException;
}
