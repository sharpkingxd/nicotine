import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class br {
   public static final b hQ = new b((fP)null);
   private final String hR;
   private final String hS;
   private final String hT;
   private final String host;
   private final int port;
   private final List<String> hU;
   private final List<String> hV;
   private final String hW;
   private final String hX;
   private final boolean hY;
   private static final char[] hZ;

   public br(String var1, String var2, String var3, String var4, int var5, List<String> var6, List<String> var7, String var8, String var9) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      fR.c(var6, (String)"");
      fR.c(var9, (String)"");
      super();
      this.hR = var1;
      this.hS = var2;
      this.hT = var3;
      this.host = var4;
      this.port = var5;
      this.hU = var6;
      this.hV = var7;
      this.hW = var8;
      this.hX = var9;
      this.hY = fR.c(this.hR, (Object)"https");
   }

   public final String cX() {
      return this.hR;
   }

   public final String cY() {
      return this.host;
   }

   public final int cZ() {
      return this.port;
   }

   public final boolean da() {
      return this.hY;
   }

   public final URL db() {
      try {
         return new URL(this.hX);
      } catch (MalformedURLException var2) {
         throw new RuntimeException((Throwable)var2);
      }
   }

   public final URI dc() {
      String var1 = this.dl().dp().toString();

      URI var2;
      try {
         var2 = new URI(var1);
      } catch (URISyntaxException var9) {
         URI var10;
         try {
            CharSequence var5 = (CharSequence)var1;
            gz var6 = new gz("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]");
            String var7 = "";
            String var4 = var6.a(var5, var7);
            var10 = URI.create(var4);
         } catch (Exception var8) {
            throw new RuntimeException((Throwable)var9);
         }

         fR.b(var10, "");
         var2 = var10;
      }

      return var2;
   }

   public final String dd() {
      if (((CharSequence)this.hS).length() == 0) {
         return "";
      } else {
         int var1 = this.hR.length() + 3;
         int var2 = bD.a(this.hX, ":@", var1, this.hX.length());
         String var10000 = this.hX.substring(var1, var2);
         fR.b(var10000, "");
         return var10000;
      }
   }

   public final String de() {
      if (((CharSequence)this.hT).length() == 0) {
         return "";
      } else {
         int var1 = gA.a((CharSequence)this.hX, ':', this.hR.length() + 3, false, 4, (Object)null) + 1;
         int var2 = gA.a((CharSequence)this.hX, '@', 0, false, 6, (Object)null);
         String var10000 = this.hX.substring(var1, var2);
         fR.b(var10000, "");
         return var10000;
      }
   }

   public final String df() {
      int var1 = gA.a((CharSequence)this.hX, '/', this.hR.length() + 3, false, 4, (Object)null);
      int var2 = bD.a(this.hX, "?#", var1, this.hX.length());
      String var10000 = this.hX.substring(var1, var2);
      fR.b(var10000, "");
      return var10000;
   }

   public final List<String> dg() {
      int var1 = gA.a((CharSequence)this.hX, '/', this.hR.length() + 3, false, 4, (Object)null);
      int var2 = bD.a(this.hX, "?#", var1, this.hX.length());
      List var3 = (List)(new ArrayList());

      int var5;
      for(int var4 = var1; var4 < var2; var4 = var5) {
         ++var4;
         var5 = bD.a(this.hX, '/', var4, var2);
         String var10001 = this.hX.substring(var4, var5);
         fR.b(var10001, "");
         var3.add(var10001);
      }

      return var3;
   }

   public final String dh() {
      if (this.hV == null) {
         return null;
      } else {
         int var1 = gA.a((CharSequence)this.hX, '?', 0, false, 6, (Object)null) + 1;
         int var2 = bD.a(this.hX, '#', var1, this.hX.length());
         String var10000 = this.hX.substring(var1, var2);
         fR.b(var10000, "");
         return var10000;
      }
   }

   public final String di() {
      if (this.hV == null) {
         return null;
      } else {
         StringBuilder var1 = new StringBuilder();
         hQ.b(this.hV, var1);
         return var1.toString();
      }
   }

   public final String dj() {
      if (this.hW == null) {
         return null;
      } else {
         int var1 = gA.a((CharSequence)this.hX, '#', 0, false, 6, (Object)null) + 1;
         String var10000 = this.hX.substring(var1);
         fR.b(var10000, "");
         return var10000;
      }
   }

   public final String dk() {
      a var10000 = this.L("/...");
      fR.m(var10000);
      return var10000.S("").T("").dq().toString();
   }

   public final br K(String var1) {
      fR.c(var1, (String)"");
      a var10000 = this.L(var1);
      return var10000 != null ? var10000.dq() : null;
   }

   public final a dl() {
      a var1 = new a();
      var1.M(this.hR);
      var1.N(this.dd());
      var1.O(this.de());
      var1.P(this.host);
      var1.l(this.port != hQ.Y(this.hR) ? this.port : -1);
      var1.dn().clear();
      var1.dn().addAll((Collection)this.dg());
      var1.V(this.dh());
      var1.Q(this.dj());
      return var1;
   }

   public final a L(String var1) {
      fR.c(var1, (String)"");

      a var2;
      try {
         var2 = (new a()).b(this, var1);
      } catch (IllegalArgumentException var4) {
         var2 = null;
      }

      return var2;
   }

   public boolean equals(Object var1) {
      return var1 instanceof br && fR.c(((br)var1).hX, (Object)this.hX);
   }

   public int hashCode() {
      return this.hX.hashCode();
   }

   public String toString() {
      return this.hX;
   }

   static {
      char[] var0 = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
      hZ = var0;
   }

   public static final class a {
      public static final a Companion = new a((fP)null);
      private String scheme;
      private String encodedUsername = "";
      private String encodedPassword = "";
      private String host;
      private int port = -1;
      private final List<String> encodedPathSegments = (List)(new ArrayList());
      private List<String> encodedQueryNamesAndValues;
      private String encodedFragment;
      public static final String INVALID_HOST = "Invalid URL host";

      public a() {
         this.encodedPathSegments.add("");
      }

      public final void M(String var1) {
         this.scheme = var1;
      }

      public final void N(String var1) {
         fR.c(var1, (String)"");
         this.encodedUsername = var1;
      }

      public final void O(String var1) {
         fR.c(var1, (String)"");
         this.encodedPassword = var1;
      }

      public final void P(String var1) {
         this.host = var1;
      }

      public final void l(int var1) {
         this.port = var1;
      }

      public final List<String> dn() {
         return this.encodedPathSegments;
      }

      public final void Q(String var1) {
         this.encodedFragment = var1;
      }

      public final a R(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         if (gA.a(var1, "http", true)) {
            var3.scheme = "http";
         } else {
            if (!gA.a(var1, "https", true)) {
               throw new IllegalArgumentException("unexpected scheme: " + var1);
            }

            var3.scheme = "https";
         }

         return this;
      }

      public final a S(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.encodedUsername = br.b.a(br.hQ, var1, 0, 0, " \"':;<=>@[]^`{}|/\\?#", false, false, false, false, (Charset)null, 251, (Object)null);
         return this;
      }

      public final a T(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.encodedPassword = br.b.a(br.hQ, var1, 0, 0, " \"':;<=>@[]^`{}|/\\?#", false, false, false, false, (Charset)null, 251, (Object)null);
         return this;
      }

      public final a U(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         String var10000 = bC.an(br.b.a(br.hQ, var1, 0, 0, false, 7, (Object)null));
         if (var10000 == null) {
            throw new IllegalArgumentException("unexpected host: " + var1);
         } else {
            String var5 = var10000;
            var3.host = var5;
            return this;
         }
      }

      public final a m(int var1) {
         a var3 = this;
         boolean var4 = false;
         if (!(1 <= var1 ? var1 < 65536 : false)) {
            boolean var5 = false;
            String var6 = "unexpected port: " + var1;
            throw new IllegalArgumentException(var6.toString());
         } else {
            var3.port = var1;
            return this;
         }
      }

      private final int do() {
         int var10000;
         if (this.port != -1) {
            var10000 = this.port;
         } else {
            b var1 = br.hQ;
            String var10001 = this.scheme;
            fR.m(var10001);
            var10000 = var1.Y(var10001);
         }

         return var10000;
      }

      public final a V(String var1) {
         a var3;
         List var10001;
         label12: {
            var3 = this;
            boolean var4 = false;
            if (var1 != null) {
               String var5 = br.b.a(br.hQ, var1, 0, 0, " \"'<>#", true, false, true, false, (Charset)null, 211, (Object)null);
               if (var5 != null) {
                  var10001 = br.hQ.Z(var5);
                  break label12;
               }
            }

            var10001 = null;
         }

         var3.encodedQueryNamesAndValues = var10001;
         return this;
      }

      public final a dp() {
         a var2 = this;
         boolean var3 = false;
         String var10001 = var2.host;
         if (var10001 != null) {
            CharSequence var4 = (CharSequence)var10001;
            gz var5 = new gz("[\"<>^`{|}]");
            String var6 = "";
            var10001 = var5.a(var4, var6);
         } else {
            var10001 = null;
         }

         var2.host = var10001;
         int var7 = 0;

         for(int var8 = var2.encodedPathSegments.size(); var7 < var8; ++var7) {
            var2.encodedPathSegments.set(var7, br.b.a(br.hQ, (String)var2.encodedPathSegments.get(var7), 0, 0, "[]", true, true, false, false, (Charset)null, 227, (Object)null));
         }

         List var11 = var2.encodedQueryNamesAndValues;
         if (var11 != null) {
            int var9 = 0;

            for(int var10 = var11.size(); var9 < var10; ++var9) {
               String var10002 = (String)var11.get(var9);
               var11.set(var9, var10002 != null ? br.b.a(br.hQ, var10002, 0, 0, "\\^`{|}", true, true, true, false, (Charset)null, 195, (Object)null) : null);
            }
         }

         var10001 = var2.encodedFragment;
         var2.encodedFragment = var10001 != null ? br.b.a(br.hQ, var10001, 0, 0, " \"#<>\\^`{|}", true, true, false, true, (Charset)null, 163, (Object)null) : null;
         return this;
      }

      public final br dq() {
         String var10000 = this.scheme;
         if (var10000 == null) {
            throw new IllegalStateException("scheme == null");
         } else {
            String var10001 = br.b.a(br.hQ, this.encodedUsername, 0, 0, false, 7, (Object)null);
            String var10002 = br.b.a(br.hQ, this.encodedPassword, 0, 0, false, 7, (Object)null);
            String var10003 = this.host;
            if (var10003 == null) {
               throw new IllegalStateException("host == null");
            } else {
               int var10004 = this.do();
               Iterable var1 = (Iterable)this.encodedPathSegments;
               int var15 = var10004;
               String var14 = var10003;
               String var13 = var10002;
               String var12 = var10001;
               String var11 = var10000;
               boolean var2 = false;
               Collection var4 = (Collection)(new ArrayList(eO.a(var1, 10)));
               boolean var5 = false;

               for(Object var7 : var1) {
                  String var8 = (String)var7;
                  boolean var9 = false;
                  var4.add(br.b.a(br.hQ, var8, 0, 0, false, 7, (Object)null));
               }

               List var16 = (List)var4;
               var10000 = var11;
               var10001 = var12;
               var10002 = var13;
               var10003 = var14;
               var10004 = var15;
               List var10005 = var16;
               List var10006 = this.encodedQueryNamesAndValues;
               if (var10006 != null) {
                  Iterable var27 = (Iterable)var10006;
                  boolean var3 = false;
                  Collection var28 = (Collection)(new ArrayList(eO.a(var27, 10)));
                  boolean var29 = false;

                  for(Object var31 : var27) {
                     String var32 = (String)var31;
                     boolean var10 = false;
                     var28.add(var32 != null ? br.b.a(br.hQ, var32, 0, 0, true, 3, (Object)null) : null);
                  }

                  List var17 = (List)var28;
                  var10000 = var11;
                  var10001 = var12;
                  var10002 = var13;
                  var10003 = var14;
                  var10004 = var15;
                  var10005 = var16;
                  var10006 = var17;
               } else {
                  var10006 = null;
               }

               String var10007 = this.encodedFragment;
               var10007 = var10007 != null ? br.b.a(br.hQ, var10007, 0, 0, false, 7, (Object)null) : null;
               String var18 = this.toString();
               String var19 = var10007;
               List var20 = var10006;
               List var21 = var10005;
               int var22 = var10004;
               String var23 = var10003;
               String var24 = var10002;
               String var25 = var10001;
               String var26 = var10000;
               return new br(var26, var25, var24, var23, var22, var21, var20, var19, var18);
            }
         }
      }

      public String toString() {
         StringBuilder var1 = new StringBuilder();
         boolean var3 = false;
         if (this.scheme != null) {
            var1.append(this.scheme);
            var1.append("://");
         } else {
            var1.append("//");
         }

         if (((CharSequence)this.encodedUsername).length() > 0 || ((CharSequence)this.encodedPassword).length() > 0) {
            var1.append(this.encodedUsername);
            if (((CharSequence)this.encodedPassword).length() > 0) {
               var1.append(':');
               var1.append(this.encodedPassword);
            }

            var1.append('@');
         }

         if (this.host != null) {
            String var10000 = this.host;
            fR.m(var10000);
            if (gA.a((CharSequence)var10000, ':', false, 2, (Object)null)) {
               var1.append('[');
               var1.append(this.host);
               var1.append(']');
            } else {
               var1.append(this.host);
            }
         }

         if (this.port != -1 || this.scheme != null) {
            label76: {
               int var4 = this.do();
               if (this.scheme != null) {
                  b var10001 = br.hQ;
                  String var10002 = this.scheme;
                  fR.m(var10002);
                  if (var4 == var10001.Y(var10002)) {
                     break label76;
                  }
               }

               var1.append(':');
               var1.append(var4);
            }
         }

         br.hQ.a(this.encodedPathSegments, var1);
         if (this.encodedQueryNamesAndValues != null) {
            var1.append('?');
            b var5 = br.hQ;
            List var7 = this.encodedQueryNamesAndValues;
            fR.m(var7);
            var5.b(var7, var1);
         }

         if (this.encodedFragment != null) {
            var1.append('#');
            var1.append(this.encodedFragment);
         }

         String var6 = var1.toString();
         fR.b(var6, "");
         return var6;
      }

      public final a b(br var1, String var2) {
         fR.c(var2, (String)"");
         int var3 = 0;
         var3 = bD.a(var2, 0, 0, 3, (Object)null);
         int var4 = bD.b(var2, var3, 0, 2, (Object)null);
         int var5 = Companion.d(var2, var3, var4);
         if (var5 != -1) {
            if (gA.a(var2, "https:", var3, true)) {
               this.scheme = "https";
               var3 += 6;
            } else {
               if (!gA.a(var2, "http:", var3, true)) {
                  StringBuilder var10002 = (new StringBuilder()).append("Expected URL scheme 'http' or 'https' but was '");
                  String var10003 = var2.substring(0, var5);
                  fR.b(var10003, "");
                  throw new IllegalArgumentException(var10002.append(var10003).append('\'').toString());
               }

               this.scheme = "http";
               var3 += 5;
            }
         } else {
            if (var1 == null) {
               String var17 = var2.length() > 6 ? gA.h(var2, 6) + "..." : var2;
               throw new IllegalArgumentException("Expected URL scheme 'http' or 'https' but no scheme was found for " + var17);
            }

            this.scheme = var1.cX();
         }

         boolean var6 = false;
         boolean var7 = false;
         int var8 = Companion.e(var2, var3, var4);
         if (var8 < 2 && var1 != null && fR.c(var1.cX(), (Object)this.scheme)) {
            this.encodedUsername = var1.dd();
            this.encodedPassword = var1.de();
            this.host = var1.cY();
            this.port = var1.cZ();
            this.encodedPathSegments.clear();
            this.encodedPathSegments.addAll((Collection)var1.dg());
            if (var3 == var4 || var2.charAt(var3) == '#') {
               this.V(var1.dh());
            }
         } else {
            var3 += var8;

            label94:
            while(true) {
               int var9 = bD.a(var2, "@/\\?#", var3, var4);
               int var10 = var9 != var4 ? var2.charAt(var9) : -1;
               switch (var10) {
                  case -1:
                  case 35:
                  case 47:
                  case 63:
                  case 92:
                     int var20 = Companion.f(var2, var3, var9);
                     if (var20 + 1 < var9) {
                        this.host = bC.an(br.b.a(br.hQ, var2, var3, var20, false, 4, (Object)null));
                        this.port = Companion.g(var2, var20 + 1, var9);
                        if (this.port == -1) {
                           boolean var13 = false;
                           StringBuilder var10000 = (new StringBuilder()).append("Invalid URL port: \"");
                           String var10001 = var2.substring(var20 + 1, var9);
                           fR.b(var10001, "");
                           String var21 = var10000.append(var10001).append('"').toString();
                           throw new IllegalArgumentException(var21.toString());
                        }
                     } else {
                        this.host = bC.an(br.b.a(br.hQ, var2, var3, var20, false, 4, (Object)null));
                        b var25 = br.hQ;
                        String var27 = this.scheme;
                        fR.m(var27);
                        this.port = var25.Y(var27);
                     }

                     if (this.host == null) {
                        boolean var22 = false;
                        StringBuilder var24 = (new StringBuilder()).append("Invalid URL host: \"");
                        String var26 = var2.substring(var3, var20);
                        fR.b(var26, "");
                        String var23 = var24.append(var26).append('"').toString();
                        throw new IllegalArgumentException(var23.toString());
                     }

                     var3 = var9;
                     break label94;
                  case 64:
                     if (!var7) {
                        int var11 = bD.a(var2, ':', var3, var9);
                        String var12 = br.b.a(br.hQ, var2, var3, var11, " \"':;<=>@[]^`{}|/\\?#", true, false, false, false, (Charset)null, 240, (Object)null);
                        this.encodedUsername = var6 ? this.encodedUsername + "%40" + var12 : var12;
                        if (var11 != var9) {
                           var7 = true;
                           this.encodedPassword = br.b.a(br.hQ, var2, var11 + 1, var9, " \"':;<=>@[]^`{}|/\\?#", true, false, false, false, (Charset)null, 240, (Object)null);
                        }

                        var6 = true;
                     } else {
                        this.encodedPassword = this.encodedPassword + "%40" + br.b.a(br.hQ, var2, var3, var9, " \"':;<=>@[]^`{}|/\\?#", true, false, false, false, (Charset)null, 240, (Object)null);
                     }

                     var3 = var9 + 1;
               }
            }
         }

         int var18 = bD.a(var2, "?#", var3, var4);
         this.c(var2, var3, var18);
         var3 = var18;
         if (var18 < var4 && var2.charAt(var18) == '?') {
            int var19 = bD.a(var2, '#', var18, var4);
            this.encodedQueryNamesAndValues = br.hQ.Z(br.b.a(br.hQ, var2, var18 + 1, var19, " \"'<>#", true, false, true, false, (Charset)null, 208, (Object)null));
            var3 = var19;
         }

         if (var3 < var4 && var2.charAt(var3) == '#') {
            this.encodedFragment = br.b.a(br.hQ, var2, var3 + 1, var4, "", true, false, false, true, (Charset)null, 176, (Object)null);
         }

         return this;
      }

      private final void c(String var1, int var2, int var3) {
         int var4 = var2;
         if (var2 != var3) {
            char var5 = var1.charAt(var2);
            if (var5 != '/' && var5 != '\\') {
               this.encodedPathSegments.set(this.encodedPathSegments.size() - 1, "");
            } else {
               this.encodedPathSegments.clear();
               this.encodedPathSegments.add("");
               var4 = var2 + 1;
            }

            int var6 = var4;

            while(var6 < var3) {
               int var7 = bD.a(var1, "/\\", var6, var3);
               boolean var8 = var7 < var3;
               this.a(var1, var6, var7, var8, true);
               var6 = var7;
               if (var8) {
                  var6 = var7 + 1;
               }
            }

         }
      }

      private final void a(String var1, int var2, int var3, boolean var4, boolean var5) {
         String var6 = br.b.a(br.hQ, var1, var2, var3, " \"<>^`{}|/\\?#", var5, false, false, false, (Charset)null, 240, (Object)null);
         if (!this.W(var6)) {
            if (this.X(var6)) {
               this.dr();
            } else {
               if (((CharSequence)this.encodedPathSegments.get(this.encodedPathSegments.size() - 1)).length() == 0) {
                  this.encodedPathSegments.set(this.encodedPathSegments.size() - 1, var6);
               } else {
                  this.encodedPathSegments.add(var6);
               }

               if (var4) {
                  this.encodedPathSegments.add("");
               }

            }
         }
      }

      private final boolean W(String var1) {
         return fR.c(var1, (Object)".") || gA.a(var1, "%2e", true);
      }

      private final boolean X(String var1) {
         return fR.c(var1, (Object)"..") || gA.a(var1, "%2e.", true) || gA.a(var1, ".%2e", true) || gA.a(var1, "%2e%2e", true);
      }

      private final void dr() {
         String var1 = (String)this.encodedPathSegments.remove(this.encodedPathSegments.size() - 1);
         if (((CharSequence)var1).length() == 0 && !((Collection)this.encodedPathSegments).isEmpty()) {
            this.encodedPathSegments.set(this.encodedPathSegments.size() - 1, "");
         } else {
            this.encodedPathSegments.add("");
         }

      }

      public static final class a {
         private a() {
         }

         private final int d(String var1, int var2, int var3) {
            if (var3 - var2 < 2) {
               return -1;
            } else {
               char var4 = var1.charAt(var2);
               if (fR.j(var4, 97) >= 0 && fR.j(var4, 122) <= 0 || fR.j(var4, 65) >= 0 && fR.j(var4, 90) <= 0) {
                  for(int var5 = var2 + 1; var5 < var3; ++var5) {
                     char var6 = var1.charAt(var5);
                     if (!(((((('a' <= var6 ? var6 < '{' : false) ? true : ('A' <= var6 ? var6 < '[' : false)) ? true : ('0' <= var6 ? var6 < ':' : false)) ? true : var6 == '+') ? true : var6 == '-') ? true : var6 == '.')) {
                        return var6 == ':' ? var5 : -1;
                     }
                  }

                  return -1;
               } else {
                  return -1;
               }
            }
         }

         private final int e(String var1, int var2, int var3) {
            int var4 = 0;

            for(int var5 = var2; var5 < var3; ++var5) {
               char var6 = var1.charAt(var5);
               if (var6 != '\\' && var6 != '/') {
                  break;
               }

               ++var4;
            }

            return var4;
         }

         private final int f(String var1, int var2, int var3) {
            for(int var4 = var2; var4 < var3; ++var4) {
               char var5 = var1.charAt(var4);
               if (var5 == '[') {
                  while(true) {
                     ++var4;
                     if (var4 >= var3 || var1.charAt(var4) == ']') {
                        break;
                     }
                  }
               } else if (var5 == ':') {
                  return var4;
               }
            }

            return var3;
         }

         private final int g(String var1, int var2, int var3) {
            int var4;
            try {
               String var7 = br.b.a(br.hQ, var1, var2, var3, "", false, false, false, false, (Charset)null, 248, (Object)null);
               int var5 = Integer.parseInt(var7);
               var4 = (1 <= var5 ? var5 < 65536 : false) ? var5 : -1;
            } catch (NumberFormatException var6) {
               var4 = -1;
            }

            return var4;
         }

         // $FF: synthetic method
         public a(fP var1) {
            this();
         }
      }
   }

   public static final class b {
      private b() {
      }

      public final int Y(String var1) {
         fR.c(var1, (String)"");
         return fR.c(var1, (Object)"http") ? 80 : (fR.c(var1, (Object)"https") ? 443 : -1);
      }

      public final void a(List<String> var1, StringBuilder var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         int var3 = 0;

         for(int var4 = var1.size(); var3 < var4; ++var3) {
            var2.append('/');
            var2.append((String)var1.get(var3));
         }

      }

      public final void b(List<String> var1, StringBuilder var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         gd var3 = gg.a(gg.l(0, var1.size()), 2);
         int var4 = var3.nC();
         int var5 = var3.nD();
         int var6 = var3.nE();
         if (var6 > 0 && var4 <= var5 || var6 < 0 && var5 <= var4) {
            while(true) {
               String var7 = (String)var1.get(var4);
               String var8 = (String)var1.get(var4 + 1);
               if (var4 > 0) {
                  var2.append('&');
               }

               var2.append(var7);
               if (var8 != null) {
                  var2.append('=');
                  var2.append(var8);
               }

               if (var4 == var5) {
                  break;
               }

               var4 += var6;
            }
         }

      }

      public final List<String> Z(String var1) {
         fR.c(var1, (String)"");
         List var2 = (List)(new ArrayList());

         int var4;
         for(int var3 = 0; var3 <= var1.length(); var3 = var4 + 1) {
            var4 = gA.a((CharSequence)var1, '&', var3, false, 4, (Object)null);
            if (var4 == -1) {
               var4 = var1.length();
            }

            int var5 = gA.a((CharSequence)var1, '=', var3, false, 4, (Object)null);
            if (var5 != -1 && var5 <= var4) {
               String var6 = var1.substring(var3, var5);
               fR.b(var6, "");
               var2.add(var6);
               var6 = var1.substring(var5 + 1, var4);
               fR.b(var6, "");
               var2.add(var6);
            } else {
               String var10001 = var1.substring(var3, var4);
               fR.b(var10001, "");
               var2.add(var10001);
               var2.add((Object)null);
            }
         }

         return var2;
      }

      public final br aa(String var1) {
         fR.c(var1, (String)"");
         return (new a()).b((br)null, var1).dq();
      }

      public final br ab(String var1) {
         fR.c(var1, (String)"");

         br var2;
         try {
            var2 = this.aa(var1);
         } catch (IllegalArgumentException var4) {
            var2 = null;
         }

         return var2;
      }

      public final String b(String var1, int var2, int var3, boolean var4) {
         fR.c(var1, (String)"");

         for(int var5 = var2; var5 < var3; ++var5) {
            char var6 = var1.charAt(var5);
            if (var6 == '%' || var6 == '+' && var4) {
               de var7 = new de();
               var7.m(var1, var2, var5);
               this.a(var7, var1, var5, var3, var4);
               return var7.kU();
            }
         }

         String var10000 = var1.substring(var2, var3);
         fR.b(var10000, "");
         return var10000;
      }

      // $FF: synthetic method
      public static String a(b var0, String var1, int var2, int var3, boolean var4, int var5, Object var6) {
         if ((var5 & 1) != 0) {
            var2 = 0;
         }

         if ((var5 & 2) != 0) {
            var3 = var1.length();
         }

         if ((var5 & 4) != 0) {
            var4 = false;
         }

         return var0.b(var1, var2, var3, var4);
      }

      private final void a(de var1, String var2, int var3, int var4, boolean var5) {
         int var6 = 0;
         int var7 = var3;

         while(var7 < var4) {
            var6 = var2.codePointAt(var7);
            if (var6 == 37 && var7 + 2 < var4) {
               int var8 = bD.d(var2.charAt(var7 + 1));
               int var9 = bD.d(var2.charAt(var7 + 2));
               if (var8 != -1 && var9 != -1) {
                  var1.V((var8 << 4) + var9);
                  var7 += 2;
                  var7 += Character.charCount(var6);
                  continue;
               }
            } else if (var6 == 43 && var5) {
               var1.V(32);
               ++var7;
               continue;
            }

            var1.U(var6);
            var7 += Character.charCount(var6);
         }

      }

      private final boolean h(String var1, int var2, int var3) {
         return var2 + 2 < var3 && var1.charAt(var2) == '%' && bD.d(var1.charAt(var2 + 1)) != -1 && bD.d(var1.charAt(var2 + 2)) != -1;
      }

      public final String a(String var1, int var2, int var3, String var4, boolean var5, boolean var6, boolean var7, boolean var8, Charset var9) {
         fR.c(var1, (String)"");
         fR.c(var4, (String)"");
         int var10 = 0;

         for(int var11 = var2; var11 < var3; var11 += Character.charCount(var10)) {
            var10 = var1.codePointAt(var11);
            if (var10 < 32 || var10 == 127 || var10 >= 128 && !var8 || gA.a((CharSequence)var4, (char)var10, false, 2, (Object)null) || var10 == 37 && (!var5 || var6 && !this.h(var1, var11, var3)) || var10 == 43 && var7) {
               de var12 = new de();
               var12.m(var1, var2, var11);
               this.a(var12, var1, var11, var3, var4, var5, var6, var7, var8, var9);
               return var12.kU();
            }
         }

         String var10000 = var1.substring(var2, var3);
         fR.b(var10000, "");
         return var10000;
      }

      // $FF: synthetic method
      public static String a(b var0, String var1, int var2, int var3, String var4, boolean var5, boolean var6, boolean var7, boolean var8, Charset var9, int var10, Object var11) {
         if ((var10 & 1) != 0) {
            var2 = 0;
         }

         if ((var10 & 2) != 0) {
            var3 = var1.length();
         }

         if ((var10 & 8) != 0) {
            var5 = false;
         }

         if ((var10 & 16) != 0) {
            var6 = false;
         }

         if ((var10 & 32) != 0) {
            var7 = false;
         }

         if ((var10 & 64) != 0) {
            var8 = false;
         }

         if ((var10 & 128) != 0) {
            var9 = null;
         }

         return var0.a(var1, var2, var3, var4, var5, var6, var7, var8, var9);
      }

      private final void a(de var1, String var2, int var3, int var4, String var5, boolean var6, boolean var7, boolean var8, boolean var9, Charset var10) {
         de var11 = null;
         int var12 = 0;

         for(int var13 = var3; var13 < var4; var13 += Character.charCount(var12)) {
            var12 = var2.codePointAt(var13);
            if (!var6 || var12 != 9 && var12 != 10 && var12 != 12 && var12 != 13) {
               if (var12 == 43 && var8) {
                  var1.aQ(var6 ? "+" : "%2B");
               } else if (var12 < 32 || var12 == 127 || var12 >= 128 && !var9 || gA.a((CharSequence)var5, (char)var12, false, 2, (Object)null) || var12 == 37 && (!var6 || var7 && !this.h(var2, var13, var4))) {
                  if (var11 == null) {
                     var11 = new de();
                  }

                  if (var10 != null && !fR.c(var10, (Object)StandardCharsets.UTF_8)) {
                     var11.a(var2, var13, var13 + Character.charCount(var12), var10);
                  } else {
                     var11.U(var12);
                  }

                  while(!var11.kK()) {
                     int var14 = var11.kN() & 255;
                     var1.V(37);
                     var1.V(br.hZ[var14 >> 4 & 15]);
                     var1.V(br.hZ[var14 & 15]);
                  }
               } else {
                  var1.U(var12);
               }
            }
         }

      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }
}
