import java.lang.reflect.Type;

public interface O<T> {
   T a(P var1, Type var2, N var3) throws T;
}
