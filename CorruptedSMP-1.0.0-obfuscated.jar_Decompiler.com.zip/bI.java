import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.Flushable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class bI implements Closeable, Flushable {
   public static final a jv = new a((fP)null);
   private final cz jw;
   private final File jx;
   private final int jy;
   private final int jz;
   private long jA;
   private final File jB;
   private final File jC;
   private final File jD;
   private long jE;
   private df jF;
   private final LinkedHashMap<String, c> jG;
   private int jH;
   private boolean jI;
   private boolean jJ;
   private boolean jK;
   private boolean closed;
   private boolean jL;
   private boolean jM;
   private long jN;
   private final bM jO;
   private final <undefinedtype> jP;
   public static final String jQ = "journal";
   public static final String jR = "journal.tmp";
   public static final String jS = "journal.bkp";
   public static final String jT = "libcore.io.DiskLruCache";
   public static final String jU = "1";
   public static final long jV = -1L;
   public static final gz jW = new gz("[a-z0-9_-]{1,120}");
   public static final String jX = "CLEAN";
   public static final String jY = "DIRTY";
   public static final String jZ = "REMOVE";
   public static final String ka = "READ";

   public final cz fC() {
      return this.jw;
   }

   public final File fD() {
      return this.jx;
   }

   public final int fE() {
      return this.jz;
   }

   public final boolean fF() {
      return this.closed;
   }

   public final synchronized void fG() throws IOException {
      boolean var2 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else if (!this.jK) {
         if (this.jw.e(this.jD)) {
            if (this.jw.e(this.jB)) {
               this.jw.d(this.jD);
            } else {
               this.jw.a(this.jD, this.jB);
            }
         }

         this.jJ = bD.a(this.jw, this.jD);
         if (this.jw.e(this.jB)) {
            try {
               this.fH();
               this.fJ();
               this.jK = true;
               return;
            } catch (IOException var6) {
               cH.oU.jZ().a("DiskLruCache " + this.jx + " is corrupt: " + var6.getMessage() + ", removing", 5, (Throwable)var6);

               try {
                  this.fP();
               } finally {
                  this.closed = false;
               }
            }
         }

         this.fK();
         this.jK = true;
      }
   }

   private final void fH() throws IOException {
      Closeable var1 = do.c(this.jw.a(this.jB));
      Throwable var2 = null;

      try {
         dg var3 = (dg)var1;
         boolean var4 = false;
         String var5 = var3.kV();
         String var6 = var3.kV();
         String var7 = var3.kV();
         String var8 = var3.kV();
         String var9 = var3.kV();
         if (!fR.c(jT, (Object)var5) || !fR.c(jU, (Object)var6) || !fR.c(String.valueOf(this.jy), (Object)var7) || !fR.c(String.valueOf(this.jz), (Object)var8) || ((CharSequence)var9).length() > 0) {
            throw new IOException("unexpected journal header: [" + var5 + ", " + var6 + ", " + var8 + ", " + var9 + ']');
         }

         int var10 = 0;

         while(true) {
            try {
               this.au(var3.kV());
               ++var10;
            } catch (EOFException var15) {
               this.jH = var10 - this.jG.size();
               if (!var3.kK()) {
                  this.fK();
                  break;
               }

               this.jF = this.fI();
               break;
            }
         }

         eE var18 = eE.sk;
      } catch (Throwable var16) {
         var2 = var16;
         throw var16;
      } finally {
         fI.a(var1, var2);
      }

   }

   private final df fI() throws FileNotFoundException {
      dy var1 = this.jw.c(this.jB);
      bJ var2 = new bJ(var1, new fK<IOException, eE>() {
         public final void b(IOException var1) {
            fR.c(var1, (String)"");
            bI var2 = bI.this;
            boolean var3 = false;
            if (bD.jn && !Thread.holdsLock(var2)) {
               throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var2);
            } else {
               bI.this.jI = true;
            }
         }

         // $FF: synthetic method
         public Object invoke(Object var1) {
            this.b((IOException)var1);
            return eE.sk;
         }
      });
      return do.b(var2);
   }

   private final void au(String var1) throws IOException {
      int var2 = gA.a((CharSequence)var1, ' ', 0, false, 6, (Object)null);
      if (var2 == -1) {
         throw new IOException("unexpected journal line: " + var1);
      } else {
         int var3 = var2 + 1;
         int var4 = gA.a((CharSequence)var1, ' ', var3, false, 4, (Object)null);
         String var5 = null;
         if (var4 == -1) {
            String var10000 = var1.substring(var3);
            fR.b(var10000, "");
            var5 = var10000;
            if (var2 == jZ.length() && gA.a(var1, jZ, false, 2, (Object)null)) {
               this.jG.remove(var5);
               return;
            }
         } else {
            String var10 = var1.substring(var3, var4);
            fR.b(var10, "");
            var5 = var10;
         }

         c var6 = (c)this.jG.get(var5);
         if (var6 == null) {
            var6 = new c(var5);
            ((Map)this.jG).put(var5, var6);
         }

         if (var4 != -1 && var2 == jX.length() && gA.a(var1, jX, false, 2, (Object)null)) {
            String var11 = var1.substring(var4 + 1);
            fR.b(var11, "");
            CharSequence var12 = (CharSequence)var11;
            char[] var8 = new char[]{' '};
            List var7 = gA.a(var12, var8, false, 0, 6, (Object)null);
            var6.o(true);
            var6.c((b)null);
            var6.c(var7);
         } else if (var4 == -1 && var2 == jY.length() && gA.a(var1, jY, false, 2, (Object)null)) {
            var6.c(new b(var6));
         } else if (var4 != -1 || var2 != ka.length() || !gA.a(var1, ka, false, 2, (Object)null)) {
            throw new IOException("unexpected journal line: " + var1);
         }

      }
   }

   private final void fJ() throws IOException {
      this.jw.d(this.jC);
      Iterator var1 = this.jG.values().iterator();

      while(var1.hasNext()) {
         Object var10000 = var1.next();
         fR.b(var10000, "");
         c var2 = (c)var10000;
         if (var2.gb() == null) {
            int var5 = 0;

            for(int var6 = this.jz; var5 < var6; ++var5) {
               this.jE += var2.fW()[var5];
            }
         } else {
            var2.c((b)null);
            int var3 = 0;

            for(int var4 = this.jz; var3 < var4; ++var3) {
               this.jw.d((File)var2.fX().get(var3));
               this.jw.d((File)var2.fY().get(var3));
            }

            var1.remove();
         }
      }

   }

   public final synchronized void fK() throws IOException {
      df var10000 = this.jF;
      if (var10000 != null) {
         var10000.close();
      }

      Closeable var1 = do.b(this.jw.b(this.jC));
      Throwable var2 = null;

      try {
         df var3 = (df)var1;
         boolean var4 = false;
         var3.aR(jT).aa(10);
         var3.aR(jU).aa(10);
         var3.D((long)this.jy).aa(10);
         var3.D((long)this.jz).aa(10);
         var3.aa(10);

         for(c var6 : this.jG.values()) {
            if (var6.gb() != null) {
               var3.aR(jY).aa(32);
               var3.aR(var6.fV());
               var3.aa(10);
            } else {
               var3.aR(jX).aa(32);
               var3.aR(var6.fV());
               var6.b(var3);
               var3.aa(10);
            }
         }

         eE var11 = eE.sk;
      } catch (Throwable var9) {
         var2 = var9;
         throw var9;
      } finally {
         fI.a(var1, var2);
      }

      if (this.jw.e(this.jB)) {
         this.jw.a(this.jB, this.jD);
      }

      this.jw.a(this.jC, this.jB);
      this.jw.d(this.jD);
      this.jF = this.fI();
      this.jI = false;
      this.jM = false;
   }

   public final synchronized d av(String var1) throws IOException {
      fR.c(var1, (String)"");
      this.fG();
      this.fM();
      this.ax(var1);
      c var10000 = (c)this.jG.get(var1);
      if (var10000 == null) {
         return null;
      } else {
         c var2 = var10000;
         d var5 = var2.ge();
         if (var5 == null) {
            return null;
         } else {
            d var3 = var5;
            int var4 = this.jH++;
            df var6 = this.jF;
            fR.m(var6);
            var6.aR(ka).aa(32).aR(var1).aa(10);
            if (this.fL()) {
               bM.a(this.jO, this.jP, 0L, 2, (Object)null);
            }

            return var3;
         }
      }
   }

   public final synchronized b b(String var1, long var2) throws IOException {
      fR.c(var1, (String)"");
      this.fG();
      this.fM();
      this.ax(var1);
      c var4 = (c)this.jG.get(var1);
      if (var2 == jV || var4 != null && var4.gd() == var2) {
         if ((var4 != null ? var4.gb() : null) != null) {
            return null;
         } else if (var4 != null && var4.gc() != 0) {
            return null;
         } else if (!this.jL && !this.jM) {
            df var10000 = this.jF;
            fR.m(var10000);
            df var5 = var10000;
            var5.aR(jY).aa(32).aR(var1).aa(10);
            var5.flush();
            if (this.jI) {
               return null;
            } else {
               if (var4 == null) {
                  var4 = new c(var1);
                  ((Map)this.jG).put(var1, var4);
               }

               b var6 = new b(var4);
               var4.c(var6);
               return var6;
            }
         } else {
            bM.a(this.jO, this.jP, 0L, 2, (Object)null);
            return null;
         }
      } else {
         return null;
      }
   }

   // $FF: synthetic method
   public static b a(bI var0, String var1, long var2, int var4, Object var5) throws IOException {
      if ((var4 & 2) != 0) {
         var2 = jV;
      }

      return var0.b(var1, var2);
   }

   public final synchronized void a(b var1, boolean var2) throws IOException {
      fR.c(var1, (String)"");
      c var3 = var1.fQ();
      if (!fR.c(var3.gb(), (Object)var1)) {
         String var16 = "Check failed.";
         throw new IllegalStateException(var16.toString());
      } else {
         if (var2 && !var3.fZ()) {
            int var4 = 0;

            for(int var5 = this.jz; var4 < var5; ++var4) {
               boolean[] var10000 = var1.fR();
               fR.m(var10000);
               if (!var10000[var4]) {
                  var1.fU();
                  throw new IllegalStateException("Newly created entry didn't create value for index " + var4);
               }

               if (!this.jw.e((File)var3.fY().get(var4))) {
                  var1.fU();
                  return;
               }
            }
         }

         int var12 = 0;

         for(int var15 = this.jz; var12 < var15; ++var12) {
            File var6 = (File)var3.fY().get(var12);
            if (var2 && !var3.ga()) {
               if (this.jw.e(var6)) {
                  File var7 = (File)var3.fX().get(var12);
                  this.jw.a(var6, var7);
                  long var8 = var3.fW()[var12];
                  long var10 = this.jw.f(var7);
                  var3.fW()[var12] = var10;
                  this.jE = this.jE - var8 + var10;
               }
            } else {
               this.jw.d(var6);
            }
         }

         var3.c((b)null);
         if (var3.ga()) {
            this.a(var3);
         } else {
            var12 = this.jH++;
            df var19 = this.jF;
            fR.m(var19);
            df var14 = var19;
            boolean var17 = false;
            if (!var3.fZ() && !var2) {
               this.jG.remove(var3.fV());
               var14.aR(jZ).aa(32);
               var14.aR(var3.fV());
               var14.aa(10);
            } else {
               var3.o(true);
               var14.aR(jX).aa(32);
               var14.aR(var3.fV());
               var3.b(var14);
               var14.aa(10);
               if (var2) {
                  long var18 = (long)(this.jN++);
                  var3.f(var18);
               }
            }

            var14.flush();
            if (this.jE > this.jA || this.fL()) {
               bM.a(this.jO, this.jP, 0L, 2, (Object)null);
            }

         }
      }
   }

   private final boolean fL() {
      short var1 = 2000;
      return this.jH >= var1 && this.jH >= this.jG.size();
   }

   public final synchronized boolean aw(String var1) throws IOException {
      fR.c(var1, (String)"");
      this.fG();
      this.fM();
      this.ax(var1);
      c var10000 = (c)this.jG.get(var1);
      if (var10000 == null) {
         return false;
      } else {
         c var2 = var10000;
         boolean var3 = this.a(var2);
         if (var3 && this.jE <= this.jA) {
            this.jL = false;
         }

         return var3;
      }
   }

   public final boolean a(c var1) throws IOException {
      fR.c(var1, (String)"");
      if (!this.jJ) {
         if (var1.gc() > 0) {
            df var10000 = this.jF;
            if (var10000 != null) {
               df var4 = var10000;
               boolean var5 = false;
               var4.aR(jY);
               var4.aa(32);
               var4.aR(var1.fV());
               var4.aa(10);
               var4.flush();
            }
         }

         if (var1.gc() > 0 || var1.gb() != null) {
            var1.p(true);
            return true;
         }
      }

      b var9 = var1.gb();
      if (var9 != null) {
         var9.fS();
      }

      int var2 = 0;

      for(int var3 = this.jz; var2 < var3; ++var2) {
         this.jw.d((File)var1.fX().get(var2));
         this.jE -= var1.fW()[var2];
         var1.fW()[var2] = 0L;
      }

      var2 = this.jH++;
      df var10 = this.jF;
      if (var10 != null) {
         df var7 = var10;
         boolean var8 = false;
         var7.aR(jZ);
         var7.aa(32);
         var7.aR(var1.fV());
         var7.aa(10);
      }

      this.jG.remove(var1.fV());
      if (this.fL()) {
         bM.a(this.jO, this.jP, 0L, 2, (Object)null);
      }

      return true;
   }

   private final synchronized void fM() {
      if (this.closed) {
         boolean var1 = false;
         String var2 = "cache is closed";
         throw new IllegalStateException(var2.toString());
      }
   }

   public synchronized void flush() throws IOException {
      if (this.jK) {
         this.fM();
         this.fN();
         df var10000 = this.jF;
         fR.m(var10000);
         var10000.flush();
      }
   }

   public synchronized void close() throws IOException {
      if (this.jK && !this.closed) {
         Collection var10000 = this.jG.values();
         fR.b(var10000, "");
         Collection var2 = var10000;
         boolean var3 = false;
         c[] var1 = (c[])var2.toArray(new c[0]);
         int var5 = 0;

         for(int var6 = var1.length; var5 < var6; ++var5) {
            c var4 = var1[var5];
            if (var4.gb() != null) {
               b var7 = var4.gb();
               if (var7 != null) {
                  var7.fS();
               }
            }
         }

         this.fN();
         df var8 = this.jF;
         fR.m(var8);
         var8.close();
         this.jF = null;
         this.closed = true;
      } else {
         this.closed = true;
      }
   }

   public final void fN() throws IOException {
      while(true) {
         if (this.jE > this.jA) {
            if (this.fO()) {
               continue;
            }

            return;
         }

         this.jL = false;
         return;
      }
   }

   private final boolean fO() {
      for(c var2 : this.jG.values()) {
         if (!var2.ga()) {
            fR.b(var2, "");
            this.a(var2);
            return true;
         }
      }

      return false;
   }

   public final void fP() throws IOException {
      this.close();
      this.jw.g(this.jx);
   }

   private final void ax(String var1) {
      if (!jW.a((CharSequence)var1)) {
         boolean var2 = false;
         String var3 = "keys must match regex [a-z0-9_-]{1,120}: \"" + var1 + '"';
         throw new IllegalArgumentException(var3.toString());
      }
   }

   // $FF: synthetic method
   public static final boolean b(bI var0) {
      return var0.jK;
   }

   // $FF: synthetic method
   public static final void b(bI var0, boolean var1) {
      var0.jL = var1;
   }

   // $FF: synthetic method
   public static final boolean c(bI var0) {
      return var0.fL();
   }

   // $FF: synthetic method
   public static final void a(bI var0, int var1) {
      var0.jH = var1;
   }

   // $FF: synthetic method
   public static final void c(bI var0, boolean var1) {
      var0.jM = var1;
   }

   // $FF: synthetic method
   public static final void a(bI var0, df var1) {
      var0.jF = var1;
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public final class b {
      private final c entry;
      private final boolean[] written;
      private boolean done;

      public b(c var2) {
         fR.c(var2, (String)"");
         super();
         this.entry = var2;
         this.written = this.entry.fZ() ? null : new boolean[bI.this.fE()];
      }

      public final c fQ() {
         return this.entry;
      }

      public final boolean[] fR() {
         return this.written;
      }

      public final void fS() {
         if (fR.c(this.entry.gb(), (Object)this)) {
            if (bI.this.jJ) {
               bI.this.a(this, false);
            } else {
               this.entry.p(true);
            }
         }

      }

      public final dy o(int var1) {
         bI var2 = bI.this;
         final bI var3 = bI.this;
         synchronized(var2){}

         dy var11;
         try {
            boolean var5 = false;
            if (this.done) {
               String var17 = "Check failed.";
               throw new IllegalStateException(var17.toString());
            }

            if (fR.c(this.entry.gb(), (Object)this)) {
               if (!this.entry.fZ()) {
                  boolean[] var10000 = this.written;
                  fR.m(var10000);
                  var10000[var1] = true;
               }

               File var7 = (File)this.entry.fY().get(var1);
               Object var6 = null;

               try {
                  var16 = var3.fC().b(var7);
               } catch (FileNotFoundException var14) {
                  dy var10 = do.lC();
                  return var10;
               }

               dy var9 = new bJ(var16, new fK<IOException, eE>() {
                  public final void a(IOException var1) {
                     fR.c(var1, (String)"");
                     bI var2 = var3;
                     b var3x = b.this;
                     synchronized(var2) {
                        boolean var5 = false;
                        var3x.fS();
                        eE var7 = eE.sk;
                     }
                  }

                  // $FF: synthetic method
                  public Object invoke(Object var1) {
                     this.a((IOException)var1);
                     return eE.sk;
                  }
               });
               return var9;
            }

            var11 = do.lC();
         } finally {
            ;
         }

         return var11;
      }

      public final void fT() throws IOException {
         bI var1 = bI.this;
         bI var2 = bI.this;
         synchronized(var1){}

         try {
            boolean var4 = false;
            if (this.done) {
               String var5 = "Check failed.";
               throw new IllegalStateException(var5.toString());
            }

            if (fR.c(this.entry.gb(), (Object)this)) {
               var2.a(this, true);
            }

            this.done = true;
            eE var8 = eE.sk;
         } finally {
            ;
         }

      }

      public final void fU() throws IOException {
         bI var1 = bI.this;
         bI var2 = bI.this;
         synchronized(var1){}

         try {
            boolean var4 = false;
            if (this.done) {
               String var5 = "Check failed.";
               throw new IllegalStateException(var5.toString());
            }

            if (fR.c(this.entry.gb(), (Object)this)) {
               var2.a(this, false);
            }

            this.done = true;
            eE var8 = eE.sk;
         } finally {
            ;
         }

      }
   }

   public final class c {
      private final String key;
      private final long[] lengths;
      private final List<File> cleanFiles;
      private final List<File> dirtyFiles;
      private boolean readable;
      private boolean zombie;
      private b currentEditor;
      private int lockingSourceCount;
      private long sequenceNumber;

      public c(String var2) {
         fR.c(var2, (String)"");
         super();
         this.key = var2;
         this.lengths = new long[bI.this.fE()];
         this.cleanFiles = (List)(new ArrayList());
         this.dirtyFiles = (List)(new ArrayList());
         StringBuilder var3 = (new StringBuilder(this.key)).append('.');
         int var4 = var3.length();
         int var5 = 0;

         for(int var6 = bI.this.fE(); var5 < var6; ++var5) {
            var3.append(var5);
            ((Collection)this.cleanFiles).add(new File(bI.this.fD(), var3.toString()));
            var3.append(".tmp");
            ((Collection)this.dirtyFiles).add(new File(bI.this.fD(), var3.toString()));
            var3.setLength(var4);
         }

      }

      public final String fV() {
         return this.key;
      }

      public final long[] fW() {
         return this.lengths;
      }

      public final List<File> fX() {
         return this.cleanFiles;
      }

      public final List<File> fY() {
         return this.dirtyFiles;
      }

      public final boolean fZ() {
         return this.readable;
      }

      public final void o(boolean var1) {
         this.readable = var1;
      }

      public final boolean ga() {
         return this.zombie;
      }

      public final void p(boolean var1) {
         this.zombie = var1;
      }

      public final b gb() {
         return this.currentEditor;
      }

      public final void c(b var1) {
         this.currentEditor = var1;
      }

      public final int gc() {
         return this.lockingSourceCount;
      }

      public final void p(int var1) {
         this.lockingSourceCount = var1;
      }

      public final long gd() {
         return this.sequenceNumber;
      }

      public final void f(long var1) {
         this.sequenceNumber = var1;
      }

      public final void c(List<String> var1) throws IOException {
         fR.c(var1, (String)"");
         if (var1.size() != bI.this.fE()) {
            this.d(var1);
            throw new eu();
         } else {
            try {
               int var2 = 0;

               for(int var3 = var1.size(); var2 < var3; ++var2) {
                  this.lengths[var2] = Long.parseLong((String)var1.get(var2));
               }

            } catch (NumberFormatException var4) {
               this.d(var1);
               throw new eu();
            }
         }
      }

      public final void b(df var1) throws IOException {
         fR.c(var1, (String)"");
         long[] var2 = this.lengths;
         int var3 = 0;

         for(int var4 = var2.length; var3 < var4; ++var3) {
            long var5 = var2[var3];
            var1.aa(32).D(var5);
         }

      }

      private final Void d(List<String> var1) throws IOException {
         throw new IOException("unexpected journal line: " + var1);
      }

      public final d ge() {
         bI var1 = bI.this;
         boolean var2 = false;
         if (bD.jn && !Thread.holdsLock(var1)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var1);
         } else if (!this.readable) {
            return null;
         } else if (bI.this.jJ || this.currentEditor == null && !this.zombie) {
            List var8 = (List)(new ArrayList());
            long[] var9 = (long[])this.lengths.clone();

            try {
               int var3 = 0;

               for(int var10 = bI.this.fE(); var3 < var10; ++var3) {
                  ((Collection)var8).add(this.q(var3));
               }

               return bI.this.new d(this.key, this.sequenceNumber, var8, var9);
            } catch (FileNotFoundException var7) {
               for(dA var5 : var8) {
                  bD.a(var5);
               }

               try {
                  bI.this.a(this);
               } catch (IOException var6) {
               }

               return null;
            }
         } else {
            return null;
         }
      }

      private final dA q(int var1) {
         dA var2 = bI.this.fC().a((File)this.cleanFiles.get(var1));
         if (bI.this.jJ) {
            return var2;
         } else {
            int var3 = this.lockingSourceCount++;
            return new dj(var2) {
               private boolean closed;

               public void close() {
                  super.close();
                  if (!this.closed) {
                     this.closed = true;
                     bI var1 = bI.this;
                     c var2 = c.this;
                     bI var3 = bI.this;
                     synchronized(var1) {
                        boolean var5 = false;
                        int var6 = var2.gc();
                        var2.p(var6 + -1);
                        if (var2.gc() == 0 && var2.ga()) {
                           var3.a(var2);
                        }

                        eE var8 = eE.sk;
                     }
                  }

               }
            };
         }
      }
   }

   public final class d implements Closeable {
      private final String key;
      private final long sequenceNumber;
      private final List<dA> sources;
      private final long[] lengths;

      public d(String var2, long var3, List<? extends dA> var5, long[] var6) {
         fR.c(var2, (String)"");
         fR.c(var5, (String)"");
         fR.c(var6, (String)"");
         super();
         this.key = var2;
         this.sequenceNumber = var3;
         this.sources = var5;
         this.lengths = var6;
      }

      public final b gf() throws IOException {
         return bI.this.b(this.key, this.sequenceNumber);
      }

      public final dA r(int var1) {
         return (dA)this.sources.get(var1);
      }

      public void close() {
         for(dA var2 : this.sources) {
            bD.a(var2);
         }

      }
   }
}
