import java.io.EOFException;
import java.io.IOException;

public final class av {
   public static P k(aT var0) throws T {
      boolean var1 = true;

      try {
         var0.aI();
         var1 = false;
         return aL.dl.b(var0);
      } catch (EOFException var3) {
         if (var1) {
            return R.aY;
         } else {
            throw new X(var3);
         }
      } catch (aW var4) {
         throw new X(var4);
      } catch (IOException var5) {
         throw new Q(var5);
      } catch (NumberFormatException var6) {
         throw new X(var6);
      }
   }

   public static void a(P var0, aV var1) throws IOException {
      aL.dl.a(var1, var0);
   }
}
