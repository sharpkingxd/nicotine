import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.Arrays;

public class dh implements Serializable, Comparable<dh> {
   public static final a pS = new a((fP)null);
   private final byte[] pT;
   private transient int dE;
   private transient String pU;
   private static final long serialVersionUID = 1L;
   public static final dh pV = new dh(new byte[0]);

   public dh(byte[] var1) {
      fR.c(var1, (String)"");
      super();
      this.pT = var1;
   }

   public final byte[] lc() {
      return this.pT;
   }

   public final int ld() {
      return this.dE;
   }

   public final void ad(int var1) {
      this.dE = var1;
   }

   public final String le() {
      return this.pU;
   }

   public final void aS(String var1) {
      this.pU = var1;
   }

   public String lf() {
      boolean var2 = false;
      String var3 = this.le();
      if (var3 == null) {
         var3 = dD.e(this.lp());
         this.aS(var3);
      }

      return var3;
   }

   public String lg() {
      boolean var2 = false;
      return da.a(this.lc(), (byte[])null, 1, (Object)null);
   }

   public final dh lh() {
      return this.aT("MD5");
   }

   public final dh li() {
      return this.aT("SHA-1");
   }

   public final dh lj() {
      return this.aT("SHA-256");
   }

   public dh aT(String var1) {
      fR.c(var1, (String)"");
      MessageDigest var3 = MessageDigest.getInstance(var1);
      boolean var4 = false;
      var3.update(this.pT, 0, this.lm());
      byte[] var2 = var3.digest();
      fR.m(var2);
      return new dh(var2);
   }

   public String lk() {
      boolean var2 = false;
      char[] var3 = new char[this.lc().length * 2];
      int var4 = 0;
      byte[] var5 = this.lc();
      int var6 = 0;

      for(int var7 = var5.length; var6 < var7; ++var6) {
         byte var8 = var5[var6];
         int var10001 = var4++;
         char[] var10002 = dF.lQ();
         byte var10 = 4;
         boolean var11 = false;
         var3[var10001] = var10002[var8 >> var10 & 15];
         var10001 = var4++;
         var10002 = dF.lQ();
         var10 = 15;
         var11 = false;
         var3[var10001] = var10002[var8 & var10];
      }

      return gA.b(var3);
   }

   public dh ll() {
      dh var1 = this;
      boolean var2 = false;
      int var3 = 0;

      dh var9;
      while(true) {
         if (var3 >= var1.lc().length) {
            var9 = var1;
            break;
         }

         byte var4 = var1.lc()[var3];
         if (var4 >= 65 && var4 <= 90) {
            byte[] var10000 = var1.lc();
            var10000 = Arrays.copyOf(var10000, var10000.length);
            fR.b(var10000, "");
            byte[] var5 = var10000;
            var5[var3++] = (byte)(var4 - -32);

            while(var3 < var5.length) {
               var4 = var5[var3];
               if (var4 >= 65 && var4 <= 90) {
                  var5[var3] = (byte)(var4 - -32);
                  ++var3;
               } else {
                  ++var3;
               }
            }

            var9 = new dh(var5);
            break;
         }

         ++var3;
      }

      return var9;
   }

   public byte ae(int var1) {
      boolean var3 = false;
      return this.lc()[var1];
   }

   public final byte af(int var1) {
      return this.ae(var1);
   }

   public final int lm() {
      return this.ln();
   }

   public int ln() {
      boolean var2 = false;
      return this.lc().length;
   }

   public byte[] lo() {
      boolean var2 = false;
      byte[] var10000 = this.lc();
      var10000 = Arrays.copyOf(var10000, var10000.length);
      fR.b(var10000, "");
      return var10000;
   }

   public byte[] lp() {
      boolean var2 = false;
      return this.lc();
   }

   public void a(de var1, int var2, int var3) {
      fR.c(var1, (String)"");
      dF.a(this, var1, var2, var3);
   }

   public boolean a(int var1, dh var2, int var3, int var4) {
      fR.c(var2, (String)"");
      boolean var6 = false;
      return var2.a(var3, this.lc(), var1, var4);
   }

   public boolean a(int var1, byte[] var2, int var3, int var4) {
      fR.c(var2, (String)"");
      boolean var6 = false;
      return var1 >= 0 && var1 <= this.lc().length - var4 && var3 >= 0 && var3 <= var2.length - var4 && db.a(this.lc(), var1, var2, var3, var4);
   }

   public final boolean g(dh var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      return this.a(0, (dh)var1, 0, var1.lm());
   }

   public boolean equals(Object var1) {
      boolean var3 = false;
      return var1 == this ? true : (var1 instanceof dh ? ((dh)var1).lm() == this.lc().length && ((dh)var1).a(0, (byte[])this.lc(), 0, this.lc().length) : false);
   }

   public int hashCode() {
      boolean var2 = false;
      int var3 = this.ld();
      int var10000;
      if (var3 != 0) {
         var10000 = var3;
      } else {
         int var4 = Arrays.hashCode(this.lc());
         boolean var6 = false;
         this.ad(var4);
         var10000 = var4;
      }

      return var10000;
   }

   public int h(dh var1) {
      fR.c(var1, (String)"");
      dh var2 = this;
      boolean var3 = false;
      int var4 = this.lm();
      int var5 = var1.lm();
      int var6 = 0;
      int var7 = Math.min(var4, var5);

      int var10000;
      while(true) {
         if (var6 < var7) {
            int var8 = var2.af(var6);
            short var9 = 255;
            short var10 = 0;
            int var11 = var8 & var9;
            var9 = var1.af(var6);
            var10 = 255;
            boolean var12 = false;
            var8 = var9 & var10;
            if (var11 == var8) {
               ++var6;
               continue;
            }

            var10000 = var11 < var8 ? -1 : 1;
            break;
         }

         var10000 = var4 == var5 ? 0 : (var4 < var5 ? -1 : 1);
         break;
      }

      return var10000;
   }

   public String toString() {
      boolean var2 = false;
      String var10000;
      if (this.lc().length == 0) {
         var10000 = "[size=0]";
      } else {
         int var3 = dF.c(this.lc(), 64);
         if (var3 == -1) {
            if (this.lc().length <= 64) {
               var10000 = "[hex=" + this.lk() + ']';
            } else {
               StringBuilder var16 = (new StringBuilder()).append("[size=").append(this.lc().length).append(" hex=");
               byte var5 = 0;
               byte var6 = 64;
               boolean var7 = false;
               int var8 = db.a((dh)this, var6);
               if (var8 > this.lc().length) {
                  boolean var13 = false;
                  String var14 = "endIndex > length(" + this.lc().length + ')';
                  throw new IllegalArgumentException(var14.toString());
               }

               int var10 = var8 - var5;
               if (var10 < 0) {
                  boolean var11 = false;
                  String var15 = "endIndex < beginIndex";
                  throw new IllegalArgumentException(var15.toString());
               }

               dh var10001;
               if (var8 == this.lc().length) {
                  var10001 = this;
               } else {
                  byte[] var9 = this.lc();
                  var10001 = new dh(eI.d(var9, var5, var8));
               }

               var10000 = var16.append(var10001.lk()).append("…]").toString();
            }
         } else {
            String var4 = this.lf();
            var10000 = var4.substring(0, var3);
            fR.b(var10000, "");
            String var12 = gA.a(gA.a(gA.a(var10000, "\\", "\\\\", false, 4, (Object)null), "\n", "\\n", false, 4, (Object)null), "\r", "\\r", false, 4, (Object)null);
            var10000 = var3 < var4.length() ? "[size=" + this.lc().length + " text=" + var12 + "…]" : "[text=" + var12 + ']';
         }
      }

      return var10000;
   }

   private final void readObject(ObjectInputStream var1) throws IOException {
      int var2 = var1.readInt();
      dh var3 = pS.a((InputStream)var1, var2);
      Field var4 = dh.class.getDeclaredField("pT");
      var4.setAccessible(true);
      var4.set(this, var3.pT);
   }

   private final void writeObject(ObjectOutputStream var1) throws IOException {
      var1.writeInt(this.pT.length);
      var1.write(this.pT);
   }

   // $FF: synthetic method
   public int compareTo(Object var1) {
      return this.h((dh)var1);
   }

   public static final class a {
      private a() {
      }

      public final dh c(byte[] var1, int var2, int var3) {
         fR.c(var1, (String)"");
         boolean var5 = false;
         int var6 = db.a(var1, var3);
         db.b((long)var1.length, (long)var2, (long)var6);
         int var8 = var2 + var6;
         return new dh(eI.d(var1, var2, var8));
      }

      // $FF: synthetic method
      public static dh a(a var0, byte[] var1, int var2, int var3, int var4, Object var5) {
         if ((var4 & 1) != 0) {
            var2 = 0;
         }

         if ((var4 & 2) != 0) {
            var3 = db.kv();
         }

         return var0.c(var1, var2, var3);
      }

      public final dh aU(String var1) {
         fR.c(var1, (String)"");
         boolean var3 = false;
         dh var4 = new dh(dD.aX(var1));
         var4.aS(var1);
         return var4;
      }

      public final dh a(String var1, Charset var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         byte[] var10002 = var1.getBytes(var2);
         fR.b(var10002, "");
         return new dh(var10002);
      }

      public final dh aV(String var1) {
         fR.c(var1, (String)"");
         boolean var3 = false;
         byte[] var4 = da.aP(var1);
         return var4 != null ? new dh(var4) : null;
      }

      public final dh aW(String var1) {
         fR.c(var1, (String)"");
         String var2 = var1;
         boolean var3 = false;
         if (var1.length() % 2 != 0) {
            boolean var9 = false;
            String var10 = "Unexpected hex string: " + var1;
            throw new IllegalArgumentException(var10.toString());
         } else {
            byte[] var5 = new byte[var1.length() / 2];
            int var4 = 0;

            for(int var6 = var5.length; var4 < var6; ++var4) {
               int var7 = dF.f(var2.charAt(var4 * 2)) << 4;
               int var8 = dF.f(var2.charAt(var4 * 2 + 1));
               var5[var4] = (byte)(var7 + var8);
            }

            return new dh(var5);
         }
      }

      public final dh a(InputStream var1, int var2) throws IOException {
         fR.c(var1, (String)"");
         if (var2 < 0) {
            boolean var6 = false;
            String var7 = "byteCount < 0: " + var2;
            throw new IllegalArgumentException(var7.toString());
         } else {
            byte[] var3 = new byte[var2];
            int var4 = 0;

            int var8;
            for(var8 = 0; var4 < var2; var4 += var8) {
               var8 = var1.read(var3, var4, var2 - var4);
               if (var8 == -1) {
                  throw new EOFException();
               }
            }

            return new dh(var3);
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
