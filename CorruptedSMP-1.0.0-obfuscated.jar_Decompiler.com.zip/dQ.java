import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Location;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class dQ implements Listener {
   private final CorruptedSMPPlugin rk;

   public dQ(CorruptedSMPPlugin var1) {
      this.rk = var1;
   }

   @EventHandler
   public void a(CraftItemEvent var1) {
      HumanEntity var3 = var1.getWhoClicked();
      if (var3 instanceof Player var2) {
         ItemStack var11 = var1.getRecipe().getResult();
         if (var11 != null && var11.hasItemMeta()) {
            ItemMeta var4 = var11.getItemMeta();
            if (var4 != null && var4.hasCustomModelData()) {
               int var5 = var4.getCustomModelData();
               l var6 = null;

               for(l var10 : l.values()) {
                  if (var10.n() == var5) {
                     var6 = var10;
                     break;
                  }
               }

               if (var6 != null) {
                  Location var12 = var1.getInventory().getLocation();
                  if (var12 == null) {
                     var12 = var2.getLocation();
                  }

                  var1.setCancelled(true);
                  if (!this.rk.i().d(var2, var6)) {
                     this.rk.i().g(var2, var6);
                     var2.closeInventory();
                  } else if (this.rk.e().k(var2.getUniqueId())) {
                     var2.sendMessage("§c§lERROR: §cYou already have an active ritual!");
                     var2.closeInventory();
                  } else {
                     CraftingInventory var13 = var1.getInventory();
                     this.rk.getServer().getScheduler().runTask(this.rk, () -> {
                        boolean var5 = this.rk.e().a(var2, var6, var12);
                        if (var5) {
                           for(int var6x = 1; var6x <= 9; ++var6x) {
                              ItemStack var7 = var13.getItem(var6x);
                              if (var7 != null && !var7.getType().isAir()) {
                                 var7.setAmount(var7.getAmount() - 1);
                                 var13.setItem(var6x, var7);
                              }
                           }

                           var2.sendMessage("§a§l✓ Ritual started! §7Ingredients consumed.");
                        } else {
                           var2.sendMessage("§c§l✗ Ritual failed to start! §7Items returned.");
                        }

                        var2.closeInventory();
                     });
                  }
               }
            }
         }
      }
   }
}
