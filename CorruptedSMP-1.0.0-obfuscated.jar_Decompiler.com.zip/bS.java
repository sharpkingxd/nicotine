import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;

public final class bS implements bb {
   private final bu kP;
   private final bw kQ;
   private final boolean kR;
   private final bU kS;
   private final bo kT;
   private final <undefinedtype> kU;
   private final AtomicBoolean kV;
   private Object kW;
   private bR kX;
   private bT kE;
   private boolean kY;
   private bQ kZ;
   private boolean la;
   private boolean lb;
   private boolean lc;
   private volatile boolean ld;
   private volatile bQ exchange;
   private volatile bT le;

   public bS(bu var1, bw var2, boolean var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.kP = var1;
      this.kQ = var2;
      this.kR = var3;
      this.kS = this.kP.dx().cx();
      this.kT = this.kP.dA().create(this);
      dc var4 = new dc() {
         protected void hh() {
            bS.this.gM();
         }
      };
      boolean var6 = false;
      ((<undefinedtype>)var4).d((long)this.kP.dR(), TimeUnit.MILLISECONDS);
      this.kU = var4;
      this.kV = new AtomicBoolean();
      this.lc = true;
   }

   public final bu gS() {
      return this.kP;
   }

   public final bo gT() {
      return this.kT;
   }

   public final bT gU() {
      return this.kE;
   }

   public final bQ gV() {
      return this.kZ;
   }

   public final void a(bT var1) {
      this.le = var1;
   }

   public bS gW() {
      return new bS(this.kP, this.kQ, this.kR);
   }

   public void gM() {
      if (!this.ld) {
         this.ld = true;
         bQ var10000 = this.exchange;
         if (var10000 != null) {
            var10000.gM();
         }

         bT var1 = this.le;
         if (var1 != null) {
            var1.hs();
         }

         this.kT.h(this);
      }
   }

   public boolean gX() {
      return this.ld;
   }

   public by ck() {
      if (!this.kV.compareAndSet(false, true)) {
         boolean var2 = false;
         String var5 = "Already Executed";
         throw new IllegalStateException(var5.toString());
      } else {
         this.kU.kw();
         this.gY();

         by var1;
         try {
            this.kP.dw().a(this);
            var1 = this.gZ();
         } finally {
            this.kP.dw().b(this);
         }

         return var1;
      }
   }

   private final void gY() {
      this.kW = cH.oU.jZ().aH("response.body().close()");
      this.kT.a(this);
   }

   public final by gZ() throws IOException {
      List var1 = (List)(new ArrayList());
      eO.a((Collection)var1, (Iterable)this.kP.dy());
      ((Collection)var1).add(new ch(this.kP));
      ((Collection)var1).add(new bY(this.kP.dF()));
      ((Collection)var1).add(new bF(this.kP.dG()));
      ((Collection)var1).add(bO.kt);
      if (!this.kR) {
         eO.a((Collection)var1, (Iterable)this.kP.dz());
      }

      ((Collection)var1).add(new bZ(this.kR));
      ce var2 = new ce(this, var1, 0, (bQ)null, this.kQ, this.kP.dS(), this.kP.dT(), this.kP.dU());
      boolean var3 = false;
      boolean var8 = false;

      by var5;
      try {
         var8 = true;
         by var4 = var2.c(this.kQ);
         if (this.gX()) {
            bD.a(var4);
            throw new IOException("Canceled");
         }

         var5 = var4;
         var8 = false;
      } catch (IOException var9) {
         var3 = true;
         IOException var10000 = this.h(var9);
         fR.m(var10000);
         throw (Throwable)var10000;
      } finally {
         if (var8) {
            if (!var3) {
               this.h((IOException)null);
            }

         }
      }

      this.h((IOException)null);
      return var5;
   }

   public final void b(bw var1, boolean var2) {
      fR.c(var1, (String)"");
      if (this.kZ != null) {
         String var9 = "Check failed.";
         throw new IllegalStateException(var9.toString());
      } else {
         synchronized(this){}

         try {
            boolean var4 = false;
            if (this.lb) {
               boolean var10 = false;
               String var11 = "cannot make a new request because the previous response is still open: please call response.close()";
               throw new IllegalStateException(var11.toString());
            }

            if (this.la) {
               String var5 = "Check failed.";
               throw new IllegalStateException(var5.toString());
            }

            eE var8 = eE.sk;
         } finally {
            ;
         }

         if (var2) {
            this.kX = new bR(this.kS, this.e(var1.eI()), this, this.kT);
         }

      }
   }

   public final bQ a(ce var1) {
      fR.c(var1, (String)"");
      synchronized(this){}

      try {
         boolean var3 = false;
         if (!this.lc) {
            boolean var14 = false;
            String var15 = "released";
            throw new IllegalStateException(var15.toString());
         }

         if (this.lb) {
            String var13 = "Check failed.";
            throw new IllegalStateException(var13.toString());
         }

         if (this.la) {
            String var4 = "Check failed.";
            throw new IllegalStateException(var4.toString());
         }

         eE var11 = eE.sk;
      } finally {
         ;
      }

      bR var10000 = this.kX;
      fR.m(var10000);
      bR var2 = var10000;
      cb var12 = var2.a(this.kP, var1);
      bQ var16 = new bQ(this, this.kT, var2, var12);
      this.kZ = var16;
      this.exchange = var16;
      synchronized(this) {
         boolean var6 = false;
         this.la = true;
         this.lb = true;
         eE var17 = eE.sk;
      }

      if (this.ld) {
         throw new IOException("Canceled");
      } else {
         return var16;
      }
   }

   public final void b(bT var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (bD.jn && !Thread.holdsLock(var1)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var1);
      } else if (this.kE != null) {
         String var4 = "Check failed.";
         throw new IllegalStateException(var4.toString());
      } else {
         this.kE = var1;
         var1.hk().add(new b(this, this.kW));
      }
   }

   public final <E extends IOException> E a(bQ var1, boolean var2, boolean var3, E var4) {
      fR.c(var1, (String)"");
      if (!fR.c(var1, (Object)this.exchange)) {
         return (E)var4;
      } else {
         boolean var5 = false;
         boolean var6 = false;
         synchronized(this) {
            boolean var8 = false;
            if (var2 && this.la || var3 && this.lb) {
               if (var2) {
                  this.la = false;
               }

               if (var3) {
                  this.lb = false;
               }

               var5 = !this.la && !this.lb;
               var6 = !this.la && !this.lb && !this.lc;
            }

            eE var10 = eE.sk;
         }

         if (var5) {
            this.exchange = null;
            bT var10000 = this.kE;
            if (var10000 != null) {
               var10000.hp();
            }
         }

         return (E)(var6 ? this.i(var4) : var4);
      }
   }

   public final IOException h(IOException var1) {
      boolean var2 = false;
      synchronized(this) {
         boolean var4 = false;
         if (this.lc) {
            this.lc = false;
            var2 = !this.la && !this.lb;
         }

         eE var6 = eE.sk;
      }

      return var2 ? this.i(var1) : var1;
   }

   private final <E extends IOException> E i(E param1) {
      // $FF: Couldn't be decompiled
   }

   public final Socket ha() {
      bT var10000 = this.kE;
      fR.m(var10000);
      bT var1 = var10000;
      int var3 = 0;
      if (bD.jn && !Thread.holdsLock(var1)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var1);
      } else {
         List var2 = var1.hk();
         boolean var5 = false;
         int var6 = 0;
         Iterator var7 = var2.iterator();

         while(true) {
            if (!var7.hasNext()) {
               var13 = -1;
               break;
            }

            Object var8 = var7.next();
            Reference var9 = (Reference)var8;
            boolean var10 = false;
            if (fR.c(var9.get(), (Object)this)) {
               var13 = var6;
               break;
            }

            ++var6;
         }

         var3 = var13;
         if (var3 == -1) {
            String var12 = "Check failed.";
            throw new IllegalStateException(var12.toString());
         } else {
            var2.remove(var3);
            this.kE = null;
            if (var2.isEmpty()) {
               var1.i(System.nanoTime());
               if (this.kS.e(var1)) {
                  return var1.ht();
               }
            }

            return null;
         }
      }
   }

   private final <E extends IOException> E j(E var1) {
      if (this.kY) {
         return (E)var1;
      } else if (!this.kU.kx()) {
         return (E)var1;
      } else {
         InterruptedIOException var2 = new InterruptedIOException("timeout");
         if (var1 != null) {
            var2.initCause((Throwable)var1);
         }

         return (E)(var2);
      }
   }

   public final void hb() {
      if (this.kY) {
         String var1 = "Check failed.";
         throw new IllegalStateException(var1.toString());
      } else {
         this.kY = true;
         this.kU.kx();
      }
   }

   public final void s(boolean var1) {
      synchronized(this){}

      try {
         boolean var3 = false;
         if (!this.lc) {
            boolean var4 = false;
            String var8 = "released";
            throw new IllegalStateException(var8.toString());
         }

         eE var7 = eE.sk;
      } finally {
         ;
      }

      if (var1) {
         bQ var10000 = this.exchange;
         if (var10000 != null) {
            var10000.gN();
         }
      }

      this.kZ = null;
   }

   private final aX e(br var1) {
      SSLSocketFactory var2 = null;
      HostnameVerifier var3 = null;
      bd var4 = null;
      if (var1.da()) {
         var2 = this.kP.dM();
         var3 = this.kP.dP();
         var4 = this.kP.dQ();
      }

      return new aX(var1.cY(), var1.cZ(), this.kP.dH(), this.kP.dL(), var2, var3, var4, this.kP.dK(), this.kP.dI(), this.kP.dO(), this.kP.dN(), this.kP.dJ());
   }

   public final boolean hc() {
      bR var10000 = this.kX;
      fR.m(var10000);
      return var10000.gQ();
   }

   private final String hd() {
      return (this.gX() ? "canceled " : "") + (this.kR ? "web socket" : "call") + " to " + this.he();
   }

   public final String he() {
      return this.kQ.eI().dk();
   }

   // $FF: synthetic method
   public Object clone() {
      return this.gW();
   }

   public final class a implements Runnable {
      private final bc responseCallback;
      private volatile AtomicInteger callsPerHost;
      // $FF: synthetic field
      final bS this$0;

      public final AtomicInteger hf() {
         return this.callsPerHost;
      }

      public final void a(ExecutorService var1) {
         fR.c(var1, (String)"");
         bm var2 = this.this$0.gS().dw();
         boolean var3 = false;
         if (bD.jn && Thread.holdsLock(var2)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + var2);
         } else {
            boolean var10 = false;
            boolean var7 = false;

            try {
               var7 = true;
               var1.execute(this);
               var10 = true;
               var7 = false;
               return;
            } catch (RejectedExecutionException var8) {
               InterruptedIOException var4 = new InterruptedIOException("executor rejected");
               var4.initCause((Throwable)var8);
               this.this$0.h((IOException)var4);
               this.responseCallback.a(this.this$0, (IOException)var4);
               var7 = false;
            } finally {
               if (var7) {
                  this.this$0.gS().dw().a(this);
               }
            }

            this.this$0.gS().dw().a(this);
         }
      }

      public void run() {
         String var1 = "OkHttp " + this.this$0.he();
         bS var2 = this.this$0;
         boolean var3 = false;
         Thread var4 = Thread.currentThread();
         String var5 = var4.getName();
         var4.setName(var1);

         try {
            boolean var6 = false;
            boolean var7 = false;
            var2.kU.kw();

            try {
               by var8 = var2.gZ();
               var7 = true;
               this.responseCallback.a(var2, var8);
            } catch (IOException var18) {
               if (var7) {
                  cH.oU.jZ().a("Callback failure for " + var2.hd(), 4, (Throwable)var18);
               } else {
                  this.responseCallback.a(var2, var18);
               }
            } catch (Throwable var19) {
               var2.gM();
               if (!var7) {
                  IOException var9 = new IOException("canceled due to " + var19);
                  er.a((Throwable)var9, var19);
                  this.responseCallback.a(var2, var9);
               }

               throw var19;
            } finally {
               var2.gS().dw().a(this);
            }
         } finally {
            var4.setName(var5);
         }

      }
   }

   public static final class b extends WeakReference<bS> {
      private final Object callStackTrace;

      public b(bS var1, Object var2) {
         fR.c(var1, (String)"");
         super(var1);
         this.callStackTrace = var2;
      }

      public final Object hg() {
         return this.callStackTrace;
      }
   }
}
