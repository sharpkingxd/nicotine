import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class gs extends gr {
   public static final <T> gm<T> a(gm<? extends T> var0, int var1) {
      fR.c(var0, (String)"");
      boolean var2 = var1 >= 0;
      if (!var2) {
         boolean var3 = false;
         String var4 = "Requested element count " + var1 + " is less than zero.";
         throw new IllegalArgumentException(var4.toString());
      } else {
         return var1 == 0 ? var0 : (var0 instanceof gl ? ((gl)var0).aq(var1) : (gm)(new gk(var0, var1)));
      }
   }

   public static final <T, C extends Collection<? super T>> C a(gm<? extends T> var0, C var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");

      for(Object var3 : var0) {
         var1.add(var3);
      }

      return (C)var1;
   }

   public static final <T> List<T> a(gm<? extends T> var0) {
      fR.c(var0, (String)"");
      return eO.l(gn.b(var0));
   }

   public static final <T> List<T> b(gm<? extends T> var0) {
      fR.c(var0, (String)"");
      return (List)gn.a(var0, (Collection)(new ArrayList()));
   }

   public static final <T, R> gm<R> a(gm<? extends T> var0, fK<? super T, ? extends R> var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return new gt(var0, var1);
   }

   public static final <T, A extends Appendable> A a(gm<? extends T> var0, A var1, CharSequence var2, CharSequence var3, CharSequence var4, int var5, CharSequence var6, fK<? super T, ? extends CharSequence> var7) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      fR.c(var6, (String)"");
      var1.append(var3);
      int var8 = 0;

      for(Object var10 : var0) {
         ++var8;
         if (var8 > 1) {
            var1.append(var2);
         }

         if (var5 >= 0 && var8 > var5) {
            break;
         }

         gA.a(var1, var10, var7);
      }

      if (var5 >= 0 && var8 > var5) {
         var1.append(var6);
      }

      var1.append(var4);
      return (A)var1;
   }

   public static final <T> String a(gm<? extends T> var0, CharSequence var1, CharSequence var2, CharSequence var3, int var4, CharSequence var5, fK<? super T, ? extends CharSequence> var6) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var5, (String)"");
      String var10000 = ((StringBuilder)gn.a(var0, (Appendable)(new StringBuilder()), var1, var2, var3, var4, var5, var6)).toString();
      fR.b(var10000, "");
      return var10000;
   }

   // $FF: synthetic method
   public static String a(gm var0, CharSequence var1, CharSequence var2, CharSequence var3, int var4, CharSequence var5, fK var6, int var7, Object var8) {
      if ((var7 & 1) != 0) {
         var1 = (CharSequence)", ";
      }

      if ((var7 & 2) != 0) {
         var2 = (CharSequence)"";
      }

      if ((var7 & 4) != 0) {
         var3 = (CharSequence)"";
      }

      if ((var7 & 8) != 0) {
         var4 = -1;
      }

      if ((var7 & 16) != 0) {
         var5 = (CharSequence)"...";
      }

      if ((var7 & 32) != 0) {
         var6 = null;
      }

      return gn.a(var0, var1, var2, var3, var4, var5, var6);
   }

   public static final <T> Iterable<T> c(gm<? extends T> var0) {
      fR.c(var0, (String)"");
      return new gs$a(var0);
   }
}
