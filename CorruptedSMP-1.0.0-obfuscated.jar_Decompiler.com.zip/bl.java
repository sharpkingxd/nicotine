import java.nio.charset.Charset;

public final class bl {
   public static final bl hz = new bl();

   private bl() {
   }

   public static final String a(String var0, String var1, Charset var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      String var3 = var0 + ':' + var1;
      String var4 = dh.pS.a(var3, var2).lg();
      return "Basic " + var4;
   }
}
