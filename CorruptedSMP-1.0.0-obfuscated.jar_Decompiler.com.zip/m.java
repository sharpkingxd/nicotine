import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class m {
   static final Set<UUID> J = new HashSet();
   static final Map<UUID, b> K = new HashMap();
   static final Map<String, Material> L = new HashMap();
   static final Map<String, Integer> M = new HashMap();

   static String a(World var0, int var1, int var2, int var3) {
      return String.valueOf(var0.getUID()) + ":" + var1 + "," + var2 + "," + var3;
   }

   public static boolean a(Location var0) {
      for(b var2 : K.values()) {
         if (var2.b(var0)) {
            return true;
         }
      }

      return false;
   }

   public static boolean c(UUID var0) {
      return J.contains(var0);
   }

   public static b d(UUID var0) {
      return (b)K.get(var0);
   }

   public static void q() {
      for(UUID var2 : new ArrayList(K.keySet())) {
         b var3 = (b)K.get(var2);
         if (var3 != null) {
            var3.c("Server cleanup");
         }
      }

      K.clear();
      J.clear();
   }

   public static void e(UUID var0) {
      b var1 = (b)K.get(var0);
      if (var1 != null) {
         var1.c("Player cleanup");
      }

   }

   public static boolean a(final Player var0, final CorruptedSMPPlugin var1) {
      final UUID var2 = var0.getUniqueId();
      if (K.containsKey(var2)) {
         var0.sendMessage("§8§l[§5SHADOW CAGE§8§l] §cYou already have an active cage!");
         return false;
      } else {
         final int var3 = var1.getConfig().getInt("corruptions.darkness.ability-duration", 30);
         final Location var4 = var0.getLocation().clone();
         final double var5 = (double)10.0F;
         final b var7 = new b(var2, var4, var5);
         a(var7);
         Logger var10000 = var1.getLogger();
         String var10001 = var0.getName();
         var10000.info("[Darkness Cage] Player " + var10001 + " built cage with " + var7.placedBlocks.size() + " blocks");
         BukkitRunnable var8 = new BukkitRunnable() {
            int ticks = 0;
            final long startTime = System.currentTimeMillis();
            final long maxDurationMillis = (long)var3 * 1000L;

            public void run() {
               long var1x = System.currentTimeMillis() - this.startTime;
               if (var1x < this.maxDurationMillis && this.ticks < var3 * 20) {
                  if (var0 != null && var0.isOnline() && m.K.containsKey(var2)) {
                     if (this.ticks % 20 == 0) {
                        for(int var3x = 0; var3x < 360; var3x += 60) {
                           double var4x = Math.toRadians((double)var3x);
                           double var6 = var4.getX() + var5 * Math.cos(var4x);
                           double var8 = var4.getZ() + var5 * Math.sin(var4x);
                           Location var10 = new Location(var4.getWorld(), var6, var4.getY() + (double)5.0F, var8);
                           var4.getWorld().spawnParticle(Particle.SMOKE, var10, 1, 0.3, (double)1.0F, 0.3, 0.02);
                        }
                     }

                     for(Entity var12 : var4.getWorld().getNearbyEntities(var4, var5, (double)15.0F, var5)) {
                        if (var12 instanceof Player) {
                           Player var5x = (Player)var12;
                           if (!var5x.equals(var0)) {
                              m.J.add(var5x.getUniqueId());
                              var7.trappedInThisCage.add(var5x.getUniqueId());
                              if (this.ticks % 20 == 0) {
                                 var5x.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1, false, false));
                              }
                           }
                        }
                     }

                     if (this.ticks % 20 == 0) {
                        var0.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 80, 1, false, false));
                        var0.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 80, 0, false, false));
                        var0.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 80, 0, false, false));
                     }

                     if (this.ticks % 60 == 0) {
                        var4.getWorld().playSound(var4, Sound.ENTITY_WARDEN_HEARTBEAT, 1.0F, 0.8F);
                        var4.getWorld().playSound(var4, Sound.BLOCK_SCULK_SHRIEKER_SHRIEK, 0.5F, 0.5F);
                     }

                     ++this.ticks;
                  } else {
                     var7.c("Player offline/cage removed");
                     this.cancel();
                  }
               } else {
                  var7.c("Duration ended");
                  m.J.removeAll(var7.trappedInThisCage);
                  var0.sendMessage("§8§l[§5SHADOW CAGE§8§l] §7Cage ended!");
                  var1.getLogger().info("[Darkness Cage] Player " + var0.getName() + "'s cage ended and cleaned up");
                  this.cancel();
               }
            }
         };
         BukkitTask var9 = var8.runTaskTimer(var1, 0L, 1L);
         var7.task = var9;
         K.put(var2, var7);

         try {
            var0.playSound(var0.getLocation(), "custom:darkness", 2.0F, 1.0F);
         } catch (Exception var11) {
         }

         var0.playSound(var0.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 2.0F, 0.8F);
         var4.getWorld().playSound(var4, Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 2.0F, 0.6F);
         var4.getWorld().spawnParticle(Particle.EXPLOSION, var4, 3, (double)1.0F, (double)1.0F, (double)1.0F, (double)0.0F);
         var4.getWorld().spawnParticle(Particle.SMOKE, var4, 20, (double)2.0F, (double)2.0F, (double)2.0F, 0.1);
         var0.sendMessage("§8§l[§5SHADOW CAGE§8§l] §7Activated! §5Duration: §f" + var3 + "s");
         return true;
      }
   }

   private static void a(b var0) {
      World var1 = var0.center.getWorld();
      int var2 = var0.center.getBlockX();
      int var3 = var0.center.getBlockY();
      int var4 = var0.center.getBlockZ();
      int var5 = (int)Math.ceil(var0.radius);

      for(int var6 = -var5; var6 <= var5; ++var6) {
         for(int var7 = -var5; var7 <= var5; ++var7) {
            for(int var8 = -var5; var8 <= var5; ++var8) {
               double var9 = Math.sqrt((double)(var6 * var6 + var7 * var7 + var8 * var8));
               if (var9 >= var0.radius - (double)0.5F && var9 <= var0.radius + (double)0.5F) {
                  int var11 = var2 + var6;
                  int var12 = var3 + var7;
                  int var13 = var4 + var8;
                  Block var14 = var1.getBlockAt(var11, var12, var13);
                  String var15 = a(var1, var11, var12, var13);
                  Material var16;
                  if (L.containsKey(var15)) {
                     var16 = (Material)L.get(var15);
                  } else {
                     var16 = var14.getType();
                     L.put(var15, var16);
                  }

                  M.merge(var15, 1, Integer::sum);
                  var0.placedBlocks.add(new a(var1, var11, var12, var13, var16));
                  String var17 = var11 + "," + var12 + "," + var13;
                  var0.cageBlockLocations.add(var17);
                  var14.setType(Material.OBSIDIAN);
               }
            }
         }
      }

   }

   static class a {
      final World world;
      final int x;
      final int y;
      final int z;
      final Material originalType;

      a(World var1, int var2, int var3, int var4, Material var5) {
         this.world = var1;
         this.x = var2;
         this.y = var3;
         this.z = var4;
         this.originalType = var5;
      }
   }

   public static class b {
      public final UUID casterUUID;
      public final Location center;
      public final double radius;
      public final List<a> placedBlocks;
      public final Set<String> cageBlockLocations;
      public final Set<UUID> trappedInThisCage;
      public BukkitTask task;
      public long createdTime;

      b(UUID var1, Location var2, double var3) {
         this.casterUUID = var1;
         this.center = var2.clone();
         this.radius = var3;
         this.placedBlocks = new ArrayList();
         this.cageBlockLocations = new HashSet();
         this.trappedInThisCage = new HashSet();
         this.createdTime = System.currentTimeMillis();
      }

      public boolean b(Location var1) {
         int var10000 = var1.getBlockX();
         String var2 = var10000 + "," + var1.getBlockY() + "," + var1.getBlockZ();
         return this.cageBlockLocations.contains(var2);
      }

      public void c(String var1) {
         if (this.task != null && !this.task.isCancelled()) {
            this.task.cancel();
         }

         this.r();
         this.trappedInThisCage.clear();
         m.K.remove(this.casterUUID);
      }

      public void r() {
         for(a var2 : this.placedBlocks) {
            String var3 = m.a(var2.world, var2.x, var2.y, var2.z);
            int var4 = (Integer)m.M.getOrDefault(var3, 0) - 1;
            m.M.put(var3, Math.max(0, var4));

            try {
               if (var4 <= 0) {
                  Material var5 = (Material)m.L.getOrDefault(var3, var2.originalType);
                  Block var6 = var2.world.getBlockAt(var2.x, var2.y, var2.z);
                  if (var6.getType() == Material.OBSIDIAN) {
                     var6.setType(var5);
                  }

                  m.M.remove(var3);
                  m.L.remove(var3);
               }
            } catch (Exception var7) {
            }
         }

         this.placedBlocks.clear();
         this.cageBlockLocations.clear();
      }
   }
}
