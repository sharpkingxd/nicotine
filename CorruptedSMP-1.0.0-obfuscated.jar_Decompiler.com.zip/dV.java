import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class dV implements Listener {
   private final CorruptedSMPPlugin rr;

   public dV(CorruptedSMPPlugin var1) {
      this.rr = var1;
   }

   @EventHandler
   public void e(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3 != null && var3.getType() == Material.IRON_INGOT) {
         if (this.rr.d().b(var2)) {
            if (this.rr.d().c(var2) == l.D) {
               D var4 = this.rr.f().g(var2.getUniqueId());
               long var5 = (long)this.rr.getConfig().getInt("corruptions.invincibility.armor-repair-cooldown", 60) * 1000L;
               if (System.currentTimeMillis() - var4.I() < var5) {
                  long var16 = (var5 - (System.currentTimeMillis() - var4.I())) / 1000L;
                  var2.sendMessage("§cArmor repair on cooldown! Wait " + var16 + " seconds.");
               } else {
                  ItemStack[] var7 = var2.getInventory().getArmorContents();
                  boolean var8 = false;

                  for(ItemStack var12 : var7) {
                     if (var12 != null && var12.getType() != Material.AIR) {
                        ItemMeta var13 = var12.getItemMeta();
                        if (var13 instanceof Damageable) {
                           Damageable var14 = (Damageable)var13;
                           if (var14.hasDamage()) {
                              int var15 = Math.max(0, var14.getDamage() - 50);
                              var14.setDamage(var15);
                              var12.setItemMeta(var13);
                              var8 = true;
                           }
                        }
                     }
                  }

                  if (var8) {
                     var3.setAmount(var3.getAmount() - 1);
                     var4.a(System.currentTimeMillis());
                     var2.playSound(var2.getLocation(), Sound.BLOCK_ANVIL_USE, 1.0F, 1.0F);
                     var2.sendMessage("§aRepaired armor by 50 durability!");
                     var1.setCancelled(true);
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void j(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rr.d().b(var2)) {
            if (this.rr.d().c(var2) == l.D) {
               if (var2.isBlocking() && var2.getCooldown(Material.SHIELD) > 0) {
                  var2.setCooldown(Material.SHIELD, 0);
               } else if (var2.getCooldown(Material.SHIELD) > 0) {
                  var2.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 1, false, true));
                  var2.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, false, true));
               }

            }
         }
      }
   }

   @EventHandler
   public void k(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof Player var15) {
            if (this.rr.d().b(var2)) {
               if (this.rr.d().c(var2) == l.D) {
                  D var16 = this.rr.f().g(var2.getUniqueId());
                  if (var16.Q()) {
                     ItemStack var5 = var2.getInventory().getItemInMainHand();
                     if (this.a(var5.getType())) {
                        ItemStack[] var6 = var15.getInventory().getArmorContents();
                        int var7 = 0;

                        for(ItemStack var11 : var6) {
                           if (var11 != null && var11.getType() != Material.AIR) {
                              ItemMeta var12 = var11.getItemMeta();
                              if (var12 instanceof Damageable) {
                                 Damageable var13 = (Damageable)var12;
                                 int var14 = var13.getDamage();
                                 var13.setDamage(var14 + 10);
                                 var11.setItemMeta(var12);
                                 var7 += 10;
                              }
                           }
                        }

                        if (var7 > 0) {
                           var2.sendMessage("§7§l✓ Stolen " + var7 + " armor durability!");
                           var15.sendMessage("§c§l✗ Your armor is being damaged by Bulletproof!");
                        }

                     }
                  }
               }
            }
         }
      }
   }

   private boolean a(Material var1) {
      return var1.name().endsWith("_SWORD") || var1.name().endsWith("_AXE") || var1 == Material.TRIDENT || var1 == Material.MACE || var1 == Material.BOW || var1 == Material.CROSSBOW;
   }
}
