import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class dU implements Listener {
   private final CorruptedSMPPlugin rp;
   private final Map<UUID, Long> rq = new HashMap();

   public dU(CorruptedSMPPlugin var1) {
      this.rp = var1;
   }

   @EventHandler
   public void d(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
         final Player var2 = var1.getPlayer();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (this.rp.d().b(var2)) {
            if (this.rp.d().c(var2) == l.C) {
               if (var3.getType() == Material.POPPY) {
                  if (var2.hasCooldown(Material.POPPY)) {
                     var1.setCancelled(true);
                     return;
                  }

                  long var4 = System.currentTimeMillis();
                  if (this.rq.containsKey(var2.getUniqueId())) {
                     long var6 = (Long)this.rq.get(var2.getUniqueId());
                     long var8 = 5000L - (var4 - var6);
                     if (var8 > 0L) {
                        var1.setCancelled(true);
                        return;
                     }
                  }

                  double var12 = var2.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
                  double var13 = Math.min(var2.getHealth() + (double)6.0F, var12);
                  var2.setHealth(var13);
                  double var10 = var2.getAbsorptionAmount();
                  var2.setAbsorptionAmount(var10 + (double)4.0F);
                  var2.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, 0, false, true));
                  var2.playSound(var2.getLocation(), Sound.ENTITY_GENERIC_EAT, 1.0F, 1.0F);
                  (new BukkitRunnable(this) {
                     public void run() {
                        var2.playSound(var2.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.0F, 1.0F);
                     }
                  }).runTaskLater(this.rp, 10L);
                  var2.getWorld().spawnParticle(Particle.ITEM, var2.getEyeLocation(), 10, 0.2, 0.2, 0.2, 0.1, new ItemStack(Material.POPPY));
                  var3.setAmount(var3.getAmount() - 1);
                  var2.setCooldown(Material.POPPY, 100);
                  this.rq.put(var2.getUniqueId(), var4);
                  var1.setCancelled(true);
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void i(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof Player var5) {
            if (this.rp.j().a(var1)) {
               if (this.rp.d().b(var2)) {
                  if (this.rp.d().c(var2) == l.C) {
                     if (var2.getFallDistance() > 0.0F && var2.getVelocity().getY() < (double)0.0F) {
                        var5.setAbsorptionAmount((double)0.0F);
                        var2.playSound(var2.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0F, 1.2F);
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void b(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.rp.d().b(var2)) {
         if (this.rp.d().c(var2) == l.C) {
            if (var1.getItem().getType().isEdible()) {
               var2.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, 100, 1, false, false));
            }

         }
      }
   }

   @EventHandler
   public void a(EntityRegainHealthEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof final Player var2) {
         if (this.rp.d().b(var2)) {
            if (this.rp.d().c(var2) == l.C) {
               (new BukkitRunnable() {
                  public void run() {
                     if (var2.getLevel() > 0) {
                        dU.this.g(var2);
                     }

                  }
               }).runTaskLater(this.rp, 1L);
            }
         }
      }
   }

   void g(Player var1) {
      ItemStack[] var2 = var1.getInventory().getArmorContents();
      boolean var3 = false;

      for(ItemStack var7 : var2) {
         if (var7 != null && var7.getType() != Material.AIR) {
            ItemMeta var8 = var7.getItemMeta();
            if (var8 instanceof Damageable) {
               Damageable var9 = (Damageable)var8;
               if (var9.hasDamage() && var1.getLevel() >= 1) {
                  int var10 = var9.getDamage();
                  int var11 = Math.min(var10, 10);
                  var9.setDamage(var10 - var11);
                  var7.setItemMeta(var8);
                  var1.setLevel(var1.getLevel() - 1);
                  var3 = true;
                  break;
               }
            }
         }
      }

      if (var3) {
         var1.playSound(var1.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5F, 1.5F);
      }

   }
}
