import java.util.Comparator;

final class ft implements Comparator<Comparable<? super Object>> {
   public static final ft sA = new ft();

   private ft() {
   }

   public int a(Comparable<Object> var1, Comparable<Object> var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      return var2.compareTo(var1);
   }

   public final Comparator<Comparable<Object>> reversed() {
      return fs.sz;
   }

   // $FF: synthetic method
   public int compare(Object var1, Object var2) {
      return this.a((Comparable)var1, (Comparable)var2);
   }
}
