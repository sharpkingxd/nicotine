import java.io.IOException;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

final class aK<T> extends ac<T> {
   private final K cn;
   private final ac<T> co;
   private final Type cp;

   aK(K var1, ac<T> var2, Type var3) {
      this.cn = var1;
      this.co = var2;
      this.cp = var3;
   }

   public T b(aT var1) throws IOException {
      return this.co.b(var1);
   }

   public void a(aV var1, T var2) throws IOException {
      ac var3 = this.co;
      Type var4 = a((Type)this.cp, var2);
      if (var4 != this.cp) {
         ac var5 = this.cn.a(aS.k(var4));
         if (!(var5 instanceof aH.a)) {
            var3 = var5;
         } else if (!d(this.co)) {
            var3 = this.co;
         } else {
            var3 = var5;
         }
      }

      var3.a(var1, var2);
   }

   private static boolean d(ac<?> var0) {
      while(true) {
         if (var0 instanceof aI) {
            ac var1 = ((aI)var0).V();
            if (var1 != var0) {
               var0 = var1;
               continue;
            }
         }

         return var0 instanceof aH.a;
      }
   }

   private static Type a(Type var0, Object var1) {
      if (var1 != null && (var0 instanceof Class || var0 instanceof TypeVariable)) {
         var0 = var1.getClass();
      }

      return (Type)var0;
   }
}
