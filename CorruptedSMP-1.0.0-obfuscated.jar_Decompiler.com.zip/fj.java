class fj extends fi {
}
