import java.io.Closeable;
import java.util.List;

public final class by implements Closeable {
   private final bw request;
   private final bv iQ;
   private final String iR;
   private final int iS;
   private final bp iT;
   private final bq iU;
   private final bz body;
   private final by networkResponse;
   private final by cacheResponse;
   private final by priorResponse;
   private final long sentRequestAtMillis;
   private final long receivedResponseAtMillis;
   private final bQ exchange;
   private ba iP;

   public by(bw var1, bv var2, String var3, int var4, bp var5, bq var6, bz var7, by var8, by var9, by var10, long var11, long var13, bQ var15) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var6, (String)"");
      super();
      this.request = var1;
      this.iQ = var2;
      this.iR = var3;
      this.iS = var4;
      this.iT = var5;
      this.iU = var6;
      this.body = var7;
      this.networkResponse = var8;
      this.cacheResponse = var9;
      this.priorResponse = var10;
      this.sentRequestAtMillis = var11;
      this.receivedResponseAtMillis = var13;
      this.exchange = var15;
   }

   public final bw eT() {
      return this.request;
   }

   public final bv eU() {
      return this.iQ;
   }

   public final String eV() {
      return this.iR;
   }

   public final int eW() {
      return this.iS;
   }

   public final bp eX() {
      return this.iT;
   }

   public final bq eY() {
      return this.iU;
   }

   public final bz eZ() {
      return this.body;
   }

   public final by fa() {
      return this.networkResponse;
   }

   public final by fb() {
      return this.cacheResponse;
   }

   public final by fc() {
      return this.priorResponse;
   }

   public final long fd() {
      return this.sentRequestAtMillis;
   }

   public final long fe() {
      return this.receivedResponseAtMillis;
   }

   public final bQ ff() {
      return this.exchange;
   }

   public final boolean fg() {
      int var1 = this.iS;
      return 200 <= var1 ? var1 < 300 : false;
   }

   public final String j(String var1, String var2) {
      fR.c(var1, (String)"");
      String var10000 = this.iU.E(var1);
      if (var10000 == null) {
         var10000 = var2;
      }

      return var10000;
   }

   // $FF: synthetic method
   public static String a(by var0, String var1, String var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      return var0.j(var1, var2);
   }

   public final a fh() {
      return new a(this);
   }

   public final List<be> fi() {
      bq var10000 = this.iU;
      String var10001;
      switch (this.iS) {
         case 401:
            var10001 = "WWW-Authenticate";
            break;
         case 407:
            var10001 = "Proxy-Authenticate";
            break;
         default:
            return eO.nk();
      }

      return cc.a(var10000, var10001);
   }

   public final ba fj() {
      ba var1 = this.iP;
      if (var1 == null) {
         var1 = ba.et.b(this.iU);
         this.iP = var1;
      }

      return var1;
   }

   public void close() {
      bz var10000 = this.body;
      if (var10000 == null) {
         boolean var1 = false;
         String var2 = "response is not eligible for a body and must not be closed";
         throw new IllegalStateException(var2.toString());
      } else {
         var10000.close();
      }
   }

   public String toString() {
      return "Response{protocol=" + this.iQ + ", code=" + this.iS + ", message=" + this.iR + ", url=" + this.request.eI() + '}';
   }

   public static class a {
      private bw request;
      private bv protocol;
      private int code;
      private String message;
      private bp handshake;
      private bq.a headers;
      private bz body;
      private by networkResponse;
      private by cacheResponse;
      private by priorResponse;
      private long sentRequestAtMillis;
      private long receivedResponseAtMillis;
      private bQ exchange;

      public final int fk() {
         return this.code;
      }

      public a() {
         this.code = -1;
         this.headers = new bq.a();
      }

      public a(by var1) {
         fR.c(var1, (String)"");
         super();
         this.code = -1;
         this.request = var1.eT();
         this.protocol = var1.eU();
         this.code = var1.eW();
         this.message = var1.eV();
         this.handshake = var1.eX();
         this.headers = var1.eY().cU();
         this.body = var1.eZ();
         this.networkResponse = var1.fa();
         this.cacheResponse = var1.fb();
         this.priorResponse = var1.fc();
         this.sentRequestAtMillis = var1.fd();
         this.receivedResponseAtMillis = var1.fe();
         this.exchange = var1.ff();
      }

      public a e(bw var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.request = var1;
         return this;
      }

      public a b(bv var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.protocol = var1;
         return this;
      }

      public a n(int var1) {
         a var3 = this;
         boolean var4 = false;
         var3.code = var1;
         return this;
      }

      public a al(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.message = var1;
         return this;
      }

      public a a(bp var1) {
         a var3 = this;
         boolean var4 = false;
         var3.handshake = var1;
         return this;
      }

      public a k(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         var4.headers.f(var1, var2);
         return this;
      }

      public a l(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         var4.headers.d(var1, var2);
         return this;
      }

      public a d(bq var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.headers = var1.cU();
         return this;
      }

      public a a(bz var1) {
         a var3 = this;
         boolean var4 = false;
         var3.body = var1;
         return this;
      }

      public a d(by var1) {
         a var3 = this;
         boolean var4 = false;
         var3.a("networkResponse", var1);
         var3.networkResponse = var1;
         return this;
      }

      public a e(by var1) {
         a var3 = this;
         boolean var4 = false;
         var3.a("cacheResponse", var1);
         var3.cacheResponse = var1;
         return this;
      }

      private final void a(String var1, by var2) {
         if (var2 != null) {
            boolean var5 = false;
            if (var2.eZ() != null) {
               boolean var12 = false;
               String var13 = var1 + ".body != null";
               throw new IllegalArgumentException(var13.toString());
            }

            if (var2.fa() != null) {
               boolean var10 = false;
               String var11 = var1 + ".networkResponse != null";
               throw new IllegalArgumentException(var11.toString());
            }

            if (var2.fb() != null) {
               boolean var8 = false;
               String var9 = var1 + ".cacheResponse != null";
               throw new IllegalArgumentException(var9.toString());
            }

            if (var2.fc() != null) {
               boolean var6 = false;
               String var7 = var1 + ".priorResponse != null";
               throw new IllegalArgumentException(var7.toString());
            }
         }

      }

      public a f(by var1) {
         a var3 = this;
         boolean var4 = false;
         var3.g(var1);
         var3.priorResponse = var1;
         return this;
      }

      private final void g(by var1) {
         if (var1 != null) {
            boolean var4 = false;
            if (var1.eZ() != null) {
               boolean var5 = false;
               String var6 = "priorResponse.body != null";
               throw new IllegalArgumentException(var6.toString());
            }
         }

      }

      public a d(long var1) {
         a var4 = this;
         boolean var5 = false;
         var4.sentRequestAtMillis = var1;
         return this;
      }

      public a e(long var1) {
         a var4 = this;
         boolean var5 = false;
         var4.receivedResponseAtMillis = var1;
         return this;
      }

      public final void a(bQ var1) {
         fR.c(var1, (String)"");
         this.exchange = var1;
      }

      public by fl() {
         if (this.code < 0) {
            boolean var24 = false;
            String var25 = "code < 0: " + this.code;
            throw new IllegalStateException(var25.toString());
         } else {
            bw var10000 = this.request;
            if (var10000 == null) {
               boolean var22 = false;
               String var23 = "request == null";
               throw new IllegalStateException(var23.toString());
            } else {
               bv var10001 = this.protocol;
               if (var10001 == null) {
                  boolean var20 = false;
                  String var21 = "protocol == null";
                  throw new IllegalStateException(var21.toString());
               } else {
                  String var10002 = this.message;
                  if (var10002 == null) {
                     boolean var1 = false;
                     String var4 = "message == null";
                     throw new IllegalStateException(var4.toString());
                  } else {
                     int var10003 = this.code;
                     bp var10004 = this.handshake;
                     bq var10005 = this.headers.cW();
                     bQ var5 = this.exchange;
                     long var6 = this.receivedResponseAtMillis;
                     long var8 = this.sentRequestAtMillis;
                     by var10 = this.priorResponse;
                     by var11 = this.cacheResponse;
                     by var12 = this.networkResponse;
                     bz var13 = this.body;
                     bq var14 = var10005;
                     bp var15 = var10004;
                     int var16 = var10003;
                     String var17 = var10002;
                     bv var18 = var10001;
                     bw var19 = var10000;
                     return new by(var19, var18, var17, var16, var15, var14, var13, var12, var11, var10, var8, var6, var5);
                  }
               }
            }
         }
      }
   }
}
