public abstract class fx extends fw {
   private final fv _context;
   private transient fu<Object> intercepted;
}
