import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class dc extends dB {
   public static final a Companion = new a((fP)null);
   private boolean inQueue;
   private dc next;
   private long timeoutAt;
   private static final ReentrantLock lock = new ReentrantLock();
   private static final Condition condition;
   private static final int TIMEOUT_WRITE_SIZE = 65536;
   private static final long IDLE_TIMEOUT_MILLIS;
   private static final long IDLE_TIMEOUT_NANOS;
   private static dc head;

   public final void kw() {
      long var1 = this.ls();
      boolean var3 = this.lt();
      if (var1 != 0L || var3) {
         Companion.a(this, var1, var3);
      }
   }

   public final boolean kx() {
      return Companion.d(this);
   }

   private final long s(long var1) {
      return this.timeoutAt - var1;
   }

   protected void hh() {
   }

   public final dy a(final dy var1) {
      fR.c(var1, (String)"");
      return new dy() {
         public void b(de var1x, long var2) {
            fR.c(var1x, (String)"");
            db.b(var1x.kH(), 0L, var2);

            long var14;
            for(long var4 = var2; var4 > 0L; var4 -= var14) {
               var14 = 0L;
               dv var10000 = var1x.pR;
               fR.m(var10000);

               for(dv var6 = var10000; var14 < 65536L; var6 = var10000) {
                  int var7 = var6.dI - var6.dH;
                  var14 += (long)var7;
                  if (var14 >= var4) {
                     var14 = var4;
                     break;
                  }

                  var10000 = var6.qv;
                  fR.m(var10000);
               }

               dc var21 = dc.this;
               dy var8 = var1;
               boolean var9 = false;
               boolean var10 = false;
               var21.kw();
               boolean var18 = false;

               try {
                  var18 = true;
                  boolean var11 = false;
                  var8.b(var1x, var14);
                  eE var12 = eE.sk;
                  var10 = true;
                  var18 = false;
               } catch (IOException var19) {
                  throw !var21.kx() ? (Throwable)var19 : (Throwable)var21.n(var19);
               } finally {
                  if (var18) {
                     boolean var13 = var21.kx();
                     if (var13 && var10) {
                        throw var21.n((IOException)null);
                     }

                  }
               }

               boolean var22 = var21.kx();
               if (var22) {
                  throw var21.n((IOException)null);
               }
            }

         }

         public void flush() {
            dc var1x = dc.this;
            dy var2 = var1;
            boolean var3 = false;
            boolean var4 = false;
            var1x.kw();
            boolean var10 = false;

            try {
               var10 = true;
               boolean var5 = false;
               var2.flush();
               eE var13 = eE.sk;
               var4 = true;
               var10 = false;
            } catch (IOException var11) {
               throw !var1x.kx() ? (Throwable)var11 : (Throwable)var1x.n(var11);
            } finally {
               if (var10) {
                  boolean var6 = var1x.kx();
                  if (var6 && var4) {
                     throw var1x.n((IOException)null);
                  }

               }
            }

            boolean var7 = var1x.kx();
            if (var7) {
               throw var1x.n((IOException)null);
            }
         }

         public void close() {
            dc var1x = dc.this;
            dy var2 = var1;
            boolean var3 = false;
            boolean var4 = false;
            var1x.kw();
            boolean var10 = false;

            try {
               var10 = true;
               boolean var5 = false;
               var2.close();
               eE var13 = eE.sk;
               var4 = true;
               var10 = false;
            } catch (IOException var11) {
               throw !var1x.kx() ? (Throwable)var11 : (Throwable)var1x.n(var11);
            } finally {
               if (var10) {
                  boolean var6 = var1x.kx();
                  if (var6 && var4) {
                     throw var1x.n((IOException)null);
                  }

               }
            }

            boolean var7 = var1x.kx();
            if (var7) {
               throw var1x.n((IOException)null);
            }
         }

         public dc kG() {
            return dc.this;
         }

         public String toString() {
            return "AsyncTimeout.sink(" + var1 + ')';
         }

         // $FF: synthetic method
         public dB fu() {
            return this.kG();
         }
      };
   }

   public final dA a(final dA var1) {
      fR.c(var1, (String)"");
      return new dA() {
         public long a(de var1x, long var2) {
            fR.c(var1x, (String)"");
            dc var4 = dc.this;
            dA var5 = var1;
            boolean var6 = false;
            boolean var7 = false;
            var4.kw();
            boolean var16 = false;

            long var11;
            try {
               var16 = true;
               boolean var8 = false;
               long var9 = var5.a(var1x, var2);
               var7 = true;
               var11 = var9;
               var16 = false;
            } catch (IOException var17) {
               throw !var4.kx() ? (Throwable)var17 : (Throwable)var4.n(var17);
            } finally {
               if (var16) {
                  boolean var19 = var4.kx();
                  if (var19 && var7) {
                     throw var4.n((IOException)null);
                  }

               }
            }

            boolean var13 = var4.kx();
            if (var13) {
               throw var4.n((IOException)null);
            } else {
               return var11;
            }
         }

         public void close() {
            dc var1x = dc.this;
            dA var2 = var1;
            boolean var3 = false;
            boolean var4 = false;
            var1x.kw();
            boolean var10 = false;

            try {
               var10 = true;
               boolean var5 = false;
               var2.close();
               eE var13 = eE.sk;
               var4 = true;
               var10 = false;
            } catch (IOException var11) {
               throw !var1x.kx() ? (Throwable)var11 : (Throwable)var1x.n(var11);
            } finally {
               if (var10) {
                  boolean var6 = var1x.kx();
                  if (var6 && var4) {
                     throw var1x.n((IOException)null);
                  }

               }
            }

            boolean var7 = var1x.kx();
            if (var7) {
               throw var1x.n((IOException)null);
            }
         }

         public dc kG() {
            return dc.this;
         }

         public String toString() {
            return "AsyncTimeout.source(" + var1 + ')';
         }

         // $FF: synthetic method
         public dB fu() {
            return this.kG();
         }
      };
   }

   public final IOException n(IOException var1) {
      return this.m(var1);
   }

   protected IOException m(IOException var1) {
      InterruptedIOException var2 = new InterruptedIOException("timeout");
      if (var1 != null) {
         var2.initCause((Throwable)var1);
      }

      return (IOException)var2;
   }

   static {
      Condition var10000 = lock.newCondition();
      fR.b(var10000, "");
      condition = var10000;
      IDLE_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(60L);
      IDLE_TIMEOUT_NANOS = TimeUnit.MILLISECONDS.toNanos(IDLE_TIMEOUT_MILLIS);
   }

   public static final class a {
      private a() {
      }

      public final ReentrantLock kD() {
         return dc.lock;
      }

      public final Condition kE() {
         return dc.condition;
      }

      private final void a(dc var1, long var2, boolean var4) {
         Lock var5 = (Lock)dc.Companion.kD();
         var5.lock();

         try {
            boolean var6 = false;
            if (var1.inQueue) {
               boolean var7 = false;
               String var16 = "Unbalanced enter/exit";
               throw new IllegalStateException(var16.toString());
            }

            var1.inQueue = true;
            if (dc.head == null) {
               a var10000 = dc.Companion;
               dc.head = new dc();
               (new b()).start();
            }

            long var8 = System.nanoTime();
            if (var2 != 0L && var4) {
               var1.timeoutAt = var8 + Math.min(var2, var1.lu() - var8);
            } else if (var2 != 0L) {
               var1.timeoutAt = var8 + var2;
            } else {
               if (!var4) {
                  throw new AssertionError();
               }

               var1.timeoutAt = var1.lu();
            }

            long var10 = var1.s(var8);
            dc var17 = dc.head;
            fR.m(var17);

            dc var12;
            for(var12 = var17; var12.next != null; var12 = var17) {
               dc var10001 = var12.next;
               fR.m(var10001);
               if (var10 < var10001.s(var8)) {
                  break;
               }

               var17 = var12.next;
               fR.m(var17);
            }

            var1.next = var12.next;
            var12.next = var1;
            if (var12 == dc.head) {
               dc.Companion.kE().signal();
            }

            eE var15 = eE.sk;
         } finally {
            var5.unlock();
         }

      }

      private final boolean d(dc var1) {
         Lock var2 = (Lock)dc.Companion.kD();
         var2.lock();

         boolean var7;
         try {
            boolean var3 = false;
            if (var1.inQueue) {
               var1.inQueue = false;

               for(dc var4 = dc.head; var4 != null; var4 = var4.next) {
                  if (var4.next == var1) {
                     var4.next = var1.next;
                     var1.next = null;
                     boolean var6 = false;
                     return var6;
                  }
               }

               boolean var5 = true;
               return var5;
            }

            var7 = false;
         } finally {
            var2.unlock();
         }

         return var7;
      }

      public final dc kF() throws InterruptedException {
         dc var10000 = dc.head;
         fR.m(var10000);
         dc var1 = var10000.next;
         if (var1 != null) {
            long var4 = var1.s(System.nanoTime());
            if (var4 > 0L) {
               this.kE().await(var4, TimeUnit.NANOSECONDS);
               return null;
            } else {
               var10000 = dc.head;
               fR.m(var10000);
               var10000.next = var1.next;
               var1.next = null;
               return var1;
            }
         } else {
            long var2 = System.nanoTime();
            this.kE().await(dc.IDLE_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS);
            var10000 = dc.head;
            fR.m(var10000);
            return var10000.next == null && System.nanoTime() - var2 >= dc.IDLE_TIMEOUT_NANOS ? dc.head : null;
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   static final class b extends Thread {
      public b() {
         super("Okio Watchdog");
         this.setDaemon(true);
      }

      public void run() {
         while(true) {
            try {
               dc var1 = null;
               Lock var2 = (Lock)dc.Companion.kD();
               var2.lock();

               try {
                  boolean var3 = false;
                  var1 = dc.Companion.kF();
                  if (var1 == dc.head) {
                     a var10000 = dc.Companion;
                     dc.head = null;
                     return;
                  }

                  eE var9 = eE.sk;
               } finally {
                  var2.unlock();
               }

               if (var1 != null) {
                  var1.hh();
               }
            } catch (InterruptedException var7) {
            }
         }
      }
   }
}
