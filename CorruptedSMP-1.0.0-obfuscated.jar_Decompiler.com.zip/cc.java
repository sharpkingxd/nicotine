import java.io.EOFException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class cc {
   private static final dh lP;
   private static final dh lQ;

   public static final List<be> a(bq var0, String var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      List var2 = (List)(new ArrayList());
      int var3 = 0;

      for(int var4 = var0.cT(); var3 < var4; ++var3) {
         if (gA.a(var1, var0.j(var3), true)) {
            de var5 = (new de()).aQ(var0.k(var3));

            try {
               a(var5, var2);
            } catch (EOFException var7) {
               cH.oU.jZ().a("Unable to parse challenge", 5, (Throwable)var7);
            }
         }
      }

      return var2;
   }

   private static final void a(de var0, List<be> var1) throws EOFException {
      String var2 = null;

      while(true) {
         if (var2 == null) {
            a(var0);
            var2 = c(var0);
            if (var2 == null) {
               return;
            }
         }

         String var3 = var2;
         boolean var4 = a(var0);
         var2 = c(var0);
         if (var2 == null) {
            if (!var0.kK()) {
               return;
            }

            var1.add(new be(var3, fe.nr()));
            return;
         }

         int var5 = bD.a((de)var0, (byte)61);
         boolean var6 = a(var0);
         if (!var4 && (var6 || var0.kK())) {
            Map var10004 = Collections.singletonMap((Object)null, var2 + gA.a((CharSequence)"=", var5));
            fR.b(var10004, "");
            var1.add(new be(var3, var10004));
            var2 = null;
         } else {
            Map var7 = (Map)(new LinkedHashMap());
            var5 += bD.a((de)var0, (byte)61);

            while(true) {
               if (var2 == null) {
                  var2 = c(var0);
                  if (a(var0)) {
                     break;
                  }

                  var5 = bD.a((de)var0, (byte)61);
               }

               if (var5 == 0) {
                  break;
               }

               if (var5 > 1) {
                  return;
               }

               if (a(var0)) {
                  return;
               }

               String var10000 = b(var0, (byte)34) ? b(var0) : c(var0);
               if (var10000 == null) {
                  return;
               }

               String var8 = var10000;
               String var9 = (String)var7.put(var2, var8);
               var2 = null;
               if (var9 != null) {
                  return;
               }

               if (!a(var0) && !var0.kK()) {
                  return;
               }
            }

            var1.add(new be(var3, var7));
         }
      }
   }

   private static final boolean a(de var0) {
      boolean var1 = false;

      while(!var0.kK()) {
         byte var2 = var0.v(0L);
         if (var2 == 44) {
            var0.kN();
            var1 = true;
         } else {
            if (!(var2 == 32 ? true : var2 == 9)) {
               break;
            }

            var0.kN();
         }
      }

      return var1;
   }

   private static final boolean b(de var0, byte var1) {
      return !var0.kK() && var0.v(0L) == var1;
   }

   private static final String b(de var0) throws EOFException {
      if (var0.kN() != 34) {
         String var4 = "Failed requirement.";
         throw new IllegalArgumentException(var4.toString());
      } else {
         de var1 = new de();

         while(true) {
            long var2 = var0.e(lP);
            if (var2 == -1L) {
               return null;
            }

            if (var0.v(var2) == 34) {
               var1.b(var0, var2);
               var0.kN();
               return var1.kU();
            }

            if (var0.kH() == var2 + 1L) {
               return null;
            }

            var1.b(var0, var2);
            var0.kN();
            var1.b(var0, 1L);
         }
      }
   }

   private static final String c(de var0) {
      long var1 = var0.e(lQ);
      if (var1 == -1L) {
         var1 = var0.kH();
      }

      return var1 != 0L ? var0.x(var1) : null;
   }

   public static final void a(bk var0, br var1, bq var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      if (var0 != bk.hy) {
         List var3 = bj.hj.a(var1, var2);
         if (!var3.isEmpty()) {
            var0.a(var1, var3);
         }
      }
   }

   public static final boolean n(by var0) {
      fR.c(var0, (String)"");
      if (fR.c(var0.eT().eJ(), (Object)"HEAD")) {
         return false;
      } else {
         int var1 = var0.eW();
         if ((var1 < 100 || var1 >= 200) && var1 != 204 && var1 != 304) {
            return true;
         } else {
            return bD.h(var0) != -1L || gA.a("chunked", by.a(var0, "Transfer-Encoding", (String)null, 2, (Object)null), true);
         }
      }
   }

   static {
      lP = dh.pS.aU("\"\\");
      lQ = dh.pS.aU("\t ,=");
   }
}
