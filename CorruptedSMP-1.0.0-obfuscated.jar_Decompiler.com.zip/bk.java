import java.util.List;

public interface bk {
   a hx = bk.a.$$INSTANCE;
   bk hy = new a.a();

   void a(br var1, List<bj> var2);

   List<bj> b(br var1);

   public static final class a {
      // $FF: synthetic field
      static final a $$INSTANCE = new a();

      private a() {
      }

      static final class a implements bk {
         public a() {
         }

         public void a(br var1, List<bj> var2) {
            fR.c(var1, (String)"");
            fR.c(var2, (String)"");
         }

         public List<bj> b(br var1) {
            fR.c(var1, (String)"");
            return eO.nk();
         }
      }
   }
}
