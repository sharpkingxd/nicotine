import java.util.Iterator;

public final class gs$a implements fY, Iterable<T> {
   // $FF: synthetic field
   final gm th;

   public gs$a(gm var1) {
      this.th = var1;
   }

   public Iterator<T> iterator() {
      boolean var1 = false;
      return this.th.iterator();
   }
}
