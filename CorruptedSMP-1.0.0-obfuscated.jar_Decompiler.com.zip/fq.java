class fq extends fp {
}
