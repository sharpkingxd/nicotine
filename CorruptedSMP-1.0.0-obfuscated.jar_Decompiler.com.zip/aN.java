import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class aN {
   private static final a dp;

   public static void a(AccessibleObject var0) throws Q {
      try {
         var0.setAccessible(true);
      } catch (Exception var3) {
         String var2 = a(var0, false);
         throw new Q("Failed making " + var2 + " accessible; either increase its visibility or write a custom TypeAdapter for its declaring type.", var3);
      }
   }

   public static String a(AccessibleObject var0, boolean var1) {
      String var2;
      if (var0 instanceof Field) {
         var2 = "field '" + c((Field)var0) + "'";
      } else if (var0 instanceof Method) {
         Method var3 = (Method)var0;
         StringBuilder var4 = new StringBuilder(var3.getName());
         a(var3, (StringBuilder)var4);
         String var5 = var4.toString();
         var2 = "method '" + var3.getDeclaringClass().getName() + "#" + var5 + "'";
      } else if (var0 instanceof Constructor) {
         var2 = "constructor '" + a((Constructor)var0) + "'";
      } else {
         var2 = "<unknown AccessibleObject> " + var0.toString();
      }

      if (var1 && Character.isLowerCase(var2.charAt(0))) {
         var2 = Character.toUpperCase(var2.charAt(0)) + var2.substring(1);
      }

      return var2;
   }

   public static String c(Field var0) {
      return var0.getDeclaringClass().getName() + "#" + var0.getName();
   }

   public static String a(Constructor<?> var0) {
      StringBuilder var1 = new StringBuilder(var0.getDeclaringClass().getName());
      a(var0, (StringBuilder)var1);
      return var1.toString();
   }

   private static void a(AccessibleObject var0, StringBuilder var1) {
      var1.append('(');
      Class[] var2 = var0 instanceof Method ? ((Method)var0).getParameterTypes() : ((Constructor)var0).getParameterTypes();

      for(int var3 = 0; var3 < var2.length; ++var3) {
         if (var3 > 0) {
            var1.append(", ");
         }

         var1.append(var2[var3].getSimpleName());
      }

      var1.append(')');
   }

   public static String b(Constructor<?> var0) {
      try {
         var0.setAccessible(true);
         return null;
      } catch (Exception var2) {
         return "Failed making constructor '" + a(var0) + "' accessible; either increase its visibility or write a custom InstanceCreator or TypeAdapter for its declaring type: " + var2.getMessage();
      }
   }

   public static boolean q(Class<?> var0) {
      return dp.q(var0);
   }

   public static String[] r(Class<?> var0) {
      return dp.r(var0);
   }

   public static Method a(Class<?> var0, Field var1) {
      return dp.a(var0, var1);
   }

   public static <T> Constructor<T> s(Class<T> var0) {
      return dp.<T>s(var0);
   }

   public static RuntimeException a(IllegalAccessException var0) {
      throw new RuntimeException("Unexpected IllegalAccessException occurred (Gson 2.10.1). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers.", var0);
   }

   private static RuntimeException a(ReflectiveOperationException var0) {
      throw new RuntimeException("Unexpected ReflectiveOperationException occurred (Gson 2.10.1). To support Java records, reflection is utilized to read out information about records. All these invocations happens after it is established that records exist in the JVM. This exception is unexpected behavior.", var0);
   }

   static {
      Object var0;
      try {
         var0 = new c();
      } catch (NoSuchMethodException var2) {
         var0 = new b();
      }

      dp = (a)var0;
   }

   abstract static class a {
      private a() {
      }

      abstract boolean q(Class<?> var1);

      abstract String[] r(Class<?> var1);

      abstract <T> Constructor<T> s(Class<T> var1);

      public abstract Method a(Class<?> var1, Field var2);
   }

   static class b extends a {
      private b() {
      }

      boolean q(Class<?> var1) {
         return false;
      }

      String[] r(Class<?> var1) {
         throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
      }

      <T> Constructor<T> s(Class<T> var1) {
         throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
      }

      public Method a(Class<?> var1, Field var2) {
         throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
      }
   }

   static class c extends a {
      private final Method isRecord;
      private final Method getRecordComponents;
      private final Method getName;
      private final Method getType;

      private c() throws NoSuchMethodException {
         this.isRecord = Class.class.getMethod("isRecord");
         this.getRecordComponents = Class.class.getMethod("getRecordComponents");
         Class var1 = this.getRecordComponents.getReturnType().getComponentType();
         this.getName = var1.getMethod("getName");
         this.getType = var1.getMethod("getType");
      }

      boolean q(Class<?> var1) {
         try {
            return (Boolean)this.isRecord.invoke(var1);
         } catch (ReflectiveOperationException var3) {
            throw aN.a(var3);
         }
      }

      String[] r(Class<?> var1) {
         try {
            Object[] var2 = this.getRecordComponents.invoke(var1);
            String[] var3 = new String[var2.length];

            for(int var4 = 0; var4 < var2.length; ++var4) {
               var3[var4] = (String)this.getName.invoke(var2[var4]);
            }

            return var3;
         } catch (ReflectiveOperationException var5) {
            throw aN.a(var5);
         }
      }

      public <T> Constructor<T> s(Class<T> var1) {
         try {
            Object[] var2 = this.getRecordComponents.invoke(var1);
            Class[] var3 = new Class[var2.length];

            for(int var4 = 0; var4 < var2.length; ++var4) {
               var3[var4] = (Class)this.getType.invoke(var2[var4]);
            }

            return var1.getDeclaredConstructor(var3);
         } catch (ReflectiveOperationException var5) {
            throw aN.a(var5);
         }
      }

      public Method a(Class<?> var1, Field var2) {
         try {
            return var1.getMethod(var2.getName());
         } catch (ReflectiveOperationException var4) {
            throw aN.a(var4);
         }
      }
   }
}
