import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public final class fc implements fY, Serializable, Set {
   public static final fc sy = new fc();
   private static final long serialVersionUID = 3406603774387020532L;

   private fc() {
   }

   public boolean equals(Object var1) {
      return var1 instanceof Set && ((Set)var1).isEmpty();
   }

   public int hashCode() {
      return 0;
   }

   public String toString() {
      return "[]";
   }

   public int getSize() {
      return 0;
   }

   public boolean isEmpty() {
      return true;
   }

   public boolean a(Void var1) {
      fR.c(var1, (String)"");
      return false;
   }

   public boolean containsAll(Collection var1) {
      fR.c(var1, (String)"");
      return var1.isEmpty();
   }

   public Iterator iterator() {
      return (Iterator)eZ.sv;
   }

   private final Object readResolve() {
      return sy;
   }

   public boolean addAll(Collection var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void clear() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean remove(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean removeAll(Collection var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean retainAll(Collection var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public final int size() {
      return this.getSize();
   }

   public final boolean contains(Object var1) {
      return !(var1 instanceof Void) ? false : this.a((Void)var1);
   }

   // $FF: synthetic method
   public boolean add(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public <T> T[] toArray(T[] var1) {
      fR.c(var1, (String)"");
      return (T[])fO.b((Collection)this, var1);
   }

   public Object[] toArray() {
      return fO.c((Collection)this);
   }
}
