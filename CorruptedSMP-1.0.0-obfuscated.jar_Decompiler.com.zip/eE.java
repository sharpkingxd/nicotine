public final class eE {
   public static final eE sk = new eE();

   private eE() {
   }

   public String toString() {
      return "kotlin.Unit";
   }
}
