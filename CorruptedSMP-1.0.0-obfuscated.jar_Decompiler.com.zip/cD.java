import java.security.KeyStore;
import java.security.Provider;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.conscrypt.Conscrypt;
import org.conscrypt.ConscryptHostnameVerifier;

public final class cD extends cH {
   public static final a oG = new a((fP)null);
   private final Provider oH;
   private static final boolean oI;

   private cD() {
      Provider var10001 = Conscrypt.newProvider();
      fR.b(var10001, "");
      this.oH = var10001;
   }

   public SSLContext jG() {
      SSLContext var10000 = SSLContext.getInstance("TLS", this.oH);
      fR.b(var10000, "");
      return var10000;
   }

   public X509TrustManager jH() {
      TrustManagerFactory var2 = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      boolean var4 = false;
      var2.init((KeyStore)null);
      TrustManager var10000 = var2.getTrustManagers();
      fR.m(var10000);
      TrustManager[] var1 = var10000;
      if (var1.length != 1 || !(var1[0] instanceof X509TrustManager)) {
         boolean var3 = false;
         StringBuilder var8 = (new StringBuilder()).append("Unexpected default trust managers: ");
         String var10001 = Arrays.toString(var1);
         fR.b(var10001, "");
         String var6 = var8.append(var10001).toString();
         throw new IllegalStateException(var6.toString());
      } else {
         var10000 = var1[0];
         fR.m(var1[0]);
         X509TrustManager var5 = (X509TrustManager)var10000;
         Conscrypt.setHostnameVerifier((TrustManager)var5, cD.b.INSTANCE);
         return var5;
      }
   }

   public void a(SSLSocket var1, String var2, List<bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      if (Conscrypt.isConscrypt(var1)) {
         Conscrypt.setUseSessionTickets(var1, true);
         List var4 = cH.oU.h(var3);
         Collection var5 = (Collection)var4;
         boolean var6 = false;
         Conscrypt.setApplicationProtocols(var1, (String[])var5.toArray(new String[0]));
      } else {
         super.a(var1, var2, var3);
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      return Conscrypt.isConscrypt(var1) ? Conscrypt.getApplicationProtocol(var1) : super.d(var1);
   }

   public SSLSocketFactory c(X509TrustManager var1) {
      fR.c(var1, (String)"");
      SSLContext var2 = this.jG();
      boolean var4 = false;
      TrustManager[] var5 = new TrustManager[]{var1};
      var2.init((KeyManager[])null, var5, (SecureRandom)null);
      SSLSocketFactory var10000 = var2.getSocketFactory();
      fR.b(var10000, "");
      return var10000;
   }

   // $FF: synthetic method
   public cD(fP var1) {
      this();
   }

   static {
      boolean var0;
      try {
         Class.forName("org.conscrypt.Conscrypt$Version", false, oG.getClass().getClassLoader());
         var0 = Conscrypt.isAvailable() && oG.d(2, 1, 0);
      } catch (NoClassDefFoundError var2) {
         var0 = false;
      } catch (ClassNotFoundException var3) {
         var0 = false;
      }

      oI = var0;
   }

   public static final class a {
      private a() {
      }

      public final boolean jM() {
         return cD.oI;
      }

      public final cD jN() {
         return this.jM() ? new cD((fP)null) : null;
      }

      public final boolean d(int var1, int var2, int var3) {
         Conscrypt.Version var4 = Conscrypt.version();
         if (var4.major() != var1) {
            return var4.major() > var1;
         } else if (var4.minor() != var2) {
            return var4.minor() > var2;
         } else {
            return var4.patch() >= var3;
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public static final class b implements ConscryptHostnameVerifier {
      public static final b INSTANCE = new b();

      private b() {
      }
   }
}
