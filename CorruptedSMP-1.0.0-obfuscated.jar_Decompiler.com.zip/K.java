import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

public final class K {
   static final String au = null;
   static final J av;
   static final ab aw;
   static final ab ax;
   private final ThreadLocal<Map<aS<?>, ac<?>>> ay;
   private final ConcurrentMap<aS<?>, ac<?>> az;
   private final al aA;
   private final aB aB;
   final List<ad> aC;
   final am aD;
   final J aE;
   final Map<Type, L<?>> aF;
   final boolean aG;
   final boolean aH;
   final boolean aI;
   final boolean aJ;
   final boolean aK;
   final boolean aL;
   final boolean aM;
   final boolean aN;
   final String aO;
   final int aP;
   final int aQ;
   final Y aR;
   final List<ad> aS;
   final List<ad> aT;
   final ab aU;
   final ab aV;
   final List<Z> aW;

   public K() {
      this(am.bh, av, Collections.emptyMap(), false, false, false, true, false, false, false, true, Y.DEFAULT, au, 2, 2, Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), aw, ax, Collections.emptyList());
   }

   K(am var1, J var2, Map<Type, L<?>> var3, boolean var4, boolean var5, boolean var6, boolean var7, boolean var8, boolean var9, boolean var10, boolean var11, Y var12, String var13, int var14, int var15, List<ad> var16, List<ad> var17, List<ad> var18, ab var19, ab var20, List<Z> var21) {
      this.ay = new ThreadLocal();
      this.az = new ConcurrentHashMap();
      this.aD = var1;
      this.aE = var2;
      this.aF = var3;
      this.aA = new al(var3, var11, var21);
      this.aG = var4;
      this.aH = var5;
      this.aI = var6;
      this.aJ = var7;
      this.aK = var8;
      this.aL = var9;
      this.aM = var10;
      this.aN = var11;
      this.aR = var12;
      this.aO = var13;
      this.aP = var14;
      this.aQ = var15;
      this.aS = var16;
      this.aT = var17;
      this.aU = var19;
      this.aV = var20;
      this.aW = var21;
      ArrayList var22 = new ArrayList();
      var22.add(aL.dm);
      var22.add(aG.b(var19));
      var22.add(var1);
      var22.addAll(var18);
      var22.add(aL.cS);
      var22.add(aL.cC);
      var22.add(aL.cw);
      var22.add(aL.cy);
      var22.add(aL.cA);
      ac var23 = a(var12);
      var22.add(aL.a(Long.TYPE, Long.class, var23));
      var22.add(aL.a(Double.TYPE, Double.class, this.c(var10)));
      var22.add(aL.a(Float.TYPE, Float.class, this.d(var10)));
      var22.add(aF.b(var20));
      var22.add(aL.cE);
      var22.add(aL.cG);
      var22.add(aL.a(AtomicLong.class, a(var23)));
      var22.add(aL.a(AtomicLongArray.class, b(var23)));
      var22.add(aL.cI);
      var22.add(aL.cN);
      var22.add(aL.cU);
      var22.add(aL.cW);
      var22.add(aL.a(BigDecimal.class, aL.cP));
      var22.add(aL.a(BigInteger.class, aL.cQ));
      var22.add(aL.a(ap.class, aL.cR));
      var22.add(aL.cY);
      var22.add(aL.da);
      var22.add(aL.de);
      var22.add(aL.dg);
      var22.add(aL.dk);
      var22.add(aL.dc);
      var22.add(aL.ct);
      var22.add(az.bE);
      var22.add(aL.di);
      if (aR.dw) {
         var22.add(aR.dA);
         var22.add(aR.dz);
         var22.add(aR.dB);
      }

      var22.add(ax.bA);
      var22.add(aL.cr);
      var22.add(new ay(this.aA));
      var22.add(new aE(this.aA, var5));
      this.aB = new aB(this.aA);
      var22.add(this.aB);
      var22.add(aL.dn);
      var22.add(new aH(this.aA, var2, var1, this.aB, var21));
      this.aC = Collections.unmodifiableList(var22);
   }

   private ac<Number> c(boolean var1) {
      return var1 ? aL.cL : new ac<Number>() {
         public Double a(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return var1.aP();
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               double var3 = var2.doubleValue();
               K.c(var3);
               var1.d(var3);
            }
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.a(var1);
         }
      };
   }

   private ac<Number> d(boolean var1) {
      return var1 ? aL.cK : new ac<Number>() {
         public Float c(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return (float)var1.aP();
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               float var3 = var2.floatValue();
               K.c((double)var3);
               Object var4 = var2 instanceof Float ? var2 : var3;
               var1.a((Number)var4);
            }
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.c(var1);
         }
      };
   }

   static void c(double var0) {
      if (Double.isNaN(var0) || Double.isInfinite(var0)) {
         throw new IllegalArgumentException(var0 + " is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
      }
   }

   private static ac<Number> a(Y var0) {
      return var0 == Y.DEFAULT ? aL.cJ : new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return var1.aQ();
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.t(var2.toString());
            }
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
   }

   private static ac<AtomicLong> a(final ac<Number> var0) {
      return (new ac<AtomicLong>() {
         public void a(aV var1, AtomicLong var2) throws IOException {
            var0.a(var1, var2.get());
         }

         public AtomicLong e(aT var1) throws IOException {
            Number var2 = (Number)var0.b(var1);
            return new AtomicLong(var2.longValue());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.e(var1);
         }
      }).an();
   }

   private static ac<AtomicLongArray> b(final ac<Number> var0) {
      return (new ac<AtomicLongArray>() {
         public void a(aV var1, AtomicLongArray var2) throws IOException {
            var1.ba();
            int var3 = 0;

            for(int var4 = var2.length(); var3 < var4; ++var3) {
               var0.a(var1, var2.get(var3));
            }

            var1.bb();
         }

         public AtomicLongArray f(aT var1) throws IOException {
            ArrayList var2 = new ArrayList();
            var1.aE();

            while(var1.hasNext()) {
               long var3 = ((Number)var0.b(var1)).longValue();
               var2.add(var3);
            }

            var1.aF();
            int var6 = var2.size();
            AtomicLongArray var4 = new AtomicLongArray(var6);

            for(int var5 = 0; var5 < var6; ++var5) {
               var4.set(var5, (Long)var2.get(var5));
            }

            return var4;
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.f(var1);
         }
      }).an();
   }

   public <T> ac<T> a(aS<T> var1) {
      Objects.requireNonNull(var1, "type must not be null");
      ac var2 = (ac)this.az.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         Object var3 = (Map)this.ay.get();
         boolean var4 = false;
         if (var3 == null) {
            var3 = new HashMap();
            this.ay.set(var3);
            var4 = true;
         } else {
            ac var5 = (ac)((Map)var3).get(var1);
            if (var5 != null) {
               return var5;
            }
         }

         ac var12 = null;

         try {
            a var6 = new a();
            ((Map)var3).put(var1, var6);

            for(ad var8 : this.aC) {
               var12 = var8.a(this, var1);
               if (var12 != null) {
                  var6.c(var12);
                  ((Map)var3).put(var1, var12);
                  break;
               }
            }
         } finally {
            if (var4) {
               this.ay.remove();
            }

         }

         if (var12 == null) {
            throw new IllegalArgumentException("GSON (2.10.1) cannot handle " + var1);
         } else {
            if (var4) {
               this.az.putAll((Map)var3);
            }

            return var12;
         }
      }
   }

   public <T> ac<T> a(ad var1, aS<T> var2) {
      if (!this.aC.contains(var1)) {
         var1 = this.aB;
      }

      boolean var3 = false;

      for(ad var5 : this.aC) {
         if (!var3) {
            if (var5 == var1) {
               var3 = true;
            }
         } else {
            ac var6 = var5.a(this, var2);
            if (var6 != null) {
               return var6;
            }
         }
      }

      throw new IllegalArgumentException("GSON cannot serialize " + var2);
   }

   public <T> ac<T> b(Class<T> var1) {
      return this.a(aS.t(var1));
   }

   public aT a(Reader var1) {
      aT var2 = new aT(var1);
      var2.i(this.aL);
      return var2;
   }

   public <T> T a(String var1, Class<T> var2) throws X {
      Object var3 = this.a(var1, aS.t(var2));
      return (T)at.j(var2).cast(var3);
   }

   public <T> T a(String var1, aS<T> var2) throws X {
      if (var1 == null) {
         return null;
      } else {
         StringReader var3 = new StringReader(var1);
         return (T)this.a((Reader)var3, var2);
      }
   }

   public <T> T a(Reader var1, aS<T> var2) throws Q, X {
      aT var3 = this.a(var1);
      Object var4 = this.a(var3, var2);
      a(var4, var3);
      return (T)var4;
   }

   private static void a(Object var0, aT var1) {
      try {
         if (var0 != null && var1.aI() != aU.dZ) {
            throw new X("JSON document was not fully consumed.");
         }
      } catch (aW var3) {
         throw new X(var3);
      } catch (IOException var4) {
         throw new Q(var4);
      }
   }

   public <T> T a(aT var1, aS<T> var2) throws Q, X {
      boolean var3 = true;
      boolean var4 = var1.bm();
      var1.i(true);

      Object var6;
      try {
         var1.aI();
         var3 = false;
         ac var5 = this.a(var2);
         var6 = var5.b(var1);
         return (T)var6;
      } catch (EOFException var13) {
         if (!var3) {
            throw new X(var13);
         }

         var6 = null;
      } catch (IllegalStateException var14) {
         throw new X(var14);
      } catch (IOException var15) {
         throw new X(var15);
      } catch (AssertionError var16) {
         throw new AssertionError("AssertionError (GSON 2.10.1): " + var16.getMessage(), var16);
      } finally {
         var1.i(var4);
      }

      return (T)var6;
   }

   public String toString() {
      return "{serializeNulls:" + this.aG + ",factories:" + this.aC + ",instanceCreators:" + this.aA + "}";
   }

   static {
      av = I.IDENTITY;
      aw = aa.DOUBLE;
      ax = aa.LAZILY_PARSED_NUMBER;
   }

   static class a<T> extends aI<T> {
      private ac<T> delegate = null;

      public void c(ac<T> var1) {
         if (this.delegate != null) {
            throw new AssertionError("Delegate is already set");
         } else {
            this.delegate = var1;
         }
      }

      private ac<T> U() {
         ac var1 = this.delegate;
         if (var1 == null) {
            throw new IllegalStateException("Adapter for type with cyclic dependency has been used before dependency has been resolved");
         } else {
            return var1;
         }
      }

      public ac<T> V() {
         return this.U();
      }

      public T b(aT var1) throws IOException {
         return (T)this.U().b(var1);
      }

      public void a(aV var1, T var2) throws IOException {
         this.U().a(var1, var2);
      }
   }
}
