import java.io.IOException;
import java.io.StringWriter;

public abstract class P {
   public boolean ad() {
      return this instanceof M;
   }

   public boolean ae() {
      return this instanceof S;
   }

   public boolean af() {
      return this instanceof U;
   }

   public boolean ag() {
      return this instanceof R;
   }

   public S ah() {
      if (this.ae()) {
         return (S)this;
      } else {
         throw new IllegalStateException("Not a JSON Object: " + this);
      }
   }

   public M ai() {
      if (this.ad()) {
         return (M)this;
      } else {
         throw new IllegalStateException("Not a JSON Array: " + this);
      }
   }

   public U aj() {
      if (this.af()) {
         return (U)this;
      } else {
         throw new IllegalStateException("Not a JSON Primitive: " + this);
      }
   }

   public boolean ac() {
      throw new UnsupportedOperationException(this.getClass().getSimpleName());
   }

   public Number X() {
      throw new UnsupportedOperationException(this.getClass().getSimpleName());
   }

   public String Y() {
      throw new UnsupportedOperationException(this.getClass().getSimpleName());
   }

   public double Z() {
      throw new UnsupportedOperationException(this.getClass().getSimpleName());
   }

   public long aa() {
      throw new UnsupportedOperationException(this.getClass().getSimpleName());
   }

   public int ab() {
      throw new UnsupportedOperationException(this.getClass().getSimpleName());
   }

   public String toString() {
      try {
         StringWriter var1 = new StringWriter();
         aV var2 = new aV(var1);
         var2.k(true);
         av.a(this, var2);
         return var1.toString();
      } catch (IOException var3) {
         throw new AssertionError(var3);
      }
   }
}
