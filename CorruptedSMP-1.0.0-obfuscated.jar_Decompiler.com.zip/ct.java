import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import java.util.Collection;

public final class ct {
   public static final a nS = new a((fP)null);
   private final int nT;
   private final cq nU;
   private long nv;
   private long nw;
   private long nx;
   private long ny;
   private final ArrayDeque<bq> nV;
   private boolean nW;
   private final c nX;
   private final b nY;
   private final d nZ;
   private final d oa;
   private cm ob;
   private IOException oc;

   public ct(int var1, cq var2, boolean var3, boolean var4, bq var5) {
      fR.c(var2, (String)"");
      super();
      this.nT = var1;
      this.nU = var2;
      this.ny = (long)this.nU.is().jx();
      this.nV = new ArrayDeque();
      this.nX = new c((long)this.nU.ir().jx(), var4);
      this.nY = new b(var3);
      this.nZ = new d();
      this.oa = new d();
      if (var5 != null) {
         if (this.jd()) {
            boolean var6 = false;
            String var7 = "locally-initiated streams shouldn't have headers yet";
            throw new IllegalStateException(var7.toString());
         }

         ((Collection)this.nV).add(var5);
      } else if (!this.jd()) {
         boolean var8 = false;
         String var9 = "remotely-initiated streams should have headers";
         throw new IllegalStateException(var9.toString());
      }

   }

   public final int iR() {
      return this.nT;
   }

   public final cq iS() {
      return this.nU;
   }

   public final long iT() {
      return this.nv;
   }

   public final void n(long var1) {
      this.nv = var1;
   }

   public final long iU() {
      return this.nw;
   }

   public final void o(long var1) {
      this.nw = var1;
   }

   public final long iV() {
      return this.nx;
   }

   public final void p(long var1) {
      this.nx = var1;
   }

   public final long iW() {
      return this.ny;
   }

   public final c iX() {
      return this.nX;
   }

   public final b iY() {
      return this.nY;
   }

   public final d iZ() {
      return this.nZ;
   }

   public final d ja() {
      return this.oa;
   }

   public final synchronized cm jb() {
      return this.ob;
   }

   public final IOException jc() {
      return this.oc;
   }

   public final synchronized boolean isOpen() {
      if (this.ob != null) {
         return false;
      } else {
         return !this.nX.jn() && !this.nX.jo() || !this.nY.jl() && !this.nY.jm() || !this.nW;
      }
   }

   public final boolean jd() {
      boolean var1 = (this.nT & 1) == 1;
      return this.nU.il() == var1;
   }

   public final synchronized bq je() throws IOException {
      this.nZ.kw();

      try {
         while(this.nV.isEmpty() && this.ob == null) {
            this.jk();
         }
      } finally {
         this.nZ.jp();
      }

      if (!((Collection)this.nV).isEmpty()) {
         Object var5 = this.nV.removeFirst();
         fR.b(var5, "");
         return (bq)var5;
      } else {
         IOException var10000 = this.oc;
         Throwable var4;
         if (var10000 != null) {
            var4 = (Throwable)var10000;
         } else {
            cm var10002 = this.ob;
            fR.m(var10002);
            var4 = (Throwable)(new cy(var10002));
         }

         throw var4;
      }
   }

   public final dB jf() {
      return this.nZ;
   }

   public final dB jg() {
      return this.oa;
   }

   public final dy jh() {
      synchronized(this){}

      try {
         boolean var2 = false;
         if (!this.nW && !this.jd()) {
            boolean var3 = false;
            String var7 = "reply before requesting the sink";
            throw new IllegalStateException(var7.toString());
         }

         eE var6 = eE.sk;
      } finally {
         ;
      }

      return this.nY;
   }

   public final void a(cm var1, IOException var2) throws IOException {
      fR.c(var1, (String)"");
      if (this.b(var1, var2)) {
         this.nU.b(this.nT, var1);
      }
   }

   public final void b(cm var1) {
      fR.c(var1, (String)"");
      if (this.b(var1, (IOException)null)) {
         this.nU.a(this.nT, var1);
      }
   }

   private final boolean b(cm var1, IOException var2) {
      boolean var4 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         synchronized(this){}

         label87: {
            boolean var8;
            try {
               var4 = false;
               if (this.ob == null) {
                  this.ob = var1;
                  this.oc = var2;
                  boolean var6 = false;
                  fR.m(this);
                  ((Object)this).notifyAll();
                  if (this.nX.jn() && this.nY.jl()) {
                     boolean var7 = false;
                     return var7;
                  }

                  eE var12 = eE.sk;
                  break label87;
               }

               var8 = false;
            } finally {
               ;
            }

            return var8;
         }

         this.nU.H(this.nT);
         return true;
      }
   }

   public final void a(dg var1, int var2) throws IOException {
      fR.c(var1, (String)"");
      boolean var4 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         this.nX.a(var1, (long)var2);
      }
   }

   public final void a(bq var1, boolean var2) {
      fR.c(var1, (String)"");
      boolean var4 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         boolean var3 = false;
         synchronized(this) {
            boolean var5 = false;
            if (this.nW && var2) {
               this.nX.f(var1);
            } else {
               this.nW = true;
               ((Collection)this.nV).add(var1);
            }

            if (var2) {
               this.nX.x(true);
            }

            var3 = this.isOpen();
            boolean var7 = false;
            fR.m(this);
            ((Object)this).notifyAll();
            eE var10 = eE.sk;
         }

         if (!var3) {
            this.nU.H(this.nT);
         }

      }
   }

   public final synchronized void c(cm var1) {
      fR.c(var1, (String)"");
      if (this.ob == null) {
         this.ob = var1;
         boolean var3 = false;
         fR.m(this);
         ((Object)this).notifyAll();
      }

   }

   public final void ji() throws IOException {
      boolean var2 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         boolean var1 = false;
         var2 = false;
         synchronized(this) {
            boolean var4 = false;
            var2 = !this.nX.jn() && this.nX.jo() && (this.nY.jl() || this.nY.jm());
            var1 = this.isOpen();
            eE var9 = eE.sk;
         }

         if (var2) {
            this.a(cm.mF, (IOException)null);
         } else if (!var1) {
            this.nU.H(this.nT);
         }

      }
   }

   public final void q(long var1) {
      this.ny += var1;
      if (var1 > 0L) {
         boolean var4 = false;
         fR.m(this);
         ((Object)this).notifyAll();
      }

   }

   public final void jj() throws IOException {
      if (this.nY.jm()) {
         throw new IOException("stream closed");
      } else if (this.nY.jl()) {
         throw new IOException("stream finished");
      } else if (this.ob != null) {
         IOException var10000 = this.oc;
         Throwable var1;
         if (var10000 != null) {
            var1 = (Throwable)var10000;
         } else {
            cm var10002 = this.ob;
            fR.m(var10002);
            var1 = (Throwable)(new cy(var10002));
         }

         throw var1;
      }
   }

   public final void jk() throws InterruptedIOException {
      try {
         boolean var2 = false;
         fR.m(this);
         ((Object)this).wait();
      } catch (InterruptedException var3) {
         Thread.currentThread().interrupt();
         throw new InterruptedIOException();
      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public final class b implements dy {
      private boolean finished;
      private final de sendBuffer;
      private bq trailers;
      private boolean closed;

      public b(boolean var2) {
         this.finished = var2;
         this.sendBuffer = new de();
      }

      public final boolean jl() {
         return this.finished;
      }

      public final boolean jm() {
         return this.closed;
      }

      public void b(de var1, long var2) throws IOException {
         fR.c(var1, (String)"");
         ct var4 = ct.this;
         boolean var5 = false;
         if (bD.jn && Thread.holdsLock(var4)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + var4);
         } else {
            this.sendBuffer.b(var1, var2);

            while(this.sendBuffer.kH() >= 16384L) {
               this.w(false);
            }

         }
      }

      private final void w(boolean var1) throws IOException {
         long var8 = 0L;
         boolean var2 = false;
         ct var3 = ct.this;
         ct var4 = ct.this;
         synchronized(var3){}

         try {
            boolean var6 = false;
            var4.ja().kw();

            try {
               while(var4.iV() >= var4.iW() && !this.finished && !this.closed && var4.jb() == null) {
                  var4.jk();
               }
            } finally {
               var4.ja().jp();
            }

            var4.jj();
            var8 = Math.min(var4.iW() - var4.iV(), this.sendBuffer.kH());
            var4.p(var4.iV() + var8);
            var2 = var1 && var8 == this.sendBuffer.kH();
            eE var23 = eE.sk;
         } finally {
            ;
         }

         ct.this.ja().kw();

         try {
            ct.this.iS().a(ct.this.iR(), var2, this.sendBuffer, var8);
         } finally {
            ct.this.ja().jp();
         }

      }

      public void flush() throws IOException {
         ct var1 = ct.this;
         boolean var2 = false;
         if (bD.jn && Thread.holdsLock(var1)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + var1);
         } else {
            var1 = ct.this;
            ct var7 = ct.this;
            synchronized(var1) {
               boolean var4 = false;
               var7.jj();
               eE var8 = eE.sk;
            }

            while(this.sendBuffer.kH() > 0L) {
               this.w(false);
               ct.this.iS().iv();
            }

         }
      }

      public dB fu() {
         return ct.this.ja();
      }

      public void close() throws IOException {
         ct var1 = ct.this;
         boolean var2 = false;
         if (bD.jn && Thread.holdsLock(var1)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + var1);
         } else {
            boolean var10 = false;
            ct var12 = ct.this;
            ct var3 = ct.this;
            synchronized(var12){}

            try {
               boolean var5 = false;
               if (this.closed) {
                  return;
               }

               var10 = var3.jb() == null;
               eE var17 = eE.sk;
            } finally {
               ;
            }

            if (!ct.this.iY().finished) {
               boolean var13 = this.sendBuffer.kH() > 0L;
               boolean var14 = this.trailers != null;
               if (!var14) {
                  if (var13) {
                     while(this.sendBuffer.kH() > 0L) {
                        this.w(true);
                     }
                  } else if (var10) {
                     ct.this.iS().a(ct.this.iR(), true, (de)null, 0L);
                  }
               } else {
                  while(this.sendBuffer.kH() > 0L) {
                     this.w(false);
                  }

                  cq var10000 = ct.this.iS();
                  int var10001 = ct.this.iR();
                  bq var10003 = this.trailers;
                  fR.m(var10003);
                  var10000.a(var10001, var10, bD.e(var10003));
               }
            }

            var3 = ct.this;
            synchronized(var3) {
               boolean var4 = false;
               this.closed = true;
               eE var16 = eE.sk;
            }

            ct.this.iS().iv();
            ct.this.ji();
         }
      }
   }

   public final class c implements dA {
      private final long maxByteCount;
      private boolean finished;
      private final de receiveBuffer;
      private final de readBuffer;
      private bq trailers;
      private boolean closed;

      public c(long var2, boolean var4) {
         this.maxByteCount = var2;
         this.finished = var4;
         this.receiveBuffer = new de();
         this.readBuffer = new de();
      }

      public final boolean jn() {
         return this.finished;
      }

      public final void x(boolean var1) {
         this.finished = var1;
      }

      public final void f(bq var1) {
         this.trailers = var1;
      }

      public final boolean jo() {
         return this.closed;
      }

      public long a(de var1, long var2) throws IOException {
         fR.c(var1, (String)"");
         if (var2 < 0L) {
            boolean var5 = false;
            String var22 = "byteCount < 0: " + var2;
            throw new IllegalArgumentException(var22.toString());
         } else {
            boolean var4;
            IOException var6;
            long var24;
            do {
               var4 = false;
               var24 = 0L;
               var24 = -1L;
               var6 = null;
               ct var7 = ct.this;
               ct var8 = ct.this;
               synchronized(var7){}

               try {
                  boolean var10 = false;
                  var8.iZ().kw();

                  try {
                     if (var8.jb() != null && !this.finished) {
                        IOException var10000 = var8.jc();
                        if (var10000 == null) {
                           cm var10002 = var8.jb();
                           fR.m(var10002);
                           var10000 = new cy(var10002);
                        }

                        var6 = var10000;
                     }

                     if (this.closed) {
                        throw new IOException("stream closed");
                     }

                     if (this.readBuffer.kH() > 0L) {
                        var24 = this.readBuffer.a(var1, Math.min(var2, this.readBuffer.kH()));
                        var8.n(var8.iT() + var24);
                        long var11 = var8.iT() - var8.iU();
                        if (var6 == null && var11 >= (long)(var8.iS().ir().jx() / 2)) {
                           var8.iS().b(var8.iR(), var11);
                           var8.o(var8.iT());
                        }
                     } else if (!this.finished && var6 == null) {
                        var8.jk();
                        var4 = true;
                     }
                  } finally {
                     var8.iZ().jp();
                  }

                  eE var23 = eE.sk;
               } finally {
                  ;
               }
            } while(var4);

            if (var24 != -1L) {
               return var24;
            } else if (var6 != null) {
               throw (Throwable)var6;
            } else {
               return -1L;
            }
         }
      }

      private final void r(long var1) {
         ct var3 = ct.this;
         boolean var4 = false;
         if (bD.jn && Thread.holdsLock(var3)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + var3);
         } else {
            ct.this.iS().l(var1);
         }
      }

      public final void a(dg var1, long var2) throws IOException {
         fR.c(var1, (String)"");
         ct var4 = ct.this;
         boolean var5 = false;
         if (bD.jn && Thread.holdsLock(var4)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + var4);
         } else {
            long var16 = 0L;

            eE var25;
            for(long var26 = var2; var26 > 0L; var25 = eE.sk) {
               var5 = false;
               boolean var6 = false;
               ct var8 = ct.this;
               synchronized(var8) {
                  boolean var9 = false;
                  var5 = this.finished;
                  var6 = var26 + this.readBuffer.kH() > this.maxByteCount;
                  eE var23 = eE.sk;
               }

               if (var6) {
                  var1.A(var26);
                  ct.this.b(cm.mA);
                  return;
               }

               if (var5) {
                  var1.A(var26);
                  return;
               }

               long var7 = var1.a(this.receiveBuffer, var26);
               if (var7 == -1L) {
                  throw new EOFException();
               }

               var26 -= var7;
               ct var24 = ct.this;
               ct var10 = ct.this;
               synchronized(var24) {
                  boolean var12 = false;
                  if (this.closed) {
                     this.receiveBuffer.kX();
                  } else {
                     boolean var13 = this.readBuffer.kH() == 0L;
                     this.readBuffer.b(this.receiveBuffer);
                     if (var13) {
                        boolean var15 = false;
                        fR.m(var10);
                        ((Object)var10).notifyAll();
                     }
                  }
               }
            }

            this.r(var2);
         }
      }

      public dB fu() {
         return ct.this.iZ();
      }

      public void close() throws IOException {
         long var7 = 0L;
         ct var1 = ct.this;
         ct var2 = ct.this;
         synchronized(var1) {
            boolean var4 = false;
            this.closed = true;
            var7 = this.readBuffer.kH();
            this.readBuffer.kX();
            boolean var6 = false;
            fR.m(var2);
            ((Object)var2).notifyAll();
            eE var10 = eE.sk;
         }

         if (var7 > 0L) {
            this.r(var7);
         }

         ct.this.ji();
      }
   }

   public final class d extends dc {
      protected void hh() {
         ct.this.b(cm.mF);
         ct.this.iS().iw();
      }

      protected IOException m(IOException var1) {
         SocketTimeoutException var2 = new SocketTimeoutException("timeout");
         boolean var4 = false;
         if (var1 != null) {
            var2.initCause((Throwable)var1);
         }

         return (IOException)var2;
      }

      public final void jp() throws IOException {
         if (this.kx()) {
            throw this.m((IOException)null);
         }
      }
   }
}
