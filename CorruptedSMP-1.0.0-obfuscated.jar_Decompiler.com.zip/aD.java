import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class aD extends aV {
   private static final Writer bP = new Writer() {
      public void write(char[] var1, int var2, int var3) {
         throw new AssertionError();
      }

      public void flush() {
         throw new AssertionError();
      }

      public void close() {
         throw new AssertionError();
      }
   };
   private static final U bQ = new U("closed");
   private final List<P> bR = new ArrayList();
   private String bS;
   private P bT;

   public aD() {
      super(bP);
      this.bT = R.aY;
   }

   public P aY() {
      if (!this.bR.isEmpty()) {
         throw new IllegalStateException("Expected one JSON element but was " + this.bR);
      } else {
         return this.bT;
      }
   }

   private P aZ() {
      return (P)this.bR.get(this.bR.size() - 1);
   }

   private void b(P var1) {
      if (this.bS != null) {
         if (!var1.ag() || this.bw()) {
            S var2 = (S)this.aZ();
            var2.a(this.bS, var1);
         }

         this.bS = null;
      } else if (this.bR.isEmpty()) {
         this.bT = var1;
      } else {
         P var3 = this.aZ();
         if (!(var3 instanceof M)) {
            throw new IllegalStateException();
         }

         ((M)var3).a(var1);
      }

   }

   public aV ba() throws IOException {
      M var1 = new M();
      this.b(var1);
      this.bR.add(var1);
      return this;
   }

   public aV bb() throws IOException {
      if (!this.bR.isEmpty() && this.bS == null) {
         P var1 = this.aZ();
         if (var1 instanceof M) {
            this.bR.remove(this.bR.size() - 1);
            return this;
         } else {
            throw new IllegalStateException();
         }
      } else {
         throw new IllegalStateException();
      }
   }

   public aV bc() throws IOException {
      S var1 = new S();
      this.b(var1);
      this.bR.add(var1);
      return this;
   }

   public aV bd() throws IOException {
      if (!this.bR.isEmpty() && this.bS == null) {
         P var1 = this.aZ();
         if (var1 instanceof S) {
            this.bR.remove(this.bR.size() - 1);
            return this;
         } else {
            throw new IllegalStateException();
         }
      } else {
         throw new IllegalStateException();
      }
   }

   public aV s(String var1) throws IOException {
      Objects.requireNonNull(var1, "name == null");
      if (!this.bR.isEmpty() && this.bS == null) {
         P var2 = this.aZ();
         if (var2 instanceof S) {
            this.bS = var1;
            return this;
         } else {
            throw new IllegalStateException();
         }
      } else {
         throw new IllegalStateException();
      }
   }

   public aV t(String var1) throws IOException {
      if (var1 == null) {
         return this.be();
      } else {
         this.b(new U(var1));
         return this;
      }
   }

   public aV be() throws IOException {
      this.b(R.aY);
      return this;
   }

   public aV h(boolean var1) throws IOException {
      this.b(new U(var1));
      return this;
   }

   public aV a(Boolean var1) throws IOException {
      if (var1 == null) {
         return this.be();
      } else {
         this.b(new U(var1));
         return this;
      }
   }

   public aV d(double var1) throws IOException {
      if (this.bm() || !Double.isNaN(var1) && !Double.isInfinite(var1)) {
         this.b(new U(var1));
         return this;
      } else {
         throw new IllegalArgumentException("JSON forbids NaN and infinities: " + var1);
      }
   }

   public aV b(long var1) throws IOException {
      this.b(new U(var1));
      return this;
   }

   public aV a(Number var1) throws IOException {
      if (var1 == null) {
         return this.be();
      } else {
         if (!this.bm()) {
            double var2 = var1.doubleValue();
            if (Double.isNaN(var2) || Double.isInfinite(var2)) {
               throw new IllegalArgumentException("JSON forbids NaN and infinities: " + var1);
            }
         }

         this.b(new U(var1));
         return this;
      }
   }

   public void flush() throws IOException {
   }

   public void close() throws IOException {
      if (!this.bR.isEmpty()) {
         throw new IOException("Incomplete document");
      } else {
         this.bR.add(bQ);
      }
   }
}
