import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.IDN;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public final class cU {
   public static final a pA = new a((fP)null);
   private final AtomicBoolean pB = new AtomicBoolean(false);
   private final CountDownLatch pC = new CountDownLatch(1);
   private byte[] pD;
   private byte[] pE;
   private static final byte[] pF;
   private static final List<String> pG;
   private static final cU pH;

   public final String aL(String var1) {
      fR.c(var1, (String)"");
      String var2 = IDN.toUnicode(var1);
      fR.b(var2, "");
      List var3 = this.aM(var2);
      List var4 = this.j(var3);
      if (var3.size() == var4.size() && ((String)var4.get(0)).charAt(0) != '!') {
         return null;
      } else {
         int var5 = ((String)var4.get(0)).charAt(0) == '!' ? var3.size() - var4.size() : var3.size() - (var4.size() + 1);
         return gn.a(gn.a(eO.f((Iterable)this.aM(var1)), var5), (CharSequence)".", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (fK)null, 62, (Object)null);
      }
   }

   private final List<String> aM(String var1) {
      CharSequence var10000 = (CharSequence)var1;
      char[] var3 = new char[]{'.'};
      List var2 = gA.a(var10000, var3, false, 0, 6, (Object)null);
      return fR.c(eO.o(var2), (Object)"") ? eO.a(var2, 1) : var2;
   }

   private final List<String> j(List<String> var1) {
      if (!this.pB.get() && this.pB.compareAndSet(false, true)) {
         this.kr();
      } else {
         try {
            this.pC.await();
         } catch (InterruptedException var11) {
            Thread.currentThread().interrupt();
         }
      }

      if (this.pD == null) {
         boolean var13 = false;
         String var14 = "Unable to load publicsuffixes.gz resource from the classpath.";
         throw new IllegalStateException(var14.toString());
      } else {
         int var3 = 0;
         int var4 = var1.size();

         byte[][] var5;
         for(var5 = new byte[var4][]; var3 < var4; ++var3) {
            String var7 = (String)var1.get(var3);
            Charset var10002 = StandardCharsets.UTF_8;
            fR.b(var10002, "");
            byte[] var38 = var7.getBytes(var10002);
            fR.b(var38, "");
            var5[var3] = var38;
         }

         byte[][] var2 = var5;
         String var12 = null;
         var4 = 0;

         for(int var17 = ((Object[])var5).length; var4 < var17; ++var4) {
            a var10000 = pA;
            byte[] var10001 = this.pD;
            if (var10001 == null) {
               fR.bc("");
               var10001 = null;
            }

            String var6 = var10000.a(var10001, var2, var4);
            if (var6 != null) {
               var12 = var6;
               break;
            }
         }

         String var16 = null;
         if (((Object[])var2).length > 1) {
            var5 = (byte[][])((Object[])var2).clone();
            int var21 = 0;

            for(int var25 = ((Object[])var5).length - 1; var21 < var25; ++var21) {
               var5[var21] = pF;
               a var29 = pA;
               byte[] var36 = this.pD;
               if (var36 == null) {
                  fR.bc("");
                  var36 = null;
               }

               String var8 = var29.a(var36, var5, var21);
               if (var8 != null) {
                  var16 = var8;
                  break;
               }
            }
         }

         String var19 = null;
         if (var16 != null) {
            int var22 = 0;

            for(int var26 = ((Object[])var2).length - 1; var22 < var26; ++var22) {
               a var30 = pA;
               byte[] var37 = this.pE;
               if (var37 == null) {
                  fR.bc("");
                  var37 = null;
               }

               String var28 = var30.a(var37, var2, var22);
               if (var28 != null) {
                  var19 = var28;
                  break;
               }
            }
         }

         if (var19 != null) {
            var19 = '!' + var19;
            CharSequence var35 = (CharSequence)var19;
            char[] var24 = new char[]{'.'};
            return gA.a(var35, var24, false, 0, 6, (Object)null);
         } else if (var12 == null && var16 == null) {
            return pG;
         } else {
            List var32;
            label78: {
               if (var12 != null) {
                  CharSequence var31 = (CharSequence)var12;
                  char[] var9 = new char[]{'.'};
                  var32 = gA.a(var31, var9, false, 0, 6, (Object)null);
                  if (var32 != null) {
                     break label78;
                  }
               }

               var32 = eO.nk();
            }

            List var23;
            label73: {
               var23 = var32;
               if (var16 != null) {
                  CharSequence var33 = (CharSequence)var16;
                  char[] var10 = new char[]{'.'};
                  var32 = gA.a(var33, var10, false, 0, 6, (Object)null);
                  if (var32 != null) {
                     break label73;
                  }
               }

               var32 = eO.nk();
            }

            List var27 = var32;
            return var23.size() > var27.size() ? var23 : var27;
         }
      }
   }

   private final void kr() {
      boolean var1 = false;

      try {
         while(true) {
            try {
               this.ks();
               return;
            } catch (InterruptedIOException var6) {
               Thread.interrupted();
               var1 = true;
            } catch (IOException var7) {
               cH.oU.jZ().a("Failed to read public suffix list", 5, (Throwable)var7);
               return;
            }
         }
      } finally {
         if (var1) {
            Thread.currentThread().interrupt();
         }

      }
   }

   private final void ks() throws IOException {
      try {
         fT.b var1 = new fT.b();
         fT.b var2 = new fT.b();
         InputStream var10000 = cU.class.getResourceAsStream("publicsuffixes.gz");
         if (var10000 != null) {
            InputStream var3 = var10000;
            Closeable var4 = do.c(new dl(do.a(var3)));
            Throwable var5 = null;

            try {
               dg var6 = (dg)var4;
               boolean var7 = false;
               int var8 = var6.kP();
               var1.sQ = (T)var6.z((long)var8);
               int var9 = var6.kP();
               var2.sQ = (T)var6.z((long)var9);
               eE var24 = eE.sk;
            } catch (Throwable var19) {
               var5 = var19;
               throw var19;
            } finally {
               fI.a(var4, var5);
            }

            synchronized(this) {
               boolean var22 = false;
               Object var10001 = var1.sQ;
               fR.m(var10001);
               this.pD = (byte[])var10001;
               var10001 = var2.sQ;
               fR.m(var10001);
               this.pE = (byte[])var10001;
               eE var23 = eE.sk;
               return;
            }
         }
      } finally {
         this.pC.countDown();
      }

   }

   static {
      byte[] var0 = new byte[]{42};
      pF = var0;
      pG = eO.i("*");
      pH = new cU();
   }

   public static final class a {
      private a() {
      }

      public final cU ku() {
         return cU.pH;
      }

      private final String a(byte[] var1, byte[][] var2, int var3) {
         int var4 = 0;
         int var5 = var1.length;
         String var6 = null;

         while(var4 < var5) {
            int var7;
            for(var7 = (var4 + var5) / 2; var7 > -1 && var1[var7] != 10; --var7) {
            }

            ++var7;

            int var8;
            for(var8 = 1; var1[var7 + var8] != 10; ++var8) {
            }

            int var9 = var7 + var8 - var7;
            int var10 = 0;
            int var11 = var3;
            int var12 = 0;
            int var13 = 0;
            boolean var14 = false;

            while(true) {
               int var15 = 0;
               if (var14) {
                  var15 = 46;
                  var14 = false;
               } else {
                  var15 = bD.a((byte)var2[var11][var12], 255);
               }

               int var16 = bD.a((byte)var1[var7 + var13], 255);
               var10 = var15 - var16;
               if (var10 != 0) {
                  break;
               }

               ++var13;
               ++var12;
               if (var13 == var9) {
                  break;
               }

               if (var2[var11].length == var12) {
                  if (var11 == ((Object[])var2).length - 1) {
                     break;
                  }

                  ++var11;
                  var12 = -1;
                  var14 = true;
               }
            }

            if (var10 < 0) {
               var5 = var7 - 1;
            } else if (var10 > 0) {
               var4 = var7 + var8 + 1;
            } else {
               int var22 = var9 - var13;
               int var23 = var2[var11].length - var12;
               int var17 = var11 + 1;

               for(int var18 = ((Object[])var2).length; var17 < var18; ++var17) {
                  var23 += var2[var17].length;
               }

               if (var23 < var22) {
                  var5 = var7 - 1;
               } else {
                  if (var23 <= var22) {
                     Charset var10000 = StandardCharsets.UTF_8;
                     fR.b(var10000, "");
                     Charset var24 = var10000;
                     var6 = new String(var1, var7, var9, var24);
                     break;
                  }

                  var4 = var7 + var8 + 1;
               }
            }
         }

         return var6;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
