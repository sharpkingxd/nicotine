import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class z {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      if (var0.getHealth() < (double)10.0F) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 0, false, false));
      }

   }
}
