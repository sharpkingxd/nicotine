import java.lang.ref.Reference;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

public final class bU {
   public static final a lr = new a((fP)null);
   private final int ls;
   private final long lt;
   private final bM lu;
   private final <undefinedtype> lv;
   private final ConcurrentLinkedQueue<bT> lw;

   public bU(bN var1, int var2, long var3, TimeUnit var5) {
      fR.c(var1, (String)"");
      fR.c(var5, (String)"");
      super();
      this.ls = var2;
      this.lt = var5.toNanos(var3);
      this.lu = var1.gw();
      String var6 = bD.jo + " ConnectionPool";
      this.lv = new bK(var6) {
         public long gg() {
            return bU.this.j(System.nanoTime());
         }
      };
      this.lw = new ConcurrentLinkedQueue();
      if (var3 <= 0L) {
         boolean var7 = false;
         String var8 = "keepAliveDuration <= 0: " + var3;
         throw new IllegalArgumentException(var8.toString());
      }
   }

   public final boolean a(aX var1, bS var2, List<bA> var3, boolean var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      Iterator var5 = this.lw.iterator();

      while(true) {
         if (var5.hasNext()) {
            bT var6 = (bT)var5.next();
            fR.b(var6, "");
            synchronized(var6){}

            boolean var9;
            try {
               boolean var8 = false;
               if (var4 && !var6.hm() || !var6.a(var1, var3)) {
                  eE var12 = eE.sk;
                  continue;
               }

               var2.b(var6);
               var9 = true;
            } finally {
               ;
            }

            return var9;
         }

         return false;
      }
   }

   public final void d(bT var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (bD.jn && !Thread.holdsLock(var1)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var1);
      } else {
         this.lw.add(var1);
         bM.a(this.lu, this.lv, 0L, 2, (Object)null);
      }
   }

   public final boolean e(bT var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (bD.jn && !Thread.holdsLock(var1)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var1);
      } else {
         boolean var10000;
         if (!var1.hi() && this.ls != 0) {
            bM.a(this.lu, this.lv, 0L, 2, (Object)null);
            var10000 = false;
         } else {
            var1.t(true);
            this.lw.remove(var1);
            if (this.lw.isEmpty()) {
               this.lu.gr();
            }

            var10000 = true;
         }

         return var10000;
      }
   }

   public final long j(long var1) {
      int var3 = 0;
      int var4 = 0;
      bT var5 = null;
      long var14 = 0L;
      var14 = Long.MIN_VALUE;

      for(bT var7 : this.lw) {
         fR.b(var7, "");
         synchronized(var7) {
            boolean var10 = false;
            if (this.a(var7, var1) > 0) {
               int var11 = var3++;
               var11;
            } else {
               ++var4;
               long var12 = var1 - var7.hl();
               if (var12 > var14) {
                  var14 = var12;
                  var5 = var7;
               }

               eE var23 = eE.sk;
            }
         }
      }

      if (var14 < this.lt && var4 <= this.ls) {
         if (var4 > 0) {
            return this.lt - var14;
         } else {
            return var3 > 0 ? this.lt : -1L;
         }
      } else {
         fR.m(var5);
         bT var20 = var5;
         synchronized(var5){}

         try {
            boolean var8 = false;
            if (!((Collection)var20.hk()).isEmpty()) {
               long var21 = 0L;
               return var21;
            }

            if (var20.hl() + var14 != var1) {
               long var9 = 0L;
               return var9;
            }

            var20.t(true);
            this.lw.remove(var5);
         } finally {
            ;
         }

         bD.a(var5.ht());
         if (this.lw.isEmpty()) {
            this.lu.gr();
         }

         return 0L;
      }
   }

   private final int a(bT var1, long var2) {
      int var5 = 0;
      if (bD.jn && !Thread.holdsLock(var1)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + var1);
      } else {
         List var4 = var1.hk();
         var5 = 0;

         while(var5 < var4.size()) {
            Reference var6 = (Reference)var4.get(var5);
            if (var6.get() != null) {
               ++var5;
            } else {
               fR.m(var6);
               bS.b var7 = (bS.b)var6;
               String var8 = "A connection to " + var1.hr().fo().bK() + " was leaked. Did you forget to close a response body?";
               cH.oU.jZ().b(var8, var7.hg());
               var4.remove(var5);
               var1.t(true);
               if (var4.isEmpty()) {
                  var1.i(var2 - this.lt);
                  return 0;
               }
            }
         }

         return var4.size();
      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
