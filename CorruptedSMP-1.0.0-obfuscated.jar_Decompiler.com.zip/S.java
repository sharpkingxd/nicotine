import java.util.Map;
import java.util.Set;

public final class S extends P {
   private final aq<String, P> aZ = new aq<String, P>(false);

   public void a(String var1, P var2) {
      this.aZ.put(var1, var2 == null ? R.aY : var2);
   }

   public void a(String var1, String var2) {
      this.a(var1, (P)(var2 == null ? R.aY : new U(var2)));
   }

   public void a(String var1, Number var2) {
      this.a(var1, (P)(var2 == null ? R.aY : new U(var2)));
   }

   public Set<Map.Entry<String, P>> entrySet() {
      return this.aZ.entrySet();
   }

   public boolean l(String var1) {
      return this.aZ.containsKey(var1);
   }

   public P m(String var1) {
      return this.aZ.get(var1);
   }

   public boolean equals(Object var1) {
      return var1 == this || var1 instanceof S && ((S)var1).aZ.equals(this.aZ);
   }

   public int hashCode() {
      return this.aZ.hashCode();
   }
}
