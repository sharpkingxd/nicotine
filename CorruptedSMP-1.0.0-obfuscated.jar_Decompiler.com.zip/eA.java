import java.io.Serializable;

final class eA<T> implements ev<T>, Serializable {
   private fJ<? extends T> sg;
   private volatile Object sh;
   private final Object si;

   public eA(fJ<? extends T> var1, Object var2) {
      fR.c(var1, (String)"");
      super();
      this.sg = var1;
      this.sh = eC.sj;
      Object var10001 = var2;
      if (var2 == null) {
         var10001 = this;
      }

      this.si = var10001;
   }

   // $FF: synthetic method
   public eA(fJ var1, Object var2, int var3, fP var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      this(var1, var2);
   }

   public T getValue() {
      // $FF: Couldn't be decompiled
   }

   public boolean ni() {
      return this.sh != eC.sj;
   }

   public String toString() {
      return this.ni() ? String.valueOf(this.getValue()) : "Lazy value not initialized yet.";
   }

   private final Object writeReplace() {
      return new et(this.getValue());
   }
}
