import java.util.Iterator;

public final class gk<T> implements gl<T> {
   private final gm<T> te;
   private final int tf;

   public gk(gm<? extends T> var1, int var2) {
      fR.c(var1, (String)"");
      super();
      this.te = var1;
      this.tf = var2;
      boolean var3 = this.tf >= 0;
      if (!var3) {
         boolean var4 = false;
         String var5 = "count must be non-negative, but was " + this.tf + '.';
         throw new IllegalArgumentException(var5.toString());
      }
   }

   public gm<T> aq(int var1) {
      int var2 = this.tf + var1;
      boolean var4 = false;
      return var2 < 0 ? new gk(this, var1) : new gk(this.te, var2);
   }

   public Iterator<T> iterator() {
      return (Iterator)(new fY(this) {
         private final Iterator<T> tg;
         private int left;

         {
            this.tg = var1.te.iterator();
            this.left = var1.tf;
         }

         private final void nK() {
            while(this.left > 0 && this.tg.hasNext()) {
               this.tg.next();
               int var1 = this.left;
               this.left = var1 + -1;
            }

         }

         public T next() {
            this.nK();
            return (T)this.tg.next();
         }

         public boolean hasNext() {
            this.nK();
            return this.tg.hasNext();
         }

         public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
         }
      });
   }
}
