import java.io.IOException;

public abstract class ao {
   public static ao INSTANCE;

   public abstract void j(aT var1) throws IOException;
}
