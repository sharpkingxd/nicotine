import java.util.Iterator;
import java.util.NoSuchElementException;

final class gy implements gm<gf> {
   private final CharSequence tv;
   private final int tw;
   private final int tx;
   private final fL<CharSequence, Integer, ez<Integer, Integer>> ty;

   public gy(CharSequence var1, int var2, int var3, fL<? super CharSequence, ? super Integer, ez<Integer, Integer>> var4) {
      fR.c(var1, (String)"");
      fR.c(var4, (String)"");
      super();
      this.tv = var1;
      this.tw = var2;
      this.tx = var3;
      this.ty = var4;
   }

   public Iterator<gf> iterator() {
      return (Iterator)(new fY() {
         private int tz = -1;
         private int tA;
         private int tB;
         private gf tC;
         private int tD;

         {
            this.tA = gg.k(gy.this.tw, 0, gy.this.tv.length());
            this.tB = this.tA;
         }

         private final void nN() {
            if (this.tB < 0) {
               this.tz = 0;
               this.tC = null;
            } else {
               label27: {
                  label26: {
                     if (gy.this.tx > 0) {
                        ++this.tD;
                        if (this.tD >= gy.this.tx) {
                           break label26;
                        }
                     }

                     if (this.tB <= gy.this.tv.length()) {
                        ez var1 = gy.this.ty.invoke(gy.this.tv, this.tB);
                        if (var1 == null) {
                           this.tC = new gf(this.tA, gA.e(gy.this.tv));
                           this.tB = -1;
                        } else {
                           int var2 = ((Number)var1.ng()).intValue();
                           int var3 = ((Number)var1.nh()).intValue();
                           this.tC = gg.l(this.tA, var2);
                           this.tA = var2 + var3;
                           this.tB = this.tA + (var3 == 0 ? 1 : 0);
                        }
                        break label27;
                     }
                  }

                  this.tC = new gf(this.tA, gA.e(gy.this.tv));
                  this.tB = -1;
               }

               this.tz = 1;
            }

         }

         public gf nO() {
            if (this.tz == -1) {
               this.nN();
            }

            if (this.tz == 0) {
               throw new NoSuchElementException();
            } else {
               gf var10000 = this.tC;
               fR.m(var10000);
               gf var1 = var10000;
               this.tC = null;
               this.tz = -1;
               return var1;
            }
         }

         public boolean hasNext() {
            if (this.tz == -1) {
               this.nN();
            }

            return this.tz == 1;
         }

         public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
         }

         // $FF: synthetic method
         public Object next() {
            return this.nO();
         }
      });
   }
}
