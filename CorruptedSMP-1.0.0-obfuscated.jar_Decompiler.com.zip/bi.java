import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import javax.net.ssl.SSLSocket;

public final class bi {
   public static final b gZ = new b((fP)null);
   private final boolean ha;
   private final boolean supportsTlsExtensions;
   private final String[] hb;
   private final String[] hc;
   private static final bf[] hd;
   private static final bf[] he;
   public static final bi hf;
   public static final bi hg;
   public static final bi hh;
   public static final bi hi;

   public bi(boolean var1, boolean var2, String[] var3, String[] var4) {
      this.ha = var1;
      this.supportsTlsExtensions = var2;
      this.hb = var3;
      this.hc = var4;
   }

   public final boolean cy() {
      return this.ha;
   }

   public final boolean cz() {
      return this.supportsTlsExtensions;
   }

   public final List<bf> cA() {
      String[] var10000 = this.hb;
      List var12;
      if (var10000 != null) {
         String[] var1 = var10000;
         boolean var2 = false;
         String[] var3 = var1;
         Collection var4 = (Collection)(new ArrayList(var1.length));
         boolean var5 = false;
         int var6 = 0;

         for(int var7 = var1.length; var6 < var7; ++var6) {
            String var8 = var3[var6];
            boolean var10 = false;
            var4.add(bf.eF.z(var8));
         }

         var12 = eO.c((Iterable)((List)var4));
      } else {
         var12 = null;
      }

      return var12;
   }

   public final List<bB> cB() {
      String[] var10000 = this.hc;
      List var12;
      if (var10000 != null) {
         String[] var1 = var10000;
         boolean var2 = false;
         String[] var3 = var1;
         Collection var4 = (Collection)(new ArrayList(var1.length));
         boolean var5 = false;
         int var6 = 0;

         for(int var7 = var1.length; var6 < var7; ++var6) {
            String var8 = var3[var6];
            boolean var10 = false;
            var4.add(bB.iY.am(var8));
         }

         var12 = eO.c((Iterable)((List)var4));
      } else {
         var12 = null;
      }

      return var12;
   }

   public final void a(SSLSocket var1, boolean var2) {
      fR.c(var1, (String)"");
      bi var3 = this.b(var1, var2);
      if (var3.cB() != null) {
         var1.setEnabledProtocols(var3.hc);
      }

      if (var3.cA() != null) {
         var1.setEnabledCipherSuites(var3.hb);
      }

   }

   private final bi b(SSLSocket var1, boolean var2) {
      String[] var8;
      if (this.hb != null) {
         var8 = var1.getEnabledCipherSuites();
         fR.b(var8, "");
         var8 = bD.a(var8, this.hb, bf.eF.cw());
      } else {
         var8 = var1.getEnabledCipherSuites();
      }

      String[] var3 = var8;
      if (this.hc != null) {
         var8 = var1.getEnabledProtocols();
         fR.b(var8, "");
         var8 = bD.a(var8, this.hc, fo.nt());
      } else {
         var8 = var1.getEnabledProtocols();
      }

      String[] var4 = var8;
      String[] var5 = var1.getSupportedCipherSuites();
      fR.b(var5, "");
      int var6 = bD.a(var5, "TLS_FALLBACK_SCSV", bf.eF.cw());
      if (var2 && var6 != -1) {
         fR.b(var3, "");
         String var10001 = var5[var6];
         fR.b(var5[var6], "");
         var3 = bD.c(var3, var10001);
      }

      a var11 = new a(this);
      fR.b(var3, "");
      var11 = var11.a((String[])Arrays.copyOf(var3, var3.length));
      fR.b(var4, "");
      return var11.b((String[])Arrays.copyOf(var4, var4.length)).cC();
   }

   public final boolean a(SSLSocket var1) {
      fR.c(var1, (String)"");
      if (!this.ha) {
         return false;
      } else if (this.hc != null && !bD.b(this.hc, var1.getEnabledProtocols(), fo.nt())) {
         return false;
      } else {
         return this.hb == null || bD.b(this.hb, var1.getEnabledCipherSuites(), bf.eF.cw());
      }
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof bi)) {
         return false;
      } else if (var1 == this) {
         return true;
      } else if (this.ha != ((bi)var1).ha) {
         return false;
      } else {
         if (this.ha) {
            if (!Arrays.equals(this.hb, ((bi)var1).hb)) {
               return false;
            }

            if (!Arrays.equals(this.hc, ((bi)var1).hc)) {
               return false;
            }

            if (this.supportsTlsExtensions != ((bi)var1).supportsTlsExtensions) {
               return false;
            }
         }

         return true;
      }
   }

   public int hashCode() {
      int var1 = 17;
      if (this.ha) {
         int var10000 = 31 * var1;
         String[] var10001 = this.hb;
         var1 = var10000 + (var10001 != null ? Arrays.hashCode(var10001) : 0);
         var10000 = 31 * var1;
         var10001 = this.hc;
         var1 = var10000 + (var10001 != null ? Arrays.hashCode(var10001) : 0);
         var1 = 31 * var1 + (this.supportsTlsExtensions ? 0 : 1);
      }

      return var1;
   }

   public String toString() {
      return !this.ha ? "ConnectionSpec()" : "ConnectionSpec(cipherSuites=" + Objects.toString(this.cA(), "[all enabled]") + ", tlsVersions=" + Objects.toString(this.cB(), "[all enabled]") + ", supportsTlsExtensions=" + this.supportsTlsExtensions + ')';
   }

   static {
      bf[] var0 = new bf[]{bf.gT, bf.gU, bf.gV, bf.gF, bf.gJ, bf.gG, bf.gK, bf.gQ, bf.gP};
      hd = var0;
      var0 = new bf[]{bf.gT, bf.gU, bf.gV, bf.gF, bf.gJ, bf.gG, bf.gK, bf.gQ, bf.gP, bf.gq, bf.gr, bf.fO, bf.fP, bf.fm, bf.fq, bf.eQ};
      he = var0;
      a var10000 = new a(true);
      var0 = hd;
      var10000 = var10000.a((bf[])Arrays.copyOf(var0, var0.length));
      bB[] var3 = new bB[]{bB.ja, bB.jb};
      hf = var10000.a(var3).m(true).cC();
      var10000 = new a(true);
      bf[] var4 = he;
      var10000 = var10000.a((bf[])Arrays.copyOf(var4, var4.length));
      bB[] var5 = new bB[]{bB.ja, bB.jb};
      hg = var10000.a(var5).m(true).cC();
      var10000 = new a(true);
      bf[] var6 = he;
      var10000 = var10000.a((bf[])Arrays.copyOf(var6, var6.length));
      bB[] var7 = new bB[]{bB.ja, bB.jb, bB.jc, bB.jd};
      hh = var10000.a(var7).m(true).cC();
      hi = (new a(false)).cC();
   }

   public static final class a {
      private boolean tls;
      private String[] cipherSuites;
      private String[] tlsVersions;
      private boolean supportsTlsExtensions;

      public a(boolean var1) {
         this.tls = var1;
      }

      public a(bi var1) {
         fR.c(var1, (String)"");
         super();
         this.tls = var1.cy();
         this.cipherSuites = var1.hb;
         this.tlsVersions = var1.hc;
         this.supportsTlsExtensions = var1.cz();
      }

      public final a a(bf... var1) {
         fR.c(var1, (String)"");
         a var2 = this;
         boolean var3 = false;
         if (!var2.tls) {
            boolean var16 = false;
            String var17 = "no cipher suites for cleartext connections";
            throw new IllegalArgumentException(var17.toString());
         } else {
            boolean var5 = false;
            bf[] var6 = var1;
            Collection var7 = (Collection)(new ArrayList(var1.length));
            boolean var8 = false;
            int var9 = 0;

            for(int var10 = var1.length; var9 < var10; ++var9) {
               bf var11 = var6[var9];
               boolean var14 = false;
               var7.add(var11.ct());
            }

            Collection var4 = (Collection)((List)var7);
            var5 = false;
            String[] var15 = (String[])var4.toArray(new String[0]);
            return var2.a((String[])Arrays.copyOf(var15, var15.length));
         }
      }

      public final a a(String... var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         if (!var3.tls) {
            boolean var7 = false;
            String var8 = "no cipher suites for cleartext connections";
            throw new IllegalArgumentException(var8.toString());
         } else if (var1.length == 0) {
            boolean var5 = false;
            String var6 = "At least one cipher suite is required";
            throw new IllegalArgumentException(var6.toString());
         } else {
            var3.cipherSuites = (String[])var1.clone();
            return this;
         }
      }

      public final a a(bB... var1) {
         fR.c(var1, (String)"");
         a var2 = this;
         boolean var3 = false;
         if (!var2.tls) {
            boolean var16 = false;
            String var17 = "no TLS versions for cleartext connections";
            throw new IllegalArgumentException(var17.toString());
         } else {
            boolean var5 = false;
            bB[] var6 = var1;
            Collection var7 = (Collection)(new ArrayList(var1.length));
            boolean var8 = false;
            int var9 = 0;

            for(int var10 = var1.length; var9 < var10; ++var9) {
               bB var11 = var6[var9];
               boolean var14 = false;
               var7.add(var11.fs());
            }

            Collection var4 = (Collection)((List)var7);
            var5 = false;
            String[] var15 = (String[])var4.toArray(new String[0]);
            return var2.b((String[])Arrays.copyOf(var15, var15.length));
         }
      }

      public final a b(String... var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         if (!var3.tls) {
            boolean var7 = false;
            String var8 = "no TLS versions for cleartext connections";
            throw new IllegalArgumentException(var8.toString());
         } else if (var1.length == 0) {
            boolean var5 = false;
            String var6 = "At least one TLS version is required";
            throw new IllegalArgumentException(var6.toString());
         } else {
            var3.tlsVersions = (String[])var1.clone();
            return this;
         }
      }

      public final a m(boolean var1) {
         a var3 = this;
         boolean var4 = false;
         if (!var3.tls) {
            boolean var5 = false;
            String var6 = "no TLS extensions for cleartext connections";
            throw new IllegalArgumentException(var6.toString());
         } else {
            var3.supportsTlsExtensions = var1;
            return this;
         }
      }

      public final bi cC() {
         return new bi(this.tls, this.supportsTlsExtensions, this.cipherSuites, this.tlsVersions);
      }
   }

   public static final class b {
      private b() {
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }
}
