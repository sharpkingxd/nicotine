import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;

public final class aE implements ad {
   private final al bU;
   final boolean bV;

   public aE(al var1, boolean var2) {
      this.bU = var1;
      this.bV = var2;
   }

   public <T> ac<T> a(K var1, aS<T> var2) {
      Type var3 = var2.bl();
      Class var4 = var2.bk();
      if (!Map.class.isAssignableFrom(var4)) {
         return null;
      } else {
         Type[] var5 = ak.b(var3, var4);
         ac var6 = this.a(var1, var5[0]);
         ac var7 = var1.a(aS.k(var5[1]));
         ar var8 = this.bU.b(var2);
         a var9 = new a(var1, var5[0], var6, var5[1], var7, var8);
         return var9;
      }
   }

   private ac<?> a(K var1, Type var2) {
      return var2 != Boolean.TYPE && var2 != Boolean.class ? var1.a(aS.k(var2)) : aL.cv;
   }

   final class a<K, V> extends ac<Map<K, V>> {
      private final ac<K> keyTypeAdapter;
      private final ac<V> valueTypeAdapter;
      private final ar<? extends Map<K, V>> constructor;

      public a(K var2, Type var3, ac<K> var4, Type var5, ac<V> var6, ar<? extends Map<K, V>> var7) {
         this.keyTypeAdapter = new aK<K>(var2, var4, var3);
         this.valueTypeAdapter = new aK<V>(var2, var6, var5);
         this.constructor = var7;
      }

      public Map<K, V> o(aT var1) throws IOException {
         aU var2 = var1.aI();
         if (var2 == aU.dY) {
            var1.aO();
            return null;
         } else {
            Map var3 = this.constructor.av();
            if (var2 == aU.dQ) {
               var1.aE();

               while(var1.hasNext()) {
                  var1.aE();
                  Object var4 = this.keyTypeAdapter.b(var1);
                  Object var5 = this.valueTypeAdapter.b(var1);
                  Object var6 = var3.put(var4, var5);
                  if (var6 != null) {
                     throw new X("duplicate key: " + var4);
                  }

                  var1.aF();
               }

               var1.aF();
            } else {
               var1.aG();

               while(var1.hasNext()) {
                  ao.INSTANCE.j(var1);
                  Object var7 = this.keyTypeAdapter.b(var1);
                  Object var8 = this.valueTypeAdapter.b(var1);
                  Object var9 = var3.put(var7, var8);
                  if (var9 != null) {
                     throw new X("duplicate key: " + var7);
                  }
               }

               var1.aH();
            }

            return var3;
         }
      }

      public void a(aV var1, Map<K, V> var2) throws IOException {
         if (var2 == null) {
            var1.be();
         } else if (!aE.this.bV) {
            var1.bc();

            for(Map.Entry var10 : var2.entrySet()) {
               var1.s(String.valueOf(var10.getKey()));
               this.valueTypeAdapter.a(var1, var10.getValue());
            }

            var1.bd();
         } else {
            boolean var3 = false;
            ArrayList var4 = new ArrayList(var2.size());
            ArrayList var5 = new ArrayList(var2.size());

            for(Map.Entry var7 : var2.entrySet()) {
               P var8 = this.keyTypeAdapter.a(var7.getKey());
               var4.add(var8);
               var5.add(var7.getValue());
               var3 |= var8.ad() || var8.ae();
            }

            if (var3) {
               var1.ba();
               int var11 = 0;

               for(int var13 = var4.size(); var11 < var13; ++var11) {
                  var1.ba();
                  av.a((P)var4.get(var11), var1);
                  this.valueTypeAdapter.a(var1, var5.get(var11));
                  var1.bb();
               }

               var1.bb();
            } else {
               var1.bc();
               int var12 = 0;

               for(int var14 = var4.size(); var12 < var14; ++var12) {
                  P var15 = (P)var4.get(var12);
                  var1.s(this.c(var15));
                  this.valueTypeAdapter.a(var1, var5.get(var12));
               }

               var1.bd();
            }

         }
      }

      private String c(P var1) {
         if (var1.af()) {
            U var2 = var1.aj();
            if (var2.al()) {
               return String.valueOf(var2.X());
            } else if (var2.ak()) {
               return Boolean.toString(var2.ac());
            } else if (var2.am()) {
               return var2.Y();
            } else {
               throw new AssertionError();
            }
         } else if (var1.ag()) {
            return "null";
         } else {
            throw new AssertionError();
         }
      }

      // $FF: synthetic method
      public Object b(aT var1) throws IOException {
         return this.o(var1);
      }
   }
}
