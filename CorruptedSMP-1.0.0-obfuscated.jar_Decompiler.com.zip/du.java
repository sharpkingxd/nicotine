import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

public final class du implements dg {
   public final dA qp;
   public final de qq;
   public boolean closed;

   public du(dA var1) {
      fR.c(var1, (String)"");
      super();
      this.qp = var1;
      this.qq = new de();
   }

   public de kI() {
      boolean var1 = false;
      return this.qq;
   }

   public long a(de var1, long var2) {
      fR.c(var1, (String)"");
      boolean var5 = false;
      if (var2 < 0L) {
         boolean var16 = false;
         String var17 = "byteCount < 0: " + var2;
         throw new IllegalArgumentException(var17.toString());
      } else if (this.closed) {
         boolean var14 = false;
         String var15 = "closed";
         throw new IllegalStateException(var15.toString());
      } else {
         boolean var6 = false;
         long var10000;
         if (this.qq.kH() == 0L) {
            boolean var9 = false;
            long var10 = this.qp.a(this.qq, 8192L);
            if (var10 == -1L) {
               var10000 = -1L;
               return var10000;
            }
         }

         boolean var18 = false;
         long var12 = this.qq.kH();
         long var20 = Math.min(var2, var12);
         var18 = false;
         var10000 = this.qq.a(var1, var20);
         return var10000;
      }
   }

   public boolean kK() {
      boolean var2 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var3 = false;
         boolean var10000;
         if (this.qq.kK()) {
            var3 = false;
            if (this.qp.a(this.qq, 8192L) == -1L) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      }
   }

   public void u(long var1) {
      boolean var4 = false;
      if (!this.G(var1)) {
         throw new EOFException();
      }
   }

   public boolean G(long var1) {
      du var3 = this;
      boolean var4 = false;
      if (var1 < 0L) {
         boolean var10 = false;
         String var11 = "byteCount < 0: " + var1;
         throw new IllegalArgumentException(var11.toString());
      } else if (this.closed) {
         boolean var8 = false;
         String var9 = "closed";
         throw new IllegalStateException(var9.toString());
      } else {
         boolean var10000;
         while(true) {
            boolean var5 = false;
            if (var3.qq.kH() < var1) {
               var5 = false;
               if (var3.qp.a(var3.qq, 8192L) != -1L) {
                  continue;
               }

               var10000 = false;
               break;
            }

            var10000 = true;
            break;
         }

         return var10000;
      }
   }

   public byte kN() {
      boolean var2 = false;
      this.u(1L);
      boolean var4 = false;
      return this.qq.kN();
   }

   public dh w(long var1) {
      boolean var4 = false;
      this.u(var1);
      boolean var6 = false;
      return this.qq.w(var1);
   }

   public int a(dr var1) {
      fR.c(var1, (String)"");
      du var2 = this;
      boolean var3 = false;
      if (this.closed) {
         boolean var4 = false;
         String var9 = "closed";
         throw new IllegalStateException(var9.toString());
      } else {
         while(true) {
            int var5 = 0;
            int var6 = dE.a(var2.qq, var1, true);
            int var10000;
            switch (var6) {
               case -2:
                  boolean var7 = false;
                  if (var2.qp.a(var2.qq, 8192L) != -1L) {
                     break;
                  }

                  var10000 = -1;
                  return var10000;
               case -1:
                  var10000 = -1;
                  return var10000;
               default:
                  var5 = var1.lF()[var6].lm();
                  boolean var8 = false;
                  var2.qq.A((long)var5);
                  var10000 = var6;
                  return var10000;
            }
         }
      }
   }

   public byte[] z(long var1) {
      boolean var4 = false;
      this.u(var1);
      boolean var6 = false;
      return this.qq.z(var1);
   }

   public int read(ByteBuffer var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (this.qq.kH() == 0L) {
         boolean var5 = false;
         long var2 = this.qp.a(this.qq, 8192L);
         if (var2 == -1L) {
            return -1;
         }
      }

      var3 = false;
      return this.qq.read(var1);
   }

   public String b(Charset var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      this.qq.b(this.qp);
      var3 = false;
      return this.qq.b(var1);
   }

   public String kV() {
      return this.y(Long.MAX_VALUE);
   }

   public String y(long var1) {
      boolean var4 = false;
      if (var1 < 0L) {
         boolean var5 = false;
         String var17 = "limit < 0: " + var1;
         throw new IllegalArgumentException(var17.toString());
      } else {
         label37: {
            long var6 = var1 == Long.MAX_VALUE ? Long.MAX_VALUE : var1 + 1L;
            long var8 = this.a((byte)10, 0L, var6);
            String var10000;
            if (var8 != -1L) {
               boolean var11 = false;
               var10000 = dE.d(this.qq, var8);
            } else {
               if (var6 >= Long.MAX_VALUE || !this.G(var6)) {
                  break label37;
               }

               boolean var18 = false;
               if (this.qq.v(var6 - 1L) != 13 || !this.G(var6 + 1L)) {
                  break label37;
               }

               var18 = false;
               if (this.qq.v(var6) != 10) {
                  break label37;
               }

               var18 = false;
               var10000 = dE.d(this.qq, var6);
            }

            return var10000;
         }

         de var10 = new de();
         boolean var12 = false;
         de var23 = this.qq;
         byte var21 = 32;
         boolean var13 = false;
         long var14 = this.qq.kH();
         boolean var16 = false;
         var23.a(var10, 0L, Math.min((long)var21, var14));
         StringBuilder var10002 = (new StringBuilder()).append("\\n not found: limit=");
         var12 = false;
         throw new EOFException(var10002.append(Math.min(this.qq.kH(), var1)).append(" content=").append(var10.ii().lk()).append('…').toString());
      }
   }

   public short kO() {
      boolean var2 = false;
      this.u(2L);
      boolean var4 = false;
      return this.qq.kO();
   }

   public short kQ() {
      boolean var2 = false;
      this.u(2L);
      boolean var4 = false;
      return this.qq.kQ();
   }

   public int kP() {
      boolean var2 = false;
      this.u(4L);
      boolean var4 = false;
      return this.qq.kP();
   }

   public int kR() {
      boolean var2 = false;
      this.u(4L);
      boolean var4 = false;
      return this.qq.kR();
   }

   public long kS() {
      du var1 = this;
      boolean var2 = false;
      this.u(1L);

      for(long var3 = 0L; var1.G(var3 + 1L); ++var3) {
         boolean var6 = false;
         byte var7 = var1.qq.v(var3);
         if ((var7 < 48 || var7 > 57) && (var3 != 0L || var7 != 45)) {
            if (var3 == 0L) {
               StringBuilder var10002 = (new StringBuilder()).append("Expected a digit or '-' but was 0x");
               String var10003 = Integer.toString(var7, gu.ar(gu.ar(16)));
               fR.b(var10003, "");
               throw new NumberFormatException(var10002.append(var10003).toString());
            }
            break;
         }
      }

      boolean var5 = false;
      return var1.qq.kS();
   }

   public long kT() {
      du var1 = this;
      boolean var2 = false;
      this.u(1L);

      for(int var3 = 0; var1.G((long)(var3 + 1)); ++var3) {
         boolean var5 = false;
         byte var6 = var1.qq.v((long)var3);
         if ((var6 < 48 || var6 > 57) && (var6 < 97 || var6 > 102) && (var6 < 65 || var6 > 70)) {
            if (var3 == 0) {
               StringBuilder var10002 = (new StringBuilder()).append("Expected leading [0-9a-fA-F] character but was 0x");
               String var10003 = Integer.toString(var6, gu.ar(gu.ar(16)));
               fR.b(var10003, "");
               throw new NumberFormatException(var10002.append(var10003).toString());
            }
            break;
         }
      }

      boolean var4 = false;
      return var1.qq.kT();
   }

   public void A(long var1) {
      du var3 = this;
      boolean var4 = false;
      long var5 = var1;
      if (this.closed) {
         boolean var16 = false;
         String var17 = "closed";
         throw new IllegalStateException(var17.toString());
      } else {
         while(var5 > 0L) {
            boolean var7 = false;
            if (var3.qq.kH() == 0L) {
               var7 = false;
               if (var3.qp.a(var3.qq, 8192L) == -1L) {
                  throw new EOFException();
               }
            }

            boolean var10 = false;
            long var11 = var3.qq.kH();
            long var13 = Math.min(var5, var11);
            var10 = false;
            var3.qq.A(var13);
            var5 -= var13;
         }

      }
   }

   public long b(byte var1) {
      return this.a(var1, 0L, Long.MAX_VALUE);
   }

   public long a(byte var1, long var2, long var4) {
      du var6 = this;
      boolean var7 = false;
      long var17 = 0L;
      var17 = var2;
      if (this.closed) {
         boolean var20 = false;
         String var21 = "closed";
         throw new IllegalStateException(var21.toString());
      } else if (!(0L <= var2 ? var2 <= var4 : false)) {
         boolean var8 = false;
         String var19 = "fromIndex=" + var2 + " toIndex=" + var4;
         throw new IllegalArgumentException(var19.toString());
      } else {
         long var10000;
         while(true) {
            if (var17 < var4) {
               boolean var10 = false;
               long var11 = var6.qq.a(var1, var17, var4);
               if (var11 != -1L) {
                  var10000 = var11;
                  break;
               }

               boolean var14 = false;
               long var15 = var6.qq.kH();
               if (var15 < var4) {
                  var14 = false;
                  if (var6.qp.a(var6.qq, 8192L) != -1L) {
                     var17 = Math.max(var17, var15);
                     continue;
                  }
               }

               var10000 = -1L;
               break;
            }

            var10000 = -1L;
            break;
         }

         return var10000;
      }
   }

   public boolean isOpen() {
      return !this.closed;
   }

   public void close() {
      boolean var2 = false;
      if (!this.closed) {
         this.closed = true;
         this.qp.close();
         boolean var4 = false;
         this.qq.kX();
      }

   }

   public dB fu() {
      boolean var2 = false;
      return this.qp.fu();
   }

   public String toString() {
      boolean var2 = false;
      return "buffer(" + this.qp + ')';
   }
}
