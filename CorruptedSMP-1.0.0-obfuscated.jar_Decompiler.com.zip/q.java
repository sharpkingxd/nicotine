import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

public class q {
   public static boolean a(final Player var0, CorruptedSMPPlugin var1) {
      final int var2 = var1.getConfig().getInt("corruptions.fire.ability-duration", 25);
      final D var3 = var1.f().g(var0.getUniqueId());
      var3.b(true);
      var0.sendMessage("§6§l\ud83d\udd25 LAVA PIT ACTIVATED!");
      var0.sendMessage("§7- Expanding radius (3-7 blocks)");
      var0.sendMessage("§7- Temperature: 0° → 520°");
      var0.sendMessage("§7- Blue Fire + Armor/Shield Damage");
      (new BukkitRunnable() {
         int ticks = 0;
         double radius = (double)3.0F;

         public void run() {
            if (this.ticks >= var2 * 20) {
               var3.a((double)0.0F);
               var3.b(false);
               var0.sendMessage("§c§lLava Pit ended!");
               this.cancel();
            } else {
               var3.b((double)20.0F);
               double var1 = var3.P();
               this.radius = (double)3.0F + var1 / (double)520.0F * (double)4.0F;

               for(int var3x = 0; var3x < 360; var3x += 12) {
                  double var4 = Math.toRadians((double)var3x);
                  double var6 = var0.getLocation().getX() + this.radius * Math.cos(var4);
                  double var8 = var0.getLocation().getZ() + this.radius * Math.sin(var4);
                  Location var10 = new Location(var0.getWorld(), var6, var0.getLocation().getY(), var8);
                  var0.getWorld().spawnParticle(Particle.FLAME, var10, 3, 0.1, 0.2, 0.1, 0.03);
                  var0.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var10.clone().add((double)0.0F, 0.4, (double)0.0F), 2, 0.1, 0.2, 0.1, 0.02);
                  var0.getWorld().spawnParticle(Particle.SMALL_FLAME, var10.clone().add((double)0.0F, 0.7, (double)0.0F), 2, 0.05, 0.1, 0.05, 0.01);
                  if (var3x % 24 == 0) {
                     var0.getWorld().spawnParticle(Particle.DRIPPING_LAVA, var10.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 2);
                     var0.getWorld().spawnParticle(Particle.LAVA, var10.clone().add((double)0.0F, 0.1, (double)0.0F), 1);
                  }
               }

               double var20 = this.radius * 0.65;

               for(int var5 = 0; var5 < 360; var5 += 20) {
                  double var22 = Math.toRadians((double)(var5 + this.ticks * 3));
                  double var24 = var0.getLocation().getX() + var20 * Math.cos(var22);
                  double var34 = var0.getLocation().getZ() + var20 * Math.sin(var22);
                  Location var12 = new Location(var0.getWorld(), var24, var0.getLocation().getY() + 0.2, var34);
                  var0.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var12, 3, 0.1, 0.15, 0.1, 0.02);
                  var0.getWorld().spawnParticle(Particle.SOUL, var12.clone().add((double)0.0F, 0.3, (double)0.0F), 1, 0.1, 0.1, 0.1, 0.01);
               }

               double var21 = this.radius * 0.35;

               for(int var7 = 0; var7 < 360; var7 += 25) {
                  double var25 = Math.toRadians((double)(var7 - this.ticks * 4));
                  double var35 = var0.getLocation().getX() + var21 * Math.cos(var25);
                  double var40 = var0.getLocation().getZ() + var21 * Math.sin(var25);
                  Location var14 = new Location(var0.getWorld(), var35, var0.getLocation().getY() + 0.3, var40);
                  var0.getWorld().spawnParticle(Particle.FLAME, var14, 2, 0.1, 0.2, 0.1, 0.02);
                  var0.getWorld().spawnParticle(Particle.SMALL_FLAME, var14.clone().add((double)0.0F, 0.4, (double)0.0F), 1);
               }

               Location var23 = var0.getLocation();
               var0.getWorld().spawnParticle(Particle.LAVA, var23.clone().add((double)0.0F, 0.1, (double)0.0F), 4, (double)0.5F, 0.05, (double)0.5F, (double)0.0F);
               var0.getWorld().spawnParticle(Particle.DRIPPING_LAVA, var23.clone().add((double)0.0F, (double)1.5F, (double)0.0F), 3, 0.3, 0.3, 0.3, (double)0.0F);

               for(double var26 = (double)0.0F; var26 < (double)2.0F; var26 += (double)0.5F) {
                  var0.getWorld().spawnParticle(Particle.FLAME, var23.clone().add((double)0.0F, var26, (double)0.0F), 4, 0.3, 0.1, 0.3, 0.03);
                  var0.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var23.clone().add((double)0.0F, var26 + 0.2, (double)0.0F), 2, 0.2, 0.1, 0.2, 0.02);
               }

               var0.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, var23.clone().add((double)0.0F, (double)2.0F, (double)0.0F), 3, 0.2, 0.3, 0.2, 0.02);
               if (this.ticks % 5 == 0) {
                  var0.getWorld().spawnParticle(Particle.WHITE_ASH, var23.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 8, (double)0.5F, (double)0.5F, (double)0.5F, 0.05);
               }

               if (this.ticks % 10 == 0) {
                  for(int var27 = 0; var27 < 8; ++var27) {
                     double var9 = Math.toRadians((double)(var27 * 45));
                     Location var11 = var23.clone().add(Math.cos(var9) * (double)1.5F, 0.05, Math.sin(var9) * (double)1.5F);
                     var0.getWorld().spawnParticle(Particle.DUST, var11, 3, 0.1, (double)0.0F, 0.1, new Particle.DustOptions(Color.fromRGB(255, 100, 0), 1.5F));
                  }
               }

               if (this.ticks % 3 == 0) {
                  for(int var28 = 0; var28 < 5; ++var28) {
                     double var31 = (Math.random() - (double)0.5F) * this.radius;
                     double var37 = (Math.random() - (double)0.5F) * this.radius;
                     Location var13 = var23.clone().add(var31, 0.1, var37);
                     var0.getWorld().spawnParticle(Particle.FLAME, var13, 1, (double)0.0F, (double)0.5F, (double)0.0F, 0.02);
                  }
               }

               if (this.ticks % 15 == 0) {
                  for(int var29 = 0; var29 < 360; var29 += 60) {
                     double var32 = Math.toRadians((double)var29);
                     double var38 = var0.getLocation().getX() + this.radius * 1.1 * Math.cos(var32);
                     double var42 = var0.getLocation().getZ() + this.radius * 1.1 * Math.sin(var32);
                     Location var15 = new Location(var0.getWorld(), var38, var0.getLocation().getY() + (double)0.5F, var42);
                     var0.getWorld().spawnParticle(Particle.LARGE_SMOKE, var15, 2, 0.2, 0.3, 0.2, 0.02);
                  }
               }

               if (this.ticks % 40 == 0) {
                  var0.getWorld().playSound(var0.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1.5F, 0.8F);
                  var0.getWorld().playSound(var0.getLocation(), Sound.BLOCK_LAVA_POP, 1.0F, 1.2F);
               }

               for(Entity var33 : var0.getNearbyEntities(this.radius, this.radius, this.radius)) {
                  if (var33 instanceof Player) {
                     Player var36 = (Player)var33;
                     if (!var36.equals(var0)) {
                        var36.setFireTicks(100);
                        if (var36.isBlocking()) {
                           var36.setCooldown(Material.SHIELD, 100);
                           var36.sendMessage("§c§l✗ Your shield has been stunned by Lava Pit!");
                        }

                        ItemStack[] var39 = var36.getInventory().getArmorContents();
                        int var41 = 0;

                        for(ItemStack var16 : var39) {
                           if (var16 != null && var16.getType() != Material.AIR) {
                              ItemMeta var17 = var16.getItemMeta();
                              if (var17 instanceof Damageable) {
                                 Damageable var18 = (Damageable)var17;
                                 int var19 = var18.getDamage();
                                 var18.setDamage(var19 + 5);
                                 var16.setItemMeta(var17);
                                 var41 += 5;
                              }
                           }
                        }

                        ItemStack var44 = var36.getInventory().getItemInMainHand();
                        ItemStack var46 = var36.getInventory().getItemInOffHand();
                        if (var44.getType() == Material.SHIELD) {
                           ItemMeta var48 = var44.getItemMeta();
                           if (var48 instanceof Damageable) {
                              Damageable var51 = (Damageable)var48;
                              int var53 = var51.getDamage();
                              var51.setDamage(var53 + 5);
                              var44.setItemMeta(var48);
                              var41 += 5;
                           }
                        }

                        if (var46.getType() == Material.SHIELD) {
                           ItemMeta var49 = var46.getItemMeta();
                           if (var49 instanceof Damageable) {
                              Damageable var52 = (Damageable)var49;
                              int var54 = var52.getDamage();
                              var52.setDamage(var54 + 5);
                              var46.setItemMeta(var49);
                              var41 += 5;
                           }
                        }

                        if (var41 > 0 && this.ticks % 40 == 0) {
                           var36.sendMessage("§c§l✗ Lava Pit is melting your equipment! (-" + var41 + " durability)");
                        }

                        Location var50 = var36.getLocation();
                        if (var50.getBlock().getType() == Material.WATER) {
                           var50.getBlock().setType(Material.AIR);
                           var0.getWorld().spawnParticle(Particle.CLOUD, var50, 10, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                           var0.getWorld().playSound(var50, Sound.BLOCK_FIRE_EXTINGUISH, 1.0F, 1.5F);
                        }
                     }
                  }
               }

               this.ticks += 10;
            }
         }
      }).runTaskTimer(var1, 0L, 10L);
      var0.playSound(var0.getLocation(), Sound.ITEM_FIRECHARGE_USE, 2.0F, 0.8F);
      var0.getWorld().playSound(var0.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.5F, 0.6F);
      String var4 = var1.getConfig().getString("messages.ability-activated").replace("{ability}", "Lava Pit");
      var0.sendMessage(a(var4, var1));
      return true;
   }

   private static String a(String var0, CorruptedSMPPlugin var1) {
      String var2 = var1.getConfig().getString("messages.prefix", "");
      return (var2 + var0).replace("&", "§");
   }
}
