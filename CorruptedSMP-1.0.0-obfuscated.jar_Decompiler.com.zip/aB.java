public final class aB implements ad {
   private final al bI;

   public aB(al var1) {
      this.bI = var1;
   }

   public <T> ac<T> a(K var1, aS<T> var2) {
      Class var3 = var2.bk();
      af var4 = (af)var3.getAnnotation(af.class);
      return var4 == null ? null : this.a(this.bI, var1, var2, var4);
   }

   ac<?> a(al var1, K var2, aS<?> var3, af var4) {
      Object var5 = var1.b(aS.t(var4.aq())).av();
      boolean var7 = var4.ar();
      Object var6;
      if (var5 instanceof ac) {
         var6 = (ac)var5;
      } else if (var5 instanceof ad) {
         var6 = ((ad)var5).a(var2, var3);
      } else {
         if (!(var5 instanceof W) && !(var5 instanceof O)) {
            throw new IllegalArgumentException("Invalid attempt to bind an instance of " + var5.getClass().getName() + " as a @JsonAdapter for " + var3.toString() + ". @JsonAdapter value must be a TypeAdapter, TypeAdapterFactory, JsonSerializer or JsonDeserializer.");
         }

         W var8 = var5 instanceof W ? (W)var5 : null;
         O var9 = var5 instanceof O ? (O)var5 : null;
         aJ var10 = new aJ(var8, var9, var2, var3, (ad)null, var7);
         var6 = var10;
         var7 = false;
      }

      if (var6 != null && var7) {
         var6 = ((ac)var6).an();
      }

      return (ac<?>)var6;
   }
}
