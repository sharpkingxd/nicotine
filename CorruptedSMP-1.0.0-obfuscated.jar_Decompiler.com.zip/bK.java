public abstract class bK {
   private final String name;
   private final boolean cancelable;
   private bM queue;
   private long nextExecuteNanoTime;

   public bK(String var1, boolean var2) {
      fR.c(var1, (String)"");
      super();
      this.name = var1;
      this.cancelable = var2;
      this.nextExecuteNanoTime = -1L;
   }

   // $FF: synthetic method
   public bK(String var1, boolean var2, int var3, fP var4) {
      if ((var3 & 2) != 0) {
         var2 = true;
      }

      this(var1, var2);
   }

   public final String gh() {
      return this.name;
   }

   public final boolean gi() {
      return this.cancelable;
   }

   public final bM gj() {
      return this.queue;
   }

   public final long gk() {
      return this.nextExecuteNanoTime;
   }

   public final void g(long var1) {
      this.nextExecuteNanoTime = var1;
   }

   public abstract long gg();

   public final void a(bM var1) {
      fR.c(var1, (String)"");
      if (this.queue != var1) {
         if (this.queue != null) {
            boolean var2 = false;
            String var3 = "task is in multiple queues";
            throw new IllegalStateException(var3.toString());
         } else {
            this.queue = var1;
         }
      }
   }

   public String toString() {
      return this.name;
   }
}
