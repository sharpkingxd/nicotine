import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.Socket;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public final class cq implements Closeable {
   public static final b ne = new b((fP)null);
   private final boolean client;
   private final c listener;
   private final Map<Integer, ct> nf;
   private final String connectionName;
   private int ng;
   private int nh;
   private boolean ni;
   private final bN nj;
   private final bM nk;
   private final bM nl;
   private final bM nm;
   private final cw pushObserver;
   private long nn;
   private long no;
   private long np;
   private long nq;
   private long nr;
   private long ns;
   private final cx nt;
   private cx nu;
   private long nv;
   private long nw;
   private long nx;
   private long ny;
   private final Socket nz;
   private final cu nA;
   private final d nB;
   private final Set<Integer> nC;
   private static final cx nD;

   public cq(a var1) {
      fR.c(var1, (String)"");
      super();
      this.client = var1.iy();
      this.listener = var1.iE();
      this.nf = (Map)(new LinkedHashMap());
      this.connectionName = var1.iB();
      this.nh = var1.iy() ? 3 : 2;
      this.nj = var1.iz();
      this.nk = this.nj.gw();
      this.nl = this.nj.gw();
      this.nm = this.nj.gw();
      this.pushObserver = var1.iF();
      cx var2 = new cx();
      boolean var4 = false;
      if (var1.iy()) {
         var2.d(7, 16777216);
      }

      this.nt = var2;
      this.nu = nD;
      this.ny = (long)this.nu.jx();
      this.nz = var1.iA();
      this.nA = new cu(var1.iD(), this.client);
      this.nB = new d(new cs(var1.iC(), this.client));
      this.nC = (Set)(new LinkedHashSet());
      if (var1.iG() != 0) {
         long var8 = TimeUnit.MILLISECONDS.toNanos((long)var1.iG());
         bM var9 = this.nk;
         String var5 = this.connectionName + " ping";
         boolean var6 = false;
         var9.a(new cq$j(var5, this, var8), var8);
      }

   }

   public final boolean il() {
      return this.client;
   }

   public final c im() {
      return this.listener;
   }

   public final Map<Integer, ct> in() {
      return this.nf;
   }

   public final String io() {
      return this.connectionName;
   }

   public final int ip() {
      return this.ng;
   }

   public final void F(int var1) {
      this.ng = var1;
   }

   public final int iq() {
      return this.nh;
   }

   public final cx ir() {
      return this.nt;
   }

   public final cx is() {
      return this.nu;
   }

   public final void a(cx var1) {
      fR.c(var1, (String)"");
      this.nu = var1;
   }

   public final long it() {
      return this.ny;
   }

   public final cu iu() {
      return this.nA;
   }

   public final synchronized ct G(int var1) {
      return (ct)this.nf.get(var1);
   }

   public final synchronized ct H(int var1) {
      ct var2 = (ct)this.nf.remove(var1);
      boolean var4 = false;
      fR.m(this);
      ((Object)this).notifyAll();
      return var2;
   }

   public final synchronized void l(long var1) {
      this.nv += var1;
      long var3 = this.nv - this.nw;
      if (var3 >= (long)(this.nt.jx() / 2)) {
         this.b(0, var3);
         this.nw += var3;
      }

   }

   public final ct a(List<cn> var1, boolean var2) throws IOException {
      fR.c(var1, (String)"");
      return this.a(0, var1, var2);
   }

   private final ct a(int var1, List<cn> var2, boolean var3) throws IOException {
      boolean var4 = !var3;
      boolean var5 = false;
      boolean var6 = false;
      ct var7 = null;
      int var8 = 0;
      cu var9 = this.nA;
      synchronized(var9) {
         boolean var10 = false;
         synchronized(this){}

         try {
            boolean var12 = false;
            if (this.nh > 1073741823) {
               this.a(cm.mE);
            }

            if (this.ni) {
               throw new cl();
            }

            var8 = this.nh;
            this.nh += 2;
            var7 = new ct(var8, this, var4, var5, (bq)null);
            var6 = !var3 || this.nx >= this.ny || var7.iV() >= var7.iW();
            if (var7.isOpen()) {
               this.nf.put(var8, var7);
            }

            eE var21 = eE.sk;
         } finally {
            ;
         }

         if (var1 == 0) {
            this.nA.a(var4, var8, var2);
         } else {
            if (this.client) {
               boolean var22 = false;
               String var23 = "client streams shouldn't have associated stream IDs";
               throw new IllegalArgumentException(var23.toString());
            }

            this.nA.b(var1, var8, var2);
         }

         eE var20 = eE.sk;
      }

      if (var6) {
         this.nA.jr();
      }

      return var7;
   }

   public final void a(int var1, boolean var2, List<cn> var3) throws IOException {
      fR.c(var3, (String)"");
      this.nA.a(var2, var1, var3);
   }

   public final void a(int var1, boolean var2, de var3, long var4) throws IOException {
      if (var4 == 0L) {
         this.nA.a(var2, var1, var3, 0);
      } else {
         long var11 = 0L;
         var11 = var4;

         while(var11 > 0L) {
            int var6 = 0;
            synchronized(this){}

            try {
               boolean var8 = false;

               try {
                  while(this.nx >= this.ny) {
                     if (!this.nf.containsKey(var1)) {
                        throw new IOException("stream closed");
                     }

                     boolean var10 = false;
                     fR.m(this);
                     ((Object)this).wait();
                  }
               } catch (InterruptedException var15) {
                  Thread.currentThread().interrupt();
                  throw new InterruptedIOException();
               }

               int var17 = (int)Math.min(var11, this.ny - this.nx);
               var6 = Math.min(var17, this.nA.js());
               this.nx += (long)var6;
               eE var19 = eE.sk;
            } finally {
               ;
            }

            var11 -= (long)var6;
            this.nA.a(var2 && var11 == 0L, var1, var3, var6);
         }

      }
   }

   public final void a(int var1, cm var2) {
      fR.c(var2, (String)"");
      bM var3 = this.nk;
      String var4 = this.connectionName + '[' + var1 + "] writeSynReset";
      long var5 = 0L;
      boolean var7 = true;
      boolean var8 = false;
      var3.a(new cq$k(var4, var7, this, var1, var2), var5);
   }

   public final void b(int var1, cm var2) throws IOException {
      fR.c(var2, (String)"");
      this.nA.e(var1, var2);
   }

   public final void b(int var1, long var2) {
      bM var4 = this.nk;
      String var5 = this.connectionName + '[' + var1 + "] windowUpdate";
      long var6 = 0L;
      boolean var8 = true;
      boolean var9 = false;
      var4.a(new cq$l(var5, var8, this, var1, var2), var6);
   }

   public final void a(boolean var1, int var2, int var3) {
      try {
         this.nA.c(var1, var2, var3);
      } catch (IOException var5) {
         this.l(var5);
      }

   }

   public final void iv() throws IOException {
      this.nA.jr();
   }

   public final void a(cm var1) throws IOException {
      fR.c(var1, (String)"");
      cu var2 = this.nA;
      synchronized(var2) {
         boolean var3 = false;
         fT.a var4 = new fT.a();
         synchronized(this){}

         try {
            boolean var6 = false;
            if (this.ni) {
               return;
            }

            this.ni = true;
            var4.sP = this.ng;
            eE var12 = eE.sk;
         } finally {
            ;
         }

         this.nA.a(var4.sP, var1, bD.jg);
         eE var11 = eE.sk;
      }

   }

   public void close() {
      this.a(cm.mx, cm.mF, (IOException)null);
   }

   public final void a(cm var1, cm var2, IOException var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      boolean var5 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         boolean var4 = false;

         try {
            var5 = false;
            this.a(var1);
         } catch (IOException var19) {
         }

         Object[] var21 = null;
         synchronized(this) {
            boolean var6 = false;
            if (!this.nf.isEmpty()) {
               Collection var7 = this.nf.values();
               boolean var8 = false;
               var21 = var7.toArray(new ct[0]);
               this.nf.clear();
            }

            eE var25 = eE.sk;
         }

         ct[] var10000 = (ct[])var21;
         if ((ct[])var21 != null) {
            ct[] var26 = var10000;
            boolean var29 = false;
            int var30 = 0;

            for(int var9 = var26.length; var30 < var9; ++var30) {
               ct var10 = var26[var30];
               ct var11 = var10;
               boolean var12 = false;
               boolean var13 = false;

               try {
                  boolean var14 = false;
                  var11.a(var2, var3);
               } catch (IOException var18) {
               }
            }
         }

         var5 = false;

         try {
            boolean var27 = false;
            this.nA.close();
         } catch (IOException var17) {
         }

         var5 = false;

         try {
            boolean var28 = false;
            this.nz.close();
         } catch (IOException var16) {
         }

         this.nk.gs();
         this.nl.gs();
         this.nm.gs();
      }
   }

   private final void l(IOException var1) {
      this.a(cm.my, cm.my, var1);
   }

   public final void a(boolean var1, bN var2) throws IOException {
      // $FF: Couldn't be decompiled
   }

   // $FF: synthetic method
   public static void a(cq var0, boolean var1, bN var2, int var3, Object var4) throws IOException {
      if ((var3 & 1) != 0) {
         var1 = true;
      }

      if ((var3 & 2) != 0) {
         var2 = bN.kr;
      }

      var0.a(var1, var2);
   }

   public final synchronized boolean m(long var1) {
      if (this.ni) {
         return false;
      } else {
         return this.nq >= this.np || var1 < this.ns;
      }
   }

   public final void iw() {
      synchronized(this){}

      label39: {
         try {
            boolean var2 = false;
            if (this.nq >= this.np) {
               int var3 = this.np++;
               this.ns = System.nanoTime() + (long)1000000000;
               eE var9 = eE.sk;
               break label39;
            }
         } finally {
            ;
         }

         return;
      }

      bM var1 = this.nk;
      String var10 = this.connectionName + " ping";
      long var11 = 0L;
      boolean var5 = true;
      boolean var6 = false;
      var1.a(new cq$i(var10, var5, this), var11);
   }

   public final boolean I(int var1) {
      return var1 != 0 && (var1 & 1) == 0;
   }

   public final void a(int var1, List<cn> var2) {
      fR.c(var2, (String)"");
      synchronized(this){}

      label44: {
         try {
            boolean var4 = false;
            if (!this.nC.contains(var1)) {
               var4 = this.nC.add(var1);
               break label44;
            }

            this.a(var1, cm.my);
         } finally {
            ;
         }

         return;
      }

      bM var3 = this.nl;
      String var12 = this.connectionName + '[' + var1 + "] onRequest";
      long var5 = 0L;
      boolean var7 = true;
      boolean var8 = false;
      var3.a(new cq$g(var12, var7, this, var1, var2), var5);
   }

   public final void b(int var1, List<cn> var2, boolean var3) {
      fR.c(var2, (String)"");
      bM var4 = this.nl;
      String var5 = this.connectionName + '[' + var1 + "] onHeaders";
      long var6 = 0L;
      boolean var8 = true;
      boolean var9 = false;
      var4.a(new cq$f(var5, var8, this, var1, var2, var3), var6);
   }

   public final void a(int var1, dg var2, int var3, boolean var4) throws IOException {
      fR.c(var2, (String)"");
      de var5 = new de();
      var2.u((long)var3);
      var2.a(var5, (long)var3);
      bM var6 = this.nl;
      String var7 = this.connectionName + '[' + var1 + "] onData";
      long var8 = 0L;
      boolean var10 = true;
      boolean var11 = false;
      var6.a(new cq$e(var7, var10, this, var1, var5, var3, var4), var8);
   }

   public final void c(int var1, cm var2) {
      fR.c(var2, (String)"");
      bM var3 = this.nl;
      String var4 = this.connectionName + '[' + var1 + "] onReset";
      long var5 = 0L;
      boolean var7 = true;
      boolean var8 = false;
      var3.a(new cq$h(var4, var7, this, var1, var2), var5);
   }

   // $FF: synthetic method
   public static final long h(cq var0) {
      return var0.nn;
   }

   // $FF: synthetic method
   public static final void e(cq var0, long var1) {
      var0.nn = var1;
   }

   // $FF: synthetic method
   public static final Set i(cq var0) {
      return var0.nC;
   }

   // $FF: synthetic method
   public static final cw j(cq var0) {
      return var0.pushObserver;
   }

   static {
      cx var0 = new cx();
      boolean var2 = false;
      var0.d(7, 65535);
      var0.d(5, 16384);
      nD = var0;
   }

   public static final class a {
      private boolean client;
      private final bN taskRunner;
      public Socket socket;
      public String connectionName;
      public dg source;
      public df sink;
      private c listener;
      private cw pushObserver;
      private int pingIntervalMillis;

      public a(boolean var1, bN var2) {
         fR.c(var2, (String)"");
         super();
         this.client = var1;
         this.taskRunner = var2;
         this.listener = cq.c.REFUSE_INCOMING_STREAMS;
         this.pushObserver = cw.op;
      }

      public final boolean iy() {
         return this.client;
      }

      public final bN iz() {
         return this.taskRunner;
      }

      public final Socket iA() {
         Socket var10000 = this.socket;
         if (var10000 != null) {
            return var10000;
         } else {
            fR.bc("");
            return null;
         }
      }

      public final void b(Socket var1) {
         fR.c(var1, (String)"");
         this.socket = var1;
      }

      public final String iB() {
         String var10000 = this.connectionName;
         if (var10000 != null) {
            return var10000;
         } else {
            fR.bc("");
            return null;
         }
      }

      public final void aF(String var1) {
         fR.c(var1, (String)"");
         this.connectionName = var1;
      }

      public final dg iC() {
         dg var10000 = this.source;
         if (var10000 != null) {
            return var10000;
         } else {
            fR.bc("");
            return null;
         }
      }

      public final void d(dg var1) {
         fR.c(var1, (String)"");
         this.source = var1;
      }

      public final df iD() {
         df var10000 = this.sink;
         if (var10000 != null) {
            return var10000;
         } else {
            fR.bc("");
            return null;
         }
      }

      public final void c(df var1) {
         fR.c(var1, (String)"");
         this.sink = var1;
      }

      public final c iE() {
         return this.listener;
      }

      public final cw iF() {
         return this.pushObserver;
      }

      public final int iG() {
         return this.pingIntervalMillis;
      }

      public final a a(Socket var1, String var2, dg var3, df var4) throws IOException {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         fR.c(var3, (String)"");
         fR.c(var4, (String)"");
         a var6 = this;
         boolean var7 = false;
         var6.b(var1);
         var6.aF(var6.client ? bD.jo + ' ' + var2 : "MockWebServer " + var2);
         var6.d(var3);
         var6.c(var4);
         return this;
      }

      public final a a(c var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.listener = var1;
         return this;
      }

      public final a J(int var1) {
         a var3 = this;
         boolean var4 = false;
         var3.pingIntervalMillis = var1;
         return this;
      }

      public final cq iH() {
         return new cq(this);
      }
   }

   public static final class b {
      private b() {
      }

      public final cx iI() {
         return cq.nD;
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }

   public abstract static class c {
      public static final a Companion = new a((fP)null);
      public static final c REFUSE_INCOMING_STREAMS = new c() {
         public void a(ct var1) throws IOException {
            fR.c(var1, (String)"");
            var1.a(cm.mE, (IOException)null);
         }
      };

      public abstract void a(ct var1) throws IOException;

      public void a(cq var1, cx var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
      }

      public static final class a {
         private a() {
         }

         // $FF: synthetic method
         public a(fP var1) {
            this();
         }
      }
   }

   public final class d implements cs.c, fJ<eE> {
      private final cs reader;

      public d(cs var2) {
         fR.c(var2, (String)"");
         super();
         this.reader = var2;
      }

      public void iJ() {
         cm var1 = cm.mz;
         cm var2 = cm.mz;
         IOException var3 = null;

         try {
            this.reader.a(this);

            while(this.reader.a(false, this)) {
            }

            var1 = cm.mx;
            var2 = cm.mF;
         } catch (IOException var7) {
            var3 = var7;
            var1 = cm.my;
            var2 = cm.my;
         } finally {
            cq.this.a(var1, var2, var3);
            bD.a(this.reader);
         }

      }

      public void a(boolean var1, int var2, dg var3, int var4) throws IOException {
         fR.c(var3, (String)"");
         if (cq.this.I(var2)) {
            cq.this.a(var2, var3, var4, var1);
         } else {
            ct var5 = cq.this.G(var2);
            if (var5 == null) {
               cq.this.a(var2, cm.my);
               cq.this.l((long)var4);
               var3.A((long)var4);
            } else {
               var5.a(var3, var4);
               if (var1) {
                  var5.a(bD.jh, true);
               }

            }
         }
      }

      public void a(boolean var1, int var2, int var3, List<cn> var4) {
         fR.c(var4, (String)"");
         if (cq.this.I(var2)) {
            cq.this.b(var2, var4, var1);
         } else {
            ct var5 = null;
            cq var6 = cq.this;
            cq var7 = cq.this;
            synchronized(var6){}

            label107: {
               try {
                  boolean var9 = false;
                  var5 = var7.G(var2);
                  if (var5 != null) {
                     eE var21 = eE.sk;
                     break label107;
                  }

                  if (!var7.ni) {
                     if (var2 <= var7.ip()) {
                        return;
                     }

                     if (var2 % 2 == var7.iq() % 2) {
                        return;
                     }

                     bq var10 = bD.a(var4);
                     ct var11 = new ct(var2, var7, false, var1, var10);
                     var7.F(var2);
                     Integer var12 = var2;
                     var7.in().put(var12, var11);
                     bM var13 = var7.nj.gw();
                     String var22 = var7.io() + '[' + var2 + "] onStream";
                     long var14 = 0L;
                     boolean var16 = true;
                     boolean var17 = false;
                     var13.a(new cq$d$b(var22, var16, var7, var11), var14);
                     return;
                  }
               } finally {
                  ;
               }

               return;
            }

            var5.a(bD.a(var4), var1);
         }
      }

      public void d(int var1, cm var2) {
         fR.c(var2, (String)"");
         if (cq.this.I(var1)) {
            cq.this.c(var1, var2);
         } else {
            ct var3 = cq.this.H(var1);
            if (var3 != null) {
               var3.c(var2);
            }

         }
      }

      public void a(boolean var1, cx var2) {
         fR.c(var2, (String)"");
         bM var3 = cq.this.nk;
         String var4 = cq.this.io() + " applyAndAckSettings";
         long var5 = 0L;
         boolean var7 = true;
         boolean var8 = false;
         var3.a(new cq$d$d(var4, var7, this, var1, var2), var5);
      }

      public final void b(boolean var1, cx var2) {
         fR.c(var2, (String)"");
         long var24 = 0L;
         Object var3 = null;
         fT.b var4 = new fT.b();
         cu var5 = cq.this.iu();
         cq var6 = cq.this;
         ct[] var30;
         synchronized(var5) {
            boolean var8 = false;
            synchronized(var6) {
               boolean var10 = false;
               cx var11 = var6.is();
               fT.b var10000 = var4;
               cx var10001;
               if (var1) {
                  var10001 = var2;
               } else {
                  cx var12 = new cx();
                  boolean var15 = false;
                  var12.d(var11);
                  var12.d(var2);
                  var10000 = var4;
                  var10001 = var12;
               }

               var10000.sQ = (T)var10001;
               long var16 = (long)((cx)var4.sQ).jx();
               var24 = var16 - (long)var11.jx();
               ct[] var42;
               if (var24 != 0L && !var6.in().isEmpty()) {
                  Collection var38 = var6.in().values();
                  boolean var18 = false;
                  var42 = (ct[])var38.toArray(new ct[0]);
               } else {
                  var42 = null;
               }

               var30 = var42;
               var6.a((cx)var4.sQ);
               bM var39 = var6.nm;
               String var40 = var6.io() + " onSettings";
               long var20 = 0L;
               boolean var22 = true;
               boolean var23 = false;
               var39.a(new cq$d$a(var40, var22, var6, var4), var20);
               eE var35 = eE.sk;
            }

            try {
               var6.iu().b((cx)var4.sQ);
            } catch (IOException var27) {
               var6.l(var27);
            }

            eE var33 = eE.sk;
         }

         if (var30 != null) {
            ct[] var31 = var30;
            int var32 = 0;

            for(int var7 = var30.length; var32 < var7; ++var32) {
               ct var34 = var31[var32];
               synchronized(var34) {
                  boolean var36 = false;
                  var34.q(var24);
                  eE var37 = eE.sk;
               }
            }
         }

      }

      public void iK() {
      }

      public void b(boolean var1, int var2, int var3) {
         if (var1) {
            cq var4 = cq.this;
            cq var5 = cq.this;
            synchronized(var4) {
               boolean var7 = false;
               switch (var2) {
                  case 1:
                     long var16 = var5.no;
                     var5.no = var16 + 1L;
                     Long var19 = var16;
                     break;
                  case 2:
                     long var15 = var5.nq;
                     var5.nq = var15 + 1L;
                     Long var18 = var15;
                     break;
                  case 3:
                     long var8 = var5.nr;
                     var5.nr = var8 + 1L;
                     boolean var11 = false;
                     fR.m(var5);
                     ((Object)var5).notifyAll();
                     eE var10000 = eE.sk;
                     break;
                  default:
                     eE var20 = eE.sk;
               }
            }
         } else {
            bM var13 = cq.this.nk;
            String var14 = cq.this.io() + " ping";
            cq var9 = cq.this;
            long var6 = 0L;
            boolean var17 = true;
            boolean var10 = false;
            var13.a(new cq$d$c(var14, var17, var9, var2, var3), var6);
         }

      }

      public void a(int var1, cm var2, dh var3) {
         fR.c(var2, (String)"");
         fR.c(var3, (String)"");
         if (var3.lm() > 0) {
         }

         Object var4 = null;
         cq var5 = cq.this;
         cq var6 = cq.this;
         Object[] var13;
         synchronized(var5) {
            boolean var8 = false;
            Collection var9 = var6.in().values();
            boolean var10 = false;
            var13 = var9.toArray(new ct[0]);
            var6.ni = true;
            eE var16 = eE.sk;
         }

         ct[] var14 = (ct[])var13;
         int var15 = 0;

         for(int var7 = var14.length; var15 < var7; ++var15) {
            ct var17 = var14[var15];
            if (var17.iR() > var1 && var17.jd()) {
               var17.c(cm.mE);
               cq.this.H(var17.iR());
            }
         }

      }

      public void c(int var1, long var2) {
         if (var1 == 0) {
            cq var4 = cq.this;
            cq var5 = cq.this;
            synchronized(var4) {
               boolean var7 = false;
               var5.ny = var5.it() + var2;
               boolean var9 = false;
               fR.m(var5);
               ((Object)var5).notifyAll();
               eE var14 = eE.sk;
            }
         } else {
            ct var12 = cq.this.G(var1);
            if (var12 != null) {
               synchronized(var12) {
                  boolean var6 = false;
                  var12.q(var2);
                  eE var13 = eE.sk;
               }
            }
         }

      }

      public void a(int var1, int var2, int var3, boolean var4) {
      }

      public void a(int var1, int var2, List<cn> var3) {
         fR.c(var3, (String)"");
         cq.this.a(var2, var3);
      }

      // $FF: synthetic method
      public Object invoke() {
         this.iJ();
         return eE.sk;
      }
   }
}
