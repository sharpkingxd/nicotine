import java.io.IOException;

public abstract class di implements dy {
   private final dy delegate;

   public di(dy var1) {
      fR.c(var1, (String)"");
      super();
      this.delegate = var1;
   }

   public void b(de var1, long var2) throws IOException {
      fR.c(var1, (String)"");
      this.delegate.b(var1, var2);
   }

   public void flush() throws IOException {
      this.delegate.flush();
   }

   public dB fu() {
      return this.delegate.fu();
   }

   public void close() throws IOException {
      this.delegate.close();
   }

   public String toString() {
      return this.getClass().getSimpleName() + '(' + this.delegate + ')';
   }
}
