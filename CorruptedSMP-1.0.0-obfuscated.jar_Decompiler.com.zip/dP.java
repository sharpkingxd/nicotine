import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitRunnable;

public class dP implements Listener {
   final CorruptedSMPPlugin ri;
   int rj = 0;

   public dP(CorruptedSMPPlugin var1) {
      this.ri = var1;
      this.mE();
   }

   private void mE() {
      (new BukkitRunnable() {
         public void run() {
            ++dP.this.rj;
            if (dP.this.rj % 10 == 0) {
               for(Player var2 : dP.this.ri.getServer().getOnlinePlayers()) {
                  if (dP.this.ri.d().b(var2)) {
                     dP.this.f(var2);
                  }
               }
            }

         }
      }).runTaskTimer(this.ri, 0L, 1L);
   }

   void f(Player var1) {
      l var2 = this.ri.d().c(var1);
      if (var2 != null) {
         Location var3 = var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
         switch (var2) {
            case C:
               Particle.DustOptions var12 = new Particle.DustOptions(Color.fromRGB(255, 50, 50), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var12);
               if (this.rj % 40 == 0) {
                  var1.getWorld().spawnParticle(Particle.HEART, var3, 1, 0.3, 0.3, 0.3, (double)0.0F);
               }
               break;
            case E:
               Particle.DustOptions var11 = new Particle.DustOptions(Color.fromRGB(30, 100, 200), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var11);
               var1.getWorld().spawnParticle(Particle.DRIPPING_WATER, var3.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 2, 0.3, 0.3, 0.3, (double)0.0F);
               break;
            case D:
               Particle.DustOptions var10 = new Particle.DustOptions(Color.fromRGB(192, 192, 192), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var10);
               var1.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var3, 2, 0.3, (double)0.5F, 0.3, (double)0.0F);
               break;
            case B:
               Particle.DustOptions var9 = new Particle.DustOptions(Color.fromRGB(255, 255, 0), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var9);
               var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var3, 2, 0.3, (double)0.5F, 0.3, 0.02);
               break;
            case A:
               Particle.DustOptions var8 = new Particle.DustOptions(Color.fromRGB(255, 140, 0), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var8);
               var1.getWorld().spawnParticle(Particle.FLAME, var3, 2, 0.3, (double)0.5F, 0.3, 0.01);
               break;
            case w:
               Particle.DustOptions var7 = new Particle.DustOptions(Color.fromRGB(230, 240, 255), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var7);
               var1.getWorld().spawnParticle(Particle.CLOUD, var3, 2, 0.3, (double)0.5F, 0.3, 0.02);
               break;
            case v:
               Particle.DustOptions var6 = new Particle.DustOptions(Color.fromRGB(128, 0, 128), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var6);
               var1.getWorld().spawnParticle(Particle.PORTAL, var3, 3, 0.3, (double)0.5F, 0.3, 0.1);
               break;
            case u:
               Particle.DustOptions var5 = new Particle.DustOptions(Color.fromRGB(30, 30, 30), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var5);
               var1.getWorld().spawnParticle(Particle.LARGE_SMOKE, var3, 2, 0.3, (double)0.5F, 0.3, 0.01);
               break;
            case t:
               Particle.DustOptions var4 = new Particle.DustOptions(Color.fromRGB(255, 0, 255), 1.0F);
               var1.getWorld().spawnParticle(Particle.DUST, var3, 3, 0.3, (double)0.5F, 0.3, (double)0.0F, var4);
               if (this.rj % 20 == 0) {
                  var1.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var3, 2, 0.3, 0.3, 0.3, (double)0.0F);
                  var1.getWorld().spawnParticle(Particle.FIREWORK, var3, 1, 0.3, 0.3, 0.3, 0.02);
               }
         }

      }
   }
}
