public class fG extends fD {
   private final boolean ao(int var1) {
      return fG.a.sM == null || fG.a.sM >= var1;
   }

   public void a(Throwable var1, Throwable var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      if (this.ao(19)) {
         var1.addSuppressed(var2);
      } else {
         super.a(var1, var2);
      }

   }

   static final class a {
      public static final a sL = new a();
      public static final Integer sM;

      private a() {
      }

      static {
         Integer var1;
         try {
            Object var5 = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get((Object)null);
            var1 = var5 instanceof Integer ? (Integer)var5 : null;
         } catch (Throwable var4) {
            var1 = null;
         }

         Integer var10000;
         if (var1 != null) {
            int var2 = ((Number)var1).intValue();
            boolean var3 = false;
            var10000 = var2 > 0 ? var1 : null;
         } else {
            var10000 = null;
         }

         sM = var10000;
      }
   }
}
