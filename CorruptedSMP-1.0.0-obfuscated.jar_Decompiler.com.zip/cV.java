import java.security.GeneralSecurityException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;

public final class cV extends cX {
   public static final a pI = new a((fP)null);
   private final cZ pJ;

   public cV(cZ var1) {
      fR.c(var1, (String)"");
      super();
      this.pJ = var1;
   }

   public List<Certificate> a(List<? extends Certificate> var1, String var2) throws SSLPeerUnverifiedException {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      Deque var3 = (Deque)(new ArrayDeque((Collection)var1));
      List var4 = (List)(new ArrayList());
      Object var10001 = var3.removeFirst();
      fR.b(var10001, "");
      var4.add(var10001);
      boolean var5 = false;

      for(int var6 = 0; var6 < 9; ++var6) {
         Object var10000 = var4.get(var4.size() - 1);
         fR.m(var10000);
         X509Certificate var7 = (X509Certificate)var10000;
         X509Certificate var8 = this.pJ.c(var7);
         if (var8 == null) {
            Iterator var11 = var3.iterator();
            fR.b(var11, "");
            Iterator var9 = var11;

            X509Certificate var10;
            do {
               if (!var9.hasNext()) {
                  if (var5) {
                     return var4;
                  }

                  throw new SSLPeerUnverifiedException("Failed to find a trusted cert that signed " + var7);
               }

               Object var12 = var9.next();
               fR.m(var12);
               var10 = (X509Certificate)var12;
            } while(!this.a(var7, var10));

            var9.remove();
            var4.add(var10);
         } else {
            if (var4.size() > 1 || !fR.c(var7, (Object)var8)) {
               var4.add(var8);
            }

            if (this.a(var8, var8)) {
               return var4;
            }

            var5 = true;
         }
      }

      throw new SSLPeerUnverifiedException("Certificate chain too long: " + var4);
   }

   private final boolean a(X509Certificate var1, X509Certificate var2) {
      if (!fR.c(var1.getIssuerDN(), (Object)var2.getSubjectDN())) {
         return false;
      } else {
         boolean var3;
         try {
            var1.verify(var2.getPublicKey());
            var3 = true;
         } catch (GeneralSecurityException var5) {
            var3 = false;
         }

         return var3;
      }
   }

   public int hashCode() {
      return this.pJ.hashCode();
   }

   public boolean equals(Object var1) {
      return var1 == this ? true : var1 instanceof cV && fR.c(((cV)var1).pJ, (Object)this.pJ);
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
