public interface fJ<R> {
   R invoke();
}
