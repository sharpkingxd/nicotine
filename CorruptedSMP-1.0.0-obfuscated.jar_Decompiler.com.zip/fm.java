import java.util.Set;

class fm extends fl {
   public static final <T> Set<T> ns() {
      return fc.sy;
   }

   public static final <T> Set<T> a(Set<? extends T> var0) {
      fR.c(var0, (String)"");
      Set var10000;
      switch (var0.size()) {
         case 0:
            var10000 = fk.ns();
            break;
         case 1:
            var10000 = fk.l(var0.iterator().next());
            break;
         default:
            var10000 = var0;
      }

      return var10000;
   }
}
