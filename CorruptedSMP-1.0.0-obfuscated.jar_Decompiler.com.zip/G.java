public interface G {
   boolean a(H var1);

   boolean a(Class<?> var1);
}
