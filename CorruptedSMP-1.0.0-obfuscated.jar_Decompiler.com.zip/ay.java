import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collection;

public final class ay implements ad {
   private final al bD;

   public ay(al var1) {
      this.bD = var1;
   }

   public <T> ac<T> a(K var1, aS<T> var2) {
      Type var3 = var2.bl();
      Class var4 = var2.bk();
      if (!Collection.class.isAssignableFrom(var4)) {
         return null;
      } else {
         Type var5 = ak.a(var3, var4);
         ac var6 = var1.a(aS.k(var5));
         ar var7 = this.bD.b(var2);
         a var8 = new a(var1, var5, var6, var7);
         return var8;
      }
   }

   static final class a<E> extends ac<Collection<E>> {
      private final ac<E> elementTypeAdapter;
      private final ar<? extends Collection<E>> constructor;

      public a(K var1, Type var2, ac<E> var3, ar<? extends Collection<E>> var4) {
         this.elementTypeAdapter = new aK<E>(var1, var3, var2);
         this.constructor = var4;
      }

      public Collection<E> l(aT var1) throws IOException {
         if (var1.aI() == aU.dY) {
            var1.aO();
            return null;
         } else {
            Collection var2 = this.constructor.av();
            var1.aE();

            while(var1.hasNext()) {
               Object var3 = this.elementTypeAdapter.b(var1);
               var2.add(var3);
            }

            var1.aF();
            return var2;
         }
      }

      public void a(aV var1, Collection<E> var2) throws IOException {
         if (var2 == null) {
            var1.be();
         } else {
            var1.ba();

            for(Object var4 : var2) {
               this.elementTypeAdapter.a(var1, var4);
            }

            var1.bb();
         }
      }

      // $FF: synthetic method
      public Object b(aT var1) throws IOException {
         return this.l(var1);
      }
   }
}
