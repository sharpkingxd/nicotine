import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class dk extends dB {
   private dB pW;

   public dk(dB var1) {
      fR.c(var1, (String)"");
      super();
      this.pW = var1;
   }

   public final dB lr() {
      return this.pW;
   }

   public final dk a(dB var1) {
      fR.c(var1, (String)"");
      this.pW = var1;
      return this;
   }

   public dB d(long var1, TimeUnit var3) {
      fR.c(var3, (String)"");
      return this.pW.d(var1, var3);
   }

   public long ls() {
      return this.pW.ls();
   }

   public boolean lt() {
      return this.pW.lt();
   }

   public long lu() {
      return this.pW.lu();
   }

   public dB F(long var1) {
      return this.pW.F(var1);
   }

   public dB lv() {
      return this.pW.lv();
   }

   public dB lw() {
      return this.pW.lw();
   }

   public void lx() throws IOException {
      this.pW.lx();
   }
}
