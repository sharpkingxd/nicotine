import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class bw {
   private final br iN;
   private final String method;
   private final bq iO;
   private final bx body;
   private final Map<Class<?>, Object> tags;
   private ba iP;

   public bw(br var1, String var2, bq var3, bx var4, Map<Class<?>, ? extends Object> var5) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var5, (String)"");
      super();
      this.iN = var1;
      this.method = var2;
      this.iO = var3;
      this.body = var4;
      this.tags = var5;
   }

   public final br eI() {
      return this.iN;
   }

   public final String eJ() {
      return this.method;
   }

   public final bq eK() {
      return this.iO;
   }

   public final bx eL() {
      return this.body;
   }

   public final Map<Class<?>, Object> eM() {
      return this.tags;
   }

   public final boolean eN() {
      return this.iN.da();
   }

   public final String ah(String var1) {
      fR.c(var1, (String)"");
      return this.iO.E(var1);
   }

   public final List<String> ai(String var1) {
      fR.c(var1, (String)"");
      return this.iO.F(var1);
   }

   public final a eO() {
      return new a(this);
   }

   public final ba eP() {
      ba var1 = this.iP;
      if (var1 == null) {
         var1 = ba.et.b(this.iO);
         this.iP = var1;
      }

      return var1;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      StringBuilder var2 = var1;
      boolean var3 = false;
      var1.append("Request{method=");
      var1.append(this.method);
      var1.append(", url=");
      var1.append(this.iN);
      if (this.iO.cT() != 0) {
         var1.append(", headers=[");
         Iterable var4 = this.iO;
         boolean var5 = false;
         int var6 = 0;

         for(Object var8 : var4) {
            int var9 = var6++;
            if (var9 < 0) {
               eO.nl();
            }

            ez var10 = (ez)var8;
            boolean var12 = false;
            String var13 = (String)var10.ng();
            String var14 = (String)var10.nh();
            if (var9 > 0) {
               var2.append(", ");
            }

            var2.append(var13);
            var2.append(':');
            var2.append(var14);
         }

         var2.append(']');
      }

      if (!this.tags.isEmpty()) {
         var2.append(", tags=");
         var2.append(this.tags);
      }

      var2.append('}');
      String var15 = var1.toString();
      fR.b(var15, "");
      return var15;
   }

   public static class a {
      private br url;
      private String method;
      private bq.a headers;
      private bx body;
      private Map<Class<?>, Object> tags;

      public a() {
         this.tags = (Map)(new LinkedHashMap());
         this.method = "GET";
         this.headers = new bq.a();
      }

      public a(bw var1) {
         fR.c(var1, (String)"");
         super();
         this.tags = (Map)(new LinkedHashMap());
         this.url = var1.eI();
         this.method = var1.eJ();
         this.body = var1.eL();
         this.tags = var1.eM().isEmpty() ? (Map)(new LinkedHashMap()) : fe.d(var1.eM());
         this.headers = var1.eK().cU();
      }

      public a c(br var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.url = var1;
         return this;
      }

      public a aj(String var1) {
         fR.c(var1, (String)"");
         String var3;
         if (gA.b(var1, "ws:", true)) {
            StringBuilder var10000 = (new StringBuilder()).append("http:");
            String var10001 = var1.substring(3);
            fR.b(var10001, "");
            var3 = var10000.append(var10001).toString();
         } else if (gA.b(var1, "wss:", true)) {
            StringBuilder var4 = (new StringBuilder()).append("https:");
            String var5 = var1.substring(4);
            fR.b(var5, "");
            var3 = var4.append(var5).toString();
         } else {
            var3 = var1;
         }

         String var2 = var3;
         return this.c(br.hQ.aa(var2));
      }

      public a h(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         var4.headers.f(var1, var2);
         return this;
      }

      public a i(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         var4.headers.d(var1, var2);
         return this;
      }

      public a ak(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.headers.H(var1);
         return this;
      }

      public a c(bq var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         var3.headers = var1.cU();
         return this;
      }

      public a a(bx var1) {
         fR.c(var1, (String)"");
         return this.a("POST", var1);
      }

      public a a(String var1, bx var2) {
         fR.c(var1, (String)"");
         a var4 = this;
         boolean var5 = false;
         if (((CharSequence)var1).length() <= 0) {
            boolean var10 = false;
            String var11 = "method.isEmpty() == true";
            throw new IllegalArgumentException(var11.toString());
         } else {
            if (var2 == null) {
               if (cd.aA(var1)) {
                  boolean var6 = false;
                  String var7 = "method " + var1 + " must have a request body.";
                  throw new IllegalArgumentException(var7.toString());
               }
            } else if (!cd.aB(var1)) {
               boolean var8 = false;
               String var9 = "method " + var1 + " must not have a request body.";
               throw new IllegalArgumentException(var9.toString());
            }

            var4.method = var1;
            var4.body = var2;
            return this;
         }
      }

      public bw eQ() {
         br var10000 = this.url;
         if (var10000 == null) {
            boolean var1 = false;
            String var7 = "url == null";
            throw new IllegalStateException(var7.toString());
         } else {
            String var10001 = this.method;
            bq var10002 = this.headers.cW();
            bx var10003 = this.body;
            Map var2 = bD.a(this.tags);
            bx var3 = var10003;
            bq var4 = var10002;
            String var5 = var10001;
            br var6 = var10000;
            return new bw(var6, var5, var4, var3, var2);
         }
      }
   }
}
