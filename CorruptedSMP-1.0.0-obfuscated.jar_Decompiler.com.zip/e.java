import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class e implements CommandExecutor {
   private final CorruptedSMPPlugin o;

   public e(CorruptedSMPPlugin var1) {
      this.o = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("corruptedsmp.withdraw")) {
            var5.sendMessage(this.a("§cYou don't have permission to use this command!"));
            return true;
         } else if (!this.o.d().b(var5)) {
            var5.sendMessage(this.a("§cYou don't have a corruption equipped in your slot!"));
            var5.sendMessage(this.a("§7Right-click a corruption core to equip it first."));
            return true;
         } else {
            l var6 = this.o.d().c(var5);
            if (var6 == null) {
               var5.sendMessage(this.a("§cError: Could not find your corruption type!"));
               return true;
            } else if (var5.getInventory().firstEmpty() == -1) {
               var5.sendMessage(this.a("§cYour inventory is full! Make space and try again."));
               return true;
            } else {
               this.o.d().a(var5);
               ItemStack var7 = this.a(var6);
               var5.getInventory().addItem(new ItemStack[]{var7});
               var5.playSound(var5.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0F, 1.0F);
               var5.sendMessage(this.a("§aYou have withdrawn your " + var6.o() + " §aCore!"));
               var5.sendMessage(this.a("§7The corruption has been removed from your slot."));
               var5.sendMessage(this.a("§7Right-click the core to equip it again."));
               return true;
            }
         }
      } else {
         var1.sendMessage("§cThis command can only be used by players!");
         return true;
      }
   }

   private ItemStack a(l var1) {
      ItemStack var2 = new ItemStack(Material.FLOW_BANNER_PATTERN);
      ItemMeta var3 = var2.getItemMeta();
      if (var3 != null) {
         var3.setDisplayName(var1.o() + " §fCore");
         var3.setLore(j.b(var1));
         var3.setCustomModelData(var1.n());
         var3.addEnchant(Enchantment.UNBREAKING, 1, true);
         var3.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         var2.setItemMeta(var3);
      }

      return var2;
   }

   private String a(String var1) {
      String var2 = this.o.getConfig().getString("messages.prefix", "");
      return (var2 + var1).replace("&", "§");
   }
}
