import java.io.IOException;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public final class cr implements cb {
   public static final a nE = new a((fP)null);
   private final bT nF;
   private final ce nG;
   private final cq nH;
   private volatile ct nI;
   private final bv nJ;
   private volatile boolean ld;
   private static final List<String> nK;
   private static final List<String> nL;

   public cr(bu var1, bT var2, ce var3, cq var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      super();
      this.nF = var2;
      this.nG = var3;
      this.nH = var4;
      this.nJ = var1.dO().contains(bv.iK) ? bv.iK : bv.iJ;
   }

   public bT gU() {
      return this.nF;
   }

   public dy a(bw var1, long var2) {
      fR.c(var1, (String)"");
      ct var10000 = this.nI;
      fR.m(var10000);
      return var10000.jh();
   }

   public void g(bw var1) {
      fR.c(var1, (String)"");
      if (this.nI == null) {
         boolean var2 = var1.eL() != null;
         List var3 = nE.i(var1);
         this.nI = this.nH.a(var3, var2);
         if (this.ld) {
            ct var5 = this.nI;
            fR.m(var5);
            var5.b(cm.mF);
            throw new IOException("Canceled");
         } else {
            ct var10000 = this.nI;
            fR.m(var10000);
            var10000.jf().d((long)this.nG.hK(), TimeUnit.MILLISECONDS);
            var10000 = this.nI;
            fR.m(var10000);
            var10000.jg().d((long)this.nG.hL(), TimeUnit.MILLISECONDS);
         }
      }
   }

   public void gI() {
      this.nH.iv();
   }

   public void gJ() {
      ct var10000 = this.nI;
      fR.m(var10000);
      var10000.jh().close();
   }

   public by.a r(boolean var1) {
      ct var10000 = this.nI;
      if (var10000 == null) {
         throw new IOException("stream wasn't created");
      } else {
         ct var2 = var10000;
         bq var3 = var2.je();
         by.a var4 = nE.a(var3, this.nJ);
         return var1 && var4.fk() == 100 ? null : var4;
      }
   }

   public long l(by var1) {
      fR.c(var1, (String)"");
      return !cc.n(var1) ? 0L : bD.h(var1);
   }

   public dA m(by var1) {
      fR.c(var1, (String)"");
      ct var10000 = this.nI;
      fR.m(var10000);
      return var10000.iX();
   }

   public void gM() {
      this.ld = true;
      ct var10000 = this.nI;
      if (var10000 != null) {
         var10000.b(cm.mF);
      }

   }

   static {
      String[] var0 = new String[]{"connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade", ":method", ":path", ":scheme", ":authority"};
      nK = bD.b(var0);
      var0 = new String[]{"connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade"};
      nL = bD.b(var0);
   }

   public static final class a {
      private a() {
      }

      public final List<cn> i(bw var1) {
         fR.c(var1, (String)"");
         bq var2 = var1.eK();
         ArrayList var3 = new ArrayList(var2.cT() + 4);
         var3.add(new cn(cn.mS, var1.eJ()));
         var3.add(new cn(cn.mT, cg.me.g(var1.eI())));
         String var4 = var1.ah("Host");
         if (var4 != null) {
            var3.add(new cn(cn.mV, var4));
         }

         var3.add(new cn(cn.mU, var1.eI().cX()));
         int var5 = 0;

         for(int var6 = var2.cT(); var5 < var6; ++var5) {
            String var8 = var2.j(var5);
            Locale var10000 = Locale.US;
            fR.b(var10000, "");
            String var9 = var8.toLowerCase(var10000);
            fR.b(var9, "");
            String var7 = var9;
            if (!cr.nK.contains(var7) || fR.c(var7, (Object)"te") && fR.c(var2.k(var5), (Object)"trailers")) {
               var3.add(new cn(var7, var2.k(var5)));
            }
         }

         return (List)var3;
      }

      public final by.a a(bq var1, bv var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         ci var3 = null;
         bq.a var4 = new bq.a();
         int var5 = 0;

         for(int var6 = var1.cT(); var5 < var6; ++var5) {
            String var7 = var1.j(var5);
            String var8 = var1.k(var5);
            if (fR.c(var7, (Object)":status")) {
               var3 = ci.mh.aE("HTTP/1.1 " + var8);
            } else if (!cr.nL.contains(var7)) {
               var4.e(var7, var8);
            }
         }

         if (var3 == null) {
            throw new ProtocolException("Expected ':status' header not present");
         } else {
            return (new by.a()).b(var2).n(var3.mj).al(var3.mk).d(var4.cW());
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
