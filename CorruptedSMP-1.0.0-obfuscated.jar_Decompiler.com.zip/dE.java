public final class dE {
   private static final byte[] qF = dD.aX("0123456789abcdef");

   public static final byte[] lP() {
      return qF;
   }

   public static final String d(de var0, long var1) {
      fR.c(var0, (String)"");
      String var10000;
      if (var1 > 0L && var0.v(var1 - 1L) == 13) {
         String var4 = var0.x(var1 - 1L);
         var0.A(2L);
         var10000 = var4;
      } else {
         String var3 = var0.x(var1);
         var0.A(1L);
         var10000 = var3;
      }

      return var10000;
   }

   public static final int a(de var0, dr var1, boolean var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      dv var10000 = var0.pR;
      if (var10000 == null) {
         return var2 ? -2 : -1;
      } else {
         dv var3 = var10000;
         dv var4 = var3;
         byte[] var5 = var3.qs;
         int var6 = var3.dH;
         int var7 = var3.dI;
         int[] var8 = var1.lG();
         int var9 = 0;
         int var10 = -1;

         while(true) {
            int var11 = var8[var9++];
            int var12 = var8[var9++];
            if (var12 != -1) {
               var10 = var12;
            }

            int var13 = 0;
            if (var4 != null) {
               label99: {
                  if (var11 < 0) {
                     int var14 = -1 * var11;
                     int var15 = var9 + var14;

                     byte var26;
                     do {
                        var26 = var5[var6++];
                        short var18 = 255;
                        boolean var19 = false;
                        int var16 = var26 & var18;
                        if (var16 != var8[var9++]) {
                           return var10;
                        }

                        var26 = var9 == var15;
                        if (var6 == var7) {
                           fR.m(var4);
                           var10000 = var4.qv;
                           fR.m(var10000);
                           var4 = var10000;
                           var6 = var4.dH;
                           var5 = var4.qs;
                           var7 = var4.dI;
                           if (var4 == var3) {
                              if (!var26) {
                                 break label99;
                              }

                              var4 = null;
                           }
                        }
                     } while(!var26);

                     var13 = var8[var9];
                  } else {
                     int var24 = var5[var6++];
                     short var27 = 255;
                     boolean var28 = false;
                     int var23 = var24 & var27;
                     var24 = var9 + var11;

                     while(true) {
                        if (var9 == var24) {
                           return var10;
                        }

                        if (var23 == var8[var9]) {
                           var13 = var8[var9 + var11];
                           if (var6 == var7) {
                              var10000 = var4.qv;
                              fR.m(var10000);
                              var4 = var10000;
                              var6 = var4.dH;
                              var5 = var4.qs;
                              var7 = var4.dI;
                              if (var4 == var3) {
                                 var4 = null;
                              }
                           }
                           break;
                        }

                        ++var9;
                     }
                  }

                  if (var13 >= 0) {
                     return var13;
                  }

                  var9 = -var13;
                  continue;
               }
            }

            if (var2) {
               return -2;
            }

            return var10;
         }
      }
   }

   // $FF: synthetic method
   public static int a(de var0, dr var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return a(var0, var1, var2);
   }
}
