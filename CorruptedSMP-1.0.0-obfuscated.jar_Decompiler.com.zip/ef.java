import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;

public class ef implements Listener {
   private final CorruptedSMPPlugin rC;

   public ef(CorruptedSMPPlugin var1) {
      this.rC = var1;
   }

   @EventHandler
   public void a(ProjectileLaunchEvent var1) {
   }
}
