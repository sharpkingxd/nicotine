import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class en {
   private final CorruptedSMPPlugin rY;
   private final Map<UUID, el> rZ;

   public en(CorruptedSMPPlugin var1) {
      this.rY = var1;
      this.rZ = new HashMap();
   }

   public boolean a(Player var1, l var2, Location var3) {
      if (!this.rZ.isEmpty()) {
         el var4 = (el)this.rZ.values().stream().filter((var0) -> !var0.mY()).findFirst().orElse((Object)null);
         if (var4 != null) {
            Player var11 = var4.mU();
            String var12 = this.a(var4.mX().getWorld());
            Location var13 = var4.mX();
            var1.sendMessage(this.a("§c§lA ritual is already in progress!"));
            var1.sendMessage(this.a(String.format("§7Player: §f%s §7| Corruption: %s", var11.getName(), var4.mV().o())));
            var1.sendMessage(this.a(String.format("§7World: §f%s §7| Location: §fX:%d Y:%d Z:%d", var12, var13.getBlockX(), var13.getBlockY(), var13.getBlockZ())));
            var1.sendMessage(this.a(String.format("§7Time Remaining: §e%d:%02d", var4.mW() / 60, var4.mW() % 60)));
            return false;
         }
      }

      if (this.rZ.containsKey(var1.getUniqueId())) {
         el var9 = (el)this.rZ.get(var1.getUniqueId());
         if (var9 != null && !var9.mY()) {
            var1.sendMessage(this.a("§cYou already have an active ritual!"));
            return false;
         }

         this.rZ.remove(var1.getUniqueId());
      }

      int var10 = this.rY.getConfig().getInt("rituals.duration", 900);
      int var5 = this.rY.getConfig().getInt("rituals.radius", 5);
      el var6 = new el(this.rY, var1, var2, var3, var10, var5);
      this.rZ.put(var1.getUniqueId(), var6);
      var6.mF();
      String var7 = this.rY.getConfig().getString("messages.ritual-started").replace("{radius}", String.valueOf(var5)).replace("{duration}", String.valueOf(var10));
      var1.sendMessage(this.a(var7));
      if (this.rY.getConfig().getBoolean("rituals.broadcast", true)) {
         String var8 = this.a(var3.getWorld());
         Server var10000 = this.rY.getServer();
         String var10002 = var1.getName();
         var10000.broadcastMessage(this.a("§e" + var10002 + " §7has started a §e" + var2.o() + " §7ritual in §f" + var8 + "§7!"));
      }

      return true;
   }

   public void j(UUID var1) {
      el var2 = (el)this.rZ.remove(var1);
      if (var2 != null) {
         var2.mR();
      }

   }

   public void nb() {
      for(el var2 : this.rZ.values()) {
         try {
            var2.t();
         } catch (Exception var4) {
            this.rY.getLogger().warning("Error cleaning up ritual: " + var4.getMessage());
         }
      }

      this.rZ.clear();
   }

   public boolean k(UUID var1) {
      return this.rZ.containsKey(var1);
   }

   public Collection<el> nc() {
      return this.rZ.values();
   }

   private String a(String var1) {
      String var2 = this.rY.getConfig().getString("messages.prefix", "");
      return (var2 + var1).replace("&", "§");
   }

   private String a(World var1) {
      if (var1 == null) {
         return "Unknown";
      } else {
         String var10000;
         switch (var1.getEnvironment()) {
            case NORMAL -> var10000 = "Overworld";
            case NETHER -> var10000 = "Nether";
            case THE_END -> var10000 = "The End";
            default -> var10000 = var1.getName();
         }

         return var10000;
      }
   }
}
