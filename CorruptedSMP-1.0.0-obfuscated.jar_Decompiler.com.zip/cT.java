import java.io.IOException;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.List;

public final class cT extends ProxySelector {
   public static final cT pz = new cT();

   private cT() {
   }

   public List<Proxy> select(URI var1) {
      if (var1 == null) {
         boolean var2 = false;
         String var3 = "uri must not be null";
         throw new IllegalArgumentException(var3.toString());
      } else {
         return eO.i(Proxy.NO_PROXY);
      }
   }

   public void connectFailed(URI var1, SocketAddress var2, IOException var3) {
   }
}
