import java.io.IOException;
import java.util.concurrent.TimeUnit;

public final class bF implements bs {
   public static final a jq = new a((fP)null);
   private final aZ jr;

   public bF(aZ var1) {
      this.jr = var1;
   }

   public by a(bs.a var1) throws IOException {
      fR.c(var1, (String)"");
      bb var2 = var1.dt();
      aZ var10000 = this.jr;
      by var3 = var10000 != null ? var10000.a(var1.ds()) : null;
      long var4 = System.currentTimeMillis();
      bH var6 = (new bH.b(var4, var1.ds(), var3)).fy();
      bw var7 = var6.fv();
      by var8 = var6.fw();
      var10000 = this.jr;
      if (var10000 != null) {
         var10000.a(var6);
      }

      label234: {
         bS var30 = var2 instanceof bS ? (bS)var2 : null;
         if ((var2 instanceof bS ? (bS)var2 : null) != null) {
            var31 = var30.gT();
            if (var31 != null) {
               break label234;
            }
         }

         var31 = bo.NONE;
      }

      bo var9 = var31;
      if (var3 != null && var8 == null) {
         bz var32 = var3.eZ();
         if (var32 != null) {
            bD.a(var32);
         }
      }

      if (var7 == null && var8 == null) {
         by var23 = (new by.a()).e(var1.ds()).b(bv.iH).n(504).al("Unsatisfiable Request (only-if-cached)").a(bD.ji).d(-1L).e(System.currentTimeMillis()).fl();
         boolean var26 = false;
         var9.c(var2, var23);
         return var23;
      } else if (var7 == null) {
         fR.m(var8);
         by var22 = var8.fh().e(jq.i(var8)).fl();
         boolean var25 = false;
         var9.d(var2, var22);
         return var22;
      } else {
         if (var8 != null) {
            var9.e(var2, var8);
         } else if (this.jr != null) {
            var9.i(var2);
         }

         by var10 = null;
         boolean var18 = false;

         try {
            var18 = true;
            var10 = var1.c(var7);
            var18 = false;
         } finally {
            if (var18) {
               if (var3 != null) {
                  bz var33 = var3.eZ();
                  if (var33 != null) {
                     bD.a(var33);
                  }
               }

            }
         }

         if (var10 == null && var3 != null) {
            bz var34 = var3.eZ();
            if (var34 != null) {
               bD.a(var34);
            }
         }

         if (var8 != null) {
            if (var10 != null ? var10.eW() == 304 : false) {
               by var24 = var8.fh().d(jq.b(var8.eY(), var10.eY())).d(var10.fd()).e(var10.fe()).e(jq.i(var8)).d(jq.i(var10)).fl();
               bz var36 = var10.eZ();
               fR.m(var36);
               var36.close();
               aZ var37 = this.jr;
               fR.m(var37);
               var37.bP();
               this.jr.a(var8, var24);
               boolean var14 = false;
               var9.d(var2, var24);
               return var24;
            }

            bz var35 = var8.eZ();
            if (var35 != null) {
               bD.a(var35);
            }
         }

         fR.m(var10);
         by var11 = var10.fh().e(jq.i(var8)).d(jq.i(var10)).fl();
         if (this.jr != null) {
            if (cc.n(var11) && bH.js.a(var11, var7)) {
               bG var12 = this.jr.a(var11);
               by var13 = this.a(var12, var11);
               boolean var15 = false;
               if (var8 != null) {
                  var9.i(var2);
               }

               return var13;
            }

            if (cd.lR.az(var7.eJ())) {
               try {
                  this.jr.b(var7);
               } catch (IOException var19) {
               }
            }
         }

         return var11;
      }
   }

   private final by a(final bG var1, by var2) throws IOException {
      if (var1 == null) {
         return var2;
      } else {
         dy var3 = var1.bX();
         bz var10000 = var2.eZ();
         fR.m(var10000);
         final dg var4 = var10000.bT();
         final df var5 = do.b(var3);
         dA var6 = new dA() {
            private boolean cacheRequestClosed;

            public long a(de var1x, long var2) throws IOException {
               fR.c(var1x, (String)"");
               long var4x = 0L;

               try {
                  var4x = var4.a(var1x, var2);
               } catch (IOException var7) {
                  if (!this.cacheRequestClosed) {
                     this.cacheRequestClosed = true;
                     var1.bW();
                  }

                  throw var7;
               }

               if (var4x == -1L) {
                  if (!this.cacheRequestClosed) {
                     this.cacheRequestClosed = true;
                     var5.close();
                  }

                  return -1L;
               } else {
                  var1x.a(var5.kI(), var1x.kH() - var4x, var4x);
                  var5.lb();
                  return var4x;
               }
            }

            public dB fu() {
               return var4.fu();
            }

            public void close() throws IOException {
               if (!this.cacheRequestClosed && !bD.b(this, 100, TimeUnit.MILLISECONDS)) {
                  this.cacheRequestClosed = true;
                  var1.bW();
               }

               var4.close();
            }
         };
         String var7 = by.a(var2, "Content-Type", (String)null, 2, (Object)null);
         long var8 = var2.eZ().bS();
         return var2.fh().a(new cf(var7, var8, do.c(var6))).fl();
      }
   }

   public static final class a {
      private a() {
      }

      private final by i(by var1) {
         return (var1 != null ? var1.eZ() : null) != null ? var1.fh().a((bz)null).fl() : var1;
      }

      private final bq b(bq var1, bq var2) {
         bq.a var3 = new bq.a();
         int var4 = 0;

         for(int var5 = var1.cT(); var4 < var5; ++var4) {
            String var6 = var1.j(var4);
            String var7 = var1.k(var4);
            if ((!gA.a("Warning", var6, true) || !gA.a(var7, "1", false, 2, (Object)null)) && (this.at(var6) || !this.as(var6) || var2.E(var6) == null)) {
               var3.e(var6, var7);
            }
         }

         var4 = 0;

         for(int var9 = var2.cT(); var4 < var9; ++var4) {
            String var10 = var2.j(var4);
            if (!this.at(var10) && this.as(var10)) {
               var3.e(var10, var2.k(var4));
            }
         }

         return var3.cW();
      }

      private final boolean as(String var1) {
         return !gA.a("Connection", var1, true) && !gA.a("Keep-Alive", var1, true) && !gA.a("Proxy-Authenticate", var1, true) && !gA.a("Proxy-Authorization", var1, true) && !gA.a("TE", var1, true) && !gA.a("Trailers", var1, true) && !gA.a("Transfer-Encoding", var1, true) && !gA.a("Upgrade", var1, true);
      }

      private final boolean at(String var1) {
         return gA.a("Content-Length", var1, true) || gA.a("Content-Encoding", var1, true) || gA.a("Content-Type", var1, true);
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
