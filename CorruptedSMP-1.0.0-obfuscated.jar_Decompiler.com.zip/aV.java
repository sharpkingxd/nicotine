import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

public class aV implements Closeable, Flushable {
   private static final Pattern eb = Pattern.compile("-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?");
   private static final String[] ec = new String[128];
   private static final String[] ed;
   private final Writer ee;
   private int[] dP = new int[32];
   private int bM = 0;
   private String ef;
   private String eg;
   private boolean aL;
   private boolean aJ;
   private String eh;
   private boolean aG;

   public aV(Writer var1) {
      this.e(6);
      this.eg = ":";
      this.aG = true;
      this.ee = (Writer)Objects.requireNonNull(var1, "out == null");
   }

   public final void k(boolean var1) {
      this.aL = var1;
   }

   public boolean bm() {
      return this.aL;
   }

   public final boolean bw() {
      return this.aG;
   }

   public aV ba() throws IOException {
      this.by();
      return this.a(1, '[');
   }

   public aV bb() throws IOException {
      return this.a(1, 2, ']');
   }

   public aV bc() throws IOException {
      this.by();
      return this.a(3, '{');
   }

   public aV bd() throws IOException {
      return this.a(3, 5, '}');
   }

   private aV a(int var1, char var2) throws IOException {
      this.bB();
      this.e(var1);
      this.ee.write(var2);
      return this;
   }

   private aV a(int var1, int var2, char var3) throws IOException {
      int var4 = this.bx();
      if (var4 != var2 && var4 != var1) {
         throw new IllegalStateException("Nesting problem.");
      } else if (this.eh != null) {
         throw new IllegalStateException("Dangling name: " + this.eh);
      } else {
         --this.bM;
         if (var4 == var2) {
            this.bz();
         }

         this.ee.write(var3);
         return this;
      }
   }

   private void e(int var1) {
      if (this.bM == this.dP.length) {
         this.dP = Arrays.copyOf(this.dP, this.bM * 2);
      }

      this.dP[this.bM++] = var1;
   }

   private int bx() {
      if (this.bM == 0) {
         throw new IllegalStateException("JsonWriter is closed.");
      } else {
         return this.dP[this.bM - 1];
      }
   }

   private void g(int var1) {
      this.dP[this.bM - 1] = var1;
   }

   public aV s(String var1) throws IOException {
      Objects.requireNonNull(var1, "name == null");
      if (this.eh != null) {
         throw new IllegalStateException();
      } else if (this.bM == 0) {
         throw new IllegalStateException("JsonWriter is closed.");
      } else {
         this.eh = var1;
         return this;
      }
   }

   private void by() throws IOException {
      if (this.eh != null) {
         this.bA();
         this.w(this.eh);
         this.eh = null;
      }

   }

   public aV t(String var1) throws IOException {
      if (var1 == null) {
         return this.be();
      } else {
         this.by();
         this.bB();
         this.w(var1);
         return this;
      }
   }

   public aV be() throws IOException {
      if (this.eh != null) {
         if (!this.aG) {
            this.eh = null;
            return this;
         }

         this.by();
      }

      this.bB();
      this.ee.write("null");
      return this;
   }

   public aV h(boolean var1) throws IOException {
      this.by();
      this.bB();
      this.ee.write(var1 ? "true" : "false");
      return this;
   }

   public aV a(Boolean var1) throws IOException {
      if (var1 == null) {
         return this.be();
      } else {
         this.by();
         this.bB();
         this.ee.write(var1 ? "true" : "false");
         return this;
      }
   }

   public aV d(double var1) throws IOException {
      this.by();
      if (this.aL || !Double.isNaN(var1) && !Double.isInfinite(var1)) {
         this.bB();
         this.ee.append(Double.toString(var1));
         return this;
      } else {
         throw new IllegalArgumentException("Numeric values must be finite, but was " + var1);
      }
   }

   public aV b(long var1) throws IOException {
      this.by();
      this.bB();
      this.ee.write(Long.toString(var1));
      return this;
   }

   private static boolean u(Class<? extends Number> var0) {
      return var0 == Integer.class || var0 == Long.class || var0 == Double.class || var0 == Float.class || var0 == Byte.class || var0 == Short.class || var0 == BigDecimal.class || var0 == BigInteger.class || var0 == AtomicInteger.class || var0 == AtomicLong.class;
   }

   public aV a(Number var1) throws IOException {
      if (var1 == null) {
         return this.be();
      } else {
         this.by();
         String var2 = var1.toString();
         if (!var2.equals("-Infinity") && !var2.equals("Infinity") && !var2.equals("NaN")) {
            Class var3 = var1.getClass();
            if (!u(var3) && !eb.matcher(var2).matches()) {
               throw new IllegalArgumentException("String created by " + var3 + " is not a valid JSON number: " + var2);
            }
         } else if (!this.aL) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + var2);
         }

         this.bB();
         this.ee.append(var2);
         return this;
      }
   }

   public void flush() throws IOException {
      if (this.bM == 0) {
         throw new IllegalStateException("JsonWriter is closed.");
      } else {
         this.ee.flush();
      }
   }

   public void close() throws IOException {
      this.ee.close();
      int var1 = this.bM;
      if (var1 <= 1 && (var1 != 1 || this.dP[var1 - 1] == 7)) {
         this.bM = 0;
      } else {
         throw new IOException("Incomplete document");
      }
   }

   private void w(String var1) throws IOException {
      String[] var2 = this.aJ ? ed : ec;
      this.ee.write(34);
      int var3 = 0;
      int var4 = var1.length();

      for(int var5 = 0; var5 < var4; ++var5) {
         char var6 = var1.charAt(var5);
         String var7;
         if (var6 < 128) {
            var7 = var2[var6];
            if (var7 == null) {
               continue;
            }
         } else if (var6 == 8232) {
            var7 = "\\u2028";
         } else {
            if (var6 != 8233) {
               continue;
            }

            var7 = "\\u2029";
         }

         if (var3 < var5) {
            this.ee.write(var1, var3, var5 - var3);
         }

         this.ee.write(var7);
         var3 = var5 + 1;
      }

      if (var3 < var4) {
         this.ee.write(var1, var3, var4 - var3);
      }

      this.ee.write(34);
   }

   private void bz() throws IOException {
      if (this.ef != null) {
         this.ee.write(10);
         int var1 = 1;

         for(int var2 = this.bM; var1 < var2; ++var1) {
            this.ee.write(this.ef);
         }

      }
   }

   private void bA() throws IOException {
      int var1 = this.bx();
      if (var1 == 5) {
         this.ee.write(44);
      } else if (var1 != 3) {
         throw new IllegalStateException("Nesting problem.");
      }

      this.bz();
      this.g(4);
   }

   private void bB() throws IOException {
      switch (this.bx()) {
         case 1:
            this.g(2);
            this.bz();
            break;
         case 2:
            this.ee.append(',');
            this.bz();
            break;
         case 3:
         case 5:
         default:
            throw new IllegalStateException("Nesting problem.");
         case 4:
            this.ee.append(this.eg);
            this.g(5);
            break;
         case 7:
            if (!this.aL) {
               throw new IllegalStateException("JSON must have only one top-level value.");
            }
         case 6:
            this.g(7);
      }

   }

   static {
      for(int var0 = 0; var0 <= 31; ++var0) {
         ec[var0] = String.format("\\u%04x", var0);
      }

      ec[34] = "\\\"";
      ec[92] = "\\\\";
      ec[9] = "\\t";
      ec[8] = "\\b";
      ec[10] = "\\n";
      ec[13] = "\\r";
      ec[12] = "\\f";
      ed = (String[])ec.clone();
      ed[60] = "\\u003c";
      ed[62] = "\\u003e";
      ed[38] = "\\u0026";
      ed[61] = "\\u003d";
      ed[39] = "\\u0027";
   }
}
