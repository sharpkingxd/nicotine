public enum cm {
   public static final a mv = new a((fP)null);
   private final int mw;
   mx(0),
   my(1),
   mz(2),
   mA(3),
   mB(4),
   mC(5),
   mD(6),
   mE(7),
   mF(8),
   mG(9),
   mH(10),
   mI(11),
   mJ(12),
   mK(13);

   private cm(int var3) {
      this.mw = var3;
   }

   public final int hU() {
      return this.mw;
   }

   // $FF: synthetic method
   private static final cm[] hV() {
      cm[] var0 = new cm[]{mx, my, mz, mA, mB, mC, mD, mE, mF, mG, mH, mI, mJ, mK};
      return var0;
   }

   public static final class a {
      private a() {
      }

      public final cm u(int var1) {
         cm[] var2 = cm.values();
         int var3 = 0;
         int var4 = var2.length;

         cm var10000;
         while(true) {
            if (var3 >= var4) {
               var10000 = null;
               break;
            }

            cm var5 = var2[var3];
            boolean var7 = false;
            if (var5.hU() == var1) {
               var10000 = var5;
               break;
            }

            ++var3;
         }

         return var10000;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
