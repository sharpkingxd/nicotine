import java.util.List;
import javax.net.ssl.SSLSocket;

public final class cQ implements cR {
   private final a pu;
   private cR pv;

   public cQ(a var1) {
      fR.c(var1, (String)"");
      super();
      this.pu = var1;
   }

   public boolean jB() {
      return true;
   }

   public boolean f(SSLSocket var1) {
      fR.c(var1, (String)"");
      return this.pu.f(var1);
   }

   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      cR var10000 = this.h(var1);
      if (var10000 != null) {
         var10000.a(var1, var2, var3);
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      cR var10000 = this.h(var1);
      return var10000 != null ? var10000.d(var1) : null;
   }

   private final synchronized cR h(SSLSocket var1) {
      if (this.pv == null && this.pu.f(var1)) {
         this.pv = this.pu.g(var1);
      }

      return this.pv;
   }

   public interface a {
      boolean f(SSLSocket var1);

      cR g(SSLSocket var1);
   }
}
