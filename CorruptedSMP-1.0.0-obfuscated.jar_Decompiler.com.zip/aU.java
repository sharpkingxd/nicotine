public enum aU {
   dQ,
   dR,
   dS,
   dT,
   dU,
   dV,
   dW,
   dX,
   dY,
   dZ;
}
