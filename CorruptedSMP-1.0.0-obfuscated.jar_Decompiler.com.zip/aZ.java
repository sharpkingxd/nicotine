import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public final class aZ implements Closeable, Flushable {
   public static final b em = new b((fP)null);
   private final bI en;
   private int eo;
   private int ep;
   private int eq;
   private int er;
   private int es;

   public final int bN() {
      return this.eo;
   }

   public final void h(int var1) {
      this.eo = var1;
   }

   public final int bO() {
      return this.ep;
   }

   public final void i(int var1) {
      this.ep = var1;
   }

   public final by a(bw var1) {
      fR.c(var1, (String)"");
      String var2 = em.a(var1.eI());

      bI.d var4;
      try {
         bI.d var10000 = this.en.av(var2);
         if (var10000 == null) {
            return null;
         }

         var4 = var10000;
      } catch (IOException var8) {
         return null;
      }

      bI.d var3 = var4;

      c var5;
      try {
         var5 = new c(var3.r(0));
      } catch (IOException var7) {
         bD.a(var4);
         return null;
      }

      c var9 = var5;
      by var10 = var5.a(var3);
      if (!var9.a(var1, var10)) {
         bz var11 = var10.eZ();
         if (var11 != null) {
            bD.a(var11);
         }

         return null;
      } else {
         return var10;
      }
   }

   public final bG a(by var1) {
      fR.c(var1, (String)"");
      String var2 = var1.eT().eJ();
      if (cd.lR.az(var1.eT().eJ())) {
         try {
            this.b(var1.eT());
         } catch (IOException var6) {
         }

         return null;
      } else if (!fR.c(var2, (Object)"GET")) {
         return null;
      } else if (em.b(var1)) {
         return null;
      } else {
         c var3 = new c(var1);
         bI.b var4 = null;

         try {
            bI.b var10000 = bI.a(this.en, em.a(var1.eT().eI()), 0L, 2, (Object)null);
            if (var10000 == null) {
               return null;
            } else {
               var4 = var10000;
               var3.b(var4);
               return new d(var4);
            }
         } catch (IOException var7) {
            this.a(var4);
            return null;
         }
      }
   }

   public final void b(bw var1) throws IOException {
      fR.c(var1, (String)"");
      this.en.aw(em.a(var1.eI()));
   }

   public final void a(by var1, by var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      c var3 = new c(var2);
      bz var10000 = var1.eZ();
      fR.m(var10000);
      bI.d var4 = ((a)var10000).bQ();
      bI.b var5 = null;

      try {
         bI.b var9 = var4.gf();
         if (var9 == null) {
            return;
         }

         var5 = var9;
         var3.b(var5);
         var5.fT();
      } catch (IOException var7) {
         this.a(var5);
      }

   }

   private final void a(bI.b var1) {
      try {
         if (var1 != null) {
            var1.fU();
         }
      } catch (IOException var3) {
      }

   }

   public void flush() throws IOException {
      this.en.flush();
   }

   public void close() throws IOException {
      this.en.close();
   }

   public final synchronized void a(bH var1) {
      fR.c(var1, (String)"");
      int var2 = this.es++;
      if (var1.fv() != null) {
         var2 = this.eq++;
      } else if (var1.fw() != null) {
         var2 = this.er++;
      }

   }

   public final synchronized void bP() {
      int var1 = this.er++;
   }

   static final class a extends bz {
      private final bI.d snapshot;
      private final String contentType;
      private final String contentLength;
      private final dg bodySource;

      public a(bI.d var1, String var2, String var3) {
         fR.c(var1, (String)"");
         super();
         this.snapshot = var1;
         this.contentType = var2;
         this.contentLength = var3;
         dA var4 = this.snapshot.r(1);
         this.bodySource = do.c(new dj(var4) {
            public void close() throws IOException {
               a.this.bQ().close();
               super.close();
            }
         });
      }

      public final bI.d bQ() {
         return this.snapshot;
      }

      public bt bR() {
         String var10000 = this.contentType;
         return var10000 != null ? bt.ib.af(var10000) : null;
      }

      public long bS() {
         String var10000 = this.contentLength;
         return var10000 != null ? bD.a(var10000, -1L) : -1L;
      }

      public dg bT() {
         return this.bodySource;
      }
   }

   public static final class b {
      private b() {
      }

      public final String a(br var1) {
         fR.c(var1, (String)"");
         return dh.pS.aU(var1.toString()).lh().lk();
      }

      public final int a(dg var1) throws IOException {
         fR.c(var1, (String)"");

         try {
            long var2 = var1.kS();
            String var4 = var1.kV();
            if (var2 >= 0L && var2 <= 2147483647L && ((CharSequence)var4).length() <= 0) {
               return (int)var2;
            } else {
               throw new IOException("expected an int but was \"" + var2 + var4 + '"');
            }
         } catch (NumberFormatException var5) {
            throw new IOException(var5.getMessage());
         }
      }

      public final boolean a(by var1, bq var2, bw var3) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         fR.c(var3, (String)"");
         Iterable var4 = (Iterable)this.a(var1.eY());
         boolean var5 = false;
         boolean var10000;
         if (var4 instanceof Collection && ((Collection)var4).isEmpty()) {
            var10000 = true;
         } else {
            for(Object var7 : var4) {
               String var8 = (String)var7;
               boolean var9 = false;
               if (!fR.c(var2.F(var8), (Object)var3.ai(var8))) {
                  var10000 = false;
                  return var10000;
               }
            }

            var10000 = true;
         }

         return var10000;
      }

      public final boolean b(by var1) {
         fR.c(var1, (String)"");
         return this.a(var1.eY()).contains("*");
      }

      private final Set<String> a(bq var1) {
         Set var2 = null;
         int var3 = 0;

         for(int var4 = var1.cT(); var3 < var4; ++var3) {
            if (gA.a("Vary", var1.j(var3), true)) {
               String var5 = var1.k(var3);
               if (var2 == null) {
                  var2 = (Set)(new TreeSet(gA.a(fW.sT)));
               }

               CharSequence var10000 = (CharSequence)var5;
               char[] var7 = new char[]{','};

               for(String var8 : gA.a(var10000, var7, false, 0, 6, (Object)null)) {
                  var2.add(gA.c((CharSequence)var8).toString());
               }
            }
         }

         Set var9 = var2;
         if (var2 == null) {
            var9 = fk.ns();
         }

         return var9;
      }

      public final bq c(by var1) {
         fR.c(var1, (String)"");
         by var10000 = var1.fa();
         fR.m(var10000);
         bq var2 = var10000.eT().eK();
         bq var3 = var1.eY();
         return this.a(var2, var3);
      }

      private final bq a(bq var1, bq var2) {
         Set var3 = this.a(var2);
         if (var3.isEmpty()) {
            return bD.jh;
         } else {
            bq.a var4 = new bq.a();
            int var5 = 0;

            for(int var6 = var1.cT(); var5 < var6; ++var5) {
               String var7 = var1.j(var5);
               if (var3.contains(var7)) {
                  var4.d(var7, var1.k(var5));
               }
            }

            return var4.cW();
         }
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }

   static final class c {
      public static final a Companion = new a((fP)null);
      private final br url;
      private final bq varyHeaders;
      private final String requestMethod;
      private final bv protocol;
      private final int code;
      private final String message;
      private final bq responseHeaders;
      private final bp handshake;
      private final long sentRequestMillis;
      private final long receivedResponseMillis;
      private static final String SENT_MILLIS;
      private static final String RECEIVED_MILLIS;

      private final boolean bU() {
         return fR.c(this.url.cX(), (Object)"https");
      }

      public c(dA var1) throws IOException {
         fR.c(var1, (String)"");
         super();
         Closeable var2 = var1;
         Throwable var3 = null;

         try {
            dA var4 = (dA)var2;
            boolean var5 = false;
            dg var6 = do.c(var1);
            String var7 = var6.kV();
            br var10001 = br.hQ.ab(var7);
            if (var10001 == null) {
               IOException var27 = new IOException("Cache corruption for " + var7);
               boolean var29 = false;
               cH.oU.jZ().a("cache corruption", 5, (Throwable)var27);
               throw (Throwable)var27;
            }

            this.url = var10001;
            this.requestMethod = var6.kV();
            bq.a var12 = new bq.a();
            int var8 = aZ.em.a(var6);

            for(int var9 = 0; var9 < var8; ++var9) {
               var12.G(var6.kV());
            }

            this.varyHeaders = var12.cW();
            ci var28 = ci.mh.aE(var6.kV());
            this.protocol = var28.mi;
            this.code = var28.mj;
            this.message = var28.mk;
            bq.a var11 = new bq.a();
            int var13 = aZ.em.a(var6);

            for(int var14 = 0; var14 < var13; ++var14) {
               var11.G(var6.kV());
            }

            String var30 = var11.I(SENT_MILLIS);
            String var15 = var11.I(RECEIVED_MILLIS);
            var11.H(SENT_MILLIS);
            var11.H(RECEIVED_MILLIS);
            this.sentRequestMillis = var30 != null ? Long.parseLong(var30) : 0L;
            this.receivedResponseMillis = var15 != null ? Long.parseLong(var15) : 0L;
            this.responseHeaders = var11.cW();
            if (this.bU()) {
               String var16 = var6.kV();
               if (((CharSequence)var16).length() > 0) {
                  throw new IOException("expected \"\" but was \"" + var16 + '"');
               }

               String var17 = var6.kV();
               bf var18 = bf.eF.z(var17);
               List var19 = this.b(var6);
               List var20 = this.b(var6);
               bB var21 = !var6.kK() ? bB.iY.am(var6.kV()) : bB.je;
               this.handshake = bp.hJ.a(var21, var18, var19, var20);
            } else {
               this.handshake = null;
            }

            eE var26 = eE.sk;
         } catch (Throwable var24) {
            var3 = var24;
            throw var24;
         } finally {
            fI.a(var2, var3);
         }

      }

      public c(by var1) {
         fR.c(var1, (String)"");
         super();
         this.url = var1.eT().eI();
         this.varyHeaders = aZ.em.c(var1);
         this.requestMethod = var1.eT().eJ();
         this.protocol = var1.eU();
         this.code = var1.eW();
         this.message = var1.eV();
         this.responseHeaders = var1.eY();
         this.handshake = var1.eX();
         this.sentRequestMillis = var1.fd();
         this.receivedResponseMillis = var1.fe();
      }

      public final void b(bI.b var1) throws IOException {
         fR.c(var1, (String)"");
         Closeable var2 = do.b(var1.o(0));
         Throwable var3 = null;

         try {
            df var4 = (df)var2;
            boolean var5 = false;
            var4.aR(this.url.toString()).aa(10);
            var4.aR(this.requestMethod).aa(10);
            var4.D((long)this.varyHeaders.cT()).aa(10);
            int var6 = 0;

            for(int var7 = this.varyHeaders.cT(); var6 < var7; ++var6) {
               var4.aR(this.varyHeaders.j(var6)).aR(": ").aR(this.varyHeaders.k(var6)).aa(10);
            }

            var4.aR((new ci(this.protocol, this.code, this.message)).toString()).aa(10);
            var4.D((long)(this.responseHeaders.cT() + 2)).aa(10);
            var6 = 0;

            for(int var14 = this.responseHeaders.cT(); var6 < var14; ++var6) {
               var4.aR(this.responseHeaders.j(var6)).aR(": ").aR(this.responseHeaders.k(var6)).aa(10);
            }

            var4.aR(SENT_MILLIS).aR(": ").D(this.sentRequestMillis).aa(10);
            var4.aR(RECEIVED_MILLIS).aR(": ").D(this.receivedResponseMillis).aa(10);
            if (this.bU()) {
               var4.aa(10);
               bp var10001 = this.handshake;
               fR.m(var10001);
               var4.aR(var10001.cN().ct()).aa(10);
               this.a(var4, this.handshake.cP());
               this.a(var4, this.handshake.cO());
               var4.aR(this.handshake.cM().fs()).aa(10);
            }

            eE var12 = eE.sk;
         } catch (Throwable var10) {
            var3 = var10;
            throw var10;
         } finally {
            fI.a(var2, var3);
         }

      }

      private final List<Certificate> b(dg var1) throws IOException {
         int var2 = aZ.em.a(var1);
         if (var2 == -1) {
            return eO.nk();
         } else {
            try {
               CertificateFactory var3 = CertificateFactory.getInstance("X.509");
               ArrayList var4 = new ArrayList(var2);

               for(int var5 = 0; var5 < var2; ++var5) {
                  String var6 = var1.kV();
                  de var7 = new de();
                  dh var10000 = dh.pS.aV(var6);
                  if (var10000 == null) {
                     throw new IOException("Corrupt certificate in cache entry");
                  }

                  dh var8 = var10000;
                  var7.d(var8);
                  var4.add(var3.generateCertificate(var7.kL()));
               }

               return (List)var4;
            } catch (CertificateException var9) {
               throw new IOException(var9.getMessage());
            }
         }
      }

      private final void a(df var1, List<? extends Certificate> var2) throws IOException {
         try {
            var1.D((long)var2.size()).aa(10);

            for(Certificate var4 : var2) {
               byte[] var5 = var4.getEncoded();
               dh.a var10000 = dh.pS;
               fR.b(var5, "");
               String var6 = dh.a.a(var10000, var5, 0, 0, 3, (Object)null).lg();
               var1.aR(var6).aa(10);
            }

         } catch (CertificateEncodingException var7) {
            throw new IOException(var7.getMessage());
         }
      }

      public final boolean a(bw var1, by var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         return fR.c(this.url, (Object)var1.eI()) && fR.c(this.requestMethod, (Object)var1.eJ()) && aZ.em.a(var2, this.varyHeaders, var1);
      }

      public final by a(bI.d var1) {
         fR.c(var1, (String)"");
         String var2 = this.responseHeaders.E("Content-Type");
         String var3 = this.responseHeaders.E("Content-Length");
         bw var4 = (new bw.a()).c(this.url).a(this.requestMethod, (bx)null).c(this.varyHeaders).eQ();
         return (new by.a()).e(var4).b(this.protocol).n(this.code).al(this.message).d(this.responseHeaders).a(new a(var1, var2, var3)).a(this.handshake).d(this.sentRequestMillis).e(this.receivedResponseMillis).fl();
      }

      static {
         SENT_MILLIS = cH.oU.jZ().jX() + "-Sent-Millis";
         RECEIVED_MILLIS = cH.oU.jZ().jX() + "-Received-Millis";
      }

      public static final class a {
         private a() {
         }

         // $FF: synthetic method
         public a(fP var1) {
            this();
         }
      }
   }

   final class d implements bG {
      private final bI.b editor;
      private final dy cacheOut;
      private final dy body;
      private boolean done;

      public d(bI.b var2) {
         fR.c(var2, (String)"");
         super();
         this.editor = var2;
         this.cacheOut = this.editor.o(1);
         dy var3 = this.cacheOut;
         this.body = new di(var3) {
            public void close() throws IOException {
               aZ var1 = aZ.this;
               d var2 = d.this;
               aZ var3 = aZ.this;
               synchronized(var1){}

               label39: {
                  try {
                     boolean var5 = false;
                     if (!var2.bV()) {
                        var2.l(true);
                        int var6 = var3.bN();
                        var3.h(var6 + 1);
                        break label39;
                     }
                  } finally {
                     ;
                  }

                  return;
               }

               super.close();
               d.this.editor.fT();
            }
         };
      }

      public final boolean bV() {
         return this.done;
      }

      public final void l(boolean var1) {
         this.done = var1;
      }

      public void bW() {
         aZ var1 = aZ.this;
         aZ var2 = aZ.this;
         synchronized(var1){}

         try {
            boolean var4 = false;
            if (this.done) {
               return;
            }

            this.done = true;
            int var5 = var2.bO();
            var2.i(var5 + 1);
         } finally {
            ;
         }

         bD.a(this.cacheOut);

         try {
            this.editor.fU();
         } catch (IOException var8) {
         }

      }

      public dy bX() {
         return this.body;
      }
   }
}
