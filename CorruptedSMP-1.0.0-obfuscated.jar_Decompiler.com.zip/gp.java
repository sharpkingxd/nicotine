class gp extends go {
}
