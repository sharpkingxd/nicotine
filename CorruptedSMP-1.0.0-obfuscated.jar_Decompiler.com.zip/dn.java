import java.io.IOException;
import java.io.InputStream;

class dn implements dA {
   private final InputStream qf;
   private final dB qg;

   public dn(InputStream var1, dB var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.qf = var1;
      this.qg = var2;
   }

   public long a(de var1, long var2) {
      fR.c(var1, (String)"");
      if (var2 == 0L) {
         return 0L;
      } else if (var2 < 0L) {
         boolean var9 = false;
         String var10 = "byteCount < 0: " + var2;
         throw new IllegalArgumentException(var10.toString());
      } else {
         try {
            this.qg.lx();
            dv var4 = var1.Y(1);
            int var6 = 8192 - var4.dI;
            boolean var7 = false;
            int var5 = (int)Math.min(var2, (long)var6);
            var6 = this.qf.read(var4.qs, var4.dI, var5);
            if (var6 == -1) {
               if (var4.dH == var4.dI) {
                  var1.pR = var4.lI();
                  dw.c(var4);
               }

               return -1L;
            } else {
               var4.dI += var6;
               var1.t(var1.kH() + (long)var6);
               return (long)var6;
            }
         } catch (AssertionError var8) {
            if (do.a(var8)) {
               throw new IOException((Throwable)var8);
            } else {
               throw var8;
            }
         }
      }
   }

   public void close() {
      this.qf.close();
   }

   public dB fu() {
      return this.qg;
   }

   public String toString() {
      return "source(" + this.qf + ')';
   }
}
