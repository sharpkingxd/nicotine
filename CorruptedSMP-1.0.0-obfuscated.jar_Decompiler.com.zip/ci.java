import java.io.IOException;
import java.net.ProtocolException;

public final class ci {
   public static final a mh = new a((fP)null);
   public final bv mi;
   public final int mj;
   public final String mk;

   public ci(bv var1, int var2, String var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      super();
      this.mi = var1;
      this.mj = var2;
      this.mk = var3;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      boolean var3 = false;
      if (this.mi == bv.iG) {
         var1.append("HTTP/1.0");
      } else {
         var1.append("HTTP/1.1");
      }

      var1.append(' ').append(this.mj);
      var1.append(' ').append(this.mk);
      String var10000 = var1.toString();
      fR.b(var10000, "");
      return var10000;
   }

   public static final class a {
      private a() {
      }

      public final ci aE(String var1) throws IOException {
         fR.c(var1, (String)"");
         byte var2 = 0;
         bv var3 = null;
         if (gA.a(var1, "HTTP/1.", false, 2, (Object)null)) {
            if (var1.length() < 9 || var1.charAt(8) != ' ') {
               throw new ProtocolException("Unexpected status line: " + var1);
            }

            int var4 = var1.charAt(7) - 48;
            var2 = 9;
            bv var10000;
            switch (var4) {
               case 0:
                  var10000 = bv.iG;
                  break;
               case 1:
                  var10000 = bv.iH;
                  break;
               default:
                  throw new ProtocolException("Unexpected status line: " + var1);
            }

            var3 = var10000;
         } else {
            if (!gA.a(var1, "ICY ", false, 2, (Object)null)) {
               throw new ProtocolException("Unexpected status line: " + var1);
            }

            var3 = bv.iG;
            var2 = 4;
         }

         if (var1.length() < var2 + 3) {
            throw new ProtocolException("Unexpected status line: " + var1);
         } else {
            int var5;
            try {
               String var12 = var1.substring(var2, var2 + 3);
               fR.b(var12, "");
               var5 = Integer.parseInt(var12);
            } catch (NumberFormatException var7) {
               throw new ProtocolException("Unexpected status line: " + var1);
            }

            int var10 = var5;
            String var11 = "";
            if (var1.length() > var2 + 3) {
               if (var1.charAt(var2 + 3) != ' ') {
                  throw new ProtocolException("Unexpected status line: " + var1);
               }

               String var13 = var1.substring(var2 + 4);
               fR.b(var13, "");
               var11 = var13;
            }

            return new ci(var3, var10, var11);
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
