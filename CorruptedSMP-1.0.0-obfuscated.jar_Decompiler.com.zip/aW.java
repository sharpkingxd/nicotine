import java.io.IOException;

public final class aW extends IOException {
   private static final long serialVersionUID = 1L;

   public aW(String var1) {
      super(var1);
   }
}
