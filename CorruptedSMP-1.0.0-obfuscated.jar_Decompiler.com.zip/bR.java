import java.io.IOException;
import java.net.Socket;
import java.util.List;

public final class bR {
   private final bU kF;
   private final aX kG;
   private final bS kH;
   private final bo kI;
   private bX.b kJ;
   private bX kK;
   private int kL;
   private int kM;
   private int kN;
   private bA kO;

   public bR(bU var1, aX var2, bS var3, bo var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      super();
      this.kF = var1;
      this.kG = var2;
      this.kH = var3;
      this.kI = var4;
   }

   public final aX gP() {
      return this.kG;
   }

   public final cb a(bu var1, ce var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");

      try {
         bT var3 = this.a(var2.hJ(), var2.hK(), var2.hL(), var1.dV(), var1.dB(), !fR.c(var2.hI().eJ(), (Object)"GET"));
         return var3.b(var1, var2);
      } catch (bW var4) {
         this.g(var4.hx());
         throw var4;
      } catch (IOException var5) {
         this.g(var5);
         throw new bW(var5);
      }
   }

   private final bT a(int var1, int var2, int var3, int var4, boolean var5, boolean var6) throws IOException {
      while(true) {
         bT var7 = this.a(var1, var2, var3, var4, var5);
         if (var7.u(var6)) {
            return var7;
         }

         var7.hn();
         if (this.kO == null) {
            bX.b var10000 = this.kJ;
            boolean var8 = var10000 != null ? var10000.hD() : true;
            if (!var8) {
               bX var10 = this.kK;
               boolean var9 = var10 != null ? var10.hy() : true;
               if (!var9) {
                  throw new IOException("exhausted all routes");
               }
            }
         }
      }
   }

   private final bT a(int var1, int var2, int var3, int var4, boolean var5) throws IOException {
      if (this.kH.gX()) {
         throw new IOException("Canceled");
      } else {
         bT var6 = this.kH.gU();
         if (var6 != null) {
            Socket var7 = null;
            synchronized(var6) {
               boolean var9 = false;
               if (var6.hi() || !this.d(var6.hr().fo().bK())) {
                  var7 = this.kH.ha();
               }

               eE var22 = eE.sk;
            }

            if (this.kH.gU() != null) {
               if (var7 != null) {
                  String var25 = "Check failed.";
                  throw new IllegalStateException(var25.toString());
               }

               return var6;
            }

            if (var7 != null) {
               bD.a(var7);
            }

            this.kI.b(this.kH, var6);
         }

         this.kL = 0;
         this.kM = 0;
         this.kN = 0;
         if (this.kF.a(this.kG, this.kH, (List)null, false)) {
            bT var33 = this.kH.gU();
            fR.m(var33);
            bT var20 = var33;
            this.kI.a(this.kH, var20);
            return var20;
         } else {
            Object var18 = null;
            bA var8 = null;
            List var19;
            if (this.kO != null) {
               var19 = null;
               bA var10000 = this.kO;
               fR.m(var10000);
               var8 = var10000;
               this.kO = null;
            } else {
               label196: {
                  if (this.kJ != null) {
                     bX.b var29 = this.kJ;
                     fR.m(var29);
                     if (var29.hD()) {
                        var19 = null;
                        var29 = this.kJ;
                        fR.m(var29);
                        var8 = var29.hE();
                        break label196;
                     }
                  }

                  bX var23 = this.kK;
                  if (var23 == null) {
                     var23 = new bX(this.kG, this.kH.gS().dW(), this.kH, this.kI);
                     this.kK = var23;
                  }

                  bX.b var10 = var23.hz();
                  this.kJ = var10;
                  var19 = var10.hC();
                  if (this.kH.gX()) {
                     throw new IOException("Canceled");
                  }

                  if (this.kF.a(this.kG, this.kH, var19, false)) {
                     bT var30 = this.kH.gU();
                     fR.m(var30);
                     bT var11 = var30;
                     this.kI.a(this.kH, var11);
                     return var11;
                  }

                  var8 = var10.hE();
               }
            }

            bT var24 = new bT(this.kF, var8);
            this.kH.a(var24);

            try {
               var24.a(var1, var2, var3, var4, var5, this.kH, this.kI);
            } finally {
               this.kH.a((bT)null);
            }

            this.kH.gS().dW().b(var24.hr());
            if (this.kF.a(this.kG, this.kH, var19, true)) {
               bT var32 = this.kH.gU();
               fR.m(var32);
               bT var26 = var32;
               this.kO = var8;
               bD.a(var24.ht());
               this.kI.a(this.kH, var26);
               return var26;
            } else {
               synchronized(var24) {
                  boolean var27 = false;
                  this.kF.d(var24);
                  this.kH.b(var24);
                  eE var28 = eE.sk;
               }

               this.kI.a(this.kH, var24);
               return var24;
            }
         }
      }
   }

   public final void g(IOException var1) {
      fR.c(var1, (String)"");
      this.kO = null;
      if (var1 instanceof cy && ((cy)var1).ot == cm.mE) {
         int var4 = this.kL++;
      } else if (var1 instanceof cl) {
         int var2 = this.kM++;
      } else {
         int var3 = this.kN++;
      }

   }

   public final boolean gQ() {
      if (this.kL == 0 && this.kM == 0 && this.kN == 0) {
         return false;
      } else if (this.kO != null) {
         return true;
      } else {
         bA var1 = this.gR();
         if (var1 != null) {
            this.kO = var1;
            return true;
         } else {
            bX.b var10000 = this.kJ;
            if (var10000 != null ? var10000.hD() : false) {
               return true;
            } else {
               bX var3 = this.kK;
               if (var3 == null) {
                  return true;
               } else {
                  bX var2 = var3;
                  return var2.hy();
               }
            }
         }
      }
   }

   private final bA gR() {
      if (this.kL <= 1 && this.kM <= 1 && this.kN <= 0) {
         bT var10000 = this.kH.gU();
         if (var10000 == null) {
            return null;
         } else {
            bT var1 = var10000;
            synchronized(var1){}

            Object var6;
            try {
               boolean var3 = false;
               if (var1.hj() == 0) {
                  if (!bD.a(var1.hr().fo().bK(), this.kG.bK())) {
                     Object var5 = null;
                     return (bA)var5;
                  }

                  bA var4 = var1.hr();
                  return var4;
               }

               var6 = null;
            } finally {
               ;
            }

            return (bA)var6;
         }
      } else {
         return null;
      }
   }

   public final boolean d(br var1) {
      fR.c(var1, (String)"");
      br var2 = this.kG.bK();
      return var1.cZ() == var2.cZ() && fR.c(var1.cY(), (Object)var2.cY());
   }
}
