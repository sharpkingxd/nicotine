import com.corruptedsmp.CorruptedSMPPlugin;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class dJ {
   private final CorruptedSMPPlugin qQ;
   private final File qR;
   private final File qS;
   private final File qT;
   private String qU;
   private long qV;
   private boolean qW;
   private boolean qX;
   private static final long qY;
   private static final long qZ;

   public dJ(CorruptedSMPPlugin var1) {
      this.qQ = var1;
      this.qR = new File(var1.getDataFolder(), "trial.dat");
      this.qS = new File(var1.getDataFolder(), ".trial");
      File var2 = var1.getDataFolder().getParentFile();
      this.qT = new File(var2, ".corruptedsmp_trials");
      this.qW = false;
      this.qX = false;
   }

   public boolean mj() {
      if (this.qU == null) {
         this.qU = this.mq();
      }

      this.qQ.getLogger().info("Checking trial status...");
      a var1 = this.mn();
      if (var1 == dJ.a.API_ERROR) {
         this.qQ.getLogger().warning("API unavailable, using local registry...");
         var1 = this.ml();
      }

      if (var1 == dJ.a.ALREADY_USED) {
         this.qQ.getLogger().severe("╔════════════════════════════════════════════════════════╗");
         this.qQ.getLogger().severe("║                                                        ║");
         this.qQ.getLogger().severe("║          ✗ TRIAL ALREADY USED                          ║");
         this.qQ.getLogger().severe("║                                                        ║");
         this.qQ.getLogger().severe("║  This server has already used its 24-hour trial.       ║");
         this.qQ.getLogger().severe("║  Deleting trial files will not reset the trial.        ║");
         this.qQ.getLogger().severe("║                                                        ║");
         this.qQ.getLogger().severe("║  Purchase a license at:                                ║");
         this.qQ.getLogger().severe("║  https://discord.gg/enzFpD976J                    ║");
         this.qQ.getLogger().severe("║                                                        ║");
         this.qQ.getLogger().severe("╚════════════════════════════════════════════════════════╝");
         this.qW = false;
         this.qX = true;
         return false;
      } else if (var1 == dJ.a.API_ERROR) {
         this.qQ.getLogger().warning("Unable to verify trial with API, using local verification...");
         return this.mk();
      } else if (this.ms()) {
         long var2 = System.currentTimeMillis() - this.qV;
         if (var2 < qY) {
            this.qW = true;
            this.qX = false;
            long var4 = TimeUnit.MILLISECONDS.toHours(qY - var2);
            this.qQ.getLogger().info("╔════════════════════════════════════════════════════════╗");
            this.qQ.getLogger().info("║                                                        ║");
            this.qQ.getLogger().info("║          ✓ TRIAL MODE ACTIVE (TESTING: 1 HOUR)        ║");
            this.qQ.getLogger().info("║                                                        ║");
            this.qQ.getLogger().info("║  Time Remaining: " + var4 + " hours                              ║");
            this.qQ.getLogger().info("║  Server UUID: " + this.qU.substring(0, 8) + "...                    ║");
            this.qQ.getLogger().info("║                                                        ║");
            this.qQ.getLogger().info("╚════════════════════════════════════════════════════════╝");
            this.mt();
            return true;
         } else {
            this.qW = false;
            this.qX = true;
            this.mu();
            this.mw();
            return false;
         }
      } else {
         return this.mp();
      }
   }

   private boolean mk() {
      if (this.ms()) {
         long var1 = System.currentTimeMillis() - this.qV;
         if (var1 < qY) {
            this.qW = true;
            this.qX = false;
            long var3 = TimeUnit.MILLISECONDS.toHours(qY - var1);
            this.qQ.getLogger().info("╔════════════════════════════════════════════════════════╗");
            this.qQ.getLogger().info("║                                                        ║");
            this.qQ.getLogger().info("║          ✓ TRIAL MODE ACTIVE (OFFLINE)                 ║");
            this.qQ.getLogger().info("║                                                        ║");
            this.qQ.getLogger().info("║  Time Remaining: " + var3 + " hours                              ║");
            this.qQ.getLogger().info("║  Server UUID: " + this.qU.substring(0, 8) + "...                    ║");
            this.qQ.getLogger().info("║                                                        ║");
            this.qQ.getLogger().info("╚════════════════════════════════════════════════════════╝");
            this.mt();
            return true;
         } else {
            this.qW = false;
            this.qX = true;
            this.mu();
            return false;
         }
      } else {
         this.qQ.getLogger().warning("╔════════════════════════════════════════════════════════╗");
         this.qQ.getLogger().warning("║                                                        ║");
         this.qQ.getLogger().warning("║          ⚠ STARTING TRIAL IN OFFLINE MODE              ║");
         this.qQ.getLogger().warning("║                                                        ║");
         this.qQ.getLogger().warning("║  Unable to verify with Lukittu API                     ║");
         this.qQ.getLogger().warning("║  Starting trial using local verification only          ║");
         this.qQ.getLogger().warning("║                                                        ║");
         this.qQ.getLogger().warning("║  NOTE: This is for testing only!                       ║");
         this.qQ.getLogger().warning("║  In production, API must be available                  ║");
         this.qQ.getLogger().warning("║                                                        ║");
         this.qQ.getLogger().warning("╚════════════════════════════════════════════════════════╝");
         return this.mp();
      }
   }

   private a ml() {
      try {
         if (!this.qT.exists()) {
            return dJ.a.AVAILABLE;
         } else {
            FileReader var1 = new FileReader(this.qT);

            a var11;
            label48: {
               try {
                  StringBuilder var2 = new StringBuilder();

                  int var3;
                  while((var3 = var1.read()) != -1) {
                     var2.append((char)var3);
                  }

                  String var4 = this.aZ(var2.toString());
                  K var5 = new K();
                  S var6 = (S)var5.a(var4, S.class);
                  if (var6.l(this.qU)) {
                     var11 = dJ.a.ALREADY_USED;
                     break label48;
                  }

                  var11 = dJ.a.AVAILABLE;
               } catch (Throwable var9) {
                  try {
                     var1.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }

                  throw var9;
               }

               var1.close();
               return var11;
            }

            var1.close();
            return var11;
         }
      } catch (Exception var10) {
         this.qQ.getLogger().warning("Failed to check local trial registry: " + var10.getMessage());
         return dJ.a.API_ERROR;
      }
   }

   private boolean mm() {
      try {
         S var1;
         if (this.qT.exists()) {
            FileReader var2 = new FileReader(this.qT);

            try {
               StringBuilder var3 = new StringBuilder();

               int var4;
               while((var4 = var2.read()) != -1) {
                  var3.append((char)var4);
               }

               String var5 = this.aZ(var3.toString());
               K var6 = new K();
               var1 = (S)var6.a(var5, S.class);
            } catch (Throwable var11) {
               try {
                  var2.close();
               } catch (Throwable var8) {
                  var11.addSuppressed(var8);
               }

               throw var11;
            }

            var2.close();
         } else {
            var1 = new S();
         }

         S var13 = new S();
         var13.a("timestamp", (Number)this.qV);
         var13.a("plugin_version", this.qQ.getDescription().getVersion());
         var13.a("server_version", this.qQ.getServer().getVersion());
         var1.a(this.qU, (P)var13);
         String var14 = this.aY(var1.toString());
         this.qT.getParentFile().mkdirs();
         FileWriter var15 = new FileWriter(this.qT);

         try {
            var15.write(var14);
         } catch (Throwable var10) {
            try {
               var15.close();
            } catch (Throwable var7) {
               var10.addSuppressed(var7);
            }

            throw var10;
         }

         var15.close();

         try {
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
               Runtime.getRuntime().exec("attrib +H \"" + this.qT.getAbsolutePath() + "\"");
            }
         } catch (Exception var9) {
         }

         this.qQ.getLogger().info("✓ Trial registered in local registry");
         return true;
      } catch (Exception var12) {
         this.qQ.getLogger().warning("Failed to register trial in local registry: " + var12.getMessage());
         return false;
      }
   }

   private a mn() {
      try {
         bu var1 = (new bu.a()).a(10L, TimeUnit.SECONDS).b(10L, TimeUnit.SECONDS).eE();
         S var2 = new S();
         var2.a("server_uuid", this.qU);
         var2.a("action", "check");
         bx var3 = bx.a(var2.toString(), bt.ad("application/json"));
         bw var4 = (new bw.a()).aj("https://api.lukittu.com/v1/trial/check").a(var3).i("Content-Type", "application/json").eQ();
         by var5 = var1.d(var4).ck();

         a var14;
         label80: {
            a var16;
            label81: {
               label82: {
                  a var9;
                  try {
                     if (!var5.fg()) {
                        this.qQ.getLogger().warning("API returned error: HTTP " + var5.eW());
                        var14 = dJ.a.API_ERROR;
                        break label80;
                     }

                     String var6 = var5.eZ() != null ? var5.eZ().fm() : "{}";
                     K var7 = new K();
                     S var8 = (S)var7.a(var6, S.class);
                     if (var8.l("trial_available")) {
                        boolean var15 = var8.m("trial_available").ac();
                        if (var15) {
                           this.qQ.getLogger().info("✓ Trial available for this server (API)");
                           var16 = dJ.a.AVAILABLE;
                           break label81;
                        }

                        this.qQ.getLogger().warning("✗ Trial already used by this server (API)");
                        var16 = dJ.a.ALREADY_USED;
                        break label82;
                     }

                     this.qQ.getLogger().warning("Unknown API response format");
                     var9 = dJ.a.API_ERROR;
                  } catch (Throwable var12) {
                     if (var5 != null) {
                        try {
                           var5.close();
                        } catch (Throwable var11) {
                           var12.addSuppressed(var11);
                        }
                     }

                     throw var12;
                  }

                  if (var5 != null) {
                     var5.close();
                  }

                  return var9;
               }

               if (var5 != null) {
                  var5.close();
               }

               return var16;
            }

            if (var5 != null) {
               var5.close();
            }

            return var16;
         }

         if (var5 != null) {
            var5.close();
         }

         return var14;
      } catch (Exception var13) {
         this.qQ.getLogger().warning("Failed to check trial with API: " + var13.getMessage());
         return dJ.a.API_ERROR;
      }
   }

   private boolean mo() {
      try {
         bu var1 = (new bu.a()).a(10L, TimeUnit.SECONDS).b(10L, TimeUnit.SECONDS).eE();
         S var2 = new S();
         var2.a("server_uuid", this.qU);
         var2.a("action", "start");
         var2.a("plugin_version", this.qQ.getDescription().getVersion());
         var2.a("server_version", this.qQ.getServer().getVersion());
         var2.a("timestamp", (Number)this.qV);
         bx var3 = bx.a(var2.toString(), bt.ad("application/json"));
         bw var4 = (new bw.a()).aj("https://api.lukittu.com/v1/trial/start").a(var3).i("Content-Type", "application/json").eQ();
         by var5 = var1.d(var4).ck();

         boolean var11;
         label48: {
            try {
               if (var5.fg()) {
                  this.qQ.getLogger().info("✓ Trial registered with Lukittu API");
                  var11 = true;
                  break label48;
               }

               this.qQ.getLogger().warning("Failed to register trial: HTTP " + var5.eW());
               var11 = false;
            } catch (Throwable var9) {
               if (var5 != null) {
                  try {
                     var5.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (var5 != null) {
               var5.close();
            }

            return var11;
         }

         if (var5 != null) {
            var5.close();
         }

         return var11;
      } catch (Exception var10) {
         this.qQ.getLogger().warning("Failed to register trial with API: " + var10.getMessage());
         return false;
      }
   }

   private boolean mp() {
      try {
         this.qV = System.currentTimeMillis();
         this.qW = true;
         this.qX = false;
         this.qQ.getLogger().info("Registering trial...");
         boolean var1 = this.mo();
         if (!var1) {
            this.qQ.getLogger().warning("Failed to register with API, using local registry...");
            this.mm();
         } else {
            this.mm();
         }

         this.mr();
         this.qQ.getLogger().info("╔════════════════════════════════════════════════════════╗");
         this.qQ.getLogger().info("║                                                        ║");
         this.qQ.getLogger().info("║          ✓ 1-HOUR TRIAL ACTIVATED! (TESTING)           ║");
         this.qQ.getLogger().info("║                                                        ║");
         this.qQ.getLogger().info("║  Welcome to CorruptedSMP!                              ║");
         this.qQ.getLogger().info("║  Your trial will expire in 1 hour (TESTING MODE)       ║");
         this.qQ.getLogger().info("║                                                        ║");
         this.qQ.getLogger().info("║  Purchase a license at:                                ║");
         this.qQ.getLogger().info("║  https://discord.gg/enzFpD976J                    ║");
         this.qQ.getLogger().info("║                                                        ║");
         this.qQ.getLogger().info("║  NOTE: Deleting trial files will NOT reset trial      ║");
         this.qQ.getLogger().info("║  Trial is tracked by Lukittu API per server           ║");
         this.qQ.getLogger().info("║                                                        ║");
         this.qQ.getLogger().info("╚════════════════════════════════════════════════════════╝");
         this.mv();
         this.mt();
         return true;
      } catch (Exception var2) {
         this.qQ.getLogger().severe("Failed to start trial: " + var2.getMessage());
         return false;
      }
   }

   private String mq() {
      try {
         String var10000 = this.qQ.getServer().getName();
         String var1 = var10000 + this.qQ.getServer().getVersion() + this.qQ.getServer().getPort() + System.getProperty("user.dir") + System.currentTimeMillis();
         MessageDigest var2 = MessageDigest.getInstance("SHA-256");
         byte[] var3 = var2.digest(var1.getBytes(StandardCharsets.UTF_8));
         String var4 = Base64.getEncoder().encodeToString(var3);
         return UUID.nameUUIDFromBytes(var4.getBytes()).toString();
      } catch (Exception var5) {
         return UUID.randomUUID().toString();
      }
   }

   private void mr() {
      try {
         S var1 = new S();
         var1.a("serverUUID", this.qU);
         var1.a("trialStartTime", (Number)this.qV);
         var1.a("version", this.qQ.getDescription().getVersion());
         String var2 = this.aY(var1.toString());
         FileWriter var3 = new FileWriter(this.qR);

         try {
            var3.write(var2);
         } catch (Throwable var9) {
            try {
               var3.close();
            } catch (Throwable var7) {
               var9.addSuppressed(var7);
            }

            throw var9;
         }

         var3.close();
         var3 = new FileWriter(this.qS);

         try {
            var3.write(var2);
         } catch (Throwable var8) {
            try {
               var3.close();
            } catch (Throwable var6) {
               var8.addSuppressed(var6);
            }

            throw var8;
         }

         var3.close();
      } catch (Exception var10) {
         this.qQ.getLogger().warning("Failed to save trial data: " + var10.getMessage());
      }

   }

   private boolean ms() {
      File var1 = this.qR.exists() ? this.qR : (this.qS.exists() ? this.qS : null);
      if (var1 == null) {
         return false;
      } else {
         try {
            FileReader var2 = new FileReader(var1);

            boolean var8;
            try {
               StringBuilder var3 = new StringBuilder();

               int var4;
               while((var4 = var2.read()) != -1) {
                  var3.append((char)var4);
               }

               String var5 = this.aZ(var3.toString());
               K var6 = new K();
               S var7 = (S)var6.a(var5, S.class);
               this.qU = var7.m("serverUUID").Y();
               this.qV = var7.m("trialStartTime").aa();
               var8 = true;
            } catch (Throwable var10) {
               try {
                  var2.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }

               throw var10;
            }

            var2.close();
            return var8;
         } catch (Exception var11) {
            this.qQ.getLogger().warning("Failed to load trial data: " + var11.getMessage());
            return false;
         }
      }
   }

   private String aY(String var1) {
      try {
         byte[] var2 = var1.getBytes(StandardCharsets.UTF_8);
         byte[] var3 = new byte[var2.length];
         byte[] var4 = "CorruptedSMP2024".getBytes(StandardCharsets.UTF_8);

         for(int var5 = 0; var5 < var2.length; ++var5) {
            var3[var5] = (byte)(var2[var5] ^ var4[var5 % var4.length]);
         }

         return Base64.getEncoder().encodeToString(var3);
      } catch (Exception var6) {
         return var1;
      }
   }

   private String aZ(String var1) {
      try {
         byte[] var2 = Base64.getDecoder().decode(var1);
         byte[] var3 = new byte[var2.length];
         byte[] var4 = "CorruptedSMP2024".getBytes(StandardCharsets.UTF_8);

         for(int var5 = 0; var5 < var2.length; ++var5) {
            var3[var5] = (byte)(var2[var5] ^ var4[var5 % var4.length]);
         }

         return new String(var3, StandardCharsets.UTF_8);
      } catch (Exception var6) {
         return var1;
      }
   }

   private void mt() {
      this.qQ.getServer().getScheduler().runTaskTimerAsynchronously(this.qQ, () -> {
         if (this.qW) {
            long var1 = System.currentTimeMillis() - this.qV;
            long var3 = qY - var1;
            if (var3 <= 0L) {
               this.qW = false;
               this.qX = true;
               this.qQ.getServer().getScheduler().runTask(this.qQ, () -> {
                  this.mu();
                  this.mw();
                  this.qQ.getServer().getPluginManager().disablePlugin(this.qQ);
               });
            } else {
               long var5 = TimeUnit.MILLISECONDS.toHours(var3);
               this.qQ.getLogger().info("╔════════════════════════════════════════════════════════╗");
               this.qQ.getLogger().info("║                                                        ║");
               this.qQ.getLogger().info("║          ⏰ TRIAL REMINDER (TESTING MODE)              ║");
               this.qQ.getLogger().info("║                                                        ║");
               this.qQ.getLogger().info("║  Time Remaining: " + var5 + " hours                              ║");
               this.qQ.getLogger().info("║                                                        ║");
               this.qQ.getLogger().info("║  Purchase a license at:                                ║");
               this.qQ.getLogger().info("║  https://discord.gg/enzFpD976J                    ║");
               this.qQ.getLogger().info("║                                                        ║");
               this.qQ.getLogger().info("╚════════════════════════════════════════════════════════╝");
            }

         }
      }, qZ / 50L, qZ / 50L);
   }

   private void mu() {
      this.qQ.getLogger().severe("╔════════════════════════════════════════════════════════╗");
      this.qQ.getLogger().severe("║                                                        ║");
      this.qQ.getLogger().severe("║          ✗ TRIAL EXPIRED - 24 HOURS USED               ║");
      this.qQ.getLogger().severe("║                                                        ║");
      this.qQ.getLogger().severe("║  Purchase CorruptedSMP License:                        ║");
      this.qQ.getLogger().severe("║  https://discord.gg/enzFpD976J                    ║");
      this.qQ.getLogger().severe("║                                                        ║");
      this.qQ.getLogger().severe("║  Plugin will remain disabled until you add             ║");
      this.qQ.getLogger().severe("║  a valid license key to config.yml                     ║");
      this.qQ.getLogger().severe("║                                                        ║");
      this.qQ.getLogger().severe("╚════════════════════════════════════════════════════════╝");
   }

   private void mv() {
      this.qQ.getServer().getScheduler().runTaskAsynchronously(this.qQ, () -> {
         try {
            S var1 = new S();
            var1.a("event", "trial_started");
            var1.a("server_uuid", this.qU);
            var1.a("plugin_version", this.qQ.getDescription().getVersion());
            var1.a("server_version", this.qQ.getServer().getVersion());
            var1.a("timestamp", (Number)System.currentTimeMillis());
            this.a(var1);
         } catch (Exception var2) {
         }

      });
   }

   private void mw() {
      this.qQ.getServer().getScheduler().runTaskAsynchronously(this.qQ, () -> {
         try {
            S var1 = new S();
            var1.a("event", "trial_expired");
            var1.a("server_uuid", this.qU);
            var1.a("plugin_version", this.qQ.getDescription().getVersion());
            var1.a("timestamp", (Number)System.currentTimeMillis());
            this.a(var1);
         } catch (Exception var2) {
         }

      });
   }

   private void a(S var1) {
      try {
         bu var2 = (new bu.a()).a(5L, TimeUnit.SECONDS).b(5L, TimeUnit.SECONDS).eE();
         bx var3 = bx.a(var1.toString(), bt.ad("application/json"));
         bw var4 = (new bw.a()).aj("https://api.lukittu.com/v1/analytics/trial").a(var3).i("Content-Type", "application/json").eQ();
         by var5 = var2.d(var4).ck();
         if (var5 != null) {
            var5.close();
         }
      } catch (Exception var6) {
      }

   }

   public boolean mx() {
      return this.qW;
   }

   public void my() {
      this.qW = false;
      this.qX = true;
   }

   static {
      qY = TimeUnit.HOURS.toMillis(1L);
      qZ = TimeUnit.MINUTES.toMillis(15L);
   }

   static enum a {
      AVAILABLE,
      ALREADY_USED,
      API_ERROR;

      // $FF: synthetic method
      private static a[] mD() {
         return new a[]{AVAILABLE, ALREADY_USED, API_ERROR};
      }
   }
}
