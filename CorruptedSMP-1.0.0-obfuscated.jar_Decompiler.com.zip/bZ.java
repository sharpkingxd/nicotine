import java.io.IOException;
import java.net.ProtocolException;

public final class bZ implements bs {
   private final boolean lK;

   public bZ(boolean var1) {
      this.lK = var1;
   }

   public by a(bs.a var1) throws IOException {
      fR.c(var1, (String)"");
      ce var2 = (ce)var1;
      bQ var10000 = var2.hH();
      fR.m(var10000);
      bQ var3 = var10000;
      bw var4 = var2.hI();
      bx var5 = var4.eL();
      long var6 = System.currentTimeMillis();
      boolean var8 = true;
      by.a var9 = null;
      IOException var10 = null;

      try {
         var3.g(var4);
         if (cd.aB(var4.eJ()) && var5 != null) {
            if (gA.a("100-continue", var4.ah("Expect"), true)) {
               var3.gI();
               var9 = var3.r(true);
               var3.gK();
               var8 = false;
            }

            if (var9 == null) {
               if (var5.eR()) {
                  var3.gI();
                  df var11 = do.b(var3.a(var4, true));
                  var5.a(var11);
               } else {
                  df var16 = do.b(var3.a(var4, false));
                  var5.a(var16);
                  var16.close();
               }
            } else {
               var3.gO();
               if (!var3.gG().hm()) {
                  var3.gL();
               }
            }
         } else {
            var3.gO();
         }

         if (var5 == null || !var5.eR()) {
            var3.gJ();
         }
      } catch (IOException var14) {
         if (var14 instanceof cl) {
            throw var14;
         }

         if (!var3.gF()) {
            throw var14;
         }

         var10 = var14;
      }

      try {
         if (var9 == null) {
            by.a var19 = var3.r(false);
            fR.m(var19);
            var9 = var19;
            if (var8) {
               var3.gK();
               var8 = false;
            }
         }

         by var17 = var9.e(var4).a(var3.gG().eX()).d(var6).e(System.currentTimeMillis()).fl();
         int var12 = var17.eW();
         if (this.t(var12)) {
            by.a var20 = var3.r(false);
            fR.m(var20);
            var9 = var20;
            if (var8) {
               var3.gK();
            }

            var17 = var9.e(var4).a(var3.gG().eX()).d(var6).e(System.currentTimeMillis()).fl();
            var12 = var17.eW();
         }

         var3.j(var17);
         var17 = this.lK && var12 == 101 ? var17.fh().a(bD.ji).fl() : var17.fh().a(var3.k(var17)).fl();
         if (gA.a("close", var17.eT().ah("Connection"), true) || gA.a("close", by.a(var17, "Connection", (String)null, 2, (Object)null), true)) {
            var3.gL();
         }

         if (var12 == 204 || var12 == 205) {
            bz var21 = var17.eZ();
            if ((var21 != null ? var21.bS() : -1L) > 0L) {
               StringBuilder var10002 = (new StringBuilder()).append("HTTP ").append(var12).append(" had non-zero Content-Length: ");
               bz var10003 = var17.eZ();
               throw new ProtocolException(var10002.append(var10003 != null ? var10003.bS() : null).toString());
            }
         }

         return var17;
      } catch (IOException var13) {
         if (var10 != null) {
            er.a((Throwable)var10, (Throwable)var13);
            throw var10;
         } else {
            throw var13;
         }
      }
   }

   private final boolean t(int var1) {
      return var1 == 100 ? true : (102 <= var1 ? var1 < 200 : false);
   }
}
