import java.util.concurrent.TimeUnit;

public final class bh {
   private final bU gY;

   public bh(bU var1) {
      fR.c(var1, (String)"");
      super();
      this.gY = var1;
   }

   public final bU cx() {
      return this.gY;
   }

   public bh(int var1, long var2, TimeUnit var4) {
      fR.c(var4, (String)"");
      this(new bU(bN.kr, var1, var2, var4));
   }

   public bh() {
      this(5, 5L, TimeUnit.MINUTES);
   }
}
