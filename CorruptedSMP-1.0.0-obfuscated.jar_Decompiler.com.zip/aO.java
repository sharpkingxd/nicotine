import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

final class aO extends ac<Date> {
   static final ad dq = new ad() {
      public <T> ac<T> a(K var1, aS<T> var2) {
         return var2.bk() == Date.class ? new aO() : null;
      }
   };
   private final DateFormat dr;

   private aO() {
      this.dr = new SimpleDateFormat("MMM d, yyyy");
   }

   public Date L(aT var1) throws IOException {
      if (var1.aI() == aU.dY) {
         var1.aO();
         return null;
      } else {
         String var2 = var1.aM();

         try {
            java.util.Date var3;
            synchronized(this) {
               var3 = this.dr.parse(var2);
            }

            return new Date(var3.getTime());
         } catch (ParseException var7) {
            throw new X("Failed parsing '" + var2 + "' as SQL Date; at path " + var1.aV(), var7);
         }
      }
   }

   public void a(aV var1, Date var2) throws IOException {
      if (var2 == null) {
         var1.be();
      } else {
         String var3;
         synchronized(this) {
            var3 = this.dr.format(var2);
         }

         var1.t(var3);
      }
   }

   // $FF: synthetic method
   public Object b(aT var1) throws IOException {
      return this.L(var1);
   }
}
