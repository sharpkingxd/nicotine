public enum l {
   t("Clown", 401, "§d\ud83c\udfaa Clown Corruption"),
   u("Darkness", 402, "§0☠ Darkness Corruption"),
   v("Ender", 403, "§5⬡ Ender Corruption"),
   w("Breeze", 404, "§f☁ Breeze Corruption"),
   A("Fire", 405, "§6\ud83d\udd25 Fire Corruption"),
   B("Velocity", 406, "§e⚡ Velocity Corruption"),
   C("Health", 407, "§c❤ Health Corruption"),
   D("Invincibility", 408, "§7⛨ Invincibility Corruption"),
   E("Ocean", 409, "§b≈ Ocean Corruption");

   private final String F;
   private final int G;
   private final String H;

   private l(String var3, int var4, String var5) {
      this.F = var3;
      this.G = var4;
      this.H = var5;
   }

   public String m() {
      return this.F;
   }

   public int n() {
      return this.G;
   }

   public String o() {
      return this.H;
   }

   public static l b(String var0) {
      for(l var4 : values()) {
         if (var4.F.equalsIgnoreCase(var0)) {
            return var4;
         }
      }

      return null;
   }

   // $FF: synthetic method
   private static l[] p() {
      return new l[]{t, u, v, w, A, B, C, D, E};
   }
}
