class eJ {
   public static final void g(int var0, int var1) {
      if (var0 > var1) {
         throw new IndexOutOfBoundsException("toIndex (" + var0 + ") is greater than size (" + var1 + ").");
      }
   }
}
