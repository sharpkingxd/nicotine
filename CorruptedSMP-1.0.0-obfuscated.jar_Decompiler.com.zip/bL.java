import java.util.Arrays;
import java.util.logging.Logger;

public final class bL {
   private static final void a(bK var0, bM var1, String var2) {
      Logger var10000 = bN.kj.gA();
      StringBuilder var10001 = (new StringBuilder()).append(var1.gm()).append(' ');
      fW var10002 = fW.sT;
      String var3 = "%-22s";
      Object[] var4 = new Object[]{var2};
      String var5 = String.format(var3, Arrays.copyOf(var4, var4.length));
      fR.b(var5, "");
      var10000.fine(var10001.append(var5).append(": ").append(var0.gh()).toString());
   }

   public static final String h(long var0) {
      String var2 = var0 <= -999500000L ? (var0 - (long)500000000) / (long)1000000000 + " s " : (var0 <= -999500L ? (var0 - (long)500000) / (long)1000000 + " ms" : (var0 <= 0L ? (var0 - (long)500) / (long)1000 + " µs" : (var0 < 999500L ? (var0 + (long)500) / (long)1000 + " µs" : (var0 < 999500000L ? (var0 + (long)500000) / (long)1000000 + " ms" : (var0 + (long)500000000) / (long)1000000000 + " s "))));
      fW var10000 = fW.sT;
      String var3 = "%6s";
      Object[] var4 = new Object[]{var2};
      String var5 = String.format(var3, Arrays.copyOf(var4, var4.length));
      fR.b(var5, "");
      return var5;
   }

   // $FF: synthetic method
   public static final void b(bK var0, bM var1, String var2) {
      a(var0, var1, var2);
   }
}
