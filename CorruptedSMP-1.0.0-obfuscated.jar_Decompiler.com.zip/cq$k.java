import java.io.IOException;

public final class cq$k extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final int $streamId$inlined;
   // $FF: synthetic field
   final cm $errorCode$inlined;

   public cq$k(String var1, boolean var2, cq var3, int var4, cm var5) {
      super(var1, var2);
      this.this$0 = var3;
      this.$streamId$inlined = var4;
      this.$errorCode$inlined = var5;
   }

   public long gg() {
      boolean var1 = false;

      try {
         this.this$0.b(this.$streamId$inlined, this.$errorCode$inlined);
      } catch (IOException var3) {
         cq.a(this.this$0, var3);
      }

      return -1L;
   }
}
