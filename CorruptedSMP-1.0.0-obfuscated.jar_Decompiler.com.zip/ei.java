import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public class ei implements Listener {
   private final CorruptedSMPPlugin rG;

   public ei(CorruptedSMPPlugin var1) {
      this.rG = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerInteractAtEntityEvent var1) {
      Entity var2 = var1.getRightClicked();
      if (var2 instanceof ArmorStand) {
         for(el var4 : this.rG.e().nc()) {
            if (!var4.mY() && this.a(var4, var2)) {
               var1.setCancelled(true);
               var1.getPlayer().sendMessage("§c§l✗ You cannot interact with the ritual!");
               return;
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerArmorStandManipulateEvent var1) {
      ArmorStand var2 = var1.getRightClicked();

      for(el var4 : this.rG.e().nc()) {
         if (!var4.mY() && this.a(var4, var2)) {
            var1.setCancelled(true);
            var1.getPlayer().sendMessage("§c§l✗ You cannot take items from the ritual!");
            return;
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void o(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof ArmorStand) {
         if (var1.getDamager() instanceof Player) {
            ArmorStand var2 = (ArmorStand)var1.getEntity();
            Player var3 = (Player)var1.getDamager();

            for(el var5 : this.rG.e().nc()) {
               if (!var5.mY() && this.a(var5, var2)) {
                  var1.setCancelled(true);
                  var3.sendMessage("§c§l✗ You cannot damage the ritual!");
                  return;
               }
            }

         }
      }
   }

   private boolean a(el var1, Entity var2) {
      if (!(var2 instanceof ArmorStand var3)) {
         return false;
      } else if (var3.getLocation().distance(var1.mX()) > (double)5.0F) {
         return false;
      } else {
         return var3.isMarker();
      }
   }
}
