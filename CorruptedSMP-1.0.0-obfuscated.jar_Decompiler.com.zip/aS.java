import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Objects;

public class aS<T> {
   private final Class<? super T> dC;
   private final Type dD;
   private final int dE;

   protected aS() {
      this.dD = this.bj();
      this.dC = ak.f(this.dD);
      this.dE = this.dD.hashCode();
   }

   private aS(Type var1) {
      this.dD = ak.e((Type)Objects.requireNonNull(var1));
      this.dC = ak.f(this.dD);
      this.dE = this.dD.hashCode();
   }

   private Type bj() {
      Type var1 = this.getClass().getGenericSuperclass();
      if (var1 instanceof ParameterizedType) {
         ParameterizedType var2 = (ParameterizedType)var1;
         if (var2.getRawType() == aS.class) {
            return ak.e(var2.getActualTypeArguments()[0]);
         }
      } else if (var1 == aS.class) {
         throw new IllegalStateException("TypeToken must be created with a type argument: new TypeToken<...>() {}; When using code shrinkers (ProGuard, R8, ...) make sure that generic signatures are preserved.");
      }

      throw new IllegalStateException("Must only create direct subclasses of TypeToken");
   }

   public final Class<? super T> bk() {
      return this.dC;
   }

   public final Type bl() {
      return this.dD;
   }

   public final int hashCode() {
      return this.dE;
   }

   public final boolean equals(Object var1) {
      return var1 instanceof aS && ak.a(this.dD, ((aS)var1).dD);
   }

   public final String toString() {
      return ak.g(this.dD);
   }

   public static aS<?> k(Type var0) {
      return new aS(var0);
   }

   public static <T> aS<T> t(Class<T> var0) {
      return new aS<T>(var0);
   }
}
