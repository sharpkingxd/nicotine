import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;

public class dB {
   public static final a Companion = new a((fP)null);
   private boolean hasDeadline;
   private long deadlineNanoTime;
   private long timeoutNanos;
   public static final dB NONE = new dB() {
      public dB d(long var1, TimeUnit var3) {
         fR.c(var3, (String)"");
         return this;
      }

      public dB F(long var1) {
         return this;
      }

      public void lx() {
      }
   };

   public dB d(long var1, TimeUnit var3) {
      fR.c(var3, (String)"");
      if (var1 < 0L) {
         boolean var4 = false;
         String var5 = "timeout < 0: " + var1;
         throw new IllegalArgumentException(var5.toString());
      } else {
         this.timeoutNanos = var3.toNanos(var1);
         return this;
      }
   }

   public long ls() {
      return this.timeoutNanos;
   }

   public boolean lt() {
      return this.hasDeadline;
   }

   public long lu() {
      if (!this.hasDeadline) {
         boolean var1 = false;
         String var2 = "No deadline";
         throw new IllegalStateException(var2.toString());
      } else {
         return this.deadlineNanoTime;
      }
   }

   public dB F(long var1) {
      this.hasDeadline = true;
      this.deadlineNanoTime = var1;
      return this;
   }

   public dB lv() {
      this.timeoutNanos = 0L;
      return this;
   }

   public dB lw() {
      this.hasDeadline = false;
      return this;
   }

   public void lx() throws IOException {
      if (Thread.currentThread().isInterrupted()) {
         throw new InterruptedIOException("interrupted");
      } else if (this.hasDeadline && this.deadlineNanoTime - System.nanoTime() <= 0L) {
         throw new InterruptedIOException("deadline reached");
      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
