public interface fQ<R> {
}
