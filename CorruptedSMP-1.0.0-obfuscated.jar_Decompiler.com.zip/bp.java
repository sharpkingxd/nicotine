import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;

public final class bp {
   public static final a hJ = new a((fP)null);
   private final bB hK;
   private final bf hL;
   private final List<Certificate> hM;
   private final ev hN;

   public bp(bB var1, bf var2, List<? extends Certificate> var3, final fJ<? extends List<? extends Certificate>> var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      super();
      this.hK = var1;
      this.hL = var2;
      this.hM = var3;
      this.hN = ew.a(new fJ<List<? extends Certificate>>() {
         public final List<Certificate> cS() {
            List var1;
            try {
               var1 = (List)var4.invoke();
            } catch (SSLPeerUnverifiedException var3) {
               var1 = eO.nk();
            }

            return var1;
         }

         // $FF: synthetic method
         public Object invoke() {
            return this.cS();
         }
      });
   }

   public final bB cM() {
      return this.hK;
   }

   public final bf cN() {
      return this.hL;
   }

   public final List<Certificate> cO() {
      return this.hM;
   }

   public final List<Certificate> cP() {
      ev var1 = this.hN;
      return (List)var1.getValue();
   }

   public boolean equals(Object var1) {
      return var1 instanceof bp && ((bp)var1).hK == this.hK && fR.c(((bp)var1).hL, (Object)this.hL) && fR.c(((bp)var1).cP(), (Object)this.cP()) && fR.c(((bp)var1).hM, (Object)this.hM);
   }

   public int hashCode() {
      int var1 = 17;
      var1 = 31 * var1 + this.hK.hashCode();
      var1 = 31 * var1 + this.hL.hashCode();
      var1 = 31 * var1 + this.cP().hashCode();
      var1 = 31 * var1 + this.hM.hashCode();
      return var1;
   }

   public String toString() {
      Iterable var2 = (Iterable)this.cP();
      boolean var3 = false;
      Collection var5 = (Collection)(new ArrayList(eO.a(var2, 10)));
      boolean var6 = false;

      for(Object var8 : var2) {
         Certificate var9 = (Certificate)var8;
         boolean var10 = false;
         var5.add(this.b(var9));
      }

      String var1 = ((List)var5).toString();
      StringBuilder var10000 = (new StringBuilder()).append("Handshake{tlsVersion=").append(this.hK).append(" cipherSuite=").append(this.hL).append(" peerCertificates=").append(var1).append(" localCertificates=");
      var2 = (Iterable)this.hM;
      StringBuilder var11 = var10000;
      var3 = false;
      var5 = (Collection)(new ArrayList(eO.a(var2, 10)));
      var6 = false;

      for(Object var18 : var2) {
         Certificate var19 = (Certificate)var18;
         boolean var20 = false;
         var5.add(this.b(var19));
      }

      return var11.append((List)var5).append('}').toString();
   }

   private final String b(Certificate var1) {
      String var10000;
      if (var1 instanceof X509Certificate) {
         var10000 = ((X509Certificate)var1).getSubjectDN().toString();
      } else {
         var10000 = var1.getType();
         fR.b(var10000, "");
      }

      return var10000;
   }

   public static final class a {
      private a() {
      }

      public final bp a(SSLSession var1) throws IOException {
         fR.c(var1, (String)"");
         String var10000 = var1.getCipherSuite();
         if (var10000 == null) {
            boolean var10 = false;
            String var11 = "cipherSuite == null";
            throw new IllegalStateException(var11.toString());
         } else {
            String var2 = var10000;
            if (fR.c(var2, (Object)"TLS_NULL_WITH_NULL_NULL") ? true : fR.c(var2, (Object)"SSL_NULL_WITH_NULL_NULL")) {
               throw new IOException("cipherSuite == " + var2);
            } else {
               bf var3 = bf.eF.z(var2);
               var10000 = var1.getProtocol();
               if (var10000 == null) {
                  boolean var6 = false;
                  String var12 = "tlsVersion == null";
                  throw new IllegalStateException(var12.toString());
               } else {
                  String var4 = var10000;
                  if (fR.c("NONE", (Object)var4)) {
                     throw new IOException("tlsVersion == NONE");
                  } else {
                     bB var5 = bB.iY.am(var4);

                     final List var7;
                     try {
                        var7 = this.a(var1.getPeerCertificates());
                     } catch (SSLPeerUnverifiedException var9) {
                        var7 = eO.nk();
                     }

                     return new bp(var5, var3, this.a(var1.getLocalCertificates()), new fJ<List<? extends Certificate>>() {
                        public final List<Certificate> cR() {
                           return var7;
                        }

                        // $FF: synthetic method
                        public Object invoke() {
                           return this.cR();
                        }
                     });
                  }
               }
            }
         }
      }

      private final List<Certificate> a(Certificate[] var1) {
         return var1 != null ? bD.b(Arrays.copyOf(var1, var1.length)) : eO.nk();
      }

      public final bp a(bB var1, bf var2, List<? extends Certificate> var3, List<? extends Certificate> var4) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         fR.c(var3, (String)"");
         fR.c(var4, (String)"");
         final List var5 = bD.b(var3);
         return new bp(var1, var2, bD.b(var4), new fJ<List<? extends Certificate>>() {
            public final List<Certificate> cQ() {
               return var5;
            }

            // $FF: synthetic method
            public Object invoke() {
               return this.cQ();
            }
         });
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
