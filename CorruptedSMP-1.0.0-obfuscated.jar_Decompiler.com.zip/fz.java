import java.lang.reflect.Field;

public final class fz {
   public static final StackTraceElement a(fw var0) {
      fR.c(var0, (String)"");
      fy var10000 = b(var0);
      if (var10000 == null) {
         return null;
      } else {
         fy var1 = var10000;
         h(1, var1.nw());
         int var2 = c(var0);
         int var3 = var2 < 0 ? -1 : var1.ny()[var2];
         String var4 = fA.sB.d(var0);
         String var5 = var4 == null ? var1.nA() : var4 + '/' + var1.nA();
         return new StackTraceElement(var5, var1.nz(), var1.nx(), var3);
      }
   }

   private static final fy b(fw var0) {
      return (fy)var0.getClass().getAnnotation(fy.class);
   }

   private static final int c(fw var0) {
      int var1;
      try {
         Field var5 = var0.getClass().getDeclaredField("label");
         var5.setAccessible(true);
         Object var3 = var5.get(var0);
         var1 = ((var3 instanceof Integer ? (Integer)var3 : null) != null ? var3 instanceof Integer ? (Integer)var3 : null : 0) - 1;
      } catch (Exception var4) {
         var1 = -1;
      }

      return var1;
   }

   private static final void h(int var0, int var1) {
      if (var1 > var0) {
         throw new IllegalStateException(("Debug metadata version mismatch. Expected: " + var0 + ", got " + var1 + ". Please update the Kotlin standard library.").toString());
      }
   }
}
