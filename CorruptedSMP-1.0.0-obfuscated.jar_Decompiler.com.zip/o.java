import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class o {
   static final Set<UUID> N = new HashSet();
   private static final List<a> O = new ArrayList();
   private static final Set<String> P = new HashSet();
   private static UUID Q = null;
   private static BukkitRunnable R = null;

   public static boolean c(Location var0) {
      int var10000 = var0.getBlockX();
      String var1 = var10000 + "," + var0.getBlockY() + "," + var0.getBlockZ();
      return P.contains(var1);
   }

   public static boolean f(UUID var0) {
      return var0.equals(Q);
   }

   public static boolean a(final Player var0, final CorruptedSMPPlugin var1) {
      t();
      final int var2 = var1.getConfig().getInt("corruptions.ender.ability-duration", 20);
      final Location var3 = var0.getLocation().clone();
      final double var4 = (double)20.0F;
      Q = var0.getUniqueId();
      var0.playSound(var0.getLocation(), "custom:ender", 2.0F, 1.0F);
      var0.playSound(var0.getLocation(), Sound.ENTITY_ENDERMAN_SCREAM, 2.0F, 0.8F);
      var3.getWorld().playSound(var3, Sound.BLOCK_SCULK_CATALYST_BLOOM, 2.0F, 0.6F);
      var3.getWorld().spawnParticle(Particle.EXPLOSION, var3, 3, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
      var0.sendMessage("§5§l✓ ENDER BORDER §7activating...");
      (new BukkitRunnable() {
         double currentRadius = (double)0.0F;
         int animTicks = 0;

         public void run() {
            if (this.animTicks >= 20) {
               o.a(var3, var4);
               int var9 = var2 * 20 + 20;
               var0.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, var9, 2, false, false));
               var0.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, var9, 1, false, false));
               var3.getWorld().playSound(var3, Sound.BLOCK_END_PORTAL_SPAWN, 2.0F, 1.0F);
               var3.getWorld().spawnParticle(Particle.SCULK_SOUL, var3, 100, (double)5.0F, (double)3.0F, (double)5.0F, 0.1);
               var3.getWorld().spawnParticle(Particle.PORTAL, var3, 50, (double)3.0F, (double)2.0F, (double)3.0F, (double)1.0F);
               var0.sendMessage("§5§l✓ ENDER BORDER §7activated! §5Duration: " + var2 + "s");
               o.a(var0, var1, var3, var4, var2);
               this.cancel();
            } else {
               this.currentRadius = (double)this.animTicks / (double)20.0F * (double)5.0F;

               for(int var1x = 0; var1x < 360; var1x += 10) {
                  double var2x = Math.toRadians((double)var1x);
                  double var4x = var3.getX() + this.currentRadius * Math.cos(var2x);
                  double var6 = var3.getZ() + this.currentRadius * Math.sin(var2x);
                  Location var8 = new Location(var3.getWorld(), var4x, var3.getY() + 0.1, var6);
                  var3.getWorld().spawnParticle(Particle.SQUID_INK, var8, 3, 0.1, 0.05, 0.1, 0.01);
                  var3.getWorld().spawnParticle(Particle.SCULK_SOUL, var8, 2, 0.1, 0.1, 0.1, 0.02);
                  var3.getWorld().spawnParticle(Particle.PORTAL, var8, 1, 0.05, 0.05, 0.05, (double)0.0F);
               }

               var3.getWorld().spawnParticle(Particle.SCULK_SOUL, var3.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 5, 0.3, 0.3, 0.3, 0.05);
               if (this.animTicks % 5 == 0) {
                  var3.getWorld().playSound(var3, Sound.BLOCK_SCULK_SENSOR_CLICKING, 0.5F, 0.8F + (float)this.animTicks / 20.0F);
               }

               ++this.animTicks;
            }
         }
      }).runTaskTimer(var1, 0L, 1L);
      return true;
   }

   static void a(final Player var0, CorruptedSMPPlugin var1, final Location var2, final double var3, final int var5) {
      R = new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            if (this.ticks >= var5 * 20) {
               o.t();
               this.cancel();
               var0.sendMessage("§5§lENDER BORDER §7ended!");
            } else {
               if (this.ticks % 10 == 0) {
                  for(int var1 = 0; var1 < 360; var1 += 30) {
                     double var2x = Math.toRadians((double)var1);
                     double var4 = var2.getX() + var3 * Math.cos(var2x);
                     double var6 = var2.getZ() + var3 * Math.sin(var2x);
                     Location var8 = new Location(var2.getWorld(), var4, var2.getY() + (double)5.0F, var6);
                     var2.getWorld().spawnParticle(Particle.SCULK_SOUL, var8, 3, (double)0.5F, (double)2.0F, (double)0.5F, 0.02);
                     var2.getWorld().spawnParticle(Particle.PORTAL, var8, 2, 0.3, (double)1.0F, 0.3, (double)0.0F);
                  }
               }

               for(Entity var10 : var2.getWorld().getNearbyEntities(var2, var3, (double)15.0F, var3)) {
                  if (var10 instanceof Player) {
                     Player var3x = (Player)var10;
                     if (!var3x.equals(var0)) {
                        o.N.add(var3x.getUniqueId());
                        if (this.ticks % 20 == 0) {
                           var3x.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 2, false, false));
                           var3x.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0, false, false));
                        }
                     }
                  }
               }

               if (this.ticks % 60 == 0) {
                  var2.getWorld().playSound(var2, Sound.BLOCK_SCULK_CATALYST_BLOOM, 1.0F, 0.8F);
                  var2.getWorld().playSound(var2, Sound.ENTITY_ENDERMAN_AMBIENT, 0.5F, 0.5F);
               }

               ++this.ticks;
            }
         }
      };
      R.runTaskTimer(var1, 0L, 1L);
   }

   static void a(Location var0, double var1) {
      O.clear();
      P.clear();
      World var3 = var0.getWorld();
      int var4 = var0.getBlockX();
      int var5 = var0.getBlockZ();
      int var6 = Math.max(0, (int)var0.getY() - 20);
      int var7 = (int)var0.getY() + 15;
      int var8 = (int)Math.ceil(var1);

      for(int var9 = -var8; var9 <= var8; ++var9) {
         for(int var10 = -var8; var10 <= var8; ++var10) {
            double var11 = Math.sqrt((double)(var9 * var9 + var10 * var10));
            if (var11 >= var1 - (double)0.5F && var11 <= var1 + (double)0.5F) {
               int var13 = var4 + var9;
               int var14 = var5 + var10;

               for(int var15 = var6; var15 <= var7; ++var15) {
                  Block var16 = var3.getBlockAt(var13, var15, var14);
                  O.add(new a(var3, var13, var15, var14, var16.getType()));
                  String var17 = var13 + "," + var15 + "," + var14;
                  P.add(var17);
                  var16.setType(Material.SCULK_CATALYST);
               }
            }
         }
      }

   }

   private static void s() {
      for(a var1 : O) {
         try {
            Block var2 = var1.world.getBlockAt(var1.x, var1.y, var1.z);
            var2.setType(var1.originalType);
         } catch (Exception var3) {
         }
      }

      O.clear();
      P.clear();
   }

   public static void t() {
      if (R != null && !R.isCancelled()) {
         R.cancel();
         R = null;
      }

      s();
      N.clear();
      Q = null;
   }

   public static boolean c(UUID var0) {
      return N.contains(var0);
   }

   static class a {
      final World world;
      final int x;
      final int y;
      final int z;
      final Material originalType;

      a(World var1, int var2, int var3, int var4, Material var5) {
         this.world = var1;
         this.x = var2;
         this.y = var3;
         this.z = var4;
         this.originalType = var5;
      }
   }
}
