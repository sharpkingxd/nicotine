import java.io.IOException;

public final class cq$d$b extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final ct $newStream$inlined;

   public cq$d$b(String var1, boolean var2, cq var3, ct var4) {
      super(var1, var2);
      this.this$0 = var3;
      this.$newStream$inlined = var4;
   }

   public long gg() {
      boolean var1 = false;

      try {
         this.this$0.im().a(this.$newStream$inlined);
      } catch (IOException var7) {
         IOException var2 = var7;
         cH.oU.jZ().a("Http2Connection.Listener failure for " + this.this$0.io(), 4, (Throwable)var7);
         boolean var3 = false;

         try {
            boolean var4 = false;
            this.$newStream$inlined.a(cm.my, var2);
         } catch (IOException var6) {
         }
      }

      return -1L;
   }
}
