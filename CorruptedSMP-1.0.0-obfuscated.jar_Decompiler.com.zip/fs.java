import java.util.Comparator;

final class fs implements Comparator<Comparable<? super Object>> {
   public static final fs sz = new fs();

   private fs() {
   }

   public int a(Comparable<Object> var1, Comparable<Object> var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      return var1.compareTo(var2);
   }

   public final Comparator<Comparable<Object>> reversed() {
      return ft.sA;
   }

   // $FF: synthetic method
   public int compare(Object var1, Object var2) {
      return this.a((Comparable)var1, (Comparable)var2);
   }
}
