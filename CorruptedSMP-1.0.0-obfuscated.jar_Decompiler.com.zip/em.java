import org.bukkit.Location;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class em {
   private final Plugin rU;
   private EnderCrystal rV;
   private BukkitTask rW;
   private boolean rX;

   public em(Plugin var1) {
      this.rU = var1;
      this.rX = false;
   }

   public void a(Location var1, int var2) {
      this.na();
      this.rX = true;
      Location var3 = var1.clone().add((double)0.5F, (double)0.0F, (double)0.5F);
      var3.setY((double)-100.0F);
      Location var4 = var1.clone().add((double)0.5F, (double)0.0F, (double)0.5F);
      var4.setY((double)500.0F);
      this.rV = (EnderCrystal)var1.getWorld().spawnEntity(var3, EntityType.END_CRYSTAL);
      this.rV.setShowingBottom(false);
      this.rV.setInvulnerable(true);
      this.rV.setBeamTarget(var4);
      this.rW = this.rU.getServer().getScheduler().runTaskLater(this.rU, this::na, (long)var2 * 20L);
   }

   public void na() {
      this.rX = false;
      if (this.rW != null && !this.rW.isCancelled()) {
         this.rW.cancel();
         this.rW = null;
      }

      if (this.rV != null) {
         try {
            if (this.rV.isValid()) {
               this.rV.remove();
            }
         } catch (Exception var2) {
            this.rU.getLogger().warning("Failed to remove ritual beam crystal: " + var2.getMessage());
         }

         this.rV = null;
      }

   }
}
