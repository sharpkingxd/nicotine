import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class bq implements fY, Iterable<ez<? extends String, ? extends String>> {
   public static final b hO = new b((fP)null);
   private final String[] hP;

   private bq(String[] var1) {
      this.hP = var1;
   }

   public final String E(String var1) {
      fR.c(var1, (String)"");
      return hO.b(this.hP, var1);
   }

   public final int cT() {
      return this.hP.length / 2;
   }

   public final String j(int var1) {
      return this.hP[var1 * 2];
   }

   public final String k(int var1) {
      return this.hP[var1 * 2 + 1];
   }

   public final List<String> F(String var1) {
      fR.c(var1, (String)"");
      List var2 = null;
      int var3 = 0;

      for(int var4 = this.cT(); var3 < var4; ++var3) {
         if (gA.a(var1, this.j(var3), true)) {
            if (var2 == null) {
               var2 = (List)(new ArrayList(2));
            }

            var2.add(this.k(var3));
         }
      }

      List var10000;
      if (var2 != null) {
         var10000 = Collections.unmodifiableList(var2);
         fR.b(var10000, "");
      } else {
         var10000 = eO.nk();
      }

      return var10000;
   }

   public Iterator<ez<String, String>> iterator() {
      int var1 = 0;
      int var2 = this.cT();

      ez[] var3;
      for(var3 = new ez[var2]; var1 < var2; ++var1) {
         var3[var1] = eB.b(this.j(var1), this.k(var1));
      }

      return fN.<ez<String, String>>m(var3);
   }

   public final a cU() {
      a var1 = new a();
      eO.a((Collection)var1.cV(), this.hP);
      return var1;
   }

   public boolean equals(Object var1) {
      return var1 instanceof bq && Arrays.equals(this.hP, ((bq)var1).hP);
   }

   public int hashCode() {
      return Arrays.hashCode(this.hP);
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      StringBuilder var2 = var1;
      boolean var3 = false;
      int var4 = 0;

      for(int var5 = this.cT(); var4 < var5; ++var4) {
         String var6 = this.j(var4);
         String var7 = this.k(var4);
         var2.append(var6);
         var2.append(": ");
         var2.append(bD.ar(var6) ? "██" : var7);
         var2.append("\n");
      }

      String var10000 = var1.toString();
      fR.b(var10000, "");
      return var10000;
   }

   // $FF: synthetic method
   public bq(String[] var1, fP var2) {
      this(var1);
   }

   public static final class a {
      private final List<String> namesAndValues = (List)(new ArrayList(20));

      public final List<String> cV() {
         return this.namesAndValues;
      }

      public final a G(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;
         int var5 = gA.a((CharSequence)var1, ':', 1, false, 4, (Object)null);
         if (var5 != -1) {
            String var10001 = var1.substring(0, var5);
            fR.b(var10001, "");
            String var10002 = var1.substring(var5 + 1);
            fR.b(var10002, "");
            var3.e(var10001, var10002);
         } else if (var1.charAt(0) == ':') {
            String var6 = var1.substring(1);
            fR.b(var6, "");
            var3.e("", var6);
         } else {
            var3.e("", var1);
         }

         return this;
      }

      public final a d(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         bq.hO.J(var1);
         bq.hO.g(var2, var1);
         var4.e(var1, var2);
         return this;
      }

      public final a e(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         var4.namesAndValues.add(var1);
         var4.namesAndValues.add(gA.c((CharSequence)var2).toString());
         return this;
      }

      public final a H(String var1) {
         fR.c(var1, (String)"");
         a var3 = this;
         boolean var4 = false;

         for(int var5 = 0; var5 < var3.namesAndValues.size(); var5 += 2) {
            if (gA.a(var1, (String)var3.namesAndValues.get(var5), true)) {
               var3.namesAndValues.remove(var5);
               var3.namesAndValues.remove(var5);
               var5 -= 2;
            }
         }

         return this;
      }

      public final a f(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         bq.hO.J(var1);
         bq.hO.g(var2, var1);
         var4.H(var1);
         var4.e(var1, var2);
         return this;
      }

      public final String I(String var1) {
         fR.c(var1, (String)"");
         int var2 = this.namesAndValues.size() - 2;
         int var3 = var2;
         int var4 = fF.i(var2, 0, -2);
         if (var4 <= var2) {
            while(true) {
               if (gA.a(var1, (String)this.namesAndValues.get(var3), true)) {
                  return (String)this.namesAndValues.get(var3 + 1);
               }

               if (var3 == var4) {
                  break;
               }

               var3 -= 2;
            }
         }

         return null;
      }

      public final bq cW() {
         Collection var1 = (Collection)this.namesAndValues;
         boolean var2 = false;
         return new bq((String[])var1.toArray(new String[0]), (fP)null);
      }
   }

   public static final class b {
      private b() {
      }

      private final String b(String[] var1, String var2) {
         int var3 = var1.length - 2;
         int var4 = var3;
         int var5 = fF.i(var3, 0, -2);
         if (var5 <= var3) {
            while(true) {
               if (gA.a(var2, var1[var4], true)) {
                  return var1[var4 + 1];
               }

               if (var4 == var5) {
                  break;
               }

               var4 -= 2;
            }
         }

         return null;
      }

      public final bq c(String... var1) {
         fR.c(var1, (String)"");
         if (var1.length % 2 != 0) {
            boolean var9 = false;
            String var10 = "Expected alternating header names and values";
            throw new IllegalArgumentException(var10.toString());
         } else {
            String[] var2 = (String[])var1.clone();
            int var3 = 0;

            for(int var4 = var2.length; var3 < var4; ++var3) {
               if (var2[var3] == null) {
                  boolean var6 = false;
                  String var12 = "Headers cannot be null";
                  throw new IllegalArgumentException(var12.toString());
               }

               var2[var3] = gA.c((CharSequence)var2[var3]).toString();
            }

            var3 = var2.length + -1;
            int var11 = 0;
            int var5 = fF.i(0, var3, 2);
            if (var11 <= var5) {
               while(true) {
                  String var13 = var2[var11];
                  String var7 = var2[var11 + 1];
                  this.J(var13);
                  this.g(var7, var13);
                  if (var11 == var5) {
                     break;
                  }

                  var11 += 2;
               }
            }

            return new bq(var2, (fP)null);
         }
      }

      private final void J(String var1) {
         if (((CharSequence)var1).length() <= 0) {
            boolean var7 = false;
            String var8 = "name is empty";
            throw new IllegalArgumentException(var8.toString());
         } else {
            int var2 = 0;

            for(int var3 = var1.length(); var2 < var3; ++var2) {
               char var4 = var1.charAt(var2);
               if (!('!' <= var4 ? var4 < 127 : false)) {
                  boolean var5 = false;
                  Object[] var6 = new Object[]{var4, var2, var1};
                  String var9 = bD.a("Unexpected char %#04x at %d in header name: %s", var6);
                  throw new IllegalArgumentException(var9.toString());
               }
            }

         }
      }

      private final void g(String var1, String var2) {
         int var3 = 0;

         for(int var4 = var1.length(); var3 < var4; ++var3) {
            char var5 = var1.charAt(var3);
            if (var5 != '\t' && !(' ' <= var5 ? var5 < 127 : false)) {
               boolean var6 = false;
               StringBuilder var10000 = new StringBuilder();
               Object[] var7 = new Object[]{var5, var3, var2};
               String var8 = var10000.append(bD.a("Unexpected char %#04x at %d in %s value", var7)).append(bD.ar(var2) ? "" : ": " + var1).toString();
               throw new IllegalArgumentException(var8.toString());
            }
         }

      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }
}
