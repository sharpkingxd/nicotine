public final class X extends T {
   private static final long serialVersionUID = 1L;

   public X(String var1) {
      super(var1);
   }

   public X(String var1, Throwable var2) {
      super(var1, var2);
   }

   public X(Throwable var1) {
      super(var1);
   }
}
