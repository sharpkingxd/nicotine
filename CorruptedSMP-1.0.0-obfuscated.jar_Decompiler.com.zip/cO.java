import java.lang.reflect.Method;

public final class cO {
   public static final a po = new a((fP)null);
   private final Method pp;
   private final Method pq;
   private final Method pr;

   public cO(Method var1, Method var2, Method var3) {
      this.pp = var1;
      this.pq = var2;
      this.pr = var3;
   }

   public final Object aJ(String var1) {
      fR.c(var1, (String)"");
      if (this.pp != null) {
         try {
            Object var2 = this.pp.invoke((Object)null);
            Method var10000 = this.pq;
            fR.m(var10000);
            Object[] var3 = new Object[]{var1};
            var10000.invoke(var2, var3);
            return var2;
         } catch (Exception var4) {
         }
      }

      return null;
   }

   public final boolean g(Object var1) {
      boolean var2 = false;
      if (var1 != null) {
         try {
            Method var10000 = this.pr;
            fR.m(var10000);
            var10000.invoke(var1);
            var2 = true;
         } catch (Exception var4) {
         }
      }

      return var2;
   }

   public static final class a {
      private a() {
      }

      public final cO ko() {
         Method var1 = null;
         Method var2 = null;
         Method var3 = null;

         try {
            Class var4 = Class.forName("dalvik.system.CloseGuard");
            var1 = var4.getMethod("get");
            Class[] var5 = new Class[]{String.class};
            var2 = var4.getMethod("open", var5);
            var3 = var4.getMethod("warnIfOpen");
         } catch (Exception var6) {
            var1 = null;
            var2 = null;
            var3 = null;
         }

         return new cO(var1, var2, var3);
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
