import java.net.Proxy;
import java.net.ProxySelector;
import java.util.List;
import java.util.Objects;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;

public final class aX {
   private final bn dns;
   private final SocketFactory socketFactory;
   private final SSLSocketFactory ei;
   private final HostnameVerifier hostnameVerifier;
   private final bd certificatePinner;
   private final aY proxyAuthenticator;
   private final Proxy proxy;
   private final ProxySelector proxySelector;
   private final br url;
   private final List<bv> protocols;
   private final List<bi> connectionSpecs;

   public aX(String var1, int var2, bn var3, SocketFactory var4, SSLSocketFactory var5, HostnameVerifier var6, bd var7, aY var8, Proxy var9, List<? extends bv> var10, List<bi> var11, ProxySelector var12) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      fR.c(var8, (String)"");
      fR.c(var10, (String)"");
      fR.c(var11, (String)"");
      fR.c(var12, (String)"");
      super();
      this.dns = var3;
      this.socketFactory = var4;
      this.ei = var5;
      this.hostnameVerifier = var6;
      this.certificatePinner = var7;
      this.proxyAuthenticator = var8;
      this.proxy = var9;
      this.proxySelector = var12;
      this.url = (new br.a()).R(this.ei != null ? "https" : "http").U(var1).m(var2).dq();
      this.protocols = bD.b(var10);
      this.connectionSpecs = bD.b(var11);
   }

   public final bn bC() {
      return this.dns;
   }

   public final SocketFactory bD() {
      return this.socketFactory;
   }

   public final SSLSocketFactory bE() {
      return this.ei;
   }

   public final HostnameVerifier bF() {
      return this.hostnameVerifier;
   }

   public final bd bG() {
      return this.certificatePinner;
   }

   public final aY bH() {
      return this.proxyAuthenticator;
   }

   public final Proxy bI() {
      return this.proxy;
   }

   public final ProxySelector bJ() {
      return this.proxySelector;
   }

   public final br bK() {
      return this.url;
   }

   public final List<bv> bL() {
      return this.protocols;
   }

   public final List<bi> bM() {
      return this.connectionSpecs;
   }

   public boolean equals(Object var1) {
      return var1 instanceof aX && fR.c(this.url, (Object)((aX)var1).url) && this.a((aX)var1);
   }

   public int hashCode() {
      int var1 = 17;
      var1 = 31 * var1 + this.url.hashCode();
      var1 = 31 * var1 + this.dns.hashCode();
      var1 = 31 * var1 + this.proxyAuthenticator.hashCode();
      var1 = 31 * var1 + this.protocols.hashCode();
      var1 = 31 * var1 + this.connectionSpecs.hashCode();
      var1 = 31 * var1 + this.proxySelector.hashCode();
      var1 = 31 * var1 + Objects.hashCode(this.proxy);
      var1 = 31 * var1 + Objects.hashCode(this.ei);
      var1 = 31 * var1 + Objects.hashCode(this.hostnameVerifier);
      var1 = 31 * var1 + Objects.hashCode(this.certificatePinner);
      return var1;
   }

   public final boolean a(aX var1) {
      fR.c(var1, (String)"");
      return fR.c(this.dns, (Object)var1.dns) && fR.c(this.proxyAuthenticator, (Object)var1.proxyAuthenticator) && fR.c(this.protocols, (Object)var1.protocols) && fR.c(this.connectionSpecs, (Object)var1.connectionSpecs) && fR.c(this.proxySelector, (Object)var1.proxySelector) && fR.c(this.proxy, (Object)var1.proxy) && fR.c(this.ei, (Object)var1.ei) && fR.c(this.hostnameVerifier, (Object)var1.hostnameVerifier) && fR.c(this.certificatePinner, (Object)var1.certificatePinner) && this.url.cZ() == var1.url.cZ();
   }

   public String toString() {
      return "Address{" + this.url.cY() + ':' + this.url.cZ() + ", " + (this.proxy != null ? "proxy=" + this.proxy : "proxySelector=" + this.proxySelector) + '}';
   }
}
