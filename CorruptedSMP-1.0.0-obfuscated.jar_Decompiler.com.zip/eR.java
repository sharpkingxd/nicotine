import java.util.Collection;

class eR extends eQ {
   public static final <T> int a(Iterable<? extends T> var0, int var1) {
      fR.c(var0, (String)"");
      return var0 instanceof Collection ? ((Collection)var0).size() : var1;
   }
}
