import java.io.Closeable;

public final class fI {
   public static final void a(Closeable var0, Throwable var1) {
      if (var0 != null) {
         if (var1 == null) {
            var0.close();
         } else {
            try {
               var0.close();
            } catch (Throwable var3) {
               er.a(var1, var3);
            }
         }
      }

   }
}
