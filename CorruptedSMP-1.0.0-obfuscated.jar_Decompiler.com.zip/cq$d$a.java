public final class cq$d$a extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final fT.b $newPeerSettings$inlined;

   public cq$d$a(String var1, boolean var2, cq var3, fT.b var4) {
      super(var1, var2);
      this.this$0 = var3;
      this.$newPeerSettings$inlined = var4;
   }

   public long gg() {
      boolean var1 = false;
      this.this$0.im().a(this.this$0, (cx)this.$newPeerSettings$inlined.sQ);
      return -1L;
   }
}
