import java.util.concurrent.atomic.AtomicReference;

public final class dw {
   public static final dw qx = new dw();
   private static final int qy = 65536;
   private static final dv qz = new dv(new byte[0], 0, 0, false, false);
   private static final int qA = Integer.highestOneBit(Runtime.getRuntime().availableProcessors() * 2 - 1);
   private static final AtomicReference<dv>[] qB;

   private dw() {
   }

   public static final dv lK() {
      AtomicReference var0 = qx.lL();
      dv var1 = (dv)var0.getAndSet(qz);
      if (var1 == qz) {
         return new dv();
      } else if (var1 == null) {
         var0.set((Object)null);
         return new dv();
      } else {
         var0.set(var1.qv);
         var1.qv = null;
         var1.dI = 0;
         return var1;
      }
   }

   public static final void c(dv var0) {
      fR.c(var0, (String)"");
      if (var0.qv != null || var0.qw != null) {
         String var4 = "Failed requirement.";
         throw new IllegalArgumentException(var4.toString());
      } else if (!var0.qt) {
         AtomicReference var1 = qx.lL();
         dv var2 = (dv)var1.getAndSet(qz);
         if (var2 != qz) {
            int var3 = var2 != null ? var2.dI : 0;
            dw var10001 = qx;
            if (var3 >= qy) {
               var1.set(var2);
            } else {
               var0.qv = var2;
               var0.dH = 0;
               var0.dI = var3 + 8192;
               var1.set(var0);
            }
         }
      }
   }

   private final AtomicReference<dv> lL() {
      int var1 = (int)(Thread.currentThread().getId() & (long)qA - 1L);
      return qB[var1];
   }

   static {
      int var0 = 0;
      int var1 = qA;

      AtomicReference[] var2;
      for(var2 = new AtomicReference[var1]; var0 < var1; ++var0) {
         var2[var0] = new AtomicReference();
      }

      qB = var2;
   }
}
