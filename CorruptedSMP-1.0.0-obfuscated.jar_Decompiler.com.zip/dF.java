public final class dF {
   private static final char[] qG;

   public static final char[] lQ() {
      return qG;
   }

   public static final void a(dh var0, de var1, int var2, int var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      var1.a(var0.lc(), var2, var3);
   }

   private static final int e(char var0) {
      int var10000;
      if ('0' <= var0 ? var0 < ':' : false) {
         var10000 = var0 - 48;
      } else if ('a' <= var0 ? var0 < 'g' : false) {
         var10000 = var0 - 97 + 10;
      } else {
         if (!('A' <= var0 ? var0 < 'G' : false)) {
            throw new IllegalArgumentException("Unexpected hex digit: " + var0);
         }

         var10000 = var0 - 65 + 10;
      }

      return var10000;
   }

   private static final int b(byte[] var0, int var1) {
      int var2 = 0;
      int var3 = 0;
      byte[] var4 = var0;
      byte var5 = 0;
      int var6 = var0.length;
      boolean var7 = false;
      int var8 = var5;

      label1181:
      while(var8 < var6) {
         byte var9 = var4[var8];
         if (var9 >= 0) {
            boolean var46 = false;
            int var85 = var3++;
            if (var85 == var1) {
               return var2;
            }

            if (var9 != 10 && var9 != 13) {
               var85 = 0;
               if ((0 <= var9 ? var9 < 32 : false) || (127 <= var9 ? var9 < 160 : false)) {
                  return -1;
               }
            }

            if (var9 != '�') {
               var2 += var9 < 65536 ? 1 : 2;
               ++var8;

               while(true) {
                  if (var8 >= var6 || var4[var8] < 0) {
                     continue label1181;
                  }

                  byte var27 = var4[var8++];
                  var46 = false;
                  var85 = var3++;
                  if (var85 == var1) {
                     return var2;
                  }

                  if (var27 != 10 && var27 != 13) {
                     var85 = 0;
                     if ((0 <= var27 ? var27 < 32 : false) || (127 <= var27 ? var27 < 160 : false)) {
                        break;
                     }
                  }

                  if (var27 == '�') {
                     break;
                  }

                  var2 += var27 < 65536 ? 1 : 2;
               }

               return -1;
            }

            return -1;
         } else {
            byte var14 = 5;
            char var15 = '\u0000';
            if (var9 >> var14 == -2) {
               var14 = 0;
               int var180;
               byte var182;
               if (var6 <= var8 + 1) {
                  var15 = '�';
                  boolean var124 = false;
                  boolean var42 = false;
                  int var77 = var3++;
                  if (var77 == var1) {
                     return var2;
                  }

                  if (var15 != '\n' && var15 != '\r') {
                     var77 = 0;
                     if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                        return -1;
                     }
                  }

                  if (var15 == '�') {
                     return -1;
                  }

                  var2 += var15 < 65536 ? 1 : 2;
                  eE var141 = eE.sk;
                  var180 = var8;
                  var182 = 1;
               } else {
                  byte var149 = var4[var8];
                  byte var154 = var4[var8 + 1];
                  int var158 = 0;
                  short var172 = 192;
                  boolean var176 = false;
                  if ((var154 & var172) != 128) {
                     var15 = '�';
                     boolean var125 = false;
                     boolean var43 = false;
                     int var79 = var3++;
                     if (var79 == var1) {
                        return var2;
                     }

                     if (var15 != '\n' && var15 != '\r') {
                        var79 = 0;
                        if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                           return -1;
                        }
                     }

                     if (var15 == '�') {
                        return -1;
                     }

                     var2 += var15 < 65536 ? 1 : 2;
                     eE var142 = eE.sk;
                     var180 = var8;
                     var182 = 1;
                  } else {
                     var158 = 3968 ^ var154 ^ var149 << 6;
                     if (var158 < 128) {
                        var15 = '�';
                        boolean var126 = false;
                        boolean var44 = false;
                        int var81 = var3++;
                        if (var81 == var1) {
                           return var2;
                        }

                        if (var15 != '\n' && var15 != '\r') {
                           var81 = 0;
                           if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                              return -1;
                           }
                        }

                        if (var15 == '�') {
                           return -1;
                        }

                        var2 += var15 < 65536 ? 1 : 2;
                        eE var143 = eE.sk;
                        var180 = var8;
                     } else {
                        boolean var127 = false;
                        boolean var45 = false;
                        int var83 = var3++;
                        if (var83 == var1) {
                           return var2;
                        }

                        if (var158 != 10 && var158 != 13) {
                           var83 = 0;
                           if ((0 <= var158 ? var158 < 32 : false) || (127 <= var158 ? var158 < 160 : false)) {
                              return -1;
                           }
                        }

                        if (var158 == 65533) {
                           return -1;
                        }

                        var2 += var158 < 65536 ? 1 : 2;
                        eE var144 = eE.sk;
                        var180 = var8;
                     }

                     var182 = 2;
                  }
               }

               var8 = var180 + var182;
            } else {
               var14 = 4;
               var15 = '\u0000';
               if (var9 >> var14 == -2) {
                  var14 = 0;
                  int var179;
                  byte var181;
                  if (var6 <= var8 + 2) {
                     label1197: {
                        var15 = '�';
                        boolean var118 = false;
                        boolean var36 = false;
                        int var65 = var3++;
                        if (var65 == var1) {
                           return var2;
                        }

                        if (var15 != '\n' && var15 != '\r') {
                           var65 = 0;
                           if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                              return -1;
                           }
                        }

                        if (var15 == '�') {
                           return -1;
                        }

                        var2 += var15 < 65536 ? 1 : 2;
                        eE var135 = eE.sk;
                        var179 = var8;
                        if (var6 > var8 + 1) {
                           byte var147 = var4[var8 + 1];
                           boolean var152 = false;
                           short var163 = 192;
                           boolean var170 = false;
                           if ((var147 & var163) == 128) {
                              var181 = 2;
                              break label1197;
                           }
                        }

                        var181 = 1;
                     }
                  } else {
                     byte var148 = var4[var8];
                     byte var153 = var4[var8 + 1];
                     byte var156 = 0;
                     short var171 = 192;
                     short var174 = 0;
                     if ((var153 & var171) != 128) {
                        var15 = '�';
                        boolean var119 = false;
                        boolean var37 = false;
                        int var67 = var3++;
                        if (var67 == var1) {
                           return var2;
                        }

                        if (var15 != '\n' && var15 != '\r') {
                           var67 = 0;
                           if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                              return -1;
                           }
                        }

                        if (var15 == '�') {
                           return -1;
                        }

                        var2 += var15 < 65536 ? 1 : 2;
                        eE var136 = eE.sk;
                        var179 = var8;
                        var181 = 1;
                     } else {
                        var156 = var4[var8 + 2];
                        int var164 = 0;
                        var174 = 192;
                        boolean var178 = false;
                        if ((var156 & var174) != 128) {
                           var15 = '�';
                           boolean var120 = false;
                           boolean var38 = false;
                           int var69 = var3++;
                           if (var69 == var1) {
                              return var2;
                           }

                           if (var15 != '\n' && var15 != '\r') {
                              var69 = 0;
                              if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                 return -1;
                              }
                           }

                           if (var15 == '�') {
                              return -1;
                           }

                           var2 += var15 < 65536 ? 1 : 2;
                           eE var137 = eE.sk;
                           var179 = var8;
                           var181 = 2;
                        } else {
                           var164 = -123008 ^ var156 ^ var153 << 6 ^ var148 << 12;
                           if (var164 < 2048) {
                              var15 = '�';
                              boolean var121 = false;
                              boolean var39 = false;
                              int var71 = var3++;
                              if (var71 == var1) {
                                 return var2;
                              }

                              if (var15 != '\n' && var15 != '\r') {
                                 var71 = 0;
                                 if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                    return -1;
                                 }
                              }

                              if (var15 == '�') {
                                 return -1;
                              }

                              var2 += var15 < 65536 ? 1 : 2;
                              eE var138 = eE.sk;
                              var179 = var8;
                           } else if (55296 <= var164 ? var164 < 57344 : false) {
                              var15 = '�';
                              boolean var122 = false;
                              boolean var40 = false;
                              int var73 = var3++;
                              if (var73 == var1) {
                                 return var2;
                              }

                              if (var15 != '\n' && var15 != '\r') {
                                 var73 = 0;
                                 if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                    return -1;
                                 }
                              }

                              if (var15 == '�') {
                                 return -1;
                              }

                              var2 += var15 < 65536 ? 1 : 2;
                              eE var139 = eE.sk;
                              var179 = var8;
                           } else {
                              boolean var123 = false;
                              boolean var41 = false;
                              int var75 = var3++;
                              if (var75 == var1) {
                                 return var2;
                              }

                              if (var164 != 10 && var164 != 13) {
                                 var75 = 0;
                                 if ((0 <= var164 ? var164 < 32 : false) || (127 <= var164 ? var164 < 160 : false)) {
                                    return -1;
                                 }
                              }

                              if (var164 == 65533) {
                                 return -1;
                              }

                              var2 += var164 < 65536 ? 1 : 2;
                              eE var140 = eE.sk;
                              var179 = var8;
                           }

                           var181 = 3;
                        }
                     }
                  }

                  var8 = var179 + var181;
               } else {
                  var14 = 3;
                  var15 = '\u0000';
                  if (var9 >> var14 == -2) {
                     var14 = 0;
                     int var10000;
                     byte var10001;
                     if (var6 <= var8 + 3) {
                        label1209: {
                           var15 = '�';
                           boolean var17 = false;
                           boolean var28 = false;
                           int var49 = var3++;
                           if (var49 == var1) {
                              return var2;
                           }

                           if (var15 != '\n' && var15 != '\r') {
                              var49 = 0;
                              if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                 return -1;
                              }
                           }

                           if (var15 == '�') {
                              return -1;
                           }

                           var2 += var15 < 65536 ? 1 : 2;
                           eE var18 = eE.sk;
                           var10000 = var8;
                           if (var6 > var8 + 1) {
                              byte var19 = var4[var8 + 1];
                              boolean var20 = false;
                              short var22 = 192;
                              boolean var23 = false;
                              if ((var19 & var22) == 128) {
                                 if (var6 > var8 + 2) {
                                    var19 = var4[var8 + 2];
                                    var20 = false;
                                    var22 = 192;
                                    var23 = false;
                                    if ((var19 & var22) == 128) {
                                       var10001 = 3;
                                       break label1209;
                                    }
                                 }

                                 var10001 = 2;
                                 break label1209;
                              }
                           }

                           var10001 = 1;
                        }
                     } else {
                        byte var146 = var4[var8];
                        byte var151 = var4[var8 + 1];
                        byte var21 = 0;
                        int var167 = 192;
                        short var24 = 0;
                        if ((var151 & var167) != 128) {
                           var15 = '�';
                           boolean var111 = false;
                           boolean var29 = false;
                           int var51 = var3++;
                           if (var51 == var1) {
                              return var2;
                           }

                           if (var15 != '\n' && var15 != '\r') {
                              var51 = 0;
                              if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                 return -1;
                              }
                           }

                           if (var15 == '�') {
                              return -1;
                           }

                           var2 += var15 < 65536 ? 1 : 2;
                           eE var128 = eE.sk;
                           var10000 = var8;
                           var10001 = 1;
                        } else {
                           var21 = var4[var8 + 2];
                           byte var161 = 0;
                           var24 = 192;
                           short var25 = 0;
                           if ((var21 & var24) != 128) {
                              var15 = '�';
                              boolean var112 = false;
                              boolean var30 = false;
                              int var53 = var3++;
                              if (var53 == var1) {
                                 return var2;
                              }

                              if (var15 != '\n' && var15 != '\r') {
                                 var53 = 0;
                                 if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                    return -1;
                                 }
                              }

                              if (var15 == '�') {
                                 return -1;
                              }

                              var2 += var15 < 65536 ? 1 : 2;
                              eE var129 = eE.sk;
                              var10000 = var8;
                              var10001 = 2;
                           } else {
                              var161 = var4[var8 + 3];
                              var167 = (short)0;
                              var25 = 192;
                              boolean var26 = false;
                              if ((var161 & var25) != 128) {
                                 var15 = '�';
                                 boolean var113 = false;
                                 boolean var31 = false;
                                 int var55 = var3++;
                                 if (var55 == var1) {
                                    return var2;
                                 }

                                 if (var15 != '\n' && var15 != '\r') {
                                    var55 = 0;
                                    if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                       return -1;
                                    }
                                 }

                                 if (var15 == '�') {
                                    return -1;
                                 }

                                 var2 += var15 < 65536 ? 1 : 2;
                                 eE var130 = eE.sk;
                                 var10000 = var8;
                                 var10001 = 3;
                              } else {
                                 var167 = 3678080 ^ var161 ^ var21 << 6 ^ var151 << 12 ^ var146 << 18;
                                 if (var167 > 1114111) {
                                    var15 = '�';
                                    boolean var114 = false;
                                    boolean var32 = false;
                                    int var57 = var3++;
                                    if (var57 == var1) {
                                       return var2;
                                    }

                                    if (var15 != '\n' && var15 != '\r') {
                                       var57 = 0;
                                       if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                          return -1;
                                       }
                                    }

                                    if (var15 == '�') {
                                       return -1;
                                    }

                                    var2 += var15 < 65536 ? 1 : 2;
                                    eE var131 = eE.sk;
                                    var10000 = var8;
                                 } else if (55296 <= var167 ? var167 < 57344 : false) {
                                    var15 = '�';
                                    boolean var115 = false;
                                    boolean var33 = false;
                                    int var59 = var3++;
                                    if (var59 == var1) {
                                       return var2;
                                    }

                                    if (var15 != '\n' && var15 != '\r') {
                                       var59 = 0;
                                       if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                          return -1;
                                       }
                                    }

                                    if (var15 == '�') {
                                       return -1;
                                    }

                                    var2 += var15 < 65536 ? 1 : 2;
                                    eE var132 = eE.sk;
                                    var10000 = var8;
                                 } else if (var167 < 65536) {
                                    var15 = '�';
                                    boolean var116 = false;
                                    boolean var34 = false;
                                    int var61 = var3++;
                                    if (var61 == var1) {
                                       return var2;
                                    }

                                    if (var15 != '\n' && var15 != '\r') {
                                       var61 = 0;
                                       if ((0 <= var15 ? var15 < ' ' : false) || (127 <= var15 ? var15 < 160 : false)) {
                                          return -1;
                                       }
                                    }

                                    if (var15 == '�') {
                                       return -1;
                                    }

                                    var2 += var15 < 65536 ? 1 : 2;
                                    eE var133 = eE.sk;
                                    var10000 = var8;
                                 } else {
                                    boolean var117 = false;
                                    boolean var35 = false;
                                    int var63 = var3++;
                                    if (var63 == var1) {
                                       return var2;
                                    }

                                    if (var167 != 10 && var167 != 13) {
                                       var63 = 0;
                                       if ((0 <= var167 ? var167 < 32 : false) || (127 <= var167 ? var167 < 160 : false)) {
                                          return -1;
                                       }
                                    }

                                    if (var167 == 65533) {
                                       return -1;
                                    }

                                    var2 += var167 < 65536 ? 1 : 2;
                                    eE var134 = eE.sk;
                                    var10000 = var8;
                                 }

                                 var10001 = 4;
                              }
                           }
                        }
                     }

                     var8 = var10000 + var10001;
                  } else {
                     char var10 = '�';
                     boolean var11 = false;
                     int var12 = var3++;
                     if (var12 == var1) {
                        return var2;
                     }

                     if (var10 != '\n' && var10 != '\r') {
                        var12 = 0;
                        if ((0 <= var10 ? var10 < ' ' : false) || (127 <= var10 ? var10 < 160 : false)) {
                           return -1;
                        }
                     }

                     if (var10 == '�') {
                        return -1;
                     }

                     var2 += var10 < 65536 ? 1 : 2;
                     ++var8;
                  }
               }
            }
         }
      }

      return var2;
   }

   // $FF: synthetic method
   public static final int f(char var0) {
      return e(var0);
   }

   // $FF: synthetic method
   public static final int c(byte[] var0, int var1) {
      return b(var0, var1);
   }

   static {
      char[] var0 = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
      qG = var0;
   }
}
