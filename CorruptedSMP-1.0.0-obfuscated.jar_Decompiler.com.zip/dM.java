import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public class dM implements Listener {
   private final CorruptedSMPPlugin rc;
   private final Map<UUID, Integer> rd = new HashMap();
   private final Map<UUID, Long> re = new HashMap();
   private final Map<UUID, Long> rf = new HashMap();

   public dM(CorruptedSMPPlugin var1) {
      this.rc = var1;
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      HumanEntity var3 = var1.getWhoClicked();
      if (var3 instanceof Player var2) {
         String var4 = var1.getView().getTitle();
         if (var4.equals("§d§lCLOWN TRAP!")) {
            var1.setCancelled(true);
            var2.playSound(var2.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5F, 1.5F);
         }

      }
   }

   @EventHandler
   public void a(InventoryDragEvent var1) {
      HumanEntity var3 = var1.getWhoClicked();
      if (var3 instanceof Player var2) {
         String var4 = var1.getView().getTitle();
         if (var4.equals("§d§lCLOWN TRAP!")) {
            var1.setCancelled(true);
            var2.playSound(var2.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5F, 1.5F);
         }

      }
   }

   @EventHandler
   public void a(EntityExplodeEvent var1) {
      for(Entity var3 : var1.getLocation().getWorld().getNearbyEntities(var1.getLocation(), (double)5.0F, (double)5.0F, (double)5.0F)) {
         if (var3 instanceof Player var4) {
            if (this.rc.d().b(var4) && this.rc.d().c(var4) == l.t) {
               var4.setMetadata("clown_charged", new FixedMetadataValue(this.rc, true));
               var4.sendMessage("§d§lCHARGED! §7Your next attack is empowered!");
            }
         }
      }

   }

   @EventHandler
   public void c(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         if (this.rc.d().b(var2)) {
            if (this.rc.d().c(var2) == l.t) {
               if (var2.hasMetadata("clown_charged")) {
                  var1.setDamage(var1.getDamage() * (double)1.5F);
                  var2.removeMetadata("clown_charged", this.rc);
                  var2.getWorld().spawnParticle(Particle.EXPLOSION, var1.getEntity().getLocation(), 5);
               }

               if (var2.hasMetadata("clown_ability_active") && var2.isSneaking()) {
                  Entity var4 = var1.getEntity();
                  if (var4 instanceof Player) {
                     Player var5 = (Player)var4;
                     h.c(var5, this.rc);
                  }
               }

            }
         }
      }
   }

   @EventHandler
   public void a(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.rc.d().b(var2)) {
         if (this.rc.d().c(var2) == l.t) {
            if (var2.hasMetadata("clown_ability_active")) {
               if (var1.getAction().toString().contains("LEFT_CLICK")) {
                  Location var3 = var2.getEyeLocation();
                  Vector var4 = var3.getDirection();
                  RayTraceResult var5 = var2.getWorld().rayTraceEntities(var3, var4, (double)10.0F, (double)0.5F, (var1x) -> var1x instanceof LivingEntity && !var1x.equals(var2));
                  if (var5 != null && var5.getHitEntity() != null) {
                     LivingEntity var6 = (LivingEntity)var5.getHitEntity();
                     var6.damage(var2.getInventory().getItemInMainHand().getType().toString().contains("SWORD") ? (double)7.0F : (double)1.0F, var2);
                     var6.getWorld().spawnParticle(Particle.CRIT, var6.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, (double)0.5F, 0.3, 0.1);
                     if (var2.isSneaking() && var6 instanceof Player) {
                        Player var7 = (Player)var6;
                        h.c(var7, this.rc);
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler
   public void a(ProjectileHitEvent var1) {
      ProjectileSource var3 = var1.getEntity().getShooter();
      if (var3 instanceof Player var2) {
         if (var1.getHitEntity() != null) {
            if (this.rc.d().b(var2)) {
               if (this.rc.d().c(var2) == l.t) {
                  Vector var5 = var2.getLocation().toVector().subtract(var1.getHitEntity().getLocation().toVector()).normalize();
                  Vector var4 = var5.multiply((double)3.0F).setY((double)0.5F);
                  var1.getHitEntity().setVelocity(var4);
                  var1.getHitEntity().getWorld().spawnParticle(Particle.CLOUD, var1.getHitEntity().getLocation(), 10, 0.3, 0.3, 0.3, 0.1);
               }
            }
         }
      }
   }

   @EventHandler
   public void b(ProjectileHitEvent var1) {
      if (var1.getEntity() instanceof Egg) {
         ProjectileSource var3 = var1.getEntity().getShooter();
         if (var3 instanceof Player) {
            Player var2 = (Player)var3;
            if (this.rc.d().b(var2)) {
               if (this.rc.d().c(var2) == l.t) {
                  UUID var8 = var2.getUniqueId();
                  long var4 = System.currentTimeMillis();
                  if (this.rf.containsKey(var8)) {
                     long var6 = (Long)this.rf.get(var8);
                     if (var4 < var6) {
                        return;
                     }
                  }

                  this.rf.put(var8, var4 + 10000L);
                  Location var9 = var1.getEntity().getLocation();
                  var9.getWorld().createExplosion(var9, 1.5F, false, false);
               }
            }
         }
      }
   }

   @EventHandler
   public void a(PlayerDropItemEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.rc.d().b(var2)) {
         if (this.rc.d().c(var2) == l.t) {
            if (var2.isSneaking()) {
               UUID var3 = var2.getUniqueId();
               long var4 = System.currentTimeMillis();
               if (this.re.containsKey(var3)) {
                  long var6 = (Long)this.re.get(var3);
                  if (var4 < var6) {
                     return;
                  }
               }

               this.re.put(var3, var4 + 10000L);
               final Item var10 = var1.getItemDrop();
               UUID var7 = var10.getUniqueId();
               var2.sendMessage("§d§l✓ Trap item activated! §7(Shift+Q)");
               Vector var8 = var2.getEyeLocation().getDirection().multiply(1.2);
               var10.setVelocity(var8);
               Bukkit.getScheduler().runTaskTimer(this.rc, new Runnable(this) {
                  int particleTicks = 0;

                  public void run() {
                     if (var10.isValid() && !var10.isDead() && this.particleTicks <= 100) {
                        var10.getWorld().spawnParticle(Particle.WITCH, var10.getLocation(), 2, 0.1, 0.1, 0.1, 0.01);
                        ++this.particleTicks;
                     }
                  }
               }, 0L, 2L);
               int var9 = Bukkit.getScheduler().runTaskTimer(this.rc, () -> {
                  if (var10.isValid() && !var10.isDead()) {
                     Location var4 = var10.getLocation();
                     double var5 = var10.isOnGround() ? (double)2.5F : (double)1.5F;

                     for(Entity var8 : var4.getWorld().getNearbyEntities(var4, var5, var5, var5)) {
                        if (var8 instanceof Player) {
                           Player var9 = (Player)var8;
                           if (!var9.equals(var2)) {
                              var9.damage((double)4.0F);
                              var9.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 5, false, true));
                              var9.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1, false, true));
                              var4.getWorld().spawnParticle(Particle.EXPLOSION, var4, 10, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                              var4.getWorld().spawnParticle(Particle.WITCH, var4, 30, (double)1.0F, (double)1.0F, (double)1.0F, 0.2);
                              var4.getWorld().playSound(var4, Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 1.5F);
                              var9.sendMessage("§d§l✗ Hit by Clown's trap item!");
                              var2.sendMessage("§d§l✓ Your trap hit " + var9.getName() + "!");
                              var10.remove();
                              this.i(var7);
                              return;
                           }
                        }
                     }

                  } else {
                     this.i(var7);
                  }
               }, 0L, 2L).getTaskId();
               this.rd.put(var7, var9);
               Bukkit.getScheduler().runTaskLater(this.rc, () -> {
                  if (var10.isValid() && !var10.isDead()) {
                     var10.remove();
                  }

                  this.i(var7);
               }, 600L);
            }
         }
      }
   }

   private void i(UUID var1) {
      if (this.rd.containsKey(var1)) {
         Bukkit.getScheduler().cancelTask((Integer)this.rd.get(var1));
         this.rd.remove(var1);
      }

   }
}
