import java.io.Serializable;

public final class ez<A, B> implements Serializable {
   private final A se;
   private final B sf;

   public ez(A var1, B var2) {
      this.se = var1;
      this.sf = var2;
   }

   public final A ne() {
      return this.se;
   }

   public final B nf() {
      return this.sf;
   }

   public String toString() {
      return "" + '(' + this.se + ", " + this.sf + ')';
   }

   public final A ng() {
      return this.se;
   }

   public final B nh() {
      return this.sf;
   }

   public int hashCode() {
      int var1 = this.se == null ? 0 : this.se.hashCode();
      var1 = var1 * 31 + (this.sf == null ? 0 : this.sf.hashCode());
      return var1;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof ez)) {
         return false;
      } else {
         ez var2 = (ez)var1;
         if (!fR.c(this.se, var2.se)) {
            return false;
         } else {
            return fR.c(this.sf, var2.sf);
         }
      }
   }
}
