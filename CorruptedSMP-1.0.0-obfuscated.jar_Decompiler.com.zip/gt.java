import java.util.Iterator;

public final class gt<T, R> implements gm<R> {
   private final gm<T> ti;
   private final fK<T, R> tj;

   public gt(gm<? extends T> var1, fK<? super T, ? extends R> var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.ti = var1;
      this.tj = var2;
   }

   public Iterator<R> iterator() {
      return (Iterator)(new fY() {
         private final Iterator<T> tk;

         {
            this.tk = gt.this.ti.iterator();
         }

         public R next() {
            return gt.this.tj.invoke(this.tk.next());
         }

         public boolean hasNext() {
            return this.tk.hasNext();
         }

         public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
         }
      });
   }
}
