public interface ad {
   <T> ac<T> a(K var1, aS<T> var2);
}
