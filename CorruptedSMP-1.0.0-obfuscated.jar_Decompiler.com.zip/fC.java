public abstract class fC extends fB implements fQ<Object> {
   private final int arity;

   public String toString() {
      String var10000;
      if (this.nu() == null) {
         var10000 = fU.a(this);
         fR.b(var10000, "");
      } else {
         var10000 = super.toString();
      }

      return var10000;
   }
}
