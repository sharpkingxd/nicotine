class gi extends gh {
   public static final gd k(int var0, int var1) {
      return gd.sU.j(var0, var1, -1);
   }

   public static final gd a(gd var0, int var1) {
      fR.c(var0, (String)"");
      gg.a(var1 > 0, (Number)var1);
      return gd.sU.j(var0.nC(), var0.nD(), var0.nE() > 0 ? var1 : -var1);
   }

   public static final gf l(int var0, int var1) {
      return var1 <= Integer.MIN_VALUE ? gf.tc.nJ() : new gf(var0, var1 - 1);
   }

   public static final int m(int var0, int var1) {
      return var0 < var1 ? var1 : var0;
   }

   public static final int n(int var0, int var1) {
      return var0 > var1 ? var1 : var0;
   }

   public static final int k(int var0, int var1, int var2) {
      if (var1 > var2) {
         throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + var2 + " is less than minimum " + var1 + '.');
      } else if (var0 < var1) {
         return var1;
      } else {
         return var0 > var2 ? var2 : var0;
      }
   }
}
