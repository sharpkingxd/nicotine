import java.io.IOException;

public final class aF extends ac<Number> {
   private static final ad bW;
   private final ab bX;

   private aF(ab var1) {
      this.bX = var1;
   }

   private static ad a(ab var0) {
      final aF var1 = new aF(var0);
      return new ad() {
         public <T> ac<T> a(K var1x, aS<T> var2) {
            return var2.bk() == Number.class ? var1 : null;
         }
      };
   }

   public static ad b(ab var0) {
      return var0 == aa.LAZILY_PARSED_NUMBER ? bW : a(var0);
   }

   public Number d(aT var1) throws IOException {
      aU var2 = var1.aI();
      switch (var2) {
         case dY:
            var1.aO();
            return null;
         case dW:
         case dV:
            return this.bX.h(var1);
         default:
            throw new X("Expecting number, got: " + var2 + "; at path " + var1.aW());
      }
   }

   public void a(aV var1, Number var2) throws IOException {
      var1.a(var2);
   }

   // $FF: synthetic method
   public Object b(aT var1) throws IOException {
      return this.d(var1);
   }

   static {
      bW = a(aa.LAZILY_PARSED_NUMBER);
   }
}
