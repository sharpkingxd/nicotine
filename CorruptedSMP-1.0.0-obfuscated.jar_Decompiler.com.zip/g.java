import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class g {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      var0.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 1, false, false));
   }
}
