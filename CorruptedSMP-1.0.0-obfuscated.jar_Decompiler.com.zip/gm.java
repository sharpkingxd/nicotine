import java.util.Iterator;

public interface gm<T> {
   Iterator<T> iterator();
}
