import java.lang.reflect.Field;

public interface J {
   String a(Field var1);
}
