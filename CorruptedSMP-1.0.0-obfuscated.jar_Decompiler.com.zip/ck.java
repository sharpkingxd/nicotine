import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;

public final class ck implements cb {
   public static final d mo = new d((fP)null);
   private final bu mp;
   private final bT mq;
   private final dg mr;
   private final df ms;
   private int mt;
   private final cj mu;
   private bq trailers;

   public ck(bu var1, bT var2, dg var3, df var4) {
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      super();
      this.mp = var1;
      this.mq = var2;
      this.mr = var3;
      this.ms = var4;
      this.mu = new cj(this.mr);
   }

   public bT gU() {
      return this.mq;
   }

   private final boolean o(by var1) {
      return gA.a("chunked", by.a(var1, "Transfer-Encoding", (String)null, 2, (Object)null), true);
   }

   private final boolean h(bw var1) {
      return gA.a("chunked", var1.ah("Transfer-Encoding"), true);
   }

   public dy a(bw var1, long var2) {
      fR.c(var1, (String)"");
      if (var1.eL() != null && var1.eL().eR()) {
         throw new ProtocolException("Duplex connections are not supported for HTTP/1");
      } else {
         dy var10000;
         if (this.h(var1)) {
            var10000 = this.hO();
         } else {
            if (var2 == -1L) {
               throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
            }

            var10000 = this.hP();
         }

         return var10000;
      }
   }

   public void gM() {
      this.gU().hs();
   }

   public void g(bw var1) {
      fR.c(var1, (String)"");
      cg var10000 = cg.me;
      Proxy.Type var10002 = this.gU().hr().fp().type();
      fR.b(var10002, "");
      String var2 = var10000.a(var1, var10002);
      this.b(var1.eK(), var2);
   }

   public long l(by var1) {
      fR.c(var1, (String)"");
      return !cc.n(var1) ? 0L : (this.o(var1) ? -1L : bD.h(var1));
   }

   public dA m(by var1) {
      fR.c(var1, (String)"");
      dA var10000;
      if (!cc.n(var1)) {
         var10000 = this.k(0L);
      } else if (this.o(var1)) {
         var10000 = this.h(var1.eT().eI());
      } else {
         long var2 = bD.h(var1);
         var10000 = var2 != -1L ? this.k(var2) : this.hQ();
      }

      return var10000;
   }

   public void gI() {
      this.ms.flush();
   }

   public void gJ() {
      this.ms.flush();
   }

   public final void b(bq var1, String var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      if (this.mt != 0) {
         boolean var5 = false;
         String var6 = "state: " + this.mt;
         throw new IllegalStateException(var6.toString());
      } else {
         this.ms.aR(var2).aR("\r\n");
         int var3 = 0;

         for(int var4 = var1.cT(); var3 < var4; ++var3) {
            this.ms.aR(var1.j(var3)).aR(": ").aR(var1.k(var3)).aR("\r\n");
         }

         this.ms.aR("\r\n");
         this.mt = 1;
      }
   }

   public by.a r(boolean var1) {
      if (this.mt != 1 && this.mt != 2 && this.mt != 3) {
         boolean var7 = false;
         String var8 = "state: " + this.mt;
         throw new IllegalStateException(var8.toString());
      } else {
         try {
            ci var2 = ci.mh.aE(this.mu.hM());
            by.a var6 = (new by.a()).b(var2.mi).n(var2.mj).al(var2.mk).d(this.mu.hN());
            by.a var10000;
            if (var1 && var2.mj == 100) {
               var10000 = null;
            } else if (var2.mj == 100) {
               this.mt = 3;
               var10000 = var6;
            } else {
               int var4 = var2.mj;
               if (102 <= var4 ? var4 < 200 : false) {
                  this.mt = 3;
                  var10000 = var6;
               } else {
                  this.mt = 4;
                  var10000 = var6;
               }
            }

            return var10000;
         } catch (EOFException var5) {
            String var3 = this.gU().hr().fo().bK().dk();
            throw new IOException("unexpected end of stream on " + var3, (Throwable)var5);
         }
      }
   }

   private final dy hO() {
      if (this.mt != 1) {
         boolean var1 = false;
         String var2 = "state: " + this.mt;
         throw new IllegalStateException(var2.toString());
      } else {
         this.mt = 2;
         return new b();
      }
   }

   private final dy hP() {
      if (this.mt != 1) {
         boolean var1 = false;
         String var2 = "state: " + this.mt;
         throw new IllegalStateException(var2.toString());
      } else {
         this.mt = 2;
         return new f();
      }
   }

   private final dA k(long var1) {
      if (this.mt != 4) {
         boolean var3 = false;
         String var4 = "state: " + this.mt;
         throw new IllegalStateException(var4.toString());
      } else {
         this.mt = 5;
         return new e(var1);
      }
   }

   private final dA h(br var1) {
      if (this.mt != 4) {
         boolean var2 = false;
         String var3 = "state: " + this.mt;
         throw new IllegalStateException(var3.toString());
      } else {
         this.mt = 5;
         return new c(var1);
      }
   }

   private final dA hQ() {
      if (this.mt != 4) {
         boolean var1 = false;
         String var2 = "state: " + this.mt;
         throw new IllegalStateException(var2.toString());
      } else {
         this.mt = 5;
         this.gU().hn();
         return new g();
      }
   }

   private final void a(dk var1) {
      dB var2 = var1.lr();
      var1.a(dB.NONE);
      var2.lw();
      var2.lv();
   }

   public final void p(by var1) {
      fR.c(var1, (String)"");
      long var2 = bD.h(var1);
      if (var2 != -1L) {
         dA var4 = this.k(var2);
         bD.a(var4, Integer.MAX_VALUE, TimeUnit.MILLISECONDS);
         var4.close();
      }
   }

   abstract class a implements dA {
      private final dk timeout;
      private boolean closed;

      public a() {
         this.timeout = new dk(ck.this.mr.fu());
      }

      protected final boolean hR() {
         return this.closed;
      }

      protected final void v(boolean var1) {
         this.closed = var1;
      }

      public dB fu() {
         return this.timeout;
      }

      public long a(de var1, long var2) {
         fR.c(var1, (String)"");

         try {
            long var4 = ck.this.mr.a(var1, var2);
            return var4;
         } catch (IOException var7) {
            ck.this.gU().hn();
            this.hS();
            throw var7;
         }
      }

      public final void hS() {
         if (ck.this.mt != 6) {
            if (ck.this.mt != 5) {
               throw new IllegalStateException("state: " + ck.this.mt);
            } else {
               ck.this.a(this.timeout);
               ck.this.mt = 6;
            }
         }
      }
   }

   final class b implements dy {
      private final dk timeout;
      private boolean closed;

      public b() {
         this.timeout = new dk(ck.this.ms.fu());
      }

      public dB fu() {
         return this.timeout;
      }

      public void b(de var1, long var2) {
         fR.c(var1, (String)"");
         if (this.closed) {
            boolean var4 = false;
            String var5 = "closed";
            throw new IllegalStateException(var5.toString());
         } else if (var2 != 0L) {
            ck.this.ms.E(var2);
            ck.this.ms.aR("\r\n");
            ck.this.ms.b(var1, var2);
            ck.this.ms.aR("\r\n");
         }
      }

      public synchronized void flush() {
         if (!this.closed) {
            ck.this.ms.flush();
         }
      }

      public synchronized void close() {
         if (!this.closed) {
            this.closed = true;
            ck.this.ms.aR("0\r\n\r\n");
            ck.this.a(this.timeout);
            ck.this.mt = 3;
         }
      }
   }

   final class c extends a {
      private final br url;
      private long bytesRemainingInChunk;
      private boolean hasMoreChunks;

      public c(br var2) {
         fR.c(var2, (String)"");
         super();
         this.url = var2;
         this.bytesRemainingInChunk = -1L;
         this.hasMoreChunks = true;
      }

      public long a(de var1, long var2) {
         fR.c(var1, (String)"");
         if (var2 < 0L) {
            boolean var8 = false;
            String var9 = "byteCount < 0: " + var2;
            throw new IllegalArgumentException(var9.toString());
         } else if (this.hR()) {
            boolean var5 = false;
            String var7 = "closed";
            throw new IllegalStateException(var7.toString());
         } else if (!this.hasMoreChunks) {
            return -1L;
         } else {
            if (this.bytesRemainingInChunk == 0L || this.bytesRemainingInChunk == -1L) {
               this.hT();
               if (!this.hasMoreChunks) {
                  return -1L;
               }
            }

            long var4 = super.a(var1, Math.min(var2, this.bytesRemainingInChunk));
            if (var4 == -1L) {
               ck.this.gU().hn();
               ProtocolException var6 = new ProtocolException("unexpected end of stream");
               this.hS();
               throw var6;
            } else {
               this.bytesRemainingInChunk -= var4;
               return var4;
            }
         }
      }

      private final void hT() {
         if (this.bytesRemainingInChunk != -1L) {
            ck.this.mr.kV();
         }

         try {
            this.bytesRemainingInChunk = ck.this.mr.kT();
            String var1 = gA.c((CharSequence)ck.this.mr.kV()).toString();
            if (this.bytesRemainingInChunk < 0L || ((CharSequence)var1).length() > 0 && !gA.a(var1, ";", false, 2, (Object)null)) {
               throw new ProtocolException("expected chunk size and optional extensions but was \"" + this.bytesRemainingInChunk + var1 + '"');
            }
         } catch (NumberFormatException var2) {
            throw new ProtocolException(var2.getMessage());
         }

         if (this.bytesRemainingInChunk == 0L) {
            this.hasMoreChunks = false;
            ck.this.trailers = ck.this.mu.hN();
            bu var10000 = ck.this.mp;
            fR.m(var10000);
            bk var3 = var10000.dF();
            br var10001 = this.url;
            bq var10002 = ck.this.trailers;
            fR.m(var10002);
            cc.a(var3, var10001, var10002);
            this.hS();
         }

      }

      public void close() {
         if (!this.hR()) {
            if (this.hasMoreChunks && !bD.b(this, 100, TimeUnit.MILLISECONDS)) {
               ck.this.gU().hn();
               this.hS();
            }

            this.v(true);
         }
      }
   }

   public static final class d {
      private d() {
      }

      // $FF: synthetic method
      public d(fP var1) {
         this();
      }
   }

   final class e extends a {
      private long bytesRemaining;

      public e(long var2) {
         this.bytesRemaining = var2;
         if (this.bytesRemaining == 0L) {
            this.hS();
         }

      }

      public long a(de var1, long var2) {
         fR.c(var1, (String)"");
         if (var2 < 0L) {
            boolean var8 = false;
            String var9 = "byteCount < 0: " + var2;
            throw new IllegalArgumentException(var9.toString());
         } else if (this.hR()) {
            boolean var5 = false;
            String var7 = "closed";
            throw new IllegalStateException(var7.toString());
         } else if (this.bytesRemaining == 0L) {
            return -1L;
         } else {
            long var4 = super.a(var1, Math.min(this.bytesRemaining, var2));
            if (var4 == -1L) {
               ck.this.gU().hn();
               ProtocolException var6 = new ProtocolException("unexpected end of stream");
               this.hS();
               throw var6;
            } else {
               this.bytesRemaining -= var4;
               if (this.bytesRemaining == 0L) {
                  this.hS();
               }

               return var4;
            }
         }
      }

      public void close() {
         if (!this.hR()) {
            if (this.bytesRemaining != 0L && !bD.b(this, 100, TimeUnit.MILLISECONDS)) {
               ck.this.gU().hn();
               this.hS();
            }

            this.v(true);
         }
      }
   }

   final class f implements dy {
      private final dk timeout;
      private boolean closed;

      public f() {
         this.timeout = new dk(ck.this.ms.fu());
      }

      public dB fu() {
         return this.timeout;
      }

      public void b(de var1, long var2) {
         fR.c(var1, (String)"");
         if (this.closed) {
            boolean var4 = false;
            String var5 = "closed";
            throw new IllegalStateException(var5.toString());
         } else {
            bD.a(var1.kH(), 0L, var2);
            ck.this.ms.b(var1, var2);
         }
      }

      public void flush() {
         if (!this.closed) {
            ck.this.ms.flush();
         }
      }

      public void close() {
         if (!this.closed) {
            this.closed = true;
            ck.this.a(this.timeout);
            ck.this.mt = 3;
         }
      }
   }

   final class g extends a {
      private boolean inputExhausted;

      public g() {
      }

      public long a(de var1, long var2) {
         fR.c(var1, (String)"");
         if (var2 < 0L) {
            boolean var7 = false;
            String var8 = "byteCount < 0: " + var2;
            throw new IllegalArgumentException(var8.toString());
         } else if (this.hR()) {
            boolean var5 = false;
            String var6 = "closed";
            throw new IllegalStateException(var6.toString());
         } else if (this.inputExhausted) {
            return -1L;
         } else {
            long var4 = super.a(var1, var2);
            if (var4 == -1L) {
               this.inputExhausted = true;
               this.hS();
               return -1L;
            } else {
               return var4;
            }
         }
      }

      public void close() {
         if (!this.hR()) {
            if (!this.inputExhausted) {
               this.hS();
            }

            this.v(true);
         }
      }
   }
}
