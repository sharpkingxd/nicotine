import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;

public class cF extends cH {
   public static final a oP = new a((fP)null);
   private static final boolean oQ;

   public void a(SSLSocket var1, String var2, List<bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      SSLParameters var4 = var1.getSSLParameters();
      List var5 = cH.oU.h(var3);
      Collection var6 = (Collection)var5;
      boolean var7 = false;
      var4.setApplicationProtocols((String[])var6.toArray(new String[0]));
      var1.setSSLParameters(var4);
   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");

      try {
         String var2 = var1.getApplicationProtocol();
         return (var2 == null ? true : fR.c(var2, (Object)"")) ? null : var2;
      } catch (UnsupportedOperationException var3) {
         return null;
      }
   }

   static {
      String var0 = System.getProperty("java.specification.version");
      Integer var1 = var0 != null ? gA.bj(var0) : null;
      boolean var10000;
      if (var1 != null) {
         var10000 = var1 >= 9;
      } else {
         boolean var2;
         try {
            SSLSocket.class.getMethod("getApplicationProtocol");
            var2 = true;
         } catch (NoSuchMethodException var4) {
            var2 = false;
         }

         var10000 = var2;
      }

      oQ = var10000;
   }

   public static final class a {
      private a() {
      }

      public final boolean jS() {
         return cF.oQ;
      }

      public final cF jT() {
         return this.jS() ? new cF() : null;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
