import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.Objects;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

public class h {
   private static final NamespacedKey p = new NamespacedKey("corruptedsmp", "clown_reach");

   public static boolean a(Player var0, CorruptedSMPPlugin var1) {
      int var2 = var1.getConfig().getInt("corruptions.clown.ability-duration", 15);
      var0.setMetadata("clown_ability_active", new FixedMetadataValue(var1, true));

      try {
         AttributeInstance var3 = var0.getAttribute(Attribute.PLAYER_ENTITY_INTERACTION_RANGE);
         if (var3 != null) {
            Stream var10000 = var3.getModifiers().stream().filter((var0x) -> var0x.getKey().equals(p));
            Objects.requireNonNull(var3);
            var10000.forEach(var3::removeModifier);
            AttributeModifier var4 = new AttributeModifier(p, (double)7.0F, Operation.ADD_NUMBER, EquipmentSlotGroup.ANY);
            var3.addModifier(var4);
         }

         AttributeInstance var7 = var0.getAttribute(Attribute.PLAYER_BLOCK_INTERACTION_RANGE);
         if (var7 != null) {
            Stream var8 = var7.getModifiers().stream().filter((var0x) -> var0x.getKey().equals(p));
            Objects.requireNonNull(var7);
            var8.forEach(var7::removeModifier);
            AttributeModifier var5 = new AttributeModifier(p, (double)7.0F, Operation.ADD_NUMBER, EquipmentSlotGroup.ANY);
            var7.addModifier(var5);
         }

         var0.sendMessage("§d§l✓ Clown's Bracelet activated! §710-block reach enabled!");
      } catch (Exception var6) {
         var0.setMetadata("clown_reach_boost", new FixedMetadataValue(var1, (double)10.0F));
         var0.sendMessage("§d§l✓ Clown's Bracelet activated! §7(Using fallback reach system)");
         var6.printStackTrace();
      }

      Bukkit.getScheduler().runTaskLater(var1, () -> {
         var0.removeMetadata("clown_ability_active", var1);
         var0.removeMetadata("clown_reach_boost", var1);

         try {
            AttributeInstance var2 = var0.getAttribute(Attribute.PLAYER_ENTITY_INTERACTION_RANGE);
            if (var2 != null) {
               Stream var10000 = var2.getModifiers().stream().filter((var0x) -> var0x.getKey().equals(p));
               Objects.requireNonNull(var2);
               var10000.forEach(var2::removeModifier);
            }

            AttributeInstance var3 = var0.getAttribute(Attribute.PLAYER_BLOCK_INTERACTION_RANGE);
            if (var3 != null) {
               Stream var5 = var3.getModifiers().stream().filter((var0x) -> var0x.getKey().equals(p));
               Objects.requireNonNull(var3);
               var5.forEach(var3::removeModifier);
            }
         } catch (Exception var4) {
         }

         var0.sendMessage("§d§lClown's Bracelet ended!");
      }, (long)var2 * 20L);
      var0.playSound(var0.getLocation(), "custom:clown", 2.0F, 1.0F);
      var0.playSound(var0.getLocation(), Sound.ENTITY_VILLAGER_CELEBRATE, 1.0F, 0.8F);
      var0.playSound(var0.getLocation(), Sound.ENTITY_CHICKEN_EGG, 1.0F, 1.5F);
      var0.playSound(var0.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0F, 2.0F);
      return true;
   }

   public static void c(Player var0, CorruptedSMPPlugin var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 27, "§d§lCLOWN TRAP!");
      Material[] var3 = new Material[]{Material.TNT, Material.BARRIER, Material.BEDROCK, Material.COMMAND_BLOCK};

      for(int var4 = 0; var4 < 27; ++var4) {
         var2.setItem(var4, new ItemStack(var3[(int)(Math.random() * (double)var3.length)]));
      }

      var0.openInventory(var2);
      var0.playSound(var0.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0F, 0.5F);
      Bukkit.getScheduler().runTaskLater(var1, () -> {
         if (var0.getOpenInventory().getTopInventory().equals(var2)) {
            var0.closeInventory();
         }

      }, 60L);
   }
}
