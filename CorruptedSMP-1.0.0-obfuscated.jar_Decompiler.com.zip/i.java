import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;

public class i {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      if (var0.getAbsorptionAmount() > (double)0.0F) {
         var0.setAbsorptionAmount((double)0.0F);
      }

   }
}
