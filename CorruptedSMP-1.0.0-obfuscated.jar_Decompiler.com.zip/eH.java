import java.util.Collection;
import java.util.Iterator;

final class eH<T> implements fY, Collection<T> {
   private final T[] ss;
   private final boolean st;

   public eH(T[] var1, boolean var2) {
      fR.c(var1, (String)"");
      super();
      this.ss = (T[])var1;
      this.st = var2;
   }

   public int getSize() {
      return this.ss.length;
   }

   public boolean isEmpty() {
      return this.ss.length == 0;
   }

   public boolean contains(Object var1) {
      return eI.b(this.ss, var1);
   }

   public boolean containsAll(Collection<? extends Object> var1) {
      fR.c(var1, (String)"");
      Iterable var2 = (Iterable)var1;
      boolean var3 = false;
      boolean var10000;
      if (((Collection)var2).isEmpty()) {
         var10000 = true;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = true;
               break;
            }

            Object var5 = var4.next();
            boolean var7 = false;
            if (!this.contains(var5)) {
               var10000 = false;
               break;
            }
         }
      }

      return var10000;
   }

   public Iterator<T> iterator() {
      return fN.<T>m(this.ss);
   }

   public final Object[] toArray() {
      return eO.a(this.ss, this.st);
   }

   public boolean add(T var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(Collection<? extends T> var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void clear() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean remove(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean removeAll(Collection<? extends Object> var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean retainAll(Collection<? extends Object> var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public final int size() {
      return this.getSize();
   }

   public <T> T[] toArray(T[] var1) {
      fR.c(var1, (String)"");
      return (T[])fO.b(this, var1);
   }
}
