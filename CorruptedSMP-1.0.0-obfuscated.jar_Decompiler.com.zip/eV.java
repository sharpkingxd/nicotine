import java.util.Collection;

class eV extends eU {
   public static final <T> boolean a(Collection<? super T> var0, Iterable<? extends T> var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (var1 instanceof Collection) {
         return var0.addAll((Collection)var1);
      } else {
         boolean var2 = false;

         for(Object var4 : var1) {
            if (var0.add(var4)) {
               var2 = true;
            }
         }

         return var2;
      }
   }

   public static final <T> boolean a(Collection<? super T> var0, T[] var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return var0.addAll((Collection)eI.c(var1));
   }
}
