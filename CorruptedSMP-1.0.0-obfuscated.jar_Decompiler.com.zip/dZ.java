import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class dZ implements Listener {
   private final CorruptedSMPPlugin rw;

   public dZ(CorruptedSMPPlugin var1) {
      this.rw = var1;
   }

   @EventHandler
   public void g(EntityDamageEvent var1) {
   }
}
