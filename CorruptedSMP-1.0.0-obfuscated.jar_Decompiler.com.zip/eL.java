import java.util.Arrays;
import java.util.List;

class eL extends eK {
   public static final <T> List<T> c(T[] var0) {
      fR.c(var0, (String)"");
      List var10000 = eN.c(var0);
      fR.b(var10000, "");
      return var10000;
   }

   public static final byte[] a(byte[] var0, byte[] var1, int var2, int var3, int var4) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      System.arraycopy(var0, var3, var1, var2, var4 - var3);
      return var1;
   }

   // $FF: synthetic method
   public static byte[] a(byte[] var0, byte[] var1, int var2, int var3, int var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = 0;
      }

      if ((var5 & 4) != 0) {
         var3 = 0;
      }

      if ((var5 & 8) != 0) {
         var4 = var0.length;
      }

      return eI.a(var0, var1, var2, var3, var4);
   }

   public static final byte[] d(byte[] var0, int var1, int var2) {
      fR.c(var0, (String)"");
      eI.g(var2, var0.length);
      byte[] var10000 = Arrays.copyOfRange(var0, var1, var2);
      fR.b(var10000, "");
      return var10000;
   }

   public static final <T> void a(T[] var0, T var1, int var2, int var3) {
      fR.c(var0, (String)"");
      Arrays.fill(var0, var2, var3, var1);
   }

   // $FF: synthetic method
   public static void a(Object[] var0, Object var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = var0.length;
      }

      eI.a(var0, var1, var2, var3);
   }
}
