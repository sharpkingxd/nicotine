import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class dY implements Listener {
   private final CorruptedSMPPlugin rv;

   public dY(CorruptedSMPPlugin var1) {
      this.rv = var1;
   }

   @EventHandler
   public void c(PlayerItemConsumeEvent var1) {
   }
}
