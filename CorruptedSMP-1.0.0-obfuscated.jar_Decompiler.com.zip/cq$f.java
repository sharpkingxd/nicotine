import java.io.IOException;
import java.util.List;

public final class cq$f extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final int $streamId$inlined;
   // $FF: synthetic field
   final List $requestHeaders$inlined;
   // $FF: synthetic field
   final boolean $inFinished$inlined;

   public cq$f(String var1, boolean var2, cq var3, int var4, List var5, boolean var6) {
      super(var1, var2);
      this.this$0 = var3;
      this.$streamId$inlined = var4;
      this.$requestHeaders$inlined = var5;
      this.$inFinished$inlined = var6;
   }

   public long gg() {
      boolean var1 = false;
      boolean var2 = cq.j(this.this$0).c(this.$streamId$inlined, this.$requestHeaders$inlined, this.$inFinished$inlined);
      boolean var3 = false;

      try {
         boolean var4 = false;
         if (var2) {
            this.this$0.iu().e(this.$streamId$inlined, cm.mF);
         }

         if (var2 || this.$inFinished$inlined) {
            cq var5 = this.this$0;
            synchronized(var5) {
               boolean var6 = false;
               var6 = cq.i(this.this$0).remove(this.$streamId$inlined);
            }
         }
      } catch (IOException var9) {
      }

      return -1L;
   }
}
