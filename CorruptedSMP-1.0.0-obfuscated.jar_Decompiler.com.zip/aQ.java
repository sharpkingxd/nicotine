import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

class aQ extends ac<Timestamp> {
   static final ad du = new ad() {
      public <T> ac<T> a(K var1, aS<T> var2) {
         if (var2.bk() == Timestamp.class) {
            ac var3 = var1.b(Date.class);
            return new aQ(var3);
         } else {
            return null;
         }
      }
   };
   private final ac<Date> dv;

   private aQ(ac<Date> var1) {
      this.dv = var1;
   }

   public Timestamp N(aT var1) throws IOException {
      Date var2 = this.dv.b(var1);
      return var2 != null ? new Timestamp(var2.getTime()) : null;
   }

   public void a(aV var1, Timestamp var2) throws IOException {
      this.dv.a(var1, var2);
   }

   // $FF: synthetic method
   public Object b(aT var1) throws IOException {
      return this.N(var1);
   }
}
