import java.io.Serializable;

public abstract class fw implements fu<Object>, Serializable {
   private final fu<Object> completion;

   public final fu<Object> nu() {
      return this.completion;
   }

   public fu<eE> create(Object var1, fu<?> var2) {
      fR.c(var2, (String)"");
      throw new UnsupportedOperationException("create(Any?;Continuation) has not been overridden");
   }

   public String toString() {
      StringBuilder var10000 = (new StringBuilder()).append("Continuation at ");
      StackTraceElement var10001 = this.nv();
      return var10000.append(var10001 != null ? (Serializable)var10001 : (Serializable)this.getClass().getName()).toString();
   }

   public StackTraceElement nv() {
      return fz.a(this);
   }
}
