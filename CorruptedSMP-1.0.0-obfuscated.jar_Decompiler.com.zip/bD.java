import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public final class bD {
   public static final byte[] jg = new byte[0];
   public static final bq jh;
   public static final bz ji;
   public static final bx jj;
   private static final dr jk;
   public static final TimeZone jl;
   private static final gz jm;
   public static final boolean jn;
   public static final String jo;

   public static final void a(long var0, long var2, long var4) {
      if ((var2 | var4) < 0L || var2 > var0 || var0 - var2 < var4) {
         throw new ArrayIndexOutOfBoundsException();
      }
   }

   public static final ThreadFactory a(String var0, boolean var1) {
      fR.c(var0, (String)"");
      return bD::a;
   }

   public static final String[] a(String[] var0, String[] var1, Comparator<? super String> var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      List var3 = (List)(new ArrayList());
      int var4 = 0;

      for(int var5 = var0.length; var4 < var5; ++var4) {
         String var6 = var0[var4];
         int var7 = 0;

         for(int var8 = var1.length; var7 < var8; ++var7) {
            String var9 = var1[var7];
            if (var2.compare(var6, var9) == 0) {
               var3.add(var6);
               break;
            }
         }
      }

      Collection var10 = (Collection)var3;
      boolean var11 = false;
      return (String[])var10.toArray(new String[0]);
   }

   public static final boolean b(String[] var0, String[] var1, Comparator<? super String> var2) {
      fR.c(var0, (String)"");
      fR.c(var2, (String)"");
      if (var0.length != 0 && var1 != null && var1.length != 0) {
         int var3 = 0;

         for(int var4 = var0.length; var3 < var4; ++var3) {
            String var5 = var0[var3];
            Iterator var6 = fN.m(var1);

            while(var6.hasNext()) {
               String var7 = (String)var6.next();
               if (var2.compare(var5, var7) == 0) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static final String a(br var0, boolean var1) {
      fR.c(var0, (String)"");
      String var2 = gA.c((CharSequence)var0.cY(), (CharSequence)":", false, 2, (Object)null) ? '[' + var0.cY() + ']' : var0.cY();
      return !var1 && var0.cZ() == br.hQ.Y(var0.cX()) ? var2 : var2 + ':' + var0.cZ();
   }

   // $FF: synthetic method
   public static String a(br var0, boolean var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = false;
      }

      return a(var0, var1);
   }

   public static final int a(String[] var0, String var1, Comparator<String> var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      String[] var3 = var0;
      boolean var4 = false;
      int var5 = 0;
      int var6 = var0.length;

      int var10000;
      while(true) {
         if (var5 >= var6) {
            var10000 = -1;
            break;
         }

         String var7 = var3[var5];
         boolean var8 = false;
         if (var2.compare(var7, var1) == 0) {
            var10000 = var5;
            break;
         }

         ++var5;
      }

      return var10000;
   }

   public static final String[] c(String[] var0, String var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      Object[] var10000 = Arrays.copyOf(var0, var0.length + 1);
      fR.b(var10000, "");
      String[] var2 = (String[])var10000;
      var2[eI.f(var2)] = var1;
      return var2;
   }

   public static final int j(String var0, int var1, int var2) {
      fR.c(var0, (String)"");

      for(int var3 = var1; var3 < var2; ++var3) {
         char var4 = var0.charAt(var3);
         if (!((((var4 == '\t' ? true : var4 == '\n') ? true : var4 == '\f') ? true : var4 == '\r') ? true : var4 == ' ')) {
            return var3;
         }
      }

      return var2;
   }

   // $FF: synthetic method
   public static int a(String var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 0;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.length();
      }

      return j(var0, var1, var2);
   }

   public static final int k(String var0, int var1, int var2) {
      fR.c(var0, (String)"");
      int var3 = var2 - 1;
      if (var1 <= var3) {
         while(true) {
            char var4 = var0.charAt(var3);
            if (!((((var4 == '\t' ? true : var4 == '\n') ? true : var4 == '\f') ? true : var4 == '\r') ? true : var4 == ' ')) {
               return var3 + 1;
            }

            if (var3 == var1) {
               break;
            }

            --var3;
         }
      }

      return var1;
   }

   // $FF: synthetic method
   public static int b(String var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 0;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.length();
      }

      return k(var0, var1, var2);
   }

   public static final String l(String var0, int var1, int var2) {
      fR.c(var0, (String)"");
      int var3 = j(var0, var1, var2);
      int var4 = k(var0, var3, var2);
      String var10000 = var0.substring(var3, var4);
      fR.b(var10000, "");
      return var10000;
   }

   // $FF: synthetic method
   public static String c(String var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 0;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.length();
      }

      return l(var0, var1, var2);
   }

   public static final int a(String var0, String var1, int var2, int var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");

      for(int var4 = var2; var4 < var3; ++var4) {
         if (gA.a((CharSequence)var1, var0.charAt(var4), false, 2, (Object)null)) {
            return var4;
         }
      }

      return var3;
   }

   public static final int a(String var0, char var1, int var2, int var3) {
      fR.c(var0, (String)"");

      for(int var4 = var2; var4 < var3; ++var4) {
         if (var0.charAt(var4) == var1) {
            return var4;
         }
      }

      return var3;
   }

   // $FF: synthetic method
   public static int a(String var0, char var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = var0.length();
      }

      return a(var0, var1, var2, var3);
   }

   public static final int ap(String var0) {
      fR.c(var0, (String)"");
      int var1 = 0;

      for(int var2 = var0.length(); var1 < var2; ++var1) {
         char var3 = var0.charAt(var1);
         if (fR.j(var3, 31) <= 0 || fR.j(var3, 127) >= 0) {
            return var1;
         }
      }

      return -1;
   }

   public static final boolean aq(String var0) {
      fR.c(var0, (String)"");
      return jm.a((CharSequence)var0);
   }

   public static final boolean ar(String var0) {
      fR.c(var0, (String)"");
      return gA.a(var0, "Authorization", true) || gA.a(var0, "Cookie", true) || gA.a(var0, "Proxy-Authorization", true) || gA.a(var0, "Set-Cookie", true);
   }

   public static final String a(String var0, Object... var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fW var10000 = fW.sT;
      Locale var2 = Locale.US;
      Object[] var3 = Arrays.copyOf(var1, var1.length);
      String var4 = String.format(var2, var0, Arrays.copyOf(var3, var3.length));
      fR.b(var4, "");
      return var4;
   }

   public static final Charset a(dg var0, Charset var1) throws IOException {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      Charset var10000;
      switch (var0.a(jk)) {
         case -1:
            var10000 = var1;
            break;
         case 0:
            var10000 = StandardCharsets.UTF_8;
            fR.b(var10000, "");
            break;
         case 1:
            var10000 = StandardCharsets.UTF_16BE;
            fR.b(var10000, "");
            break;
         case 2:
            var10000 = StandardCharsets.UTF_16LE;
            fR.b(var10000, "");
            break;
         case 3:
            var10000 = gx.tm.nM();
            break;
         case 4:
            var10000 = gx.tm.nL();
            break;
         default:
            throw new AssertionError();
      }

      return var10000;
   }

   public static final int a(String var0, long var1, TimeUnit var3) {
      fR.c(var0, (String)"");
      if (var1 < 0L) {
         boolean var8 = false;
         String var9 = var0 + " < 0";
         throw new IllegalStateException(var9.toString());
      } else if (var3 == null) {
         boolean var5 = false;
         String var7 = "unit == null";
         throw new IllegalStateException(var7.toString());
      } else {
         long var4 = var3.toMillis(var1);
         if (var4 > 2147483647L) {
            boolean var11 = false;
            String var12 = var0 + " too large.";
            throw new IllegalArgumentException(var12.toString());
         } else if (var4 == 0L && var1 > 0L) {
            boolean var6 = false;
            String var10 = var0 + " too small.";
            throw new IllegalArgumentException(var10.toString());
         } else {
            return (int)var4;
         }
      }
   }

   public static final int d(char var0) {
      return ('0' <= var0 ? var0 < ':' : false) ? var0 - 48 : (('a' <= var0 ? var0 < 'g' : false) ? var0 - 97 + 10 : (('A' <= var0 ? var0 < 'G' : false) ? var0 - 65 + 10 : -1));
   }

   public static final bq a(List<cn> var0) {
      fR.c(var0, (String)"");
      bq.a var1 = new bq.a();

      for(cn var3 : var0) {
         dh var4 = var3.hW();
         dh var5 = var3.hX();
         var1.e(var4.lf(), var5.lf());
      }

      return var1.cW();
   }

   public static final List<cn> e(bq var0) {
      fR.c(var0, (String)"");
      Iterable var1 = gg.l(0, var0.cT());
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList(eO.a(var1, 10)));
      boolean var5 = false;
      Iterator var6 = var1.iterator();

      while(var6.hasNext()) {
         int var7 = ((fd)var6).aR();
         boolean var9 = false;
         var4.add(new cn(var0.j(var7), var0.k(var7)));
      }

      return (List)var4;
   }

   public static final boolean a(br var0, br var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return fR.c(var0.cY(), (Object)var1.cY()) && var0.cZ() == var1.cZ() && fR.c(var0.cX(), (Object)var1.cX());
   }

   public static final bo.c a(bo var0) {
      fR.c(var0, (String)"");
      return bD::a;
   }

   public static final int a(byte var0, int var1) {
      return var0 & var1;
   }

   public static final int a(short var0, int var1) {
      return var0 & var1;
   }

   public static final long a(int var0, long var1) {
      return (long)var0 & var1;
   }

   public static final void a(df var0, int var1) throws IOException {
      fR.c(var0, (String)"");
      var0.aa(var1 >>> 16 & 255);
      var0.aa(var1 >>> 8 & 255);
      var0.aa(var1 & 255);
   }

   public static final int c(dg var0) throws IOException {
      fR.c(var0, (String)"");
      return a((byte)var0.kN(), 255) << 16 | a((byte)var0.kN(), 255) << 8 | a((byte)var0.kN(), 255);
   }

   public static final boolean a(dA var0, int var1, TimeUnit var2) throws IOException {
      fR.c(var0, (String)"");
      fR.c(var2, (String)"");
      long var3 = System.nanoTime();
      long var5 = var0.fu().lt() ? var0.fu().lu() - var3 : Long.MAX_VALUE;
      var0.fu().F(var3 + Math.min(var5, var2.toNanos((long)var1)));

      boolean var7;
      try {
         de var13 = new de();

         while(var0.a(var13, 8192L) != -1L) {
            var13.kX();
         }

         var7 = true;
      } catch (InterruptedIOException var11) {
         var7 = false;
      } finally {
         if (var5 == Long.MAX_VALUE) {
            var0.fu().lw();
         } else {
            var0.fu().F(var3 + var5);
         }

      }

      return var7;
   }

   public static final boolean b(dA var0, int var1, TimeUnit var2) {
      fR.c(var0, (String)"");
      fR.c(var2, (String)"");

      boolean var3;
      try {
         var3 = a(var0, var1, var2);
      } catch (IOException var5) {
         var3 = false;
      }

      return var3;
   }

   public static final boolean a(Socket var0, dg var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");

      int var2;
      try {
         var2 = var0.getSoTimeout();

         boolean var3;
         try {
            var0.setSoTimeout(1);
            var3 = !var1.kK();
         } finally {
            var0.setSoTimeout(var2);
         }

         var2 = var3;
      } catch (SocketTimeoutException var9) {
         var2 = 1;
      } catch (IOException var10) {
         var2 = 0;
      }

      return (boolean)var2;
   }

   public static final int a(de var0, byte var1) {
      fR.c(var0, (String)"");
      int var2 = 0;

      while(!var0.kK() && var0.v(0L) == var1) {
         ++var2;
         var0.kN();
      }

      return var2;
   }

   public static final int c(String var0, int var1) {
      fR.c(var0, (String)"");
      int var2 = var1;

      for(int var3 = var0.length(); var2 < var3; ++var2) {
         char var4 = var0.charAt(var2);
         if (var4 != ' ' && var4 != '\t') {
            return var2;
         }
      }

      return var0.length();
   }

   public static final long h(by var0) {
      fR.c(var0, (String)"");
      String var10000 = var0.eY().E("Content-Length");
      return var10000 != null ? a(var10000, -1L) : -1L;
   }

   public static final long a(String var0, long var1) {
      fR.c(var0, (String)"");

      long var3;
      try {
         var3 = Long.parseLong(var0);
      } catch (NumberFormatException var6) {
         var3 = var1;
      }

      return var3;
   }

   public static final int d(String var0, int var1) {
      try {
         if (var0 != null) {
            long var2 = Long.parseLong(var0);
            return var2 > 2147483647L ? Integer.MAX_VALUE : (var2 < 0L ? 0 : (int)var2);
         } else {
            return var1;
         }
      } catch (NumberFormatException var4) {
         return var1;
      }
   }

   public static final <T> List<T> b(List<? extends T> var0) {
      fR.c(var0, (String)"");
      List var10000 = Collections.unmodifiableList(eO.b((Collection)var0));
      fR.b(var10000, "");
      return var10000;
   }

   @SafeVarargs
   public static final <T> List<T> b(T... var0) {
      fR.c(var0, (String)"");
      Object[] var1 = var0.clone();
      List var10000 = Collections.unmodifiableList(eO.j(Arrays.copyOf(var1, var1.length)));
      fR.b(var10000, "");
      return var10000;
   }

   public static final <K, V> Map<K, V> a(Map<K, ? extends V> var0) {
      fR.c(var0, (String)"");
      Map var10000;
      if (var0.isEmpty()) {
         var10000 = fe.nr();
      } else {
         var10000 = Collections.unmodifiableMap((Map)(new LinkedHashMap(var0)));
         fR.b(var10000, "");
      }

      return var10000;
   }

   public static final void a(Closeable var0) {
      fR.c(var0, (String)"");

      try {
         var0.close();
      } catch (RuntimeException var2) {
         throw var2;
      } catch (Exception var3) {
      }

   }

   public static final void a(Socket var0) {
      fR.c(var0, (String)"");

      try {
         var0.close();
      } catch (AssertionError var2) {
         throw var2;
      } catch (RuntimeException var3) {
         if (fR.c(var3.getMessage(), (Object)"bio == null")) {
            return;
         }

         throw var3;
      } catch (Exception var4) {
      }

   }

   public static final boolean a(cz var0, File var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      Closeable var2 = var0.b(var1);
      Throwable var3 = null;

      try {
         dy var4 = (dy)var2;
         boolean var5 = false;

         try {
            var0.d(var1);
            boolean var7 = true;
            return var7;
         } catch (IOException var11) {
            eE var14 = eE.sk;
         }
      } catch (Throwable var12) {
         var3 = var12;
         throw var12;
      } finally {
         fI.a(var2, var3);
      }

      var0.d(var1);
      return false;
   }

   public static final <E> void a(List<E> var0, E var1) {
      fR.c(var0, (String)"");
      if (!var0.contains(var1)) {
         var0.add(var1);
      }

   }

   public static final Throwable a(Exception var0, List<? extends Exception> var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      Exception var3 = var0;
      boolean var4 = false;

      for(Exception var6 : var1) {
         er.a((Throwable)var3, (Throwable)var6);
      }

      return (Throwable)var0;
   }

   private static final Thread a(String var0, boolean var1, Runnable var2) {
      fR.c(var0, (String)"");
      Thread var3 = new Thread(var2, var0);
      boolean var5 = false;
      var3.setDaemon(var1);
      return var3;
   }

   private static final bo a(bo var0, bb var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return var0;
   }

   static {
      jh = bq.hO.c();
      ji = bz.a.a(bz.Companion, jg, (bt)null, 1, (Object)null);
      jj = bx.a.a(bx.Companion, jg, (bt)null, 0, 0, 7, (Object)null);
      dr.a var10000 = dr.qi;
      dh[] var0 = new dh[]{dh.pS.aW("efbbbf"), dh.pS.aW("feff"), dh.pS.aW("fffe"), dh.pS.aW("0000ffff"), dh.pS.aW("ffff0000")};
      jk = var10000.a(var0);
      TimeZone var1 = TimeZone.getTimeZone("GMT");
      fR.m(var1);
      jl = var1;
      jm = new gz("([0-9a-fA-F]*:[0-9a-fA-F:.]*)|([\\d.]+)");
      jn = bu.class.desiredAssertionStatus();
      String var2 = bu.class.getName();
      fR.b(var2, "");
      jo = gA.b(gA.a(var2, (CharSequence)"com.corruptedsmp.libs.okhttp3."), (CharSequence)"Client");
   }
}
