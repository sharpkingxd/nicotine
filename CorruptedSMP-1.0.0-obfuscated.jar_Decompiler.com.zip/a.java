import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class a implements CommandExecutor {
   private final CorruptedSMPPlugin k;

   public a(CorruptedSMPPlugin var1) {
      this.k = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("corruptedsmp.ability")) {
            var5.sendMessage(this.a("§cYou don't have permission to use this command!"));
            return true;
         } else {
            this.k.d().d(var5);
            return true;
         }
      } else {
         var1.sendMessage("§cThis command can only be used by players!");
         return true;
      }
   }

   private String a(String var1) {
      String var2 = this.k.getConfig().getString("messages.prefix", "");
      return (var2 + var1).replace("&", "§");
   }
}
