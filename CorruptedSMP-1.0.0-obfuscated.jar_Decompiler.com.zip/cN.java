import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLSocket;
import org.bouncycastle.jsse.BCSSLParameters;
import org.bouncycastle.jsse.BCSSLSocket;

public final class cN implements cR {
   public static final a pm = new a((fP)null);
   private static final cQ.a pn = new cQ.a() {
      public boolean f(SSLSocket var1) {
         fR.c(var1, (String)"");
         return cC.oD.jJ() && var1 instanceof BCSSLSocket;
      }

      public cR g(SSLSocket var1) {
         fR.c(var1, (String)"");
         return new cN();
      }
   };

   public boolean f(SSLSocket var1) {
      fR.c(var1, (String)"");
      return var1 instanceof BCSSLSocket;
   }

   public boolean jB() {
      return cC.oD.jJ();
   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      BCSSLSocket var2 = (BCSSLSocket)var1;
      String var3 = var2.getApplicationProtocol();
      return (var3 == null ? true : fR.c(var3, (Object)"")) ? null : var3;
   }

   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      if (this.f(var1)) {
         BCSSLSocket var4 = (BCSSLSocket)var1;
         BCSSLParameters var5 = var4.getParameters();
         Collection var6 = (Collection)cH.oU.h(var3);
         boolean var7 = false;
         var5.setApplicationProtocols((String[])var6.toArray(new String[0]));
         var4.setParameters(var5);
      }

   }

   public static final class a {
      private a() {
      }

      public final cQ.a kn() {
         return cN.pn;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
