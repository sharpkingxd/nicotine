import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class dX implements Listener {
   private final CorruptedSMPPlugin ru;

   public dX(CorruptedSMPPlugin var1) {
      this.ru = var1;
   }

   @EventHandler
   public void n(EntityDamageByEntityEvent var1) {
   }
}
