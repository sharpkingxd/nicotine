import android.os.Build.VERSION;
import android.security.NetworkSecurityPolicy;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.security.cert.TrustAnchor;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;

public final class cB extends cH {
   public static final a oz = new a((fP)null);
   private final List<cR> oA;
   private final cO oB;
   private static final boolean oC;

   public cB() {
      cR[] var1 = new cR[]{cS.a.a(cS.pw, (String)null, 1, (Object)null), new cQ(cM.pf.kl()), new cQ(cP.ps.kq()), new cQ(cN.pm.kn())};
      Iterable var11 = (Iterable)eO.l(var1);
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList());
      boolean var5 = false;

      for(Object var7 : var11) {
         cR var8 = (cR)var7;
         boolean var9 = false;
         if (var8.jB()) {
            var4.add(var7);
         }
      }

      this.oA = (List)var4;
      this.oB = cO.po.ko();
   }

   public void a(Socket var1, InetSocketAddress var2, int var3) throws IOException {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");

      try {
         var1.connect((SocketAddress)var2, var3);
      } catch (ClassCastException var5) {
         if (VERSION.SDK_INT == 26) {
            throw new IOException("Exception in connect", (Throwable)var5);
         } else {
            throw var5;
         }
      }
   }

   public void a(SSLSocket var1, String var2, List<bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      Iterable var5 = (Iterable)this.oA;
      Iterator var6 = var5.iterator();

      Object var10000;
      while(true) {
         if (var6.hasNext()) {
            Object var7 = var6.next();
            cR var8 = (cR)var7;
            boolean var9 = false;
            if (!var8.f(var1)) {
               continue;
            }

            var10000 = var7;
            break;
         }

         var10000 = null;
         break;
      }

      cR var4 = (cR)var10000;
      if (var4 != null) {
         var4.a(var1, var2, var3);
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      Iterable var2 = (Iterable)this.oA;
      Iterator var3 = var2.iterator();

      Object var10000;
      while(true) {
         if (var3.hasNext()) {
            Object var4 = var3.next();
            cR var5 = (cR)var4;
            boolean var6 = false;
            if (!var5.f(var1)) {
               continue;
            }

            var10000 = var4;
            break;
         }

         var10000 = null;
         break;
      }

      return (cR)var10000 != null ? ((cR)var10000).d(var1) : null;
   }

   public Object aH(String var1) {
      fR.c(var1, (String)"");
      return this.oB.aJ(var1);
   }

   public void b(String var1, Object var2) {
      fR.c(var1, (String)"");
      boolean var3 = this.oB.g(var2);
      if (!var3) {
         cH.a(this, var1, 5, (Throwable)null, 4, (Object)null);
      }

   }

   public boolean aG(String var1) {
      fR.c(var1, (String)"");
      return VERSION.SDK_INT >= 24 ? NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted(var1) : (VERSION.SDK_INT >= 23 ? NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted() : true);
   }

   public cX a(X509TrustManager var1) {
      fR.c(var1, (String)"");
      cJ var10000 = cJ.oY.d(var1);
      return var10000 != null ? (cX)var10000 : super.a(var1);
   }

   public cZ b(X509TrustManager var1) {
      fR.c(var1, (String)"");

      cZ var2;
      try {
         Class var10000 = var1.getClass();
         Class[] var3 = new Class[]{X509Certificate.class};
         Method var5 = var10000.getDeclaredMethod("findTrustAnchorByIssuerAndSignature", var3);
         var5.setAccessible(true);
         fR.b(var5, "");
         var2 = new b(var1, var5);
      } catch (NoSuchMethodException var4) {
         var2 = super.b(var1);
      }

      return var2;
   }

   static {
      boolean var10000;
      if (!cH.oU.ka()) {
         var10000 = false;
      } else if (VERSION.SDK_INT >= 30) {
         var10000 = false;
      } else {
         if (VERSION.SDK_INT < 21) {
            boolean var0 = false;
            String var1 = "Expected Android API level 21+ but was " + VERSION.SDK_INT;
            throw new IllegalStateException(var1.toString());
         }

         var10000 = true;
      }

      oC = var10000;
   }

   public static final class a {
      private a() {
      }

      public final boolean jE() {
         return cB.oC;
      }

      public final cH jF() {
         return this.jE() ? (cH)(new cB()) : null;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public static final class b implements cZ {
      private final X509TrustManager trustManager;
      private final Method findByIssuerAndSignatureMethod;

      public b(X509TrustManager var1, Method var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         super();
         this.trustManager = var1;
         this.findByIssuerAndSignatureMethod = var2;
      }

      public X509Certificate c(X509Certificate var1) {
         fR.c(var1, (String)"");

         X509Certificate var2;
         try {
            Method var10000 = this.findByIssuerAndSignatureMethod;
            X509TrustManager var10001 = this.trustManager;
            Object[] var4 = new Object[]{var1};
            Object var8 = var10000.invoke(var10001, var4);
            fR.m(var8);
            TrustAnchor var7 = (TrustAnchor)var8;
            var2 = var7.getTrustedCert();
         } catch (IllegalAccessException var5) {
            throw new AssertionError("unable to get issues and signature", (Throwable)var5);
         } catch (InvocationTargetException var6) {
            var2 = null;
         }

         return var2;
      }

      public String toString() {
         return "CustomTrustRootIndex(trustManager=" + this.trustManager + ", findByIssuerAndSignatureMethod=" + this.findByIssuerAndSignatureMethod + ')';
      }

      public int hashCode() {
         int var1 = this.trustManager.hashCode();
         var1 = var1 * 31 + this.findByIssuerAndSignatureMethod.hashCode();
         return var1;
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (!(var1 instanceof b)) {
            return false;
         } else {
            b var2 = (b)var1;
            if (!fR.c(this.trustManager, (Object)var2.trustManager)) {
               return false;
            } else {
               return fR.c(this.findByIssuerAndSignatureMethod, (Object)var2.findByIssuerAndSignatureMethod);
            }
         }
      }
   }
}
