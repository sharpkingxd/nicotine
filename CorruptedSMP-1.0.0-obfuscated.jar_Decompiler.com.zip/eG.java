import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.RandomAccess;

public abstract class eG<E> extends eF<E> implements List<E> {
   public static final a sm = new a((fP)null);

   protected eG() {
   }

   public abstract E get(int var1);

   public Iterator<E> iterator() {
      return new b();
   }

   public int indexOf(E var1) {
      List var2 = this;
      boolean var3 = false;
      int var4 = 0;
      Iterator var5 = var2.iterator();

      int var10000;
      while(true) {
         if (!var5.hasNext()) {
            var10000 = -1;
            break;
         }

         Object var6 = var5.next();
         boolean var8 = false;
         if (fR.c(var6, (Object)var1)) {
            var10000 = var4;
            break;
         }

         ++var4;
      }

      return var10000;
   }

   public int lastIndexOf(E var1) {
      List var2 = this;
      boolean var3 = false;
      ListIterator var4 = var2.listIterator(var2.size());

      int var10000;
      while(true) {
         if (var4.hasPrevious()) {
            Object var5 = var4.previous();
            boolean var6 = false;
            if (!fR.c(var5, (Object)var1)) {
               continue;
            }

            var10000 = var4.nextIndex();
            break;
         }

         var10000 = -1;
         break;
      }

      return var10000;
   }

   public ListIterator<E> listIterator() {
      return new c(0);
   }

   public ListIterator<E> listIterator(int var1) {
      return new c(var1);
   }

   public List<E> subList(int var1, int var2) {
      return new d<E>(this, var1, var2);
   }

   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else {
         return !(var1 instanceof List) ? false : sm.a(this, (Collection)var1);
      }
   }

   public int hashCode() {
      return sm.a(this);
   }

   public void add(int var1, E var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(int var1, Collection<? extends E> var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public E remove(int var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public E set(int var1, E var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public static final class a {
      private a() {
      }

      public final void e(int var1, int var2) {
         if (var1 < 0 || var1 >= var2) {
            throw new IndexOutOfBoundsException("index: " + var1 + ", size: " + var2);
         }
      }

      public final void f(int var1, int var2) {
         if (var1 < 0 || var1 > var2) {
            throw new IndexOutOfBoundsException("index: " + var1 + ", size: " + var2);
         }
      }

      public final void e(int var1, int var2, int var3) {
         if (var1 >= 0 && var2 <= var3) {
            if (var1 > var2) {
               throw new IllegalArgumentException("fromIndex: " + var1 + " > toIndex: " + var2);
            }
         } else {
            throw new IndexOutOfBoundsException("fromIndex: " + var1 + ", toIndex: " + var2 + ", size: " + var3);
         }
      }

      public final void f(int var1, int var2, int var3) {
         if (var1 >= 0 && var2 <= var3) {
            if (var1 > var2) {
               throw new IllegalArgumentException("startIndex: " + var1 + " > endIndex: " + var2);
            }
         } else {
            throw new IndexOutOfBoundsException("startIndex: " + var1 + ", endIndex: " + var2 + ", size: " + var3);
         }
      }

      public final int a(Collection<?> var1) {
         fR.c(var1, (String)"");
         int var2 = 1;

         for(Object var4 : var1) {
            var2 = 31 * var2 + (var4 != null ? var4.hashCode() : 0);
         }

         return var2;
      }

      public final boolean a(Collection<?> var1, Collection<?> var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         if (var1.size() != var2.size()) {
            return false;
         } else {
            Iterator var3 = var2.iterator();

            for(Object var5 : var1) {
               Object var6 = var3.next();
               if (!fR.c(var5, var6)) {
                  return false;
               }
            }

            return true;
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   class b implements fY, Iterator<E> {
      private int lU;

      public b() {
      }

      protected final int nj() {
         return this.lU;
      }

      protected final void al(int var1) {
         this.lU = var1;
      }

      public boolean hasNext() {
         return this.lU < eG.this.size();
      }

      public E next() {
         if (!this.hasNext()) {
            throw new NoSuchElementException();
         } else {
            eG var10000 = eG.this;
            int var1 = this.lU++;
            return (E)var10000.get(var1);
         }
      }

      public void remove() {
         throw new UnsupportedOperationException("Operation is not supported for read-only collection");
      }
   }

   class c extends b implements ListIterator {
      public c(int var2) {
         eG.sm.f(var2, eG.this.size());
         this.al(var2);
      }

      public boolean hasPrevious() {
         return this.nj() > 0;
      }

      public int nextIndex() {
         return this.nj();
      }

      public E previous() {
         if (!this.hasPrevious()) {
            throw new NoSuchElementException();
         } else {
            eG var10000 = eG.this;
            this.al(this.nj() + -1);
            return (E)var10000.get(this.nj());
         }
      }

      public int previousIndex() {
         return this.nj() - 1;
      }

      public void add(E var1) {
         throw new UnsupportedOperationException("Operation is not supported for read-only collection");
      }

      public void set(E var1) {
         throw new UnsupportedOperationException("Operation is not supported for read-only collection");
      }
   }

   static final class d<E> extends eG<E> implements RandomAccess {
      private final eG<E> sp;
      private final int sq;
      private int sr;

      public d(eG<? extends E> var1, int var2, int var3) {
         fR.c(var1, (String)"");
         super();
         this.sp = var1;
         this.sq = var2;
         eG.sm.e(this.sq, var3, this.sp.size());
         this.sr = var3 - this.sq;
      }

      public E get(int var1) {
         eG.sm.e(var1, this.sr);
         return this.sp.get(this.sq + var1);
      }

      public int getSize() {
         return this.sr;
      }
   }
}
