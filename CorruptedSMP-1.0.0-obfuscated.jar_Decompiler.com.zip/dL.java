import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Egg;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.SpectralArrow;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

public class dL implements Listener {
   private final CorruptedSMPPlugin rb;

   public dL(CorruptedSMPPlugin var1) {
      this.rb = var1;
   }

   @EventHandler
   public void a(EntityDamageEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rb.d().b(var2)) {
            if (this.rb.d().c(var2) == l.w) {
               if (var1.getCause() == DamageCause.FALL) {
                  var1.setCancelled(true);
                  if (var1.getDamage() >= (double)6.0F) {
                     var2.playSound(var2.getLocation(), "custom:land", 1.5F, 1.0F);
                     var2.getWorld().spawnParticle(Particle.CLOUD, var2.getLocation(), 20, (double)0.5F, 0.1, (double)0.5F, 0.1);
                     var2.getWorld().spawnParticle(Particle.GUST_EMITTER_SMALL, var2.getLocation(), 3);
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void b(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof LivingEntity var10) {
            if (this.rb.d().b(var2)) {
               if (this.rb.d().c(var2) == l.w) {
                  double var11 = var1.getDamage();
                  double var6 = Math.max((double)1.0F, var11 - (double)2.0F);
                  var1.setDamage(var6);
                  D var8 = this.rb.f().g(var2.getUniqueId());
                  boolean var9 = var8.M() == 2;
                  var8.N();
                  if (var9) {
                     var1.setDamage(var6 * (double)1.5F);
                     var2.getWorld().spawnParticle(Particle.CRIT, var10.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 15, 0.3, (double)0.5F, 0.3, 0.1);
                     var2.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var10.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, (double)0.5F, 0.3, 0.1);
                     var2.playSound(var2.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0F, 1.0F);
                     var2.sendMessage("§f§l⚡ AUTO-CRIT!");
                  }

                  if (var10.getHealth() / var10.getMaxHealth() < 0.4) {
                     var10.getWorld().spawnParticle(Particle.GUST, var10.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 3, 0.3, (double)0.5F, 0.3, 0.05);
                     var10.getWorld().spawnParticle(Particle.CLOUD, var10.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 2, 0.3, (double)0.5F, 0.3, 0.02);
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(ProjectileHitEvent var1) {
      Entity var3 = var1.getHitEntity();
      if (var3 instanceof Player var2) {
         Projectile var4 = var1.getEntity();
         if (var4 instanceof Projectile) {
            Projectile var8 = var4;
            if (this.rb.d().b(var2)) {
               if (this.rb.d().c(var2) == l.w) {
                  ProjectileSource var9 = var4.getShooter();
                  if (var9 != null) {
                     if (var9 instanceof Player) {
                        Player var5 = (Player)var9;
                        if (this.rb.d().b(var5) && this.rb.d().c(var5) == l.w) {
                           return;
                        }
                     }

                     var1.setCancelled(true);
                     var8.remove();
                     Vector var10;
                     if (var9 instanceof LivingEntity) {
                        LivingEntity var6 = (LivingEntity)var9;
                        var10 = var6.getLocation().toVector().subtract(var2.getLocation().toVector()).normalize();
                     } else {
                        var10 = var8.getVelocity().multiply(-1).normalize();
                     }

                     Projectile var11 = null;
                     if (var8 instanceof Arrow) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), Arrow.class);
                        ((Arrow)var11).setDamage(((Arrow)var8).getDamage());
                        ((Arrow)var11).setCritical(((Arrow)var8).isCritical());
                     } else if (var8 instanceof SpectralArrow) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), SpectralArrow.class);
                     } else if (var8 instanceof Snowball) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), Snowball.class);
                     } else if (var8 instanceof Egg) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), Egg.class);
                     } else if (var8 instanceof EnderPearl) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), EnderPearl.class);
                     } else if (var8 instanceof ThrownPotion) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), ThrownPotion.class);
                        ((ThrownPotion)var11).setItem(((ThrownPotion)var8).getItem());
                     } else if (var8 instanceof Trident) {
                        var11 = (Projectile)var2.getWorld().spawn(var2.getEyeLocation(), Trident.class);
                     }

                     if (var11 != null) {
                        var11.setShooter(var2);
                        var11.setVelocity(var10.multiply((double)1.5F));
                        var2.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, var2.getEyeLocation(), 1);
                        var2.getWorld().spawnParticle(Particle.SWEEP_ATTACK, var2.getEyeLocation(), 3, 0.3, 0.3, 0.3, 0.1);
                        var2.sendMessage("§f§l⚡ REFLECTED!");
                        if (var9 instanceof Player) {
                           Player var7 = (Player)var9;
                           var7.sendMessage("§c§l✗ Your projectile was reflected!");
                        }
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void a(ProjectileLaunchEvent var1) {
      ProjectileSource var3 = var1.getEntity().getShooter();
      if (var3 instanceof Player var2) {
         if (this.rb.d().b(var2)) {
            if (this.rb.d().c(var2) == l.w) {
               if (var2.isSneaking()) {
                  Projectile var4 = var1.getEntity();
                  if (var4 instanceof AbstractArrow) {
                     AbstractArrow var5 = (AbstractArrow)var4;
                     var5.setGravity(false);
                     var2.sendMessage("§7§o*Straight shot!*");
                  }
               }

            }
         }
      }
   }

   @EventHandler
   public void b(EntityDamageEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof LivingEntity var2) {
         for(Entity var4 : var2.getNearbyEntities((double)20.0F, (double)20.0F, (double)20.0F)) {
            if (var4 instanceof Player var5) {
               if (this.rb.d().b(var5) && this.rb.d().c(var5) == l.w) {
                  if (var2.getHealth() / var2.getMaxHealth() < 0.4) {
                     var2.getWorld().spawnParticle(Particle.GUST, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 2, 0.3, (double)0.5F, 0.3, 0.05);
                  }
                  break;
               }
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerTeleportEvent var1) {
      Player var2 = var1.getPlayer();
      D var3 = this.rb.f().g(var2.getUniqueId());
      if (var3.i("inTornado") && (Boolean)var3.h("inTornado") && (var1.getCause() == TeleportCause.ENDER_PEARL || var1.getCause() == TeleportCause.CHORUS_FRUIT)) {
         var1.setCancelled(true);
         var2.sendMessage("§c§l✗ You can't teleport while in a tornado!");
      }

      if (o.c(var2.getUniqueId()) && (var1.getCause() == TeleportCause.ENDER_PEARL || var1.getCause() == TeleportCause.CHORUS_FRUIT || var1.getCause() == TeleportCause.COMMAND || var1.getCause() == TeleportCause.UNKNOWN)) {
         var1.setCancelled(true);
         var2.sendMessage("§5§l✗ The Ender Border blocks all teleportation!");
         var2.getWorld().spawnParticle(Particle.SMOKE, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.3, (double)0.5F, 0.3, 0.1);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      Block var3 = var1.getBlock();
      if (o.c(var3.getLocation()) && o.c(var2.getUniqueId())) {
         var1.setCancelled(true);
         var2.sendMessage("§5§l✗ You cannot break the Ender Border!");
         var2.getWorld().spawnParticle(Particle.SMOKE, var3.getLocation().add((double)0.5F, (double)0.5F, (double)0.5F), 10, 0.3, 0.3, 0.3, (double)0.0F);
      }

   }
}
