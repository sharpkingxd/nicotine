public final class gf extends gd {
   public static final a tc = new a((fP)null);
   private static final gf td = new gf(1, 0);

   public gf(int var1, int var2) {
      super(var1, var2, 1);
   }

   public Integer nG() {
      return this.nC();
   }

   public Integer nH() {
      return this.nD();
   }

   public boolean ap(int var1) {
      return this.nC() <= var1 && var1 <= this.nD();
   }

   public boolean isEmpty() {
      return this.nC() > this.nD();
   }

   public boolean equals(Object var1) {
      return var1 instanceof gf && (this.isEmpty() && ((gf)var1).isEmpty() || this.nC() == ((gf)var1).nC() && this.nD() == ((gf)var1).nD());
   }

   public int hashCode() {
      return this.isEmpty() ? -1 : 31 * this.nC() + this.nD();
   }

   public String toString() {
      return this.nC() + ".." + this.nD();
   }

   public static final class a {
      private a() {
      }

      public final gf nJ() {
         return gf.td;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
