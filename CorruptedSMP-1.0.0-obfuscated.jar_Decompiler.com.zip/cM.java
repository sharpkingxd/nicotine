import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.net.ssl.SSLSocket;

public class cM implements cR {
   public static final a pf = new a((fP)null);
   private final Class<? super SSLSocket> pg;
   private final Method ph;
   private final Method pi;
   private final Method pj;
   private final Method pk;
   private static final cQ.a pl;

   public cM(Class<? super SSLSocket> var1) {
      fR.c(var1, (String)"");
      super();
      this.pg = var1;
      Class var10001 = this.pg;
      Class[] var3 = new Class[]{Boolean.TYPE};
      Method var5 = var10001.getDeclaredMethod("setUseSessionTickets", var3);
      fR.b(var5, "");
      this.ph = var5;
      Class var6 = this.pg;
      Class[] var2 = new Class[]{String.class};
      this.pi = var6.getMethod("setHostname", var2);
      this.pj = this.pg.getMethod("getAlpnSelectedProtocol");
      var6 = this.pg;
      var2 = new Class[]{byte[].class};
      this.pk = var6.getMethod("setAlpnProtocols", var2);
   }

   public boolean jB() {
      return cB.oz.jE();
   }

   public boolean f(SSLSocket var1) {
      fR.c(var1, (String)"");
      return this.pg.isInstance(var1);
   }

   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      if (this.f(var1)) {
         try {
            Method var10000 = this.ph;
            Object[] var4 = new Object[]{true};
            var10000.invoke(var1, var4);
            if (var2 != null) {
               var10000 = this.pi;
               var4 = new Object[]{var2};
               var10000.invoke(var1, var4);
            }

            var10000 = this.pk;
            var4 = new Object[]{cH.oU.i(var3)};
            var10000.invoke(var1, var4);
         } catch (IllegalAccessException var5) {
            throw new AssertionError(var5);
         } catch (InvocationTargetException var6) {
            throw new AssertionError(var6);
         }
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      if (!this.f(var1)) {
         return null;
      } else {
         String var2;
         try {
            byte[] var7 = (byte[])this.pj.invoke(var1);
            var2 = var7 != null ? new String(var7, gx.tn) : null;
         } catch (IllegalAccessException var5) {
            throw new AssertionError(var5);
         } catch (InvocationTargetException var6) {
            Throwable var4 = var6.getCause();
            if (!(var4 instanceof NullPointerException) || !fR.c(((NullPointerException)var4).getMessage(), (Object)"ssl == null")) {
               throw new AssertionError(var6);
            }

            var2 = null;
         }

         return var2;
      }
   }

   static {
      pl = pf.aI("com.google.android.gms.org.conscrypt");
   }

   public static final class a {
      private a() {
      }

      public final cQ.a kl() {
         return cM.pl;
      }

      private final cM v(Class<? super SSLSocket> var1) {
         Class var2 = var1;

         while(var2 != null && !fR.c(var2.getSimpleName(), (Object)"OpenSSLSocketImpl")) {
            var2 = var2.getSuperclass();
            if (var2 == null) {
               throw new AssertionError("No OpenSSLSocketImpl superclass of socket of type " + var1);
            }
         }

         fR.m(var2);
         return new cM(var2);
      }

      public final cQ.a aI(final String var1) {
         fR.c(var1, (String)"");
         return new cQ.a() {
            public boolean f(SSLSocket var1x) {
               fR.c(var1x, (String)"");
               String var10000 = var1x.getClass().getName();
               fR.b(var10000, "");
               return gA.a(var10000, var1 + '.', false, 2, (Object)null);
            }

            public cR g(SSLSocket var1x) {
               fR.c(var1x, (String)"");
               return cM.pf.v(var1x.getClass());
            }
         };
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
