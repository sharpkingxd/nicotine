import java.math.BigInteger;
import java.util.Objects;

public final class U extends P {
   private final Object value;

   public U(Boolean var1) {
      this.value = Objects.requireNonNull(var1);
   }

   public U(Number var1) {
      this.value = Objects.requireNonNull(var1);
   }

   public U(String var1) {
      this.value = Objects.requireNonNull(var1);
   }

   public boolean ak() {
      return this.value instanceof Boolean;
   }

   public boolean ac() {
      return this.ak() ? (Boolean)this.value : Boolean.parseBoolean(this.Y());
   }

   public boolean al() {
      return this.value instanceof Number;
   }

   public Number X() {
      if (this.value instanceof Number) {
         return (Number)this.value;
      } else if (this.value instanceof String) {
         return new ap((String)this.value);
      } else {
         throw new UnsupportedOperationException("Primitive is neither a number nor a string");
      }
   }

   public boolean am() {
      return this.value instanceof String;
   }

   public String Y() {
      if (this.value instanceof String) {
         return (String)this.value;
      } else if (this.al()) {
         return this.X().toString();
      } else if (this.ak()) {
         return ((Boolean)this.value).toString();
      } else {
         throw new AssertionError("Unexpected value type: " + this.value.getClass());
      }
   }

   public double Z() {
      return this.al() ? this.X().doubleValue() : Double.parseDouble(this.Y());
   }

   public long aa() {
      return this.al() ? this.X().longValue() : Long.parseLong(this.Y());
   }

   public int ab() {
      return this.al() ? this.X().intValue() : Integer.parseInt(this.Y());
   }

   public int hashCode() {
      if (this.value == null) {
         return 31;
      } else if (a(this)) {
         long var3 = this.X().longValue();
         return (int)(var3 ^ var3 >>> 32);
      } else if (this.value instanceof Number) {
         long var1 = Double.doubleToLongBits(this.X().doubleValue());
         return (int)(var1 ^ var1 >>> 32);
      } else {
         return this.value.hashCode();
      }
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         U var2 = (U)var1;
         if (this.value == null) {
            return var2.value == null;
         } else if (a(this) && a(var2)) {
            return this.X().longValue() == var2.X().longValue();
         } else if (this.value instanceof Number && var2.value instanceof Number) {
            double var3 = this.X().doubleValue();
            double var5 = var2.X().doubleValue();
            return var3 == var5 || Double.isNaN(var3) && Double.isNaN(var5);
         } else {
            return this.value.equals(var2.value);
         }
      } else {
         return false;
      }
   }

   private static boolean a(U var0) {
      if (!(var0.value instanceof Number)) {
         return false;
      } else {
         Number var1 = (Number)var0.value;
         return var1 instanceof BigInteger || var1 instanceof Long || var1 instanceof Integer || var1 instanceof Short || var1 instanceof Byte;
      }
   }
}
