import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.Proxy.Type;
import java.security.cert.CertificateException;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;

public final class ch implements bs {
   public static final a mf = new a((fP)null);
   private final bu mg;

   public ch(bu var1) {
      fR.c(var1, (String)"");
      super();
      this.mg = var1;
   }

   public by a(bs.a var1) throws IOException {
      fR.c(var1, (String)"");
      ce var2 = (ce)var1;
      bw var3 = ((ce)var1).hI();
      bS var4 = var2.hG();
      int var5 = 0;
      by var6 = null;
      boolean var7 = true;
      List var8 = eO.nk();

      while(true) {
         var4.b(var3, var7);
         Object var9 = null;
         boolean var10 = true;

         by var13;
         try {
            if (var4.gX()) {
               throw new IOException("Canceled");
            }

            try {
               var21 = var2.c(var3);
               var7 = true;
            } catch (bW var18) {
               if (!this.a(var18.hx(), var4, var3, false)) {
                  throw bD.a((Exception)var18.hw(), var8);
               }

               var8 = eO.a((Collection)var8, var18.hw());
               var7 = false;
               continue;
            } catch (IOException var19) {
               if (!this.a(var19, var4, var3, !(var19 instanceof cl))) {
                  throw bD.a((Exception)var19, var8);
               }

               var8 = eO.a((Collection)var8, var19);
               var7 = false;
               continue;
            }

            if (var6 != null) {
               var21 = var21.fh().f(var6.fh().a((bz)null).fl()).fl();
            }

            bQ var11 = var4.gV();
            bw var12 = this.a(var21, var11);
            if (var12 != null) {
               bx var22 = var12.eL();
               if (var22 == null || !var22.eS()) {
                  bz var10000 = var21.eZ();
                  if (var10000 != null) {
                     bD.a(var10000);
                  }

                  ++var5;
                  if (var5 > 20) {
                     throw new ProtocolException("Too many follow-up requests: " + var5);
                  }

                  var3 = var12;
                  var6 = var21;
                  continue;
               }

               var10 = false;
               by var14 = var21;
               return var14;
            }

            if (var11 != null && var11.gE()) {
               var4.hb();
            }

            var10 = false;
            var13 = var21;
         } finally {
            var4.s(var10);
         }

         return var13;
      }
   }

   private final boolean a(IOException var1, bS var2, bw var3, boolean var4) {
      if (!this.mg.dB()) {
         return false;
      } else if (var4 && this.a(var1, var3)) {
         return false;
      } else if (!this.a(var1, var4)) {
         return false;
      } else {
         return var2.hc();
      }
   }

   private final boolean a(IOException var1, bw var2) {
      bx var3 = var2.eL();
      return var3 != null && var3.eS() || var1 instanceof FileNotFoundException;
   }

   private final boolean a(IOException var1, boolean var2) {
      if (var1 instanceof ProtocolException) {
         return false;
      } else if (!(var1 instanceof InterruptedIOException)) {
         if (var1 instanceof SSLHandshakeException && var1.getCause() instanceof CertificateException) {
            return false;
         } else {
            return !(var1 instanceof SSLPeerUnverifiedException);
         }
      } else {
         return var1 instanceof SocketTimeoutException && !var2;
      }
   }

   private final bw a(by var1, bQ var2) throws IOException {
      bA var11;
      label66: {
         if (var2 != null) {
            bT var10000 = var2.gG();
            if (var10000 != null) {
               var11 = var10000.hr();
               break label66;
            }
         }

         var11 = null;
      }

      bA var3 = var11;
      int var4 = var1.eW();
      String var5 = var1.eT().eJ();
      switch (var4) {
         case 300:
         case 301:
         case 302:
         case 303:
         case 307:
         case 308:
            return this.a(var1, var5);
         case 401:
            return this.mg.dC().a(var3, var1);
         case 407:
            fR.m(var3);
            Proxy var10 = var3.fp();
            if (var10.type() != Type.HTTP) {
               throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
            }

            return this.mg.dK().a(var3, var1);
         case 408:
            if (!this.mg.dB()) {
               return null;
            } else {
               bx var9 = var1.eT().eL();
               if (var9 != null && var9.eS()) {
                  return null;
               } else {
                  by var7 = var1.fc();
                  if (var7 != null && var7.eW() == 408) {
                     return null;
                  } else {
                     if (this.a(var1, 0) > 0) {
                        return null;
                     }

                     return var1.eT();
                  }
               }
            }
         case 421:
            bx var8 = var1.eT().eL();
            if (var8 != null && var8.eS()) {
               return null;
            } else {
               if (var2 != null && var2.gH()) {
                  var2.gG().ho();
                  return var1.eT();
               }

               return null;
            }
         case 503:
            by var6 = var1.fc();
            if (var6 != null && var6.eW() == 503) {
               return null;
            } else {
               if (this.a(var1, Integer.MAX_VALUE) == 0) {
                  return var1.eT();
               }

               return null;
            }
         default:
            return null;
      }
   }

   private final bw a(by var1, String var2) {
      if (!this.mg.dD()) {
         return null;
      } else {
         String var10000 = by.a(var1, "Location", (String)null, 2, (Object)null);
         if (var10000 == null) {
            return null;
         } else {
            String var3 = var10000;
            br var10 = var1.eT().eI().K(var3);
            if (var10 == null) {
               return null;
            } else {
               br var4 = var10;
               boolean var5 = fR.c(var4.cX(), (Object)var1.eT().eI().cX());
               if (!var5 && !this.mg.dE()) {
                  return null;
               } else {
                  bw.a var6 = var1.eT().eO();
                  if (cd.aB(var2)) {
                     int var7 = var1.eW();
                     boolean var8 = cd.lR.aC(var2) || var7 == 308 || var7 == 307;
                     if (cd.lR.aD(var2) && var7 != 308 && var7 != 307) {
                        var6.a("GET", (bx)null);
                     } else {
                        bx var9 = var8 ? var1.eT().eL() : null;
                        var6.a(var2, var9);
                     }

                     if (!var8) {
                        var6.ak("Transfer-Encoding");
                        var6.ak("Content-Length");
                        var6.ak("Content-Type");
                     }
                  }

                  if (!bD.a(var1.eT().eI(), var4)) {
                     var6.ak("Authorization");
                  }

                  return var6.c(var4).eQ();
               }
            }
         }
      }
   }

   private final int a(by var1, int var2) {
      String var10000 = by.a(var1, "Retry-After", (String)null, 2, (Object)null);
      if (var10000 == null) {
         return var2;
      } else {
         String var3 = var10000;
         CharSequence var4 = (CharSequence)var3;
         if ((new gz("\\d+")).a(var4)) {
            Integer var5 = Integer.valueOf(var3);
            fR.b(var5, "");
            return ((Number)var5).intValue();
         } else {
            return Integer.MAX_VALUE;
         }
      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
