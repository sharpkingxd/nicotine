import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class aG extends ac<Object> {
   private static final ad bY;
   private final K bZ;
   private final ab ca;

   private aG(K var1, ab var2) {
      this.bZ = var1;
      this.ca = var2;
   }

   private static ad a(final ab var0) {
      return new ad() {
         public <T> ac<T> a(K var1, aS<T> var2) {
            return var2.bk() == Object.class ? new aG(var1, var0) : null;
         }
      };
   }

   public static ad b(ab var0) {
      return var0 == aa.DOUBLE ? bY : a(var0);
   }

   private Object a(aT var1, aU var2) throws IOException {
      switch (var2) {
         case dQ:
            var1.aE();
            return new ArrayList();
         case dS:
            var1.aG();
            return new aq();
         default:
            return null;
      }
   }

   private Object b(aT var1, aU var2) throws IOException {
      switch (var2) {
         case dV:
            return var1.aM();
         case dW:
            return this.ca.h(var1);
         case dX:
            return var1.aN();
         case dY:
            var1.aO();
            return null;
         default:
            throw new IllegalStateException("Unexpected token: " + var2);
      }
   }

   public Object b(aT var1) throws IOException {
      aU var3 = var1.aI();
      Object var2 = this.a(var1, var3);
      if (var2 == null) {
         return this.b(var1, var3);
      } else {
         ArrayDeque var4 = new ArrayDeque();

         while(true) {
            while(!var1.hasNext()) {
               if (var2 instanceof List) {
                  var1.aF();
               } else {
                  var1.aH();
               }

               if (var4.isEmpty()) {
                  return var2;
               }

               var2 = var4.removeLast();
            }

            String var5 = null;
            if (var2 instanceof Map) {
               var5 = var1.aL();
            }

            var3 = var1.aI();
            Object var6 = this.a(var1, var3);
            boolean var7 = var6 != null;
            if (var6 == null) {
               var6 = this.b(var1, var3);
            }

            if (var2 instanceof List) {
               List var8 = (List)var2;
               var8.add(var6);
            } else {
               Map var10 = (Map)var2;
               var10.put(var5, var6);
            }

            if (var7) {
               var4.addLast(var2);
               var2 = var6;
            }
         }
      }
   }

   public void a(aV var1, Object var2) throws IOException {
      if (var2 == null) {
         var1.be();
      } else {
         ac var3 = this.bZ.b(var2.getClass());
         if (var3 instanceof aG) {
            var1.bc();
            var1.bd();
         } else {
            var3.a(var1, var2);
         }
      }
   }

   static {
      bY = a(aa.DOUBLE);
   }
}
