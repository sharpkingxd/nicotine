public interface fZ extends ga {
}
