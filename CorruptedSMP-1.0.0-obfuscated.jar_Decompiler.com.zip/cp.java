public final class cp {
   public static final cp mZ = new cp();
   public static final dh na;
   private static final String[] nb;
   private static final String[] nc;
   private static final String[] nd;

   private cp() {
   }

   public final String a(boolean var1, int var2, int var3, int var4, int var5) {
      String var6 = this.E(var4);
      String var7 = this.c(var4, var5);
      String var8 = var1 ? "<<" : ">>";
      Object[] var9 = new Object[]{var8, var2, var3, var6, var7};
      return bD.a("%s 0x%08x %5d %-13s %s", var9);
   }

   public final String E(int var1) {
      String var10000;
      if (var1 < nb.length) {
         var10000 = nb[var1];
      } else {
         Object[] var2 = new Object[]{var1};
         var10000 = bD.a("0x%02x", var2);
      }

      return var10000;
   }

   public final String c(int var1, int var2) {
      if (var2 == 0) {
         return "";
      } else {
         switch (var1) {
            case 2:
            case 3:
            case 7:
            case 8:
               return nd[var2];
            case 4:
            case 6:
               return var2 == 1 ? "ACK" : nd[var2];
            case 5:
            default:
               String var10000;
               if (var2 < nc.length) {
                  var10000 = nc[var2];
                  fR.m(var10000);
               } else {
                  var10000 = nd[var2];
               }

               String var3 = var10000;
               return var1 == 5 && (var2 & 4) != 0 ? gA.a(var3, "HEADERS", "PUSH_PROMISE", false, 4, (Object)null) : (var1 == 0 && (var2 & 32) != 0 ? gA.a(var3, "PRIORITY", "COMPRESSED", false, 4, (Object)null) : var3);
         }
      }
   }

   static {
      na = dh.pS.aU("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");
      String[] var0 = new String[]{"DATA", "HEADERS", "PRIORITY", "RST_STREAM", "SETTINGS", "PUSH_PROMISE", "PING", "GOAWAY", "WINDOW_UPDATE", "CONTINUATION"};
      nb = var0;
      nc = new String[64];
      int var8 = 0;

      String[] var1;
      for(var1 = new String[256]; var8 < 256; ++var8) {
         Object[] var3 = new Object[1];
         String var10005 = Integer.toBinaryString(var8);
         fR.b(var10005, "");
         var3[0] = var10005;
         var1[var8] = gA.a(bD.a("%8s", var3), ' ', '0', false, 4, (Object)null);
      }

      nd = var1;
      nc[0] = "";
      nc[1] = "END_STREAM";
      int[] var10 = new int[]{1};
      int[] var9 = var10;
      nc[8] = "PADDED";
      int var11 = 0;

      for(int var2 = var10.length; var11 < var2; ++var11) {
         int var16 = var9[var11];
         nc[var16 | 8] = nc[var16] + "|PADDED";
      }

      nc[4] = "END_HEADERS";
      nc[32] = "PRIORITY";
      nc[36] = "END_HEADERS|PRIORITY";
      int[] var13 = new int[]{4, 32, 36};
      int[] var12 = var13;
      int var14 = 0;

      for(int var17 = var13.length; var14 < var17; ++var14) {
         int var4 = var12[var14];
         int var5 = 0;

         for(int var6 = var9.length; var5 < var6; ++var5) {
            int var7 = var9[var5];
            nc[var7 | var4] = nc[var7] + '|' + nc[var4];
            nc[var7 | var4 | 8] = nc[var7] + '|' + nc[var4] + "|PADDED";
         }
      }

      var14 = 0;

      for(int var18 = nc.length; var14 < var18; ++var14) {
         if (nc[var14] == null) {
            nc[var14] = nd[var14];
         }
      }

   }
}
