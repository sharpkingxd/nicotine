import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.World.Environment;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class p {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      if (var0.getHealth() <= (double)6.0F) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 40, 1, false, false));
      } else if (var0.getHealth() <= (double)10.0F) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 40, 0, false, false));
      }

      if (var0.getWorld().getEnvironment() != Environment.THE_END) {
         boolean var2 = o.f(var0.getUniqueId());
         if (!var2) {
            var0.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 0, false, false));
            if (var0.hasPotionEffect(PotionEffectType.SPEED)) {
               var0.removePotionEffect(PotionEffectType.SPEED);
            }
         }
      }

   }
}
