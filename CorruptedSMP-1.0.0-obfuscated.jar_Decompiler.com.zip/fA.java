import java.lang.reflect.Method;

final class fA {
   public static final fA sB = new fA();
   private static final a sC = new a((Method)null, (Method)null, (Method)null);
   private static a sD;

   private fA() {
   }

   public final String d(fw var1) {
      fR.c(var1, (String)"");
      a var10000 = sD;
      if (var10000 == null) {
         var10000 = this.e(var1);
      }

      a var2 = var10000;
      if (var2 == sC) {
         return null;
      } else {
         Method var6 = var2.sE;
         Object var7 = var6 != null ? var6.invoke(var1.getClass()) : null;
         if (var7 == null) {
            return null;
         } else {
            Object var3 = var7;
            Method var8 = var2.sF;
            Object var9 = var8 != null ? var8.invoke(var3) : null;
            if (var9 == null) {
               return null;
            } else {
               Object var4 = var9;
               Method var10 = var2.sG;
               Object var5 = var10 != null ? var10.invoke(var4) : null;
               return var5 instanceof String ? (String)var5 : null;
            }
         }
      }
   }

   private final a e(fw var1) {
      try {
         Method var2 = Class.class.getDeclaredMethod("getModule");
         Class var11 = var1.getClass().getClassLoader().loadClass("java.lang.Module");
         Method var4 = var11.getDeclaredMethod("getDescriptor");
         Class var12 = var1.getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor");
         Method var6 = var12.getDeclaredMethod("name");
         a var7 = new a(var2, var4, var6);
         boolean var9 = false;
         fA var13 = sB;
         sD = var7;
         return var7;
      } catch (Exception var10) {
         a var3 = sC;
         boolean var5 = false;
         fA var10000 = sB;
         sD = var3;
         return var3;
      }
   }

   static final class a {
      public final Method sE;
      public final Method sF;
      public final Method sG;

      public a(Method var1, Method var2, Method var3) {
         this.sE = var1;
         this.sF = var2;
         this.sG = var3;
      }
   }
}
