import java.security.cert.Certificate;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.X509TrustManager;

public abstract class cX {
   public static final a pL = new a((fP)null);

   public abstract List<Certificate> a(List<? extends Certificate> var1, String var2) throws SSLPeerUnverifiedException;

   public static final class a {
      private a() {
      }

      public final cX e(X509TrustManager var1) {
         fR.c(var1, (String)"");
         return cH.oU.jZ().a(var1);
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
