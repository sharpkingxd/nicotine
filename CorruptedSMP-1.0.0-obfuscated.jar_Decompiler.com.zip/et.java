import java.io.Serializable;

public final class et<T> implements ev<T>, Serializable {
   private final T sd;

   public et(T var1) {
      this.sd = var1;
   }

   public T getValue() {
      return this.sd;
   }

   public String toString() {
      return String.valueOf(this.getValue());
   }
}
