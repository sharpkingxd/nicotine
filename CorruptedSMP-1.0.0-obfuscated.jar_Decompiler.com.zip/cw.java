import java.io.IOException;
import java.util.List;

public interface cw {
   a oo = cw.a.$$INSTANCE;
   cw op = new a.a();

   boolean b(int var1, List<cn> var2);

   boolean c(int var1, List<cn> var2, boolean var3);

   boolean b(int var1, dg var2, int var3, boolean var4) throws IOException;

   void f(int var1, cm var2);

   public static final class a {
      // $FF: synthetic field
      static final a $$INSTANCE = new a();

      private a() {
      }

      static final class a implements cw {
         public a() {
         }

         public boolean b(int var1, List<cn> var2) {
            fR.c(var2, (String)"");
            return true;
         }

         public boolean c(int var1, List<cn> var2, boolean var3) {
            fR.c(var2, (String)"");
            return true;
         }

         public boolean b(int var1, dg var2, int var3, boolean var4) throws IOException {
            fR.c(var2, (String)"");
            var2.A((long)var3);
            return true;
         }

         public void f(int var1, cm var2) {
            fR.c(var2, (String)"");
         }
      }
   }
}
