public final class dv {
   public static final a qr = new a((fP)null);
   public final byte[] qs;
   public int dH;
   public int dI;
   public boolean qt;
   public boolean qu;
   public dv qv;
   public dv qw;

   public dv() {
      this.qs = new byte[8192];
      this.qu = true;
      this.qt = false;
   }

   public dv(byte[] var1, int var2, int var3, boolean var4, boolean var5) {
      fR.c(var1, (String)"");
      super();
      this.qs = var1;
      this.dH = var2;
      this.dI = var3;
      this.qt = var4;
      this.qu = var5;
   }

   public final dv lH() {
      this.qt = true;
      return new dv(this.qs, this.dH, this.dI, true, false);
   }

   public final dv lI() {
      dv var1 = this.qv != this ? this.qv : null;
      dv var10000 = this.qw;
      fR.m(var10000);
      var10000.qv = this.qv;
      var10000 = this.qv;
      fR.m(var10000);
      var10000.qw = this.qw;
      this.qv = null;
      this.qw = null;
      return var1;
   }

   public final dv b(dv var1) {
      fR.c(var1, (String)"");
      var1.qw = this;
      var1.qv = this.qv;
      dv var10000 = this.qv;
      fR.m(var10000);
      var10000.qw = var1;
      this.qv = var1;
      return var1;
   }

   public final dv ah(int var1) {
      if (var1 <= 0 || var1 > this.dI - this.dH) {
         boolean var3 = false;
         String var5 = "byteCount out of range";
         throw new IllegalArgumentException(var5.toString());
      } else {
         dv var2 = null;
         if (var1 >= 1024) {
            var2 = this.lH();
         } else {
            var2 = dw.lK();
            eI.a(this.qs, var2.qs, 0, this.dH, this.dH + var1, 2, (Object)null);
         }

         var2.dI = var2.dH + var1;
         this.dH += var1;
         dv var10000 = this.qw;
         fR.m(var10000);
         var10000.b(var2);
         return var2;
      }
   }

   public final void lJ() {
      if (this.qw == this) {
         boolean var3 = false;
         String var4 = "cannot compact";
         throw new IllegalStateException(var4.toString());
      } else {
         dv var10000 = this.qw;
         fR.m(var10000);
         if (var10000.qu) {
            int var1 = this.dI - this.dH;
            dv var10001 = this.qw;
            fR.m(var10001);
            int var5 = 8192 - var10001.dI;
            var10001 = this.qw;
            fR.m(var10001);
            int var7;
            if (var10001.qt) {
               var7 = 0;
            } else {
               dv var8 = this.qw;
               fR.m(var8);
               var7 = var8.dH;
            }

            int var2 = var5 + var7;
            if (var1 <= var2) {
               dv var9 = this.qw;
               fR.m(var9);
               this.a(var9, var1);
               this.lI();
               dw.c(this);
            }
         }
      }
   }

   public final void a(dv var1, int var2) {
      fR.c(var1, (String)"");
      if (!var1.qu) {
         boolean var3 = false;
         String var4 = "only owner can write";
         throw new IllegalStateException(var4.toString());
      } else {
         if (var1.dI + var2 > 8192) {
            if (var1.qt) {
               throw new IllegalArgumentException();
            }

            if (var1.dI + var2 - var1.dH > 8192) {
               throw new IllegalArgumentException();
            }

            eI.a(var1.qs, var1.qs, 0, var1.dH, var1.dI, 2, (Object)null);
            var1.dI -= var1.dH;
            var1.dH = 0;
         }

         eI.a(this.qs, var1.qs, var1.dI, this.dH, this.dH + var2);
         var1.dI += var2;
         this.dH += var2;
      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
