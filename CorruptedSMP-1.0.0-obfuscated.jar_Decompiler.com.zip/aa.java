import java.io.IOException;
import java.math.BigDecimal;

public enum aa implements ab {
   DOUBLE {
      public Double g(aT var1) throws IOException {
         return var1.aP();
      }

      // $FF: synthetic method
      public Number h(aT var1) throws IOException {
         return this.g(var1);
      }
   },
   LAZILY_PARSED_NUMBER {
      public Number h(aT var1) throws IOException {
         return new ap(var1.aM());
      }
   },
   LONG_OR_DOUBLE {
      public Number h(aT var1) throws IOException, T {
         String var2 = var1.aM();

         try {
            return Long.parseLong(var2);
         } catch (NumberFormatException var6) {
            try {
               Double var4 = Double.valueOf(var2);
               if ((var4.isInfinite() || var4.isNaN()) && !var1.bm()) {
                  throw new aW("JSON forbids NaN and infinities: " + var4 + "; at path " + var1.aV());
               } else {
                  return var4;
               }
            } catch (NumberFormatException var5) {
               throw new T("Cannot parse " + var2 + "; at path " + var1.aV(), var5);
            }
         }
      }
   },
   BIG_DECIMAL {
      public BigDecimal i(aT var1) throws IOException {
         String var2 = var1.aM();

         try {
            return new BigDecimal(var2);
         } catch (NumberFormatException var4) {
            throw new T("Cannot parse " + var2 + "; at path " + var1.aV(), var4);
         }
      }

      // $FF: synthetic method
      public Number h(aT var1) throws IOException {
         return this.i(var1);
      }
   };

   private aa() {
   }
}
