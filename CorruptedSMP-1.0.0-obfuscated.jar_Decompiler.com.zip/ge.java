import java.util.NoSuchElementException;

public final class ge extends fd {
   private final int sY;
   private final int sZ;
   private boolean ta;
   private int tb;

   public ge(int var1, int var2, int var3) {
      this.sY = var3;
      this.sZ = var2;
      this.ta = this.sY > 0 ? var1 <= var2 : var1 >= var2;
      this.tb = this.ta ? var1 : this.sZ;
   }

   public boolean hasNext() {
      return this.ta;
   }

   public int aR() {
      int var1 = this.tb;
      if (var1 == this.sZ) {
         if (!this.ta) {
            throw new NoSuchElementException();
         }

         this.ta = false;
      } else {
         this.tb += this.sY;
      }

      return var1;
   }
}
