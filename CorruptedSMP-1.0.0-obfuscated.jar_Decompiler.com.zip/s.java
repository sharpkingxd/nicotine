import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class s {
   public static boolean a(Player var0, CorruptedSMPPlugin var1) {
      int var2 = var1.getConfig().getInt("corruptions.health.ability-duration", 30);
      var0.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, var2 * 20, 1, false, true));
      double var3 = var0.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
      var0.setHealth(var3);
      var0.getWorld().spawnParticle(Particle.HEART, var0.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
      var0.playSound(var0.getLocation(), "custom:health", 2.0F, 1.0F);
      var0.playSound(var0.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
      String var5 = var1.getConfig().getString("messages.ability-activated").replace("{ability}", "Ancient Healing");
      var0.sendMessage(a(var5, var1));
      return true;
   }

   private static String a(String var0, CorruptedSMPPlugin var1) {
      String var2 = var1.getConfig().getString("messages.prefix", "");
      return (var2 + var0).replace("&", "§");
   }
}
