public class dI {
   private d result;
   private a data;

   public d mb() {
      return this.result;
   }

   public a mc() {
      return this.data;
   }

   public boolean md() {
      return this.result != null && this.result.md();
   }

   public static class a {
      private b license;
      private String challenge;

      public b me() {
         return this.license;
      }
   }

   public static class b {
      private String id;
      private String key;
      private String status;
      private String expiresAt;
      private String productId;
      private String customerId;
      private c metadata;

      public String mf() {
         return this.id;
      }

      public String mg() {
         return this.status;
      }

      public String mh() {
         return this.expiresAt;
      }
   }

   public static class c {
      private String hwid;
      private String ip;
   }

   public static class d {
      private String timestamp;
      private boolean valid;
      private String details;
      private String code;

      public boolean md() {
         return this.valid;
      }

      public String mi() {
         return this.details;
      }
   }
}
