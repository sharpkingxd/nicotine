import java.io.IOException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

final class aP extends ac<Time> {
   static final ad ds = new ad() {
      public <T> ac<T> a(K var1, aS<T> var2) {
         return var2.bk() == Time.class ? new aP() : null;
      }
   };
   private final DateFormat dt;

   private aP() {
      this.dt = new SimpleDateFormat("hh:mm:ss a");
   }

   public Time M(aT var1) throws IOException {
      if (var1.aI() == aU.dY) {
         var1.aO();
         return null;
      } else {
         String var2 = var1.aM();

         try {
            synchronized(this) {
               Date var4 = this.dt.parse(var2);
               return new Time(var4.getTime());
            }
         } catch (ParseException var7) {
            throw new X("Failed parsing '" + var2 + "' as SQL Time; at path " + var1.aV(), var7);
         }
      }
   }

   public void a(aV var1, Time var2) throws IOException {
      if (var2 == null) {
         var1.be();
      } else {
         String var3;
         synchronized(this) {
            var3 = this.dt.format(var2);
         }

         var1.t(var3);
      }
   }

   // $FF: synthetic method
   public Object b(aT var1) throws IOException {
      return this.M(var1);
   }
}
