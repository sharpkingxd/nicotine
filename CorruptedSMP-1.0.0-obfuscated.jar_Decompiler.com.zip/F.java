import com.corruptedsmp.CorruptedSMPPlugin;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StateFlag.State;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class F {
   private final CorruptedSMPPlugin aq;
   private boolean ar = false;
   private WorldGuardPlugin as;

   public F(CorruptedSMPPlugin var1) {
      this.aq = var1;
      this.T();
   }

   private void T() {
      try {
         if (this.aq.getServer().getPluginManager().getPlugin("WorldGuard") != null) {
            this.as = (WorldGuardPlugin)this.aq.getServer().getPluginManager().getPlugin("WorldGuard");
            this.ar = true;
            this.aq.getLogger().info("[WorldGuard] Integration enabled!");
            this.aq.getLogger().info("[WorldGuard] Abilities will respect PvP flags in regions");
         } else {
            this.aq.getLogger().info("[WorldGuard] Not found - abilities will work everywhere");
         }
      } catch (Exception var2) {
         this.aq.getLogger().warning("[WorldGuard] Failed to initialize: " + var2.getMessage());
         this.ar = false;
      }

   }

   public boolean d(Location var1) {
      if (!this.ar) {
         return true;
      } else {
         try {
            RegionContainer var2 = WorldGuard.getInstance().getPlatform().getRegionContainer();
            RegionQuery var3 = var2.createQuery();
            com.sk89q.worldedit.util.Location var4 = BukkitAdapter.adapt(var1);
            StateFlag.State var5 = var3.queryState(var4, (LocalPlayer)null, new StateFlag[]{Flags.PVP});
            return var5 != State.DENY;
         } catch (Exception var6) {
            this.aq.getLogger().warning("[WorldGuard] Error checking PvP flag: " + var6.getMessage());
            return true;
         }
      }
   }

   public boolean a(Player var1, Player var2) {
      if (!this.d(var1.getLocation())) {
         return false;
      } else {
         return this.d(var2.getLocation());
      }
   }

   public boolean a(EntityDamageByEntityEvent var1) {
      if (!this.ar) {
         return true;
      } else if (var1.getDamager() instanceof Player && var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         Player var3 = (Player)var1.getEntity();
         return this.a(var2, var3);
      } else {
         return true;
      }
   }

   public void e(Player var1) {
      String var2 = this.aq.getConfig().getString("messages.prefix", "").replace("&", "§");
      var1.sendMessage(var2 + "§c§l✗ Abilities are disabled in PvP-protected regions!");
   }
}
