import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class cu implements Closeable {
   public static final a od = new a((fP)null);
   private final df oe;
   private final boolean of;
   private final de og;
   private int oh;
   private boolean closed;
   private final co.b oi;
   private static final Logger oj = Logger.getLogger(cp.class.getName());

   public cu(df var1, boolean var2) {
      fR.c(var1, (String)"");
      super();
      this.oe = var1;
      this.of = var2;
      this.og = new de();
      this.oh = 16384;
      this.oi = new co.b(0, false, this.og, 3, (fP)null);
   }

   public final synchronized void jq() throws IOException {
      if (this.closed) {
         throw new IOException("closed");
      } else if (this.of) {
         if (oj.isLoggable(Level.FINE)) {
            oj.fine(bD.a(">> CONNECTION " + cp.na.lk()));
         }

         this.oe.f(cp.na);
         this.oe.flush();
      }
   }

   public final synchronized void b(cx var1) throws IOException {
      fR.c(var1, (String)"");
      if (this.closed) {
         throw new IOException("closed");
      } else {
         this.oh = var1.R(this.oh);
         if (var1.jw() != -1) {
            this.oi.D(var1.jw());
         }

         this.b(0, 0, 4, 1);
         this.oe.flush();
      }
   }

   public final synchronized void b(int var1, int var2, List<cn> var3) throws IOException {
      fR.c(var3, (String)"");
      if (this.closed) {
         throw new IOException("closed");
      } else {
         this.oi.g(var3);
         long var4 = this.og.kH();
         int var6 = (int)Math.min((long)this.oh - 4L, var4);
         this.b(var1, var6 + 4, 5, var4 == (long)var6 ? 4 : 0);
         this.oe.ac(var2 & Integer.MAX_VALUE);
         this.oe.b(this.og, (long)var6);
         if (var4 > (long)var6) {
            this.e(var1, var4 - (long)var6);
         }

      }
   }

   public final synchronized void jr() throws IOException {
      if (this.closed) {
         throw new IOException("closed");
      } else {
         this.oe.flush();
      }
   }

   public final synchronized void e(int var1, cm var2) throws IOException {
      fR.c(var2, (String)"");
      if (this.closed) {
         throw new IOException("closed");
      } else if (var2.hU() == -1) {
         String var3 = "Failed requirement.";
         throw new IllegalArgumentException(var3.toString());
      } else {
         this.b(var1, 4, 3, 0);
         this.oe.ac(var2.hU());
         this.oe.flush();
      }
   }

   public final int js() {
      return this.oh;
   }

   public final synchronized void a(boolean var1, int var2, de var3, int var4) throws IOException {
      if (this.closed) {
         throw new IOException("closed");
      } else {
         int var5 = 0;
         if (var1) {
            var5 |= 1;
         }

         this.a(var2, var5, var3, var4);
      }
   }

   public final void a(int var1, int var2, de var3, int var4) throws IOException {
      this.b(var1, var4, 0, var2);
      if (var4 > 0) {
         df var10000 = this.oe;
         fR.m(var3);
         var10000.b(var3, (long)var4);
      }

   }

   public final synchronized void c(cx var1) throws IOException {
      fR.c(var1, (String)"");
      if (this.closed) {
         throw new IOException("closed");
      } else {
         this.b(0, var1.jy() * 6, 4, 0);

         for(int var2 = 0; var2 < 10; ++var2) {
            if (var1.P(var2)) {
               int var10000;
               switch (var2) {
                  case 4:
                     var10000 = 3;
                     break;
                  case 5:
                  case 6:
                  default:
                     var10000 = var2;
                     break;
                  case 7:
                     var10000 = 4;
               }

               int var3 = var10000;
               this.oe.ab(var3);
               this.oe.ac(var1.Q(var2));
            }
         }

         this.oe.flush();
      }
   }

   public final synchronized void c(boolean var1, int var2, int var3) throws IOException {
      if (this.closed) {
         throw new IOException("closed");
      } else {
         this.b(0, 8, 6, var1 ? 1 : 0);
         this.oe.ac(var2);
         this.oe.ac(var3);
         this.oe.flush();
      }
   }

   public final synchronized void a(int var1, cm var2, byte[] var3) throws IOException {
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      if (this.closed) {
         throw new IOException("closed");
      } else if (var2.hU() == -1) {
         boolean var4 = false;
         String var5 = "errorCode.httpCode == -1";
         throw new IllegalArgumentException(var5.toString());
      } else {
         this.b(0, 8 + var3.length, 7, 0);
         this.oe.ac(var1);
         this.oe.ac(var2.hU());
         if (var3.length != 0) {
            this.oe.d(var3);
         }

         this.oe.flush();
      }
   }

   public final synchronized void d(int var1, long var2) throws IOException {
      if (this.closed) {
         throw new IOException("closed");
      } else if (var2 == 0L || var2 > 2147483647L) {
         boolean var4 = false;
         String var5 = "windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: " + var2;
         throw new IllegalArgumentException(var5.toString());
      } else {
         this.b(var1, 4, 8, 0);
         this.oe.ac((int)var2);
         this.oe.flush();
      }
   }

   public final void b(int var1, int var2, int var3, int var4) throws IOException {
      if (oj.isLoggable(Level.FINE)) {
         oj.fine(cp.mZ.a(false, var1, var2, var3, var4));
      }

      if (var2 > this.oh) {
         boolean var7 = false;
         String var8 = "FRAME_SIZE_ERROR length > " + this.oh + ": " + var2;
         throw new IllegalArgumentException(var8.toString());
      } else if ((var1 & Integer.MIN_VALUE) != 0) {
         boolean var5 = false;
         String var6 = "reserved bit set: " + var1;
         throw new IllegalArgumentException(var6.toString());
      } else {
         bD.a(this.oe, var2);
         this.oe.aa(var3 & 255);
         this.oe.aa(var4 & 255);
         this.oe.ac(var1 & Integer.MAX_VALUE);
      }
   }

   public synchronized void close() throws IOException {
      this.closed = true;
      this.oe.close();
   }

   private final void e(int var1, long var2) throws IOException {
      long var4 = var2;

      while(var4 > 0L) {
         long var6 = Math.min((long)this.oh, var4);
         var4 -= var6;
         this.b(var1, (int)var6, 9, var4 == 0L ? 4 : 0);
         this.oe.b(this.og, var6);
      }

   }

   public final synchronized void a(boolean var1, int var2, List<cn> var3) throws IOException {
      fR.c(var3, (String)"");
      if (this.closed) {
         throw new IOException("closed");
      } else {
         this.oi.g(var3);
         long var4 = this.og.kH();
         long var6 = Math.min((long)this.oh, var4);
         int var8 = var4 == var6 ? 4 : 0;
         if (var1) {
            var8 |= 1;
         }

         this.b(var2, (int)var6, 1, var8);
         this.oe.b(this.og, var6);
         if (var4 > var6) {
            this.e(var2, var4 - var6);
         }

      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
