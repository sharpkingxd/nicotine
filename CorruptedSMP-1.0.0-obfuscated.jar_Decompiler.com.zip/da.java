import java.util.Arrays;

public final class da {
   private static final byte[] pN;
   private static final byte[] pO;

   public static final byte[] aP(String var0) {
      fR.c(var0, (String)"");

      int var1;
      for(var1 = var0.length(); var1 > 0; --var1) {
         char var2 = var0.charAt(var1 - 1);
         if (var2 != '=' && var2 != '\n' && var2 != '\r' && var2 != ' ' && var2 != '\t') {
            break;
         }
      }

      byte[] var10 = new byte[(int)((long)var1 * 6L / 8L)];
      int var3 = 0;
      int var4 = 0;
      int var5 = 0;
      int var6 = 0;

      for(int var7 = var1; var6 < var7; ++var6) {
         char var8 = var0.charAt(var6);
         int var9 = 0;
         if ('A' <= var8 ? var8 < '[' : false) {
            var9 = var8 - 65;
         } else if ('a' <= var8 ? var8 < '{' : false) {
            var9 = var8 - 71;
         } else if ('0' <= var8 ? var8 < ':' : false) {
            var9 = var8 + 4;
         } else if (var8 != '+' && var8 != '-') {
            if (var8 != '/' && var8 != '_') {
               if (var8 != '\n' && var8 != '\r' && var8 != ' ' && var8 != '\t') {
                  return null;
               }
               continue;
            }

            var9 = 63;
         } else {
            var9 = 62;
         }

         var5 = var5 << 6 | var9;
         ++var4;
         if (var4 % 4 == 0) {
            var10[var3++] = (byte)(var5 >> 16);
            var10[var3++] = (byte)(var5 >> 8);
            var10[var3++] = (byte)var5;
         }
      }

      var6 = var4 % 4;
      switch (var6) {
         case 1:
            return null;
         case 2:
            var5 <<= 12;
            var10[var3++] = (byte)(var5 >> 16);
            break;
         case 3:
            var5 <<= 6;
            var10[var3++] = (byte)(var5 >> 16);
            var10[var3++] = (byte)(var5 >> 8);
      }

      if (var3 == var10.length) {
         return var10;
      } else {
         byte[] var10000 = Arrays.copyOf(var10, var3);
         fR.b(var10000, "");
         return var10000;
      }
   }

   public static final String a(byte[] var0, byte[] var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      int var2 = (var0.length + 2) / 3 * 4;
      byte[] var3 = new byte[var2];
      int var4 = 0;
      int var5 = var0.length - var0.length % 3;

      int var6;
      byte var9;
      for(var6 = 0; var6 < var5; var3[var4++] = var1[var9 & 63]) {
         byte var7 = var0[var6++];
         byte var8 = var0[var6++];
         var9 = var0[var6++];
         var3[var4++] = var1[(var7 & 255) >> 2];
         var3[var4++] = var1[(var7 & 3) << 4 | (var8 & 255) >> 4];
         var3[var4++] = var1[(var8 & 15) << 2 | (var9 & 255) >> 6];
      }

      switch (var0.length - var5) {
         case 1:
            byte var23 = var0[var6];
            var3[var4++] = var1[(var23 & 255) >> 2];
            var3[var4++] = var1[(var23 & 3) << 4];
            var3[var4++] = 61;
            var3[var4] = 61;
            break;
         case 2:
            byte var22 = var0[var6++];
            var9 = var0[var6];
            var3[var4++] = var1[(var22 & 255) >> 2];
            var3[var4++] = var1[(var22 & 3) << 4 | (var9 & 255) >> 4];
            var3[var4++] = var1[(var9 & 15) << 2];
            var3[var4] = 61;
      }

      return dD.e(var3);
   }

   // $FF: synthetic method
   public static String a(byte[] var0, byte[] var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = pN;
      }

      return a(var0, var1);
   }

   static {
      pN = dh.pS.aU("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/").lc();
      pO = dh.pS.aU("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_").lc();
   }
}
