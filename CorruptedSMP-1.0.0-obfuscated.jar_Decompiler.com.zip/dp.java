import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Logger;

// $FF: synthetic class
final class dp {
   private static final Logger qh = Logger.getLogger("com.corruptedsmp.libs.okio.Okio");

   public static final dy b(OutputStream var0) {
      fR.c(var0, (String)"");
      return new ds(var0, new dB());
   }

   public static final dA b(InputStream var0) {
      fR.c(var0, (String)"");
      return new dn(var0, new dB());
   }

   public static final dy e(Socket var0) throws IOException {
      fR.c(var0, (String)"");
      dz var1 = new dz(var0);
      OutputStream var10002 = var0.getOutputStream();
      fR.b(var10002, "");
      ds var2 = new ds(var10002, var1);
      return var1.a(var2);
   }

   public static final dA f(Socket var0) throws IOException {
      fR.c(var0, (String)"");
      dz var1 = new dz(var0);
      InputStream var10002 = var0.getInputStream();
      fR.b(var10002, "");
      dn var2 = new dn(var10002, var1);
      return var1.a(var2);
   }

   public static final dy b(File var0, boolean var1) throws FileNotFoundException {
      fR.c(var0, (String)"");
      return do.a((OutputStream)(new FileOutputStream(var0, var1)));
   }

   // $FF: synthetic method
   public static dy a(File var0, boolean var1, int var2, Object var3) throws FileNotFoundException {
      if ((var2 & 1) != 0) {
         var1 = false;
      }

      return do.a(var0, var1);
   }

   public static final dy j(File var0) throws FileNotFoundException {
      fR.c(var0, (String)"");
      return do.a((OutputStream)(new FileOutputStream(var0, true)));
   }

   public static final dA k(File var0) throws FileNotFoundException {
      fR.c(var0, (String)"");
      return new dn((InputStream)(new FileInputStream(var0)), dB.NONE);
   }

   public static final boolean b(AssertionError var0) {
      fR.c(var0, (String)"");
      boolean var1;
      if (var0.getCause() != null) {
         String var10000 = var0.getMessage();
         if (var10000 != null ? gA.c((CharSequence)var10000, (CharSequence)"getsockname failed", false, 2, (Object)null) : false) {
            var1 = true;
            return var1;
         }
      }

      var1 = false;
      return var1;
   }

   // $FF: synthetic method
   public static final Logger lD() {
      return qh;
   }
}
