import android.annotation.SuppressLint;
import android.os.Build.VERSION;
import android.security.NetworkSecurityPolicy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;

public final class cA extends cH {
   public static final a ow = new a((fP)null);
   private final List<cR> ox;
   private static final boolean oy;

   public cA() {
      cR[] var1 = new cR[]{cI.oX.kh(), new cQ(cM.pf.kl()), new cQ(cP.ps.kq()), new cQ(cN.pm.kn())};
      Iterable var11 = (Iterable)eO.l(var1);
      boolean var2 = false;
      Collection var4 = (Collection)(new ArrayList());
      boolean var5 = false;

      for(Object var7 : var11) {
         cR var8 = (cR)var7;
         boolean var9 = false;
         if (var8.jB()) {
            var4.add(var7);
         }
      }

      this.ox = (List)var4;
   }

   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      Iterable var5 = (Iterable)this.ox;
      Iterator var6 = var5.iterator();

      Object var10000;
      while(true) {
         if (var6.hasNext()) {
            Object var7 = var6.next();
            cR var8 = (cR)var7;
            boolean var9 = false;
            if (!var8.f(var1)) {
               continue;
            }

            var10000 = var7;
            break;
         }

         var10000 = null;
         break;
      }

      cR var4 = (cR)var10000;
      if (var4 != null) {
         var4.a(var1, var2, var3);
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      Iterable var2 = (Iterable)this.ox;
      Iterator var3 = var2.iterator();

      Object var10000;
      while(true) {
         if (var3.hasNext()) {
            Object var4 = var3.next();
            cR var5 = (cR)var4;
            boolean var6 = false;
            if (!var5.f(var1)) {
               continue;
            }

            var10000 = var4;
            break;
         }

         var10000 = null;
         break;
      }

      return (cR)var10000 != null ? ((cR)var10000).d(var1) : null;
   }

   @SuppressLint({"NewApi"})
   public boolean aG(String var1) {
      fR.c(var1, (String)"");
      return NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted(var1);
   }

   public cX a(X509TrustManager var1) {
      fR.c(var1, (String)"");
      cJ var10000 = cJ.oY.d(var1);
      return var10000 != null ? (cX)var10000 : super.a(var1);
   }

   static {
      oy = cH.oU.ka() && VERSION.SDK_INT >= 29;
   }

   public static final class a {
      private a() {
      }

      public final boolean jB() {
         return cA.oy;
      }

      public final cH jC() {
         return this.jB() ? (cH)(new cA()) : null;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
