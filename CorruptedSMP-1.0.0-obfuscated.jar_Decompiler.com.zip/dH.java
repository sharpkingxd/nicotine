import com.corruptedsmp.CorruptedSMPPlugin;
import java.io.IOException;
import java.net.InetAddress;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

public class dH {
   private long qH = 0L;
   private int qI = 0;
   private final CorruptedSMPPlugin qJ;
   private final bu qK;
   private final K qL;
   private BukkitTask qM;
   private String qN;
   private boolean qO;
   private boolean qP;

   public dH(CorruptedSMPPlugin var1) {
      this.qJ = var1;
      this.qK = (new bu.a()).a(10L, TimeUnit.SECONDS).b(10L, TimeUnit.SECONDS).c(10L, TimeUnit.SECONDS).eE();
      this.qL = new K();
      this.qO = false;
      this.qP = false;
   }

   public boolean lR() {
      this.qN = this.qJ.getConfig().getString("license.key", "");
      boolean var1 = !this.qN.isEmpty() && !this.qN.equals("ENTER-YOUR-LICENSE-KEY-HERE");
      if (!var1) {
         this.qJ.getLogger().info("No license key found, checking trial system...");
         return this.lW();
      } else {
         this.qJ.getLogger().info("Verifying license with Lukittu...");

         try {
            String var2 = this.lV();
            String var3 = String.format("{\"licenseKey\":\"%s\",\"productId\":\"%s\",\"hardwareIdentifier\":\"%s\"}", this.qN, "ac302d5d-5235-4b4d-93d2-55827fe50545", var2);
            bx var4 = bx.a(var3, bt.ad("application/json"));
            bw var5 = (new bw.a()).aj("https://app.lukittu.com/api/v1/client/teams/7ab8fddb-f394-4e87-b075-e361d55c0c4b/verification/verify").a(var4).i("Content-Type", "application/json").eQ();
            by var6 = this.qK.d(var5).ck();

            boolean var17;
            label123: {
               boolean var19;
               label124: {
                  boolean var9;
                  try {
                     String var7 = var6.eZ() != null ? var6.eZ().fm() : "";
                     if (!var6.fg()) {
                        this.qJ.getLogger().severe("License verification failed: HTTP " + var6.eW());
                        this.qJ.getLogger().severe("Response: " + var7);
                        this.ai(var6.eW());
                        this.lY();
                        var17 = false;
                        break label123;
                     }

                     dI var8 = (dI)this.qL.a(var7, dI.class);
                     if (var8.md()) {
                        this.qO = true;
                        this.qP = false;
                        if (this.qJ.k() != null && this.qJ.k().mx()) {
                           this.qJ.getLogger().info("Switching from trial mode to licensed mode...");
                           this.qJ.k().my();
                        }

                        String var18 = "N/A";
                        String var10 = "ACTIVE";
                        String var11 = "";
                        if (var8.mc() != null && var8.mc().me() != null) {
                           dI.b var12 = var8.mc().me();
                           var18 = var12.mf() != null ? var12.mf() : "N/A";
                           var10 = var12.mg() != null ? var12.mg() : "ACTIVE";
                           var11 = var12.mh();
                        }

                        this.qJ.getLogger().info("╔════════════════════════════════════════════════════════╗");
                        this.qJ.getLogger().info("║                                                        ║");
                        this.qJ.getLogger().info("║          ✓ LICENSE VERIFIED SUCCESSFULLY!              ║");
                        this.qJ.getLogger().info("║                                                        ║");
                        if (!var18.equals("N/A")) {
                           Logger var20 = this.qJ.getLogger();
                           String var21 = this.e(var18, 36);
                           var20.info("║  License ID: " + var21 + "  ║");
                        }

                        this.qJ.getLogger().info("║  Status: " + var10 + "                                           ║");
                        if (var11 != null && !var11.isEmpty()) {
                           this.qJ.getLogger().info("║  Expires: " + var11 + "               ║");
                        }

                        this.qJ.getLogger().info("║                                                        ║");
                        this.qJ.getLogger().info("║  Thank you for supporting CorruptedSMP!               ║");
                        this.qJ.getLogger().info("║                                                        ║");
                        this.qJ.getLogger().info("╚════════════════════════════════════════════════════════╝");
                        this.qH = System.currentTimeMillis();
                        this.qI = 0;
                        var19 = true;
                        break label124;
                     }

                     Logger var10000 = this.qJ.getLogger();
                     String var10001 = var8.mb() != null ? var8.mb().mi() : "Unknown error";
                     var10000.severe("License verification failed: " + var10001);
                     this.lY();
                     var9 = false;
                  } catch (Throwable var14) {
                     if (var6 != null) {
                        try {
                           var6.close();
                        } catch (Throwable var13) {
                           var14.addSuppressed(var13);
                        }
                     }

                     throw var14;
                  }

                  if (var6 != null) {
                     var6.close();
                  }

                  return var9;
               }

               if (var6 != null) {
                  var6.close();
               }

               return var19;
            }

            if (var6 != null) {
               var6.close();
            }

            return var17;
         } catch (IOException var15) {
            this.qJ.getLogger().log(Level.SEVERE, "Failed to connect to Lukittu API. Please check your internet connection.", var15);
            return false;
         } catch (Exception var16) {
            this.qJ.getLogger().log(Level.SEVERE, "Unexpected error during license verification", var16);
            return false;
         }
      }
   }

   public void lS() {
      if (!this.qO) {
         this.qJ.getLogger().warning("Cannot start heartbeat - license is not valid");
      } else {
         this.qJ.getLogger().info("Starting license heartbeat checks (every 15 minutes)...");
         this.qJ.getLogger().info("Offline grace period: 2 hours");
         this.qM = Bukkit.getScheduler().runTaskTimerAsynchronously(this.qJ, () -> {
            try {
               if (!this.lT()) {
                  ++this.qI;
                  long var1 = System.currentTimeMillis() - this.qH;
                  long var3 = 7200000L - var1;
                  if (var1 < 7200000L) {
                     long var5 = var3 / 60000L;
                     this.qJ.getLogger().warning("╔════════════════════════════════════════════════════════╗");
                     this.qJ.getLogger().warning("║                                                        ║");
                     this.qJ.getLogger().warning("║          ⚠ LICENSE HEARTBEAT FAILED!                   ║");
                     this.qJ.getLogger().warning("║                                                        ║");
                     this.qJ.getLogger().warning("║  Failed to verify license with Lukittu API.            ║");
                     Logger var10000 = this.qJ.getLogger();
                     Object[] var10002 = new Object[]{this.qI};
                     var10000.warning("║  Consecutive failures: " + String.format("%-31d", var10002) + " ║");
                     var10000 = this.qJ.getLogger();
                     var10002 = new Object[]{var5};
                     var10000.warning("║  Grace period remaining: " + String.format("%-27d", var10002) + " minutes ║");
                     this.qJ.getLogger().warning("║                                                        ║");
                     this.qJ.getLogger().warning("║  The plugin will continue running but will disable    ║");
                     this.qJ.getLogger().warning("║  if license cannot be verified within grace period.   ║");
                     this.qJ.getLogger().warning("║                                                        ║");
                     this.qJ.getLogger().warning("╚════════════════════════════════════════════════════════╝");
                  } else {
                     this.qJ.getLogger().severe("╔════════════════════════════════════════════════════════╗");
                     this.qJ.getLogger().severe("║                                                        ║");
                     this.qJ.getLogger().severe("║          ✗ LICENSE HEARTBEAT FAILED!                   ║");
                     this.qJ.getLogger().severe("║                                                        ║");
                     this.qJ.getLogger().severe("║  Your license may have been revoked or expired.        ║");
                     this.qJ.getLogger().severe("║  Grace period has expired.                             ║");
                     this.qJ.getLogger().severe("║  The plugin will be disabled in 5 seconds...           ║");
                     this.qJ.getLogger().severe("║                                                        ║");
                     this.lY();
                     this.qJ.getLogger().severe("╚════════════════════════════════════════════════════════╝");
                     Bukkit.getScheduler().runTaskLater(this.qJ, () -> Bukkit.getPluginManager().disablePlugin(this.qJ), 100L);
                  }
               }
            } catch (Exception var7) {
               this.qJ.getLogger().log(Level.WARNING, "Error during heartbeat check", var7);
            }

         }, 18000L, 18000L);
      }
   }

   private boolean lT() {
      try {
         String var1 = this.lV();
         String var2 = String.format("{\"licenseKey\":\"%s\",\"productId\":\"%s\",\"hardwareIdentifier\":\"%s\"}", this.qN, "ac302d5d-5235-4b4d-93d2-55827fe50545", var1);
         bx var3 = bx.a(var2, bt.ad("application/json"));
         bw var4 = (new bw.a()).aj("https://app.lukittu.com/api/v1/client/teams/7ab8fddb-f394-4e87-b075-e361d55c0c4b/verification/heartbeat").a(var3).i("Content-Type", "application/json").eQ();
         by var5 = this.qK.d(var4).ck();

         boolean var12;
         label52: {
            try {
               if (var5.fg()) {
                  this.qJ.getLogger().info("License heartbeat successful");
                  this.qH = System.currentTimeMillis();
                  this.qI = 0;
                  var12 = true;
                  break label52;
               }

               this.qJ.getLogger().warning("License heartbeat failed: HTTP " + var5.eW());
               var12 = false;
            } catch (Throwable var9) {
               if (var5 != null) {
                  try {
                     var5.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (var5 != null) {
               var5.close();
            }

            return var12;
         }

         if (var5 != null) {
            var5.close();
         }

         return var12;
      } catch (IOException var10) {
         this.qJ.getLogger().log(Level.WARNING, "Failed to send heartbeat to Lukittu API", var10);
         return false;
      } catch (Exception var11) {
         this.qJ.getLogger().log(Level.WARNING, "Unexpected error during heartbeat", var11);
         return false;
      }
   }

   public void lU() {
      if (this.qM != null) {
         this.qM.cancel();
         this.qM = null;
         this.qJ.getLogger().info("License heartbeat stopped");
      }

   }

   private String lV() {
      try {
         String var1 = InetAddress.getLocalHost().getHostAddress();
         int var2 = Bukkit.getPort();
         String var3 = var1 + ":" + var2 + ":" + Bukkit.getVersion();
         MessageDigest var4 = MessageDigest.getInstance("SHA-256");
         byte[] var5 = var4.digest(var3.getBytes("UTF-8"));
         StringBuilder var6 = new StringBuilder();

         for(byte var10 : var5) {
            String var11 = Integer.toHexString(255 & var10);
            if (var11.length() == 1) {
               var6.append('0');
            }

            var6.append(var11);
         }

         return var6.toString();
      } catch (Exception var12) {
         this.qJ.getLogger().log(Level.WARNING, "Failed to generate hardware ID", var12);
         return "unknown-hwid";
      }
   }

   private void ai(int var1) {
      switch (var1) {
         case 400:
            this.qJ.getLogger().severe("Invalid license key format");
            break;
         case 401:
            this.qJ.getLogger().severe("License key not found or invalid");
            break;
         case 403:
            this.qJ.getLogger().severe("License has been revoked or suspended");
            break;
         case 404:
            this.qJ.getLogger().severe("Product or team not found");
            break;
         case 429:
            this.qJ.getLogger().severe("Too many verification attempts. Please wait and try again.");
            break;
         case 500:
         case 502:
         case 503:
            this.qJ.getLogger().severe("Lukittu API is temporarily unavailable. Please try again later.");
            break;
         default:
            this.qJ.getLogger().severe("Unknown error occurred during verification");
      }

   }

   private String e(String var1, int var2) {
      if (var1 == null) {
         return "";
      } else {
         return var1.length() > var2 ? var1.substring(0, var2) : var1;
      }
   }

   private boolean lW() {
      dJ var1 = this.qJ.k();
      if (var1 == null) {
         this.qJ.getLogger().severe("Trial system not initialized!");
         return false;
      } else if (var1.mj()) {
         this.qP = true;
         this.qO = false;
         return true;
      } else {
         this.qJ.getLogger().severe("╔════════════════════════════════════════════════════════╗");
         this.qJ.getLogger().severe("║                                                        ║");
         this.qJ.getLogger().severe("║          ✗ TRIAL EXPIRED & NO LICENSE KEY              ║");
         this.qJ.getLogger().severe("║                                                        ║");
         this.qJ.getLogger().severe("║  Your 24-hour trial has expired.                       ║");
         this.qJ.getLogger().severe("║                                                        ║");
         this.qJ.getLogger().severe("║  Purchase a license at:                                ║");
         this.qJ.getLogger().severe("║  https://discord.gg/enzFpD976J                         ║");
         this.qJ.getLogger().severe("║                                                        ║");
         this.qJ.getLogger().severe("║  Then add your license key to config.yml:             ║");
         this.qJ.getLogger().severe("║  license:                                              ║");
         this.qJ.getLogger().severe("║    key: YOUR-LICENSE-KEY-HERE                          ║");
         this.qJ.getLogger().severe("║                                                        ║");
         this.qJ.getLogger().severe("╚════════════════════════════════════════════════════════╝");
         return false;
      }
   }

   public boolean lX() {
      return this.qP;
   }

   private void lY() {
      this.qJ.getLogger().severe("║                                                        ║");
      this.qJ.getLogger().severe("║  Need help? Contact support:                           ║");
      this.qJ.getLogger().severe("║  Discord: " + this.f("discord.gg/GZGvJDyMTx", 43) + " ║");
      this.qJ.getLogger().severe("║  Email: " + this.f("dawoodkhan554477@gmail.com", 45) + " ║");
      this.qJ.getLogger().severe("║                                                        ║");
   }

   private String f(String var1, int var2) {
      if (var1.length() >= var2) {
         return var1.substring(0, var2);
      } else {
         int var3 = (var2 - var1.length()) / 2;
         StringBuilder var4 = new StringBuilder();

         for(int var5 = 0; var5 < var3; ++var5) {
            var4.append(" ");
         }

         var4.append(var1);

         while(var4.length() < var2) {
            var4.append(" ");
         }

         return var4.toString();
      }
   }
}
