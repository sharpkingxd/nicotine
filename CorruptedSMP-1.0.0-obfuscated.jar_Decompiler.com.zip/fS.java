import java.io.Serializable;

public abstract class fS<R> implements fQ<R>, Serializable {
   private final int arity;

   public fS(int var1) {
      this.arity = var1;
   }

   public String toString() {
      String var10000 = fU.a(this);
      fR.b(var10000, "");
      return var10000;
   }
}
