import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class eh implements Listener {
   private final CorruptedSMPPlugin rF;

   public eh(CorruptedSMPPlugin var1) {
      this.rF = var1;
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      HumanEntity var3 = var1.getWhoClicked();
      if (var3 instanceof Player var2) {
         String var11 = var1.getView().getTitle();
         if (var11.equals("§8§lCorruption Recipes") || var11.contains("§8Recipe")) {
            var1.setCancelled(true);
            ItemStack var4 = var1.getCurrentItem();
            if (var4 == null || var4.getType() == Material.AIR) {
               return;
            }

            if (var11.equals("§8§lCorruption Recipes") && var4.getType() == Material.FLOW_BANNER_PATTERN && var4.hasItemMeta()) {
               ItemMeta var5 = var4.getItemMeta();
               if (var5 != null && var5.hasCustomModelData()) {
                  int var6 = var5.getCustomModelData();

                  for(l var10 : l.values()) {
                     if (var10.n() == var6) {
                        eq.b(var2, var10, this.rF);
                        var2.playSound(var2.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
                        return;
                     }
                  }
               }
            }

            if (var11.contains("§8Recipe") && var4.getType() == Material.BARRIER) {
               eq.e(var2, this.rF);
               var2.playSound(var2.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
            }
         }

      }
   }

   @EventHandler
   public void a(InventoryDragEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         String var2 = var1.getView().getTitle();
         if (var2.equals("§8§lCorruption Recipes") || var2.contains("§8Recipe")) {
            var1.setCancelled(true);
         }

      }
   }
}
