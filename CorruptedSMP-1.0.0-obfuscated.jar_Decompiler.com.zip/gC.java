import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class gC extends gB {
   public static final String o(String var0, String var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return gA.a(var0, "", var1);
   }

   // $FF: synthetic method
   public static String a(String var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = "|";
      }

      return gA.o(var0, var1);
   }

   public static final String a(String var0, String var1, String var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      boolean var3 = !gA.b((CharSequence)var2);
      if (!var3) {
         boolean var4 = false;
         String var40 = "marginPrefix must be non-blank string.";
         throw new IllegalArgumentException(var40.toString());
      } else {
         List var39 = gA.g((CharSequence)var0);
         int var5 = var0.length() + var1.length() * var39.size();
         fK var6 = bg(var1);
         boolean var7 = false;
         int var8 = eO.k(var39);
         Iterable var9 = (Iterable)var39;
         boolean var10 = false;
         Collection var12 = (Collection)(new ArrayList());
         boolean var13 = false;
         boolean var15 = false;
         int var16 = 0;

         for(Object var18 : var9) {
            int var19 = var16++;
            if (var19 < 0) {
               eO.nl();
            }

            boolean var22 = false;
            String var23 = (String)var18;
            boolean var25 = false;
            String var44;
            if ((var19 == 0 || var19 == var8) && gA.b((CharSequence)var23)) {
               var44 = null;
            } else {
               label86: {
                  boolean var27 = false;
                  CharSequence var28 = (CharSequence)var23;
                  int var29 = 0;
                  int var30 = 0;
                  int var31 = var28.length();

                  while(true) {
                     if (var30 >= var31) {
                        var42 = -1;
                        break;
                     }

                     char var32 = var28.charAt(var30);
                     boolean var33 = false;
                     if (!gu.g(var32)) {
                        var42 = var30;
                        break;
                     }

                     ++var30;
                  }

                  int var34 = var42;
                  if (var34 == -1) {
                     var44 = null;
                  } else if (gA.a(var23, var2, var34, false, 4, (Object)null)) {
                     var29 = var34 + var2.length();
                     fR.m(var23);
                     var44 = var23.substring(var29);
                     fR.b(var44, "");
                  } else {
                     var44 = null;
                  }

                  if (var44 != null) {
                     String var35 = var44;
                     var44 = (String)var6.invoke(var35);
                     if (var44 != null) {
                        break label86;
                     }
                  }

                  var44 = var23;
               }
            }

            if (var44 != null) {
               String var36 = var44;
               boolean var38 = false;
               var12.add(var36);
            }
         }

         String var45 = ((StringBuilder)eO.a((Iterable)((List)var12), (Appendable)(new StringBuilder(var5)), (CharSequence)"\n", (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (fK)null, 124, (Object)null)).toString();
         fR.b(var45, "");
         return var45;
      }
   }

   private static final fK<String, String> bg(final String var0) {
      return ((CharSequence)var0).length() == 0 ? (fK)null.tK : (fK)(new fK<String, String>() {
         public final String bi(String var1) {
            fR.c(var1, (String)"");
            return var0 + var1;
         }

         // $FF: synthetic method
         public Object invoke(Object var1) {
            return this.bi((String)var1);
         }
      });
   }
}
