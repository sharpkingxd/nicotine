import java.nio.charset.Charset;

public final class gx {
   public static final gx tm = new gx();
   public static final Charset tn;
   public static final Charset to;
   public static final Charset tp;
   public static final Charset tq;
   public static final Charset tr;
   public static final Charset ts;
   private static volatile Charset tt;
   private static volatile Charset tu;

   private gx() {
   }

   public final Charset nL() {
      Charset var10000 = tt;
      if (var10000 == null) {
         gx var2 = this;
         boolean var3 = false;
         var10000 = Charset.forName("UTF-32LE");
         fR.b(var10000, "");
         Charset var4 = var10000;
         tt = var4;
         var10000 = var4;
      }

      return var10000;
   }

   public final Charset nM() {
      Charset var10000 = tu;
      if (var10000 == null) {
         gx var2 = this;
         boolean var3 = false;
         var10000 = Charset.forName("UTF-32BE");
         fR.b(var10000, "");
         Charset var4 = var10000;
         tu = var4;
         var10000 = var4;
      }

      return var10000;
   }

   static {
      Charset var10000 = Charset.forName("UTF-8");
      fR.b(var10000, "");
      tn = var10000;
      var10000 = Charset.forName("UTF-16");
      fR.b(var10000, "");
      to = var10000;
      var10000 = Charset.forName("UTF-16BE");
      fR.b(var10000, "");
      tp = var10000;
      var10000 = Charset.forName("UTF-16LE");
      fR.b(var10000, "");
      tq = var10000;
      var10000 = Charset.forName("US-ASCII");
      fR.b(var10000, "");
      tr = var10000;
      var10000 = Charset.forName("ISO-8859-1");
      fR.b(var10000, "");
      ts = var10000;
   }
}
