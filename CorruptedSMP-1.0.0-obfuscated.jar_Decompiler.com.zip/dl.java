import java.io.EOFException;
import java.io.IOException;
import java.util.Arrays;
import java.util.zip.CRC32;
import java.util.zip.Inflater;

public final class dl implements dA {
   private byte pX;
   private final du pY;
   private final Inflater pZ;
   private final dm qa;
   private final CRC32 qb;

   public dl(dA var1) {
      fR.c(var1, (String)"");
      super();
      this.pY = new du(var1);
      this.pZ = new Inflater(true);
      this.qa = new dm(this.pY, this.pZ);
      this.qb = new CRC32();
   }

   public long a(de var1, long var2) throws IOException {
      fR.c(var1, (String)"");
      if (var2 < 0L) {
         boolean var5 = false;
         String var8 = "byteCount < 0: " + var2;
         throw new IllegalArgumentException(var8.toString());
      } else if (var2 == 0L) {
         return 0L;
      } else {
         if (this.pX == 0) {
            this.ly();
            this.pX = 1;
         }

         if (this.pX == 1) {
            long var4 = var1.kH();
            long var6 = this.qa.a(var1, var2);
            if (var6 != -1L) {
               this.b(var1, var4, var6);
               return var6;
            }

            this.pX = 2;
         }

         if (this.pX == 2) {
            this.lz();
            this.pX = 3;
            if (!this.pY.kK()) {
               throw new IOException("gzip finished without exhausting source");
            }
         }

         return -1L;
      }
   }

   private final void ly() throws IOException {
      this.pY.u(10L);
      du var2 = this.pY;
      short var3 = 0;
      byte var1 = var2.qq.v(3L);
      byte var4 = 1;
      byte var5 = 0;
      boolean var8 = (var1 >> var4 & 1) == 1;
      if (var8) {
         du var9 = this.pY;
         var4 = 0;
         this.b(var9.qq, 0L, 10L);
      }

      var3 = this.pY.kO();
      this.n("ID1ID2", 8075, var3);
      this.pY.A(8L);
      var5 = 2;
      boolean var6 = false;
      if ((var1 >> var5 & 1) == 1) {
         this.pY.u(2L);
         if (var8) {
            du var12 = this.pY;
            var5 = 0;
            this.b(var12.qq, 0L, 2L);
         }

         du var20 = this.pY;
         boolean var7 = false;
         long var13 = (long)(var20.qq.kQ() & '\uffff');
         this.pY.u(var13);
         if (var8) {
            var20 = this.pY;
            var7 = false;
            this.b(var20.qq, 0L, var13);
         }

         this.pY.A(var13);
      }

      var5 = 3;
      var6 = false;
      if ((var1 >> var5 & 1) == 1) {
         long var14 = this.pY.b((byte)0);
         if (var14 == -1L) {
            throw new EOFException();
         }

         if (var8) {
            du var23 = this.pY;
            boolean var27 = false;
            this.b(var23.qq, 0L, var14 + 1L);
         }

         this.pY.A(var14 + 1L);
      }

      var5 = 4;
      var6 = false;
      if ((var1 >> var5 & 1) == 1) {
         long var15 = this.pY.b((byte)0);
         if (var15 == -1L) {
            throw new EOFException();
         }

         if (var8) {
            du var25 = this.pY;
            boolean var28 = false;
            this.b(var25.qq, 0L, var15 + 1L);
         }

         this.pY.A(var15 + 1L);
      }

      if (var8) {
         this.n("FHCRC", this.pY.kQ(), (short)((int)this.qb.getValue()));
         this.qb.reset();
      }

   }

   private final void lz() throws IOException {
      this.n("CRC", this.pY.kR(), (int)this.qb.getValue());
      this.n("ISIZE", this.pY.kR(), (int)this.pZ.getBytesWritten());
   }

   public dB fu() {
      return this.pY.fu();
   }

   public void close() throws IOException {
      this.qa.close();
   }

   private final void b(de var1, long var2, long var4) {
      long var6 = var2;
      long var8 = var4;
      dv var10000 = var1.pR;
      fR.m(var10000);

      dv var10;
      for(var10 = var10000; var6 >= (long)(var10.dI - var10.dH); var10 = var10000) {
         var6 -= (long)(var10.dI - var10.dH);
         var10000 = var10.qv;
         fR.m(var10000);
      }

      while(var8 > 0L) {
         int var11 = (int)((long)var10.dH + var6);
         int var13 = var10.dI - var11;
         boolean var14 = false;
         int var12 = (int)Math.min((long)var13, var8);
         this.qb.update(var10.qs, var11, var12);
         var8 -= (long)var12;
         var6 = 0L;
         var10000 = var10.qv;
         fR.m(var10000);
         var10 = var10000;
      }

   }

   private final void n(String var1, int var2, int var3) {
      if (var3 != var2) {
         String var4 = "%s: actual 0x%08x != expected 0x%08x";
         Object[] var5 = new Object[]{var1, var3, var2};
         String var10002 = String.format(var4, Arrays.copyOf(var5, var5.length));
         fR.b(var10002, "");
         throw new IOException(var10002);
      }
   }
}
