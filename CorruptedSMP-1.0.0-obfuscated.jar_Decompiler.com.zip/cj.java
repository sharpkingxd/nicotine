public final class cj {
   public static final a ml = new a((fP)null);
   private final dg mm;
   private long mn;

   public cj(dg var1) {
      fR.c(var1, (String)"");
      super();
      this.mm = var1;
      this.mn = 262144L;
   }

   public final String hM() {
      String var1 = this.mm.y(this.mn);
      this.mn -= (long)var1.length();
      return var1;
   }

   public final bq hN() {
      bq.a var1 = new bq.a();

      while(true) {
         String var2 = this.hM();
         if (((CharSequence)var2).length() == 0) {
            return var1.cW();
         }

         var1.G(var2);
      }
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
