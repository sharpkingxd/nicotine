import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class y {
   public static boolean a(final Player var0, CorruptedSMPPlugin var1) {
      final int var2 = var1.getConfig().getInt("corruptions.velocity.ability-duration", 10);
      var0.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, var2 * 20, 5, false, true));
      Vector var3 = var0.getLocation().getDirection().multiply(2);
      var0.setVelocity(var3);
      (new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            if (this.ticks >= var2 * 20) {
               this.cancel();
            } else {
               Vector var1 = var0.getLocation().getDirection().normalize();
               Location var2x = var0.getLocation();

               for(Entity var4 : var0.getNearbyEntities((double)2.0F, (double)2.0F, (double)2.0F)) {
                  if (var4 instanceof LivingEntity && !var4.equals(var0)) {
                     Vector var5 = var4.getLocation().toVector().subtract(var2x.toVector()).normalize();
                     double var6 = var1.dot(var5);
                     if (var6 > (double)0.5F) {
                        Vector var8 = var5.multiply((double)1.5F).setY(0.3);
                        var4.setVelocity(var8);
                        var4.getWorld().spawnParticle(Particle.CLOUD, var4.getLocation(), 5, 0.3, 0.3, 0.3, 0.1);
                     }
                  }
               }

               ++this.ticks;
            }
         }
      }).runTaskTimer(var1, 0L, 1L);
      var0.getWorld().spawnParticle(Particle.CLOUD, var0.getLocation(), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.2);
      var0.playSound(var0.getLocation(), "custom:velocity", 2.0F, 1.0F);
      var0.playSound(var0.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0F, 1.5F);
      String var4 = var1.getConfig().getString("messages.ability-activated").replace("{ability}", "Dash");
      var0.sendMessage(a(var4, var1));
      return true;
   }

   private static String a(String var0, CorruptedSMPPlugin var1) {
      String var2 = var1.getConfig().getString("messages.prefix", "");
      return (var2 + var0).replace("&", "§");
   }
}
