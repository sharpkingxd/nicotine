import java.util.ArrayList;
import java.util.Iterator;

public final class M extends P implements Iterable<P> {
   private final ArrayList<P> aX = new ArrayList();

   public void a(P var1) {
      if (var1 == null) {
         var1 = R.aY;
      }

      this.aX.add(var1);
   }

   public Iterator<P> iterator() {
      return this.aX.iterator();
   }

   private P W() {
      int var1 = this.aX.size();
      if (var1 == 1) {
         return (P)this.aX.get(0);
      } else {
         throw new IllegalStateException("Array must have size 1, but has size " + var1);
      }
   }

   public Number X() {
      return this.W().X();
   }

   public String Y() {
      return this.W().Y();
   }

   public double Z() {
      return this.W().Z();
   }

   public long aa() {
      return this.W().aa();
   }

   public int ab() {
      return this.W().ab();
   }

   public boolean ac() {
      return this.W().ac();
   }

   public boolean equals(Object var1) {
      return var1 == this || var1 instanceof M && ((M)var1).aX.equals(this.aX);
   }

   public int hashCode() {
      return this.aX.hashCode();
   }
}
