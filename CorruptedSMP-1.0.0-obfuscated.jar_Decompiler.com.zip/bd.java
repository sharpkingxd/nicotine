import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import javax.net.ssl.SSLPeerUnverifiedException;

public final class bd {
   public static final b eB = new b((fP)null);
   private final Set<c> eC;
   private final cX certificateChainCleaner;
   public static final bd eD = (new a()).cm();

   public bd(Set<c> var1, cX var2) {
      fR.c(var1, (String)"");
      super();
      this.eC = var1;
      this.certificateChainCleaner = var2;
   }

   // $FF: synthetic method
   public bd(Set var1, cX var2, int var3, fP var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      this(var1, var2);
   }

   public final cX cl() {
      return this.certificateChainCleaner;
   }

   public final void a(final String var1, final List<? extends Certificate> var2) throws SSLPeerUnverifiedException {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      this.a(var1, new fJ<List<? extends X509Certificate>>() {
         public final List<X509Certificate> cp() {
            List var11;
            label20: {
               cX var10000 = bd.this.cl();
               if (var10000 != null) {
                  var11 = var10000.a(var2, var1);
                  if (var11 != null) {
                     break label20;
                  }
               }

               var11 = var2;
            }

            Iterable var1x = (Iterable)var11;
            boolean var2x = false;
            Collection var4 = (Collection)(new ArrayList(eO.a(var1x, 10)));
            boolean var5 = false;

            for(Object var7 : var1x) {
               Certificate var8 = (Certificate)var7;
               boolean var9 = false;
               fR.m(var8);
               var4.add((X509Certificate)var8);
            }

            return (List)var4;
         }

         // $FF: synthetic method
         public Object invoke() {
            return this.cp();
         }
      });
   }

   public final void a(String var1, fJ<? extends List<? extends X509Certificate>> var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      List var3 = this.x(var1);
      if (!var3.isEmpty()) {
         List var4 = (List)var2.invoke();

         for(X509Certificate var6 : var4) {
            dh var7 = null;
            dh var8 = null;

            for(c var10 : var3) {
               String var11 = var10.cn();
               if (fR.c(var11, (Object)"sha256")) {
                  if (var8 == null) {
                     var8 = eB.b(var6);
                  }

                  if (fR.c(var10.co(), (Object)var8)) {
                     return;
                  }
               } else {
                  if (!fR.c(var11, (Object)"sha1")) {
                     throw new AssertionError("unsupported hashAlgorithm: " + var10.cn());
                  }

                  if (var7 == null) {
                     var7 = eB.a(var6);
                  }

                  if (fR.c(var10.co(), (Object)var7)) {
                     return;
                  }
               }
            }
         }

         StringBuilder var13 = new StringBuilder();
         StringBuilder var14 = var13;
         boolean var15 = false;
         var13.append("Certificate pinning failure!");
         var13.append("\n  Peer certificate chain:");

         for(X509Certificate var18 : var4) {
            var14.append("\n    ");
            var14.append(eB.a((Certificate)var18));
            var14.append(": ");
            var14.append(var18.getSubjectDN().getName());
         }

         var14.append("\n  Pinned certificates for ");
         var14.append(var1);
         var14.append(":");

         for(c var19 : var3) {
            var14.append("\n    ");
            var14.append(var19);
         }

         String var10000 = var13.toString();
         fR.b(var10000, "");
         String var12 = var10000;
         throw new SSLPeerUnverifiedException(var12);
      }
   }

   public final List<c> x(String var1) {
      fR.c(var1, (String)"");
      Iterable var2 = (Iterable)this.eC;
      boolean var3 = false;
      List var4 = eO.nk();

      for(Object var6 : var2) {
         c var7 = (c)var6;
         boolean var8 = false;
         if (var7.y(var1)) {
            if (var4.isEmpty()) {
               var4 = (List)(new ArrayList());
            }

            fR.m(var4);
            fX.n(var4).add(var6);
         }
      }

      return var4;
   }

   public final bd a(cX var1) {
      fR.c(var1, (String)"");
      return fR.c(this.certificateChainCleaner, (Object)var1) ? this : new bd(this.eC, var1);
   }

   public boolean equals(Object var1) {
      return var1 instanceof bd && fR.c(((bd)var1).eC, (Object)this.eC) && fR.c(((bd)var1).certificateChainCleaner, (Object)this.certificateChainCleaner);
   }

   public int hashCode() {
      int var1 = 37;
      var1 = 41 * var1 + this.eC.hashCode();
      int var10000 = 41 * var1;
      cX var10001 = this.certificateChainCleaner;
      var1 = var10000 + (var10001 != null ? var10001.hashCode() : 0);
      return var1;
   }

   public static final class a {
      private final List<c> pins = (List)(new ArrayList());

      public final bd cm() {
         return new bd(eO.e((Iterable)this.pins), (cX)null, 2, (fP)null);
      }
   }

   public static final class b {
      private b() {
      }

      public final dh a(X509Certificate var1) {
         fR.c(var1, (String)"");
         dh.a var10000 = dh.pS;
         byte[] var10001 = var1.getPublicKey().getEncoded();
         fR.b(var10001, "");
         return dh.a.a(var10000, var10001, 0, 0, 3, (Object)null).li();
      }

      public final dh b(X509Certificate var1) {
         fR.c(var1, (String)"");
         dh.a var10000 = dh.pS;
         byte[] var10001 = var1.getPublicKey().getEncoded();
         fR.b(var10001, "");
         return dh.a.a(var10000, var10001, 0, 0, 3, (Object)null).lj();
      }

      public final String a(Certificate var1) {
         fR.c(var1, (String)"");
         if (!(var1 instanceof X509Certificate)) {
            boolean var2 = false;
            String var3 = "Certificate pinning requires X509 certificates";
            throw new IllegalArgumentException(var3.toString());
         } else {
            return "sha256/" + this.b((X509Certificate)var1).lg();
         }
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }

   public static final class c {
      private final String pattern;
      private final String hashAlgorithm;
      private final dh hash;

      public final String cn() {
         return this.hashAlgorithm;
      }

      public final dh co() {
         return this.hash;
      }

      public final boolean y(String var1) {
         fR.c(var1, (String)"");
         boolean var10000;
         if (gA.a(this.pattern, "**.", false, 2, (Object)null)) {
            int var2 = this.pattern.length() - 3;
            int var3 = var1.length() - var2;
            var10000 = gA.a(var1, var1.length() - var2, this.pattern, 3, var2, false, 16, (Object)null) && (var3 == 0 || var1.charAt(var3 - 1) == '.');
         } else if (gA.a(this.pattern, "*.", false, 2, (Object)null)) {
            int var4 = this.pattern.length() - 1;
            int var5 = var1.length() - var4;
            var10000 = gA.a(var1, var1.length() - var4, this.pattern, 1, var4, false, 16, (Object)null) && gA.b((CharSequence)var1, '.', var5 - 1, false, 4, (Object)null) == -1;
         } else {
            var10000 = fR.c(var1, (Object)this.pattern);
         }

         return var10000;
      }

      public String toString() {
         return this.hashAlgorithm + '/' + this.hash.lg();
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (!(var1 instanceof c)) {
            return false;
         } else if (!fR.c(this.pattern, (Object)((c)var1).pattern)) {
            return false;
         } else if (!fR.c(this.hashAlgorithm, (Object)((c)var1).hashAlgorithm)) {
            return false;
         } else {
            return fR.c(this.hash, (Object)((c)var1).hash);
         }
      }

      public int hashCode() {
         int var1 = this.pattern.hashCode();
         var1 = 31 * var1 + this.hashAlgorithm.hashCode();
         var1 = 31 * var1 + this.hash.hashCode();
         return var1;
      }
   }
}
