public final class an {
   private static final int bo = ax();

   private static int ax() {
      String var0 = System.getProperty("java.version");
      return n(var0);
   }

   static int n(String var0) {
      int var1 = o(var0);
      if (var1 == -1) {
         var1 = p(var0);
      }

      return var1 == -1 ? 6 : var1;
   }

   private static int o(String var0) {
      try {
         String[] var1 = var0.split("[._]");
         int var2 = Integer.parseInt(var1[0]);
         return var2 == 1 && var1.length > 1 ? Integer.parseInt(var1[1]) : var2;
      } catch (NumberFormatException var3) {
         return -1;
      }
   }

   private static int p(String var0) {
      try {
         StringBuilder var1 = new StringBuilder();

         for(int var2 = 0; var2 < var0.length(); ++var2) {
            char var3 = var0.charAt(var2);
            if (!Character.isDigit(var3)) {
               break;
            }

            var1.append(var3);
         }

         return Integer.parseInt(var1.toString());
      } catch (NumberFormatException var4) {
         return -1;
      }
   }

   public static boolean ay() {
      return bo >= 9;
   }
}
