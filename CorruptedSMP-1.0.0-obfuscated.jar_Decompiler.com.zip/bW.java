import java.io.IOException;

public final class bW extends RuntimeException {
   private final IOException ly;
   private IOException lz;

   public bW(IOException var1) {
      fR.c(var1, (String)"");
      super((Throwable)var1);
      this.ly = var1;
      this.lz = this.ly;
   }

   public final IOException hw() {
      return this.ly;
   }

   public final IOException hx() {
      return this.lz;
   }

   public final void k(IOException var1) {
      fR.c(var1, (String)"");
      er.a((Throwable)this.ly, (Throwable)var1);
      this.lz = var1;
   }
}
