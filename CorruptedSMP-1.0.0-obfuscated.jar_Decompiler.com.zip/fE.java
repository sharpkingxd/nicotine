public final class fE {
   public static final fD sK;

   static {
      boolean var0 = false;

      fD var10000;
      try {
         Object var25 = Class.forName("fH").newInstance();
         fR.b(var25, "");
         Object var15 = var25;

         try {
            if (var15 == null) {
               throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
            }

            var10000 = (fD)var15;
         } catch (ClassCastException var11) {
            ClassLoader var18 = var15.getClass().getClassLoader();
            ClassLoader var21 = fD.class.getClassLoader();
            if (!fR.c(var18, (Object)var21)) {
               throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var18 + ", base type classloader: " + var21, (Throwable)var11);
            }

            throw var11;
         }
      } catch (ClassNotFoundException var12) {
         try {
            Object var24 = Class.forName("kotlin.internal.JRE8PlatformImplementations").newInstance();
            fR.b(var24, "");
            Object var14 = var24;

            try {
               if (var14 == null) {
                  throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
               }

               var10000 = (fD)var14;
            } catch (ClassCastException var9) {
               ClassLoader var17 = var14.getClass().getClassLoader();
               ClassLoader var20 = fD.class.getClassLoader();
               if (!fR.c(var17, (Object)var20)) {
                  throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var17 + ", base type classloader: " + var20, (Throwable)var9);
               }

               throw var9;
            }
         } catch (ClassNotFoundException var10) {
            try {
               Object var23 = Class.forName("fG").newInstance();
               fR.b(var23, "");
               Object var13 = var23;

               try {
                  if (var13 == null) {
                     throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                  }

                  var10000 = (fD)var13;
               } catch (ClassCastException var7) {
                  ClassLoader var16 = var13.getClass().getClassLoader();
                  ClassLoader var19 = fD.class.getClassLoader();
                  if (!fR.c(var16, (Object)var19)) {
                     throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var16 + ", base type classloader: " + var19, (Throwable)var7);
                  }

                  throw var7;
               }
            } catch (ClassNotFoundException var8) {
               try {
                  Object var22 = Class.forName("kotlin.internal.JRE7PlatformImplementations").newInstance();
                  fR.b(var22, "");
                  Object var1 = var22;

                  try {
                     if (var1 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                     }

                     var10000 = (fD)var1;
                  } catch (ClassCastException var5) {
                     ClassLoader var3 = var1.getClass().getClassLoader();
                     ClassLoader var4 = fD.class.getClassLoader();
                     if (!fR.c(var3, (Object)var4)) {
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + var3 + ", base type classloader: " + var4, (Throwable)var5);
                     }

                     throw var5;
                  }
               } catch (ClassNotFoundException var6) {
                  var10000 = new fD();
               }
            }
         }
      }

      sK = var10000;
   }
}
