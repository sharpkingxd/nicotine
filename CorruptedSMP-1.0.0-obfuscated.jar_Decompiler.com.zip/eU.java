import java.util.Collections;
import java.util.List;

class eU extends eT {
   public static final <T extends Comparable<? super T>> void m(List<T> var0) {
      fR.c(var0, (String)"");
      if (var0.size() > 1) {
         Collections.sort(var0);
      }

   }
}
