import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

public class dW implements Listener {
   private final CorruptedSMPPlugin rs;
   private final Random rt = new Random();

   public dW(CorruptedSMPPlugin var1) {
      this.rs = var1;
   }

   @EventHandler
   public void a(PlayerRiptideEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.rs.d().b(var2)) {
         if (this.rs.d().c(var2) == l.E) {
            Vector var3 = var2.getVelocity();
            var2.setVelocity(var3.multiply((double)2.0F));
            var2.sendMessage("§b§lOCEAN: §7Riptide 2x boost!");
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void l(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rs.d().b(var2)) {
            if (this.rs.d().c(var2) == l.E) {
               Entity var4 = var1.getDamager();
               if (var4 instanceof Player) {
                  Player var5 = (Player)var4;
                  if (var5.getFallDistance() > 0.0F && var5.getVelocity().getY() < (double)0.0F && this.rt.nextDouble() < 0.15) {
                     var1.setCancelled(true);
                     var2.sendMessage("§b§lPHASED! §7You dodged a critical hit!");
                     return;
                  }
               }

               if (var1.getCause() == DamageCause.FIRE || var1.getCause() == DamageCause.FIRE_TICK || var1.getCause() == DamageCause.LAVA) {
                  var1.setDamage(var1.getDamage() * (double)3.0F);
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void m(EntityDamageByEntityEvent var1) {
      if (!var1.isCancelled()) {
         Entity var3 = var1.getDamager();
         if (var3 instanceof Trident) {
            Trident var2 = (Trident)var3;
            ProjectileSource var4 = var2.getShooter();
            if (var4 instanceof Player) {
               Player var10 = (Player)var4;
               if (this.rs.d().b(var10)) {
                  if (this.rs.d().c(var10) == l.E) {
                     double var11 = var1.getDamage();
                     double var6 = var11 * (double)1.25F;
                     var1.setDamage(var6);
                     Entity var9 = var1.getEntity();
                     if (var9 instanceof Player) {
                        Player var8 = (Player)var9;
                        if (var8.isBlocking()) {
                           var8.setCooldown(Material.SHIELD, 100);
                           var8.sendMessage("§c§lYour shield was stunned by a trident!");
                        }
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void f(EntityDamageEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rs.d().b(var2)) {
            if (this.rs.d().c(var2) == l.E) {
               if (!var2.isInWater() && !var2.getWorld().hasStorm()) {
                  if (this.rt.nextDouble() < (double)0.25F) {
                     ItemStack[] var13 = var2.getInventory().getArmorContents();

                     for(ItemStack var17 : var13) {
                        if (var17 != null && var17.getType() != Material.AIR) {
                           ItemMeta var18 = var17.getItemMeta();
                           if (var18 instanceof Damageable) {
                              Damageable var19 = (Damageable)var18;
                              var19.setDamage(var19.getDamage() + 1);
                              var17.setItemMeta(var18);
                           }
                        }
                     }
                  }
               } else {
                  ItemStack[] var12 = var2.getInventory().getArmorContents();

                  for(ItemStack var7 : var12) {
                     if (var7 != null && var7.getType() != Material.AIR) {
                        ItemMeta var8 = var7.getItemMeta();
                        if (var8 instanceof Damageable) {
                           Damageable var9 = (Damageable)var8;
                           int var10 = var9.getDamage();
                           Bukkit.getScheduler().runTask(this.rs, () -> {
                              ItemMeta var2 = var7.getItemMeta();
                              if (var2 instanceof Damageable var3) {
                                 var3.setDamage(var10);
                                 var7.setItemMeta(var2);
                              }

                           });
                        }
                     }
                  }
               }

            }
         }
      }
   }
}
