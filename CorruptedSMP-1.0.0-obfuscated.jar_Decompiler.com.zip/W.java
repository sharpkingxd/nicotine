import java.lang.reflect.Type;

public interface W<T> {
   P a(T var1, Type var2, V var3);
}
