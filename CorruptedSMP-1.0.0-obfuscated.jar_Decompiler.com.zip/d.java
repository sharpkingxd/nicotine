import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class d implements CommandExecutor {
   private final CorruptedSMPPlugin n;

   public d(CorruptedSMPPlugin var1) {
      this.n = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player var5) {
         eq.e(var5, this.n);
         return true;
      } else {
         var1.sendMessage("§cThis command can only be used by players!");
         return true;
      }
   }
}
