import java.io.IOException;
import java.net.ProtocolException;

public final class bQ {
   private final bS ky;
   private final bo kz;
   private final bR kA;
   private final cb kB;
   private boolean kC;
   private boolean kD;
   private final bT kE;

   public bQ(bS var1, bo var2, bR var3, cb var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      super();
      this.ky = var1;
      this.kz = var2;
      this.kA = var3;
      this.kB = var4;
      this.kE = this.kB.gU();
   }

   public final bS gB() {
      return this.ky;
   }

   public final bo gC() {
      return this.kz;
   }

   public final bR gD() {
      return this.kA;
   }

   public final boolean gE() {
      return this.kC;
   }

   public final boolean gF() {
      return this.kD;
   }

   public final bT gG() {
      return this.kE;
   }

   public final boolean gH() {
      return !fR.c(this.kA.gP().bK().cY(), (Object)this.kE.hr().fo().bK().cY());
   }

   public final void g(bw var1) throws IOException {
      fR.c(var1, (String)"");

      try {
         this.kz.c(this.ky);
         this.kB.g(var1);
         this.kz.a(this.ky, var1);
      } catch (IOException var3) {
         this.kz.b(this.ky, var3);
         this.d(var3);
         throw var3;
      }
   }

   public final dy a(bw var1, boolean var2) throws IOException {
      fR.c(var1, (String)"");
      this.kC = var2;
      bx var10000 = var1.eL();
      fR.m(var10000);
      long var3 = var10000.bS();
      this.kz.d(this.ky);
      dy var5 = this.kB.a(var1, var3);
      return new a(var5, var3);
   }

   public final void gI() throws IOException {
      try {
         this.kB.gI();
      } catch (IOException var2) {
         this.kz.b(this.ky, var2);
         this.d(var2);
         throw var2;
      }
   }

   public final void gJ() throws IOException {
      try {
         this.kB.gJ();
      } catch (IOException var2) {
         this.kz.b(this.ky, var2);
         this.d(var2);
         throw var2;
      }
   }

   public final void gK() {
      this.kz.e(this.ky);
   }

   public final by.a r(boolean var1) throws IOException {
      try {
         by.a var2 = this.kB.r(var1);
         if (var2 != null) {
            var2.a(this);
         }

         return var2;
      } catch (IOException var3) {
         this.kz.c(this.ky, var3);
         this.d(var3);
         throw var3;
      }
   }

   public final void j(by var1) {
      fR.c(var1, (String)"");
      this.kz.b(this.ky, var1);
   }

   public final bz k(by var1) throws IOException {
      fR.c(var1, (String)"");

      try {
         String var2 = by.a(var1, "Content-Type", (String)null, 2, (Object)null);
         long var3 = this.kB.l(var1);
         dA var5 = this.kB.m(var1);
         b var6 = new b(var5, var3);
         return new cf(var2, var3, do.c(var6));
      } catch (IOException var7) {
         this.kz.c(this.ky, var7);
         this.d(var7);
         throw var7;
      }
   }

   public final void gL() {
      this.kB.gU().hn();
   }

   public final void gM() {
      this.kB.gM();
   }

   public final void gN() {
      this.kB.gM();
      this.ky.a(this, true, true, (IOException)null);
   }

   private final void d(IOException var1) {
      this.kD = true;
      this.kA.g(var1);
      this.kB.gU().a(this.ky, var1);
   }

   public final <E extends IOException> E a(long var1, boolean var3, boolean var4, E var5) {
      if (var5 != null) {
         this.d(var5);
      }

      if (var4) {
         if (var5 != null) {
            this.kz.b(this.ky, var5);
         } else {
            this.kz.a(this.ky, var1);
         }
      }

      if (var3) {
         if (var5 != null) {
            this.kz.c(this.ky, var5);
         } else {
            this.kz.b(this.ky, var1);
         }
      }

      return (E)this.ky.a(this, var4, var3, var5);
   }

   public final void gO() {
      this.ky.a(this, true, false, (IOException)null);
   }

   final class a extends di {
      private final long contentLength;
      private boolean completed;
      private long bytesReceived;
      private boolean closed;

      public a(dy var2, long var3) {
         fR.c(var2, (String)"");
         super(var2);
         this.contentLength = var3;
      }

      public void b(de var1, long var2) throws IOException {
         fR.c(var1, (String)"");
         if (this.closed) {
            boolean var5 = false;
            String var7 = "closed";
            throw new IllegalStateException(var7.toString());
         } else if (this.contentLength != -1L && this.bytesReceived + var2 > this.contentLength) {
            throw new ProtocolException("expected " + this.contentLength + " bytes but received " + (this.bytesReceived + var2));
         } else {
            try {
               super.b(var1, var2);
               this.bytesReceived += var2;
            } catch (IOException var6) {
               throw this.e(var6);
            }
         }
      }

      public void flush() throws IOException {
         try {
            super.flush();
         } catch (IOException var2) {
            throw this.e(var2);
         }
      }

      public void close() throws IOException {
         if (!this.closed) {
            this.closed = true;
            if (this.contentLength != -1L && this.bytesReceived != this.contentLength) {
               throw new ProtocolException("unexpected end of stream");
            } else {
               try {
                  super.close();
                  this.e((IOException)null);
               } catch (IOException var2) {
                  throw this.e(var2);
               }
            }
         }
      }

      private final <E extends IOException> E e(E var1) {
         if (this.completed) {
            return (E)var1;
         } else {
            this.completed = true;
            return (E)bQ.this.a(this.bytesReceived, false, true, var1);
         }
      }
   }

   public final class b extends dj {
      private final long contentLength;
      private long bytesReceived;
      private boolean invokeStartEvent;
      private boolean completed;
      private boolean closed;

      public b(dA var2, long var3) {
         fR.c(var2, (String)"");
         super(var2);
         this.contentLength = var3;
         this.invokeStartEvent = true;
         if (this.contentLength == 0L) {
            this.f((IOException)null);
         }

      }

      public long a(de var1, long var2) throws IOException {
         fR.c(var1, (String)"");
         if (this.closed) {
            boolean var5 = false;
            String var9 = "closed";
            throw new IllegalStateException(var9.toString());
         } else {
            try {
               long var4 = this.lq().a(var1, var2);
               if (this.invokeStartEvent) {
                  this.invokeStartEvent = false;
                  bQ.this.gC().f(bQ.this.gB());
               }

               if (var4 == -1L) {
                  this.f((IOException)null);
                  return -1L;
               } else {
                  long var6 = this.bytesReceived + var4;
                  if (this.contentLength != -1L && var6 > this.contentLength) {
                     throw new ProtocolException("expected " + this.contentLength + " bytes but received " + var6);
                  } else {
                     this.bytesReceived = var6;
                     if (var6 == this.contentLength) {
                        this.f((IOException)null);
                     }

                     return var4;
                  }
               }
            } catch (IOException var8) {
               throw this.f(var8);
            }
         }
      }

      public void close() throws IOException {
         if (!this.closed) {
            this.closed = true;

            try {
               super.close();
               this.f((IOException)null);
            } catch (IOException var2) {
               throw this.f(var2);
            }
         }
      }

      public final <E extends IOException> E f(E var1) {
         if (this.completed) {
            return (E)var1;
         } else {
            this.completed = true;
            if (var1 == null && this.invokeStartEvent) {
               this.invokeStartEvent = false;
               bQ.this.gC().f(bQ.this.gB());
            }

            return (E)bQ.this.a(this.bytesReceived, true, false, var1);
         }
      }
   }
}
