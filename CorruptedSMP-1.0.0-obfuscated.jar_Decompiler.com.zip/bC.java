import java.net.IDN;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.Locale;

public final class bC {
   public static final String an(String var0) {
      fR.c(var0, (String)"");
      String var1 = var0;
      if (!gA.c((CharSequence)var0, (CharSequence)":", false, 2, (Object)null)) {
         try {
            String var7 = IDN.toASCII(var1);
            fR.b(var7, "");
            String var6 = var7;
            Locale var8 = Locale.US;
            fR.b(var8, "");
            String var9 = var6.toLowerCase(var8);
            fR.b(var9, "");
            String var5 = var9;
            if (((CharSequence)var5).length() == 0) {
               return null;
            } else {
               return ao(var5) ? null : var5;
            }
         } catch (IllegalArgumentException var4) {
            return null;
         }
      } else {
         InetAddress var10000 = gA.a(var0, "[", false, 2, (Object)null) && gA.b(var0, "]", false, 2, (Object)null) ? i(var0, 1, var0.length() - 1) : i(var0, 0, var0.length());
         if (var10000 == null) {
            return null;
         } else {
            InetAddress var2 = var10000;
            byte[] var3 = var2.getAddress();
            if (var3.length == 16) {
               fR.b(var3, "");
               return a(var3);
            } else if (var3.length == 4) {
               return var2.getHostAddress();
            } else {
               throw new AssertionError("Invalid IPv6 address: '" + var0 + '\'');
            }
         }
      }
   }

   private static final boolean ao(String var0) {
      int var1 = 0;

      for(int var2 = var0.length(); var1 < var2; ++var1) {
         char var3 = var0.charAt(var1);
         if (fR.j(var3, 31) <= 0 || fR.j(var3, 127) >= 0) {
            return true;
         }

         if (gA.a((CharSequence)" #%/:?@[\\]", var3, 0, false, 6, (Object)null) != -1) {
            return true;
         }
      }

      return false;
   }

   private static final InetAddress i(String var0, int var1, int var2) {
      byte[] var3 = new byte[16];
      int var4 = 0;
      int var5 = -1;
      int var6 = -1;

      int var8;
      for(int var7 = var1; var7 < var2; var3[var4++] = (byte)(var8 & 255)) {
         if (var4 == var3.length) {
            return null;
         }

         if (var7 + 2 <= var2 && gA.a(var0, "::", var7, false, 4, (Object)null)) {
            if (var5 != -1) {
               return null;
            }

            var7 += 2;
            var4 += 2;
            var5 = var4;
            if (var7 == var2) {
               break;
            }
         } else if (var4 != 0) {
            if (!gA.a(var0, ":", var7, false, 4, (Object)null)) {
               if (!gA.a(var0, ".", var7, false, 4, (Object)null)) {
                  return null;
               }

               if (!a(var0, var6, var2, var3, var4 - 2)) {
                  return null;
               }

               var4 += 2;
               break;
            }

            ++var7;
         }

         var8 = 0;

         for(var6 = var7; var7 < var2; ++var7) {
            int var9 = bD.d(var0.charAt(var7));
            if (var9 == -1) {
               break;
            }

            var8 = (var8 << 4) + var9;
         }

         int var11 = var7 - var6;
         if (var11 == 0 || var11 > 4) {
            return null;
         }

         var3[var4++] = (byte)(var8 >>> 8 & 255);
      }

      if (var4 != var3.length) {
         if (var5 == -1) {
            return null;
         }

         System.arraycopy(var3, var5, var3, var3.length - (var4 - var5), var4 - var5);
         Arrays.fill(var3, var5, var5 + (var3.length - var4), (byte)0);
      }

      return InetAddress.getByAddress(var3);
   }

   private static final boolean a(String var0, int var1, int var2, byte[] var3, int var4) {
      int var5 = var4;

      int var7;
      for(int var6 = var1; var6 < var2; var3[var5++] = (byte)var7) {
         if (var5 == var3.length) {
            return false;
         }

         if (var5 != var4) {
            if (var0.charAt(var6) != '.') {
               return false;
            }

            ++var6;
         }

         var7 = 0;

         int var8;
         for(var8 = var6; var6 < var2; ++var6) {
            char var9 = var0.charAt(var6);
            if (fR.j(var9, 48) < 0 || fR.j(var9, 57) > 0) {
               break;
            }

            if (var7 == 0 && var8 != var6) {
               return false;
            }

            var7 = var7 * 10 + var9 - 48;
            if (var7 > 255) {
               return false;
            }
         }

         int var10 = var6 - var8;
         if (var10 == 0) {
            return false;
         }
      }

      return var5 == var4 + 4;
   }

   private static final String a(byte[] var0) {
      int var1 = 0;
      var1 = -1;
      int var2 = 0;
      boolean var3 = false;

      for(int var4 = 0; var4 < var0.length; var4 += 2) {
         int var5;
         for(var5 = var4; var4 < 16 && var0[var4] == 0 && var0[var4 + 1] == 0; var4 += 2) {
         }

         int var6 = var4 - var5;
         if (var6 > var2 && var6 >= 4) {
            var1 = var5;
            var2 = var6;
         }
      }

      de var8 = new de();
      int var9 = 0;

      while(var9 < var0.length) {
         if (var9 == var1) {
            var8.V(58);
            var9 += var2;
            if (var9 == 16) {
               var8.V(58);
            }
         } else {
            if (var9 > 0) {
               var8.V(58);
            }

            int var10 = bD.a((byte)var0[var9], 255) << 8 | bD.a((byte)var0[var9 + 1], 255);
            var8.C((long)var10);
            var9 += 2;
         }
      }

      return var8.kU();
   }
}
