import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

public final class dr extends eG<dh> implements RandomAccess {
   public static final a qi = new a((fP)null);
   private final dh[] qj;
   private final int[] qk;

   private dr(dh[] var1, int[] var2) {
      this.qj = var1;
      this.qk = var2;
   }

   public final dh[] lF() {
      return this.qj;
   }

   public final int[] lG() {
      return this.qk;
   }

   public int getSize() {
      return this.qj.length;
   }

   public dh ag(int var1) {
      return this.qj[var1];
   }

   // $FF: synthetic method
   public Object get(int var1) {
      return this.ag(var1);
   }

   public boolean i(dh var1) {
      return super.contains(var1);
   }

   public final boolean contains(Object var1) {
      return !(var1 instanceof dh) ? false : this.i((dh)var1);
   }

   public int j(dh var1) {
      return super.indexOf(var1);
   }

   public final int indexOf(Object var1) {
      return !(var1 instanceof dh) ? -1 : this.j((dh)var1);
   }

   public int k(dh var1) {
      return super.lastIndexOf(var1);
   }

   public final int lastIndexOf(Object var1) {
      return !(var1 instanceof dh) ? -1 : this.k((dh)var1);
   }

   // $FF: synthetic method
   public dr(dh[] var1, int[] var2, fP var3) {
      this(var1, var2);
   }

   public static final class a {
      private a() {
      }

      public final dr a(dh... var1) {
         fR.c(var1, (String)"");
         if (var1.length == 0) {
            dh[] var37 = new dh[0];
            int[] var16 = new int[]{0, -1};
            return new dr(var37, var16, (fP)null);
         } else {
            List var2 = eI.h(var1);
            eO.m(var2);
            int var6 = 0;
            dh[] var7 = var1;
            Collection var8 = (Collection)(new ArrayList(var1.length));
            boolean var9 = false;
            int var10 = 0;

            for(int var11 = var1.length; var10 < var11; ++var10) {
               dh var12 = var7[var10];
               boolean var14 = false;
               var8.add(-1);
            }

            Collection var5 = (Collection)((List)var8);
            var6 = (boolean)0;
            Integer[] var4 = (Integer[])var5.toArray(new Integer[0]);
            List var3 = eO.k(Arrays.copyOf(var4, var4.length));
            dh[] var17 = var1;
            boolean var19 = false;
            var6 = 0;
            int var28 = 0;

            for(int var31 = var1.length; var28 < var31; ++var28) {
               dh var32 = var17[var28];
               int var35 = var6++;
               boolean var36 = false;
               int var13 = eO.a(var2, var32, 0, 0, 6, (Object)null);
               var3.set(var13, var35);
            }

            if (((dh)var2.get(0)).lm() <= 0) {
               var19 = false;
               String var23 = "the empty byte string is not a supported option";
               throw new IllegalArgumentException(var23.toString());
            } else {
               for(int var18 = 0; var18 < var2.size(); ++var18) {
                  dh var20 = (dh)var2.get(var18);
                  var6 = var18 + 1;

                  while(var6 < var2.size()) {
                     dh var29 = (dh)var2.get(var6);
                     if (!var29.g(var20)) {
                        break;
                     }

                     if (var29.lm() == var20.lm()) {
                        var9 = false;
                        String var34 = "duplicate option: " + var29;
                        throw new IllegalArgumentException(var34.toString());
                     }

                     if (((Number)var3.get(var6)).intValue() > ((Number)var3.get(var18)).intValue()) {
                        var2.remove(var6);
                        var3.remove(var6);
                     } else {
                        ++var6;
                     }
                  }
               }

               de var21 = new de();
               a(this, 0L, var21, 0, var2, 0, 0, var3, 53, (Object)null);
               int[] var27 = new int[(int)this.d(var21)];

               for(int var30 = 0; !var21.kK(); var27[var30++] = var21.kP()) {
               }

               Object[] var10002 = Arrays.copyOf(var1, var1.length);
               fR.b(var10002, "");
               return new dr((dh[])var10002, var27, (fP)null);
            }
         }
      }

      private final void a(long var1, de var3, int var4, List<? extends dh> var5, int var6, int var7, List<Integer> var8) {
         if (var6 >= var7) {
            String var22 = "Failed requirement.";
            throw new IllegalArgumentException(var22.toString());
         } else {
            for(int var9 = var6; var9 < var7; ++var9) {
               if (((dh)var5.get(var9)).lm() < var4) {
                  String var11 = "Failed requirement.";
                  throw new IllegalArgumentException(var11.toString());
               }
            }

            int var21 = var6;
            dh var10 = (dh)var5.get(var6);
            dh var23 = (dh)var5.get(var7 - 1);
            int var12 = -1;
            if (var4 == var10.lm()) {
               var12 = ((Number)var8.get(var6)).intValue();
               var21 = var6 + 1;
               var10 = (dh)var5.get(var21);
            }

            if (var10.af(var4) != var23.af(var4)) {
               int var13 = 1;

               for(int var14 = var21 + 1; var14 < var7; ++var14) {
                  if (((dh)var5.get(var14 - 1)).af(var4) != ((dh)var5.get(var14)).af(var4)) {
                     ++var13;
                  }
               }

               long var25 = var1 + this.d(var3) + (long)2 + (long)(var13 * 2);
               var3.X(var13);
               var3.X(var12);

               for(int var16 = var21; var16 < var7; ++var16) {
                  byte var17 = ((dh)var5.get(var16)).af(var4);
                  if (var16 == var21 || var17 != ((dh)var5.get(var16 - 1)).af(var4)) {
                     short var19 = 255;
                     boolean var20 = false;
                     var3.X(var17 & var19);
                  }
               }

               de var28 = new de();

               int var35;
               for(int var31 = var21; var31 < var7; var31 = var35) {
                  byte var18 = ((dh)var5.get(var31)).af(var4);
                  var35 = var7;

                  for(int var37 = var31 + 1; var37 < var7; ++var37) {
                     if (var18 != ((dh)var5.get(var37)).af(var4)) {
                        var35 = var37;
                        break;
                     }
                  }

                  if (var31 + 1 == var35 && var4 + 1 == ((dh)var5.get(var31)).lm()) {
                     var3.X(((Number)var8.get(var31)).intValue());
                  } else {
                     var3.X(-1 * (int)(var25 + this.d(var28)));
                     this.a(var25, var28, var4 + 1, var5, var31, var35, var8);
                  }
               }

               var3.b(var28);
            } else {
               int var24 = 0;
               int var26 = var4;

               for(int var15 = Math.min(var10.lm(), var23.lm()); var26 < var15 && var10.af(var26) == var23.af(var26); ++var26) {
                  ++var24;
               }

               long var27 = var1 + this.d(var3) + (long)2 + (long)var24 + 1L;
               var3.X(-var24);
               var3.X(var12);
               int var29 = var4;

               for(int var32 = var4 + var24; var29 < var32; ++var29) {
                  byte var34 = var10.af(var29);
                  short var36 = 255;
                  boolean var38 = false;
                  var3.X(var34 & var36);
               }

               if (var21 + 1 == var7) {
                  if (var4 + var24 != ((dh)var5.get(var21)).lm()) {
                     String var33 = "Check failed.";
                     throw new IllegalStateException(var33.toString());
                  }

                  var3.X(((Number)var8.get(var21)).intValue());
               } else {
                  de var30 = new de();
                  var3.X(-1 * (int)(var27 + this.d(var30)));
                  this.a(var27, var30, var4 + var24, var5, var21, var7, var8);
                  var3.b(var30);
               }
            }

         }
      }

      // $FF: synthetic method
      static void a(a var0, long var1, de var3, int var4, List var5, int var6, int var7, List var8, int var9, Object var10) {
         if ((var9 & 1) != 0) {
            var1 = 0L;
         }

         if ((var9 & 4) != 0) {
            var4 = 0;
         }

         if ((var9 & 16) != 0) {
            var6 = 0;
         }

         if ((var9 & 32) != 0) {
            var7 = var5.size();
         }

         var0.a(var1, var3, var4, var5, var6, var7, var8);
      }

      private final long d(de var1) {
         return var1.kH() / (long)4;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
