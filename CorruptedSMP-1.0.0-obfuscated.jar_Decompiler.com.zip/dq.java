// $FF: synthetic class
final class dq {
   public static final dg d(dA var0) {
      fR.c(var0, (String)"");
      return new du(var0);
   }

   public static final df c(dy var0) {
      fR.c(var0, (String)"");
      return new dt(var0);
   }

   public static final dy lE() {
      return new dd();
   }
}
