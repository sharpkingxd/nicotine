import java.io.IOException;

public final class cq$e extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final int $streamId$inlined;
   // $FF: synthetic field
   final de $buffer$inlined;
   // $FF: synthetic field
   final int $byteCount$inlined;
   // $FF: synthetic field
   final boolean $inFinished$inlined;

   public cq$e(String var1, boolean var2, cq var3, int var4, de var5, int var6, boolean var7) {
      super(var1, var2);
      this.this$0 = var3;
      this.$streamId$inlined = var4;
      this.$buffer$inlined = var5;
      this.$byteCount$inlined = var6;
      this.$inFinished$inlined = var7;
   }

   public long gg() {
      boolean var1 = false;
      boolean var2 = false;

      try {
         boolean var3 = false;
         boolean var4 = cq.j(this.this$0).b(this.$streamId$inlined, this.$buffer$inlined, this.$byteCount$inlined, this.$inFinished$inlined);
         if (var4) {
            this.this$0.iu().e(this.$streamId$inlined, cm.mF);
         }

         if (var4 || this.$inFinished$inlined) {
            cq var5 = this.this$0;
            synchronized(var5) {
               boolean var6 = false;
               var6 = cq.i(this.this$0).remove(this.$streamId$inlined);
            }
         }
      } catch (IOException var9) {
      }

      return -1L;
   }
}
