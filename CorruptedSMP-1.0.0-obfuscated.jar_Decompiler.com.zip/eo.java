import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class eo {
   private final CorruptedSMPPlugin sa;
   final Map<UUID, BukkitRunnable> sb;

   public eo(CorruptedSMPPlugin var1) {
      this.sa = var1;
      this.sb = new HashMap();
   }

   public void j(final Player var1) {
      this.k(var1);
      BukkitRunnable var2 = new BukkitRunnable() {
         public void run() {
            if (!var1.isOnline()) {
               this.cancel();
               eo.this.sb.remove(var1.getUniqueId());
            } else {
               eo.this.l(var1);
            }
         }
      };
      var2.runTaskTimer(this.sa, 0L, 10L);
      this.sb.put(var1.getUniqueId(), var2);
   }

   public void k(Player var1) {
      BukkitRunnable var2 = (BukkitRunnable)this.sb.remove(var1.getUniqueId());
      if (var2 != null) {
         var2.cancel();
      }

      this.m(var1);
   }

   void l(Player var1) {
      if (!this.sa.d().b(var1)) {
         this.m(var1);
      } else {
         l var2 = this.sa.d().c(var1);
         if (var2 == null) {
            this.m(var1);
         } else {
            long var3 = this.sa.d().b(var1.getUniqueId());
            StringBuilder var5 = new StringBuilder();
            var5.append("\uf800");
            var5.append("\uf007");
            String var6 = this.h(var2);
            var5.append(var6);
            if (var3 > 0L) {
               var5.append("  ");
               int var7 = (int)(var3 / 60L);
               int var8 = (int)(var3 % 60L);
               if (var7 > 0) {
                  var5.append("§c").append(var7).append("m ").append(var8).append("s");
               } else {
                  var5.append("§c").append(var8).append("s");
               }
            }

            var1.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(var5.toString()));
         }
      }
   }

   private void m(Player var1) {
      StringBuilder var2 = new StringBuilder();
      var2.append("\uf800");
      var2.append("\uf007");
      var2.append("\uf80a");
      var1.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(var2.toString()));
   }

   private String h(l var1) {
      String var10000;
      switch (var1) {
         case C -> var10000 = "\uf802";
         case E -> var10000 = "\uf808";
         case D -> var10000 = "\uf807";
         case B -> var10000 = "\uf801";
         case A -> var10000 = "\uf806";
         case w -> var10000 = "\uf805";
         case v -> var10000 = "\uf809";
         case u -> var10000 = "\uf804";
         case t -> var10000 = "\uf803";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void nd() {
      for(BukkitRunnable var2 : this.sb.values()) {
         var2.cancel();
      }

      this.sb.clear();
   }
}
