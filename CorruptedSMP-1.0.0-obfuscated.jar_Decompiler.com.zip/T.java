public class T extends RuntimeException {
   static final long serialVersionUID = -4086729973971783390L;

   public T(String var1) {
      super(var1);
   }

   public T(String var1, Throwable var2) {
      super(var1, var2);
   }

   public T(Throwable var1) {
      super(var1);
   }
}
