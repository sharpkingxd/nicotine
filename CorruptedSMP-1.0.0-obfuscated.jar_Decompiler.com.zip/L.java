import java.lang.reflect.Type;

public interface L<T> {
   T a(Type var1);
}
