import java.util.Iterator;

public final class eY$a implements gm<T> {
   // $FF: synthetic field
   final Iterable su;

   public eY$a(Iterable var1) {
      this.su = var1;
   }

   public Iterator<T> iterator() {
      boolean var1 = false;
      return this.su.iterator();
   }
}
