import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class w {
   public static boolean a(final Player var0, final CorruptedSMPPlugin var1) {
      final int var2 = var1.getConfig().getInt("corruptions.ocean.ability-duration", 10);
      var0.sendMessage("§b§l✓ OCEAN GUARDIAN ACTIVATED!");
      var0.getWorld().playSound(var0.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 2.0F, 1.0F);
      (new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            if (this.ticks >= var2 * 20) {
               this.cancel();
            } else {
               Location var1x = var0.getLocation();

               for(int var2x = 0; var2x < 360; var2x += 10) {
                  double var3 = Math.toRadians((double)var2x);
                  double var5 = var1x.getX() + (double)7.0F * Math.cos(var3);
                  double var7 = var1x.getZ() + (double)7.0F * Math.sin(var3);
                  double var9 = var1x.getY() + (double)1.0F;
                  var0.getWorld().spawnParticle(Particle.FALLING_WATER, new Location(var0.getWorld(), var5, var9, var7), 5, 0.2, (double)0.5F, 0.2, 0.1);
                  var0.getWorld().spawnParticle(Particle.BUBBLE_POP, new Location(var0.getWorld(), var5, var9, var7), 3, 0.2, (double)0.5F, 0.2, 0.1);
               }

               for(Entity var12 : var0.getNearbyEntities((double)7.0F, (double)7.0F, (double)7.0F)) {
                  if (var12 instanceof Player) {
                     Player var4 = (Player)var12;
                     if (!var4.equals(var0)) {
                        var4.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 3, false, true));
                        var4.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 40, 2, false, true));
                        var4.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 40, 1, false, true));
                        int var13 = var4.getRemainingAir();
                        var4.setRemainingAir(Math.max(-20, var13 - 60));
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "execute as " + var4.getName() + " run damage @s 1 minecraft:drown");
                        var4.getWorld().spawnParticle(Particle.BUBBLE_POP, var4.getLocation().add((double)0.0F, (double)1.5F, (double)0.0F), 5, 0.3, 0.3, 0.3, 0.1);
                        if (this.ticks % 40 == 0) {
                           var4.sendMessage("§c§l✗ You are drowning!");
                        }

                        if (this.ticks == 0 && var4.getGameMode() == GameMode.SURVIVAL) {
                           var4.setGameMode(GameMode.ADVENTURE);
                           var4.sendMessage("§c§lYou've been trapped by Ocean Guardian!");
                           (new BukkitRunnable(this, var4) {
                              // $FF: synthetic field
                              final Player val$target;

                              {
                                 this.val$target = var2;
                              }

                              public void run() {
                                 if (this.val$target.getGameMode() == GameMode.ADVENTURE) {
                                    this.val$target.setGameMode(GameMode.SURVIVAL);
                                    this.val$target.sendMessage("§a§lYou can move again!");
                                    this.val$target.setRemainingAir(this.val$target.getMaximumAir());
                                 }

                              }
                           }).runTaskLater(var1, (long)var2 * 20L);
                        }

                        if (this.ticks % 20 == 0) {
                           var4.getWorld().playSound(var4.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1.0F, 0.8F);
                        }
                     }
                  }
               }

               this.ticks += 20;
            }
         }
      }).runTaskTimer(var1, 0L, 20L);
      String var3 = var1.getConfig().getString("messages.ability-activated").replace("{ability}", "Ocean Guardian");
      var0.sendMessage(a(var3, var1));
      return true;
   }

   private static String a(String var0, CorruptedSMPPlugin var1) {
      String var2 = var1.getConfig().getString("messages.prefix", "");
      return (var2 + var0).replace("&", "§");
   }
}
