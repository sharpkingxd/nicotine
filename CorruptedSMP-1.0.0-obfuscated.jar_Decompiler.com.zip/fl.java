import java.util.Collections;
import java.util.Set;

class fl {
   public static final <T> Set<T> l(T var0) {
      Set var10000 = Collections.singleton(var0);
      fR.b(var10000, "");
      return var10000;
   }
}
