import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.math.BigDecimal;

public final class ap extends Number {
   private final String bp;

   public ap(String var1) {
      this.bp = var1;
   }

   public int intValue() {
      try {
         return Integer.parseInt(this.bp);
      } catch (NumberFormatException var4) {
         try {
            return (int)Long.parseLong(this.bp);
         } catch (NumberFormatException var3) {
            return (new BigDecimal(this.bp)).intValue();
         }
      }
   }

   public long longValue() {
      try {
         return Long.parseLong(this.bp);
      } catch (NumberFormatException var2) {
         return (new BigDecimal(this.bp)).longValue();
      }
   }

   public float floatValue() {
      return Float.parseFloat(this.bp);
   }

   public double doubleValue() {
      return Double.parseDouble(this.bp);
   }

   public String toString() {
      return this.bp;
   }

   private Object writeReplace() throws ObjectStreamException {
      return new BigDecimal(this.bp);
   }

   private void readObject(ObjectInputStream var1) throws IOException {
      throw new InvalidObjectException("Deserialization is unsupported");
   }

   public int hashCode() {
      return this.bp.hashCode();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof ap)) {
         return false;
      } else {
         ap var2 = (ap)var1;
         return this.bp == var2.bp || this.bp.equals(var2.bp);
      }
   }
}
