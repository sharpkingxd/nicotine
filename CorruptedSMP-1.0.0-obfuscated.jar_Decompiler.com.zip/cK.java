import android.util.Log;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class cK {
   public static final cK pb = new cK();
   private static final CopyOnWriteArraySet<Logger> pc = new CopyOnWriteArraySet();
   private static final Map<String, String> pd;

   private cK() {
   }

   public final void kj() {
      for(Map.Entry var2 : pd.entrySet()) {
         String var3 = (String)var2.getKey();
         String var4 = (String)var2.getValue();
         this.m(var3, var4);
      }

   }

   private final void m(String var1, String var2) {
      Logger var3 = Logger.getLogger(var1);
      if (pc.add(var3)) {
         var3.setUseParentHandlers(false);
         var3.setLevel(Log.isLoggable(var2, 3) ? Level.FINE : (Log.isLoggable(var2, 4) ? Level.INFO : Level.WARNING));
         var3.addHandler(cL.pe);
      }

   }

   static {
      LinkedHashMap var0 = new LinkedHashMap();
      boolean var2 = false;
      Package var10000 = bu.class.getPackage();
      String var3 = var10000 != null ? var10000.getName() : null;
      if (var3 != null) {
         ((Map)var0).put(var3, "OkHttp");
      }

      Map var4 = (Map)var0;
      String var13 = bu.class.getName();
      fR.b(var13, "");
      String var5 = var13;
      String var6 = "okhttp.OkHttpClient";
      var4.put(var5, var6);
      var4 = (Map)var0;
      var13 = cp.class.getName();
      fR.b(var13, "");
      var5 = var13;
      var6 = "okhttp.Http2";
      var4.put(var5, var6);
      var4 = (Map)var0;
      var13 = bN.class.getName();
      fR.b(var13, "");
      var5 = var13;
      var6 = "okhttp.TaskRunner";
      var4.put(var5, var6);
      ((Map)var0).put("com.corruptedsmp.libs.okhttp3.mockwebserver.MockWebServer", "okhttp.MockWebServer");
      pd = fe.c((Map)var0);
   }
}
