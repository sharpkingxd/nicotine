public enum bB {
   public static final a iY = new a((fP)null);
   private final String iZ;
   ja("TLSv1.3"),
   jb("TLSv1.2"),
   jc("TLSv1.1"),
   jd("TLSv1"),
   je("SSLv3");

   private bB(String var3) {
      this.iZ = var3;
   }

   public final String fs() {
      return this.iZ;
   }

   // $FF: synthetic method
   private static final bB[] ft() {
      bB[] var0 = new bB[]{ja, jb, jc, jd, je};
      return var0;
   }

   public static final class a {
      private a() {
      }

      public final bB am(String var1) {
         fR.c(var1, (String)"");
         bB var10000;
         switch (var1.hashCode()) {
            case -503070503:
               if (!var1.equals("TLSv1.1")) {
                  throw new IllegalArgumentException("Unexpected TLS version: " + var1);
               }

               var10000 = bB.jc;
               break;
            case -503070502:
               if (!var1.equals("TLSv1.2")) {
                  throw new IllegalArgumentException("Unexpected TLS version: " + var1);
               }

               var10000 = bB.jb;
               break;
            case -503070501:
               if (!var1.equals("TLSv1.3")) {
                  throw new IllegalArgumentException("Unexpected TLS version: " + var1);
               }

               var10000 = bB.ja;
               break;
            case 79201641:
               if (!var1.equals("SSLv3")) {
                  throw new IllegalArgumentException("Unexpected TLS version: " + var1);
               }

               var10000 = bB.je;
               break;
            case 79923350:
               if (var1.equals("TLSv1")) {
                  var10000 = bB.jd;
                  break;
               }

               throw new IllegalArgumentException("Unexpected TLS version: " + var1);
            default:
               throw new IllegalArgumentException("Unexpected TLS version: " + var1);
         }

         return var10000;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
