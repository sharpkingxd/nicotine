import android.net.http.X509TrustManagerExtensions;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.X509TrustManager;

public final class cJ extends cX {
   public static final a oY = new a((fP)null);
   private final X509TrustManager oZ;
   private final X509TrustManagerExtensions pa;

   public cJ(X509TrustManager var1, X509TrustManagerExtensions var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.oZ = var1;
      this.pa = var2;
   }

   public List<Certificate> a(List<? extends Certificate> var1, String var2) throws SSLPeerUnverifiedException {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      Collection var4 = (Collection)var1;
      boolean var5 = false;
      X509Certificate[] var3 = (X509Certificate[])var4.toArray(new X509Certificate[0]);

      try {
         List var10000 = this.pa.checkServerTrusted(var3, "RSA", var2);
         fR.b(var10000, "");
         return var10000;
      } catch (CertificateException var8) {
         SSLPeerUnverifiedException var9 = new SSLPeerUnverifiedException(var8.getMessage());
         boolean var7 = false;
         var9.initCause((Throwable)var8);
         throw (Throwable)var9;
      }
   }

   public boolean equals(Object var1) {
      return var1 instanceof cJ && ((cJ)var1).oZ == this.oZ;
   }

   public int hashCode() {
      return System.identityHashCode(this.oZ);
   }

   public static final class a {
      private a() {
      }

      public final cJ d(X509TrustManager var1) {
         fR.c(var1, (String)"");

         X509TrustManagerExtensions var3;
         try {
            var3 = new X509TrustManagerExtensions(var1);
         } catch (IllegalArgumentException var5) {
            var3 = null;
         }

         return var3 != null ? new cJ(var1, var3) : null;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
