public final class db {
   private static final de.a pP = new de.a();
   private static final int pQ = -1234567890;

   public static final void b(long var0, long var2, long var4) {
      if ((var2 | var4) < 0L || var2 > var0 || var0 - var2 < var4) {
         throw new ArrayIndexOutOfBoundsException("size=" + var0 + " offset=" + var2 + " byteCount=" + var4);
      }
   }

   public static final short a(short var0) {
      int var1 = var0 & '\uffff';
      int var2 = (var1 & '\uff00') >>> 8 | (var1 & 255) << 8;
      return (short)var2;
   }

   public static final int S(int var0) {
      return (var0 & -16777216) >>> 24 | (var0 & 16711680) >>> 8 | (var0 & '\uff00') << 8 | (var0 & 255) << 24;
   }

   public static final boolean a(byte[] var0, int var1, byte[] var2, int var3, int var4) {
      fR.c(var0, (String)"");
      fR.c(var2, (String)"");

      for(int var5 = 0; var5 < var4; ++var5) {
         if (var0[var5 + var1] != var2[var5 + var3]) {
            return false;
         }
      }

      return true;
   }

   public static final String a(byte var0) {
      char[] var1 = new char[2];
      char[] var10002 = dF.lQ();
      byte var3 = 4;
      boolean var4 = false;
      var1[0] = var10002[var0 >> var3 & 15];
      var10002 = dF.lQ();
      var3 = 15;
      var4 = false;
      var1[1] = var10002[var0 & var3];
      return gA.b(var1);
   }

   public static final String T(int var0) {
      if (var0 == 0) {
         return "0";
      } else {
         char[] var1 = new char[]{dF.lQ()[var0 >> 28 & 15], dF.lQ()[var0 >> 24 & 15], dF.lQ()[var0 >> 20 & 15], dF.lQ()[var0 >> 16 & 15], dF.lQ()[var0 >> 12 & 15], dF.lQ()[var0 >> 8 & 15], dF.lQ()[var0 >> 4 & 15], dF.lQ()[var0 & 15]};

         int var2;
         for(var2 = 0; var2 < var1.length && var1[var2] == '0'; ++var2) {
         }

         return gA.a(var1, var2, var1.length);
      }
   }

   public static final int kv() {
      return pQ;
   }

   public static final int a(dh var0, int var1) {
      fR.c(var0, (String)"");
      return var1 == pQ ? var0.lm() : var1;
   }

   public static final int a(byte[] var0, int var1) {
      fR.c(var0, (String)"");
      return var1 == pQ ? var0.length : var1;
   }
}
