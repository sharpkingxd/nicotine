import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;

public final class bj {
   public static final a hj = new a((fP)null);
   private final String hk;
   private final String hl;
   private final long hm;
   private final String hn;
   private final String ho;
   private final boolean hp;
   private final boolean hq;
   private final boolean hr;
   private final boolean hs;
   private static final Pattern ht = Pattern.compile("(\\d{2,4})[^\\d]*");
   private static final Pattern hu = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");
   private static final Pattern hv = Pattern.compile("(\\d{1,2})[^\\d]*");
   private static final Pattern hw = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");

   private bj(String var1, String var2, long var3, String var5, String var6, boolean var7, boolean var8, boolean var9, boolean var10) {
      this.hk = var1;
      this.hl = var2;
      this.hm = var3;
      this.hn = var5;
      this.ho = var6;
      this.hp = var7;
      this.hq = var8;
      this.hr = var9;
      this.hs = var10;
   }

   public final String cD() {
      return this.hk;
   }

   public final String cE() {
      return this.hl;
   }

   public boolean equals(Object var1) {
      return var1 instanceof bj && fR.c(((bj)var1).hk, (Object)this.hk) && fR.c(((bj)var1).hl, (Object)this.hl) && ((bj)var1).hm == this.hm && fR.c(((bj)var1).hn, (Object)this.hn) && fR.c(((bj)var1).ho, (Object)this.ho) && ((bj)var1).hp == this.hp && ((bj)var1).hq == this.hq && ((bj)var1).hr == this.hr && ((bj)var1).hs == this.hs;
   }

   @IgnoreJRERequirement
   public int hashCode() {
      int var1 = 17;
      var1 = 31 * var1 + this.hk.hashCode();
      var1 = 31 * var1 + this.hl.hashCode();
      var1 = 31 * var1 + Long.hashCode(this.hm);
      var1 = 31 * var1 + this.hn.hashCode();
      var1 = 31 * var1 + this.ho.hashCode();
      var1 = 31 * var1 + Boolean.hashCode(this.hp);
      var1 = 31 * var1 + Boolean.hashCode(this.hq);
      var1 = 31 * var1 + Boolean.hashCode(this.hr);
      var1 = 31 * var1 + Boolean.hashCode(this.hs);
      return var1;
   }

   public String toString() {
      return this.n(false);
   }

   public final String n(boolean var1) {
      StringBuilder var2 = new StringBuilder();
      boolean var3 = false;
      var2.append(this.hk);
      var2.append('=');
      var2.append(this.hl);
      if (this.hr) {
         if (this.hm == Long.MIN_VALUE) {
            var2.append("; max-age=0");
         } else {
            var2.append("; expires=").append(ca.d(new Date(this.hm)));
         }
      }

      if (!this.hs) {
         var2.append("; domain=");
         if (var1) {
            var2.append(".");
         }

         var2.append(this.hn);
      }

      var2.append("; path=").append(this.ho);
      if (this.hp) {
         var2.append("; secure");
      }

      if (this.hq) {
         var2.append("; httponly");
      }

      String var10000 = var2.toString();
      fR.b(var10000, "");
      return var10000;
   }

   // $FF: synthetic method
   public bj(String var1, String var2, long var3, String var5, String var6, boolean var7, boolean var8, boolean var9, boolean var10, fP var11) {
      this(var1, var2, var3, var5, var6, var7, var8, var9, var10);
   }

   public static final class a {
      private a() {
      }

      private final boolean c(String var1, String var2) {
         if (fR.c(var1, (Object)var2)) {
            return true;
         } else {
            return gA.b(var1, var2, false, 2, (Object)null) && var1.charAt(var1.length() - var2.length() - 1) == '.' && !bD.aq(var1);
         }
      }

      public final bj a(br var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         return this.a(System.currentTimeMillis(), var1, var2);
      }

      public final bj a(long var1, br var3, String var4) {
         fR.c(var3, (String)"");
         fR.c(var4, (String)"");
         int var5 = bD.a(var4, ';', 0, 0, 6, (Object)null);
         int var6 = bD.a(var4, '=', 0, var5, 2, (Object)null);
         if (var6 == var5) {
            return null;
         } else {
            String var7 = bD.c(var4, 0, var6, 1, (Object)null);
            if (((CharSequence)var7).length() != 0 && bD.ap(var7) == -1) {
               String var8 = bD.l(var4, var6 + 1, var5);
               if (bD.ap(var8) != -1) {
                  return null;
               } else {
                  long var9 = 253402300799999L;
                  long var11 = -1L;
                  String var13 = null;
                  String var14 = null;
                  boolean var15 = false;
                  boolean var16 = false;
                  boolean var17 = true;
                  boolean var18 = false;
                  int var19 = var5 + 1;

                  int var21;
                  for(int var20 = var4.length(); var19 < var20; var19 = var21 + 1) {
                     var21 = bD.a(var4, ';', var19, var20);
                     int var22 = bD.a(var4, '=', var19, var21);
                     String var23 = bD.l(var4, var19, var22);
                     String var24 = var22 < var21 ? bD.l(var4, var22 + 1, var21) : "";
                     if (gA.a(var23, "expires", true)) {
                        try {
                           var9 = this.b(var24, 0, var24.length());
                           var18 = true;
                        } catch (IllegalArgumentException var28) {
                        }
                     } else if (gA.a(var23, "max-age", true)) {
                        try {
                           var11 = this.B(var24);
                           var18 = true;
                        } catch (NumberFormatException var27) {
                        }
                     } else if (gA.a(var23, "domain", true)) {
                        try {
                           var13 = this.C(var24);
                           var17 = false;
                        } catch (IllegalArgumentException var26) {
                        }
                     } else if (gA.a(var23, "path", true)) {
                        var14 = var24;
                     } else if (gA.a(var23, "secure", true)) {
                        var15 = true;
                     } else if (gA.a(var23, "httponly", true)) {
                        var16 = true;
                     }
                  }

                  if (var11 == Long.MIN_VALUE) {
                     var9 = Long.MIN_VALUE;
                  } else if (var11 != -1L) {
                     long var29 = var11 <= 9223372036854775L ? var11 * (long)1000 : Long.MAX_VALUE;
                     var9 = var1 + var29;
                     if (var9 < var1 || var9 > 253402300799999L) {
                        var9 = 253402300799999L;
                     }
                  }

                  String var30 = var3.cY();
                  if (var13 == null) {
                     var13 = var30;
                  } else if (!this.c(var30, var13)) {
                     return null;
                  }

                  if (var30.length() != var13.length() && cU.pA.ku().aL(var13) == null) {
                     return null;
                  } else {
                     if (var14 == null || !gA.a(var14, "/", false, 2, (Object)null)) {
                        String var31 = var3.df();
                        int var32 = gA.b((CharSequence)var31, '/', 0, false, 6, (Object)null);
                        String var10000;
                        if (var32 != 0) {
                           var10000 = var31.substring(0, var32);
                           fR.b(var10000, "");
                        } else {
                           var10000 = "/";
                        }

                        var14 = var10000;
                     }

                     return new bj(var7, var8, var9, var13, var14, var15, var16, var18, var17, (fP)null);
                  }
               }
            } else {
               return null;
            }
         }
      }

      private final long b(String var1, int var2, int var3) {
         int var4 = this.a(var1, var2, var3, false);
         int var5 = 0;
         var5 = -1;
         int var6 = 0;
         var6 = -1;
         int var7 = 0;
         var7 = -1;
         int var8 = 0;
         var8 = -1;
         int var9 = 0;
         var9 = -1;
         int var10 = 0;
         var10 = -1;

         int var12;
         for(Matcher var11 = bj.hw.matcher((CharSequence)var1); var4 < var3; var4 = this.a(var1, var12 + 1, var3, false)) {
            var12 = this.a(var1, var4 + 1, var3, true);
            var11.region(var4, var12);
            if (var5 == -1 && var11.usePattern(bj.hw).matches()) {
               String var34 = var11.group(1);
               fR.b(var34, "");
               var5 = Integer.parseInt(var34);
               var34 = var11.group(2);
               fR.b(var34, "");
               var6 = Integer.parseInt(var34);
               var34 = var11.group(3);
               fR.b(var34, "");
               var7 = Integer.parseInt(var34);
            } else if (var8 == -1 && var11.usePattern(bj.hv).matches()) {
               String var33 = var11.group(1);
               fR.b(var33, "");
               var8 = Integer.parseInt(var33);
            } else if (var9 == -1 && var11.usePattern(bj.hu).matches()) {
               String var29 = var11.group(1);
               fR.b(var29, "");
               String var14 = var29;
               Locale var30 = Locale.US;
               fR.b(var30, "");
               String var31 = var14.toLowerCase(var30);
               fR.b(var31, "");
               String var13 = var31;
               var31 = bj.hu.pattern();
               fR.b(var31, "");
               var9 = gA.a((CharSequence)var31, var13, 0, false, 6, (Object)null) / 4;
            } else if (var10 == -1 && var11.usePattern(bj.ht).matches()) {
               String var10000 = var11.group(1);
               fR.b(var10000, "");
               var10 = Integer.parseInt(var10000);
            }
         }

         if (70 <= var10 ? var10 < 100 : false) {
            var10 += 1900;
         }

         if (0 <= var10 ? var10 < 70 : false) {
            var10 += 2000;
         }

         if (var10 < 1601) {
            String var27 = "Failed requirement.";
            throw new IllegalArgumentException(var27.toString());
         } else if (var9 == -1) {
            String var26 = "Failed requirement.";
            throw new IllegalArgumentException(var26.toString());
         } else if (!(1 <= var8 ? var8 < 32 : false)) {
            String var25 = "Failed requirement.";
            throw new IllegalArgumentException(var25.toString());
         } else if (!(0 <= var5 ? var5 < 24 : false)) {
            String var24 = "Failed requirement.";
            throw new IllegalArgumentException(var24.toString());
         } else if (!(0 <= var6 ? var6 < 60 : false)) {
            String var23 = "Failed requirement.";
            throw new IllegalArgumentException(var23.toString());
         } else if (!(0 <= var7 ? var7 < 60 : false)) {
            String var22 = "Failed requirement.";
            throw new IllegalArgumentException(var22.toString());
         } else {
            GregorianCalendar var21 = new GregorianCalendar(bD.jl);
            boolean var28 = false;
            var21.setLenient(false);
            var21.set(1, var10);
            var21.set(2, var9 - 1);
            var21.set(5, var8);
            var21.set(11, var5);
            var21.set(12, var6);
            var21.set(13, var7);
            var21.set(14, 0);
            return var21.getTimeInMillis();
         }
      }

      private final int a(String var1, int var2, int var3, boolean var4) {
         for(int var5 = var2; var5 < var3; ++var5) {
            char var6 = var1.charAt(var5);
            boolean var7 = var6 < ' ' && var6 != '\t' || var6 >= 127 || ('0' <= var6 ? var6 < ':' : false) || ('a' <= var6 ? var6 < '{' : false) || ('A' <= var6 ? var6 < '[' : false) || var6 == ':';
            if (var7 == !var4) {
               return var5;
            }
         }

         return var3;
      }

      private final long B(String var1) {
         try {
            long var2 = Long.parseLong(var1);
            return var2 <= 0L ? Long.MIN_VALUE : var2;
         } catch (NumberFormatException var4) {
            CharSequence var3 = (CharSequence)var1;
            if ((new gz("-?\\d+")).a(var3)) {
               return gA.a(var1, "-", false, 2, (Object)null) ? Long.MIN_VALUE : Long.MAX_VALUE;
            } else {
               throw var4;
            }
         }
      }

      private final String C(String var1) {
         if (gA.b(var1, ".", false, 2, (Object)null)) {
            String var2 = "Failed requirement.";
            throw new IllegalArgumentException(var2.toString());
         } else {
            String var10000 = bC.an(gA.a(var1, (CharSequence)"."));
            if (var10000 == null) {
               throw new IllegalArgumentException();
            } else {
               return var10000;
            }
         }
      }

      public final List<bj> a(br var1, bq var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         List var3 = var2.F("Set-Cookie");
         List var4 = null;
         int var5 = 0;

         for(int var6 = var3.size(); var5 < var6; ++var5) {
            bj var10000 = this.a(var1, (String)var3.get(var5));
            if (var10000 != null) {
               bj var7 = var10000;
               if (var4 == null) {
                  var4 = (List)(new ArrayList());
               }

               var4.add(var7);
            }
         }

         List var8;
         if (var4 != null) {
            var8 = Collections.unmodifiableList(var4);
            fR.b(var8, "");
         } else {
            var8 = eO.nk();
         }

         return var8;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
