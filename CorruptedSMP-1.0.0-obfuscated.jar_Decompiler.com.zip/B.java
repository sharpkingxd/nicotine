import com.corruptedsmp.CorruptedSMPPlugin;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public class B {
   private static final Map<l, ItemStack[]> Y = new HashMap();
   private static File Z;
   private static FileConfiguration aa;

   public static void a(CorruptedSMPPlugin var0) {
      Z = new File(var0.getDataFolder(), "recipes.yml");
      if (!Z.exists()) {
         try {
            Z.createNewFile();
         } catch (IOException var2) {
            var0.getLogger().severe("Could not create recipes.yml!");
            var2.printStackTrace();
         }
      }

      aa = YamlConfiguration.loadConfiguration(Z);
      b(var0);
   }

   private static void b(CorruptedSMPPlugin var0) {
      Y.clear();

      for(l var4 : l.values()) {
         String var5 = var4.name().toLowerCase() + ".recipe";
         if (aa.contains(var5)) {
            ItemStack[] var6 = new ItemStack[9];

            for(int var7 = 0; var7 < 9; ++var7) {
               String var8 = var5 + "." + var7;
               if (aa.contains(var8)) {
                  var6[var7] = aa.getItemStack(var8);
               } else {
                  var6[var7] = new ItemStack(Material.AIR);
               }
            }

            Y.put(var4, var6);
            var0.getLogger().info("Loaded custom recipe for " + var4.name());
         }
      }

      if (!Y.isEmpty()) {
         var0.getLogger().info("Loaded " + Y.size() + " custom recipes!");
      }

   }

   public static void a(l var0, ItemStack[] var1, CorruptedSMPPlugin var2) {
      String var3 = var0.name().toLowerCase() + ".recipe";

      for(int var4 = 0; var4 < 9; ++var4) {
         String var5 = var3 + "." + var4;
         if (var1[var4] != null && var1[var4].getType() != Material.AIR) {
            aa.set(var5, var1[var4]);
         } else {
            aa.set(var5, new ItemStack(Material.AIR));
         }
      }

      try {
         aa.save(Z);
         Y.put(var0, var1);
         var2.getLogger().info("Saved custom recipe for " + var0.name());
         var2.g().e(var0);
         var2.g().a(var0, var1);
      } catch (IOException var6) {
         var2.getLogger().severe("Could not save recipe for " + var0.name());
         var6.printStackTrace();
      }

   }

   public static void a(l var0, CorruptedSMPPlugin var1) {
      String var2 = var0.name().toLowerCase() + ".recipe";
      aa.set(var2, (Object)null);

      try {
         aa.save(Z);
         Y.remove(var0);
         var1.getLogger().info("Reset recipe for " + var0.name() + " to default");
         var1.g().e(var0);
         var1.g().a(var0, d(var0));
      } catch (IOException var4) {
         var1.getLogger().severe("Could not reset recipe for " + var0.name());
         var4.printStackTrace();
      }

   }

   public static ItemStack[] b(l var0, CorruptedSMPPlugin var1) {
      return Y.containsKey(var0) ? (ItemStack[])((ItemStack[])Y.get(var0)).clone() : d(var0);
   }

   public static ItemStack[] d(l var0) {
      ItemStack[] var1 = new ItemStack[9];

      for(int var2 = 0; var2 < 9; ++var2) {
         var1[var2] = new ItemStack(Material.AIR);
      }

      switch (var0) {
         case C:
            var1[0] = new ItemStack(Material.GOLD_BLOCK);
            var1[1] = new ItemStack(Material.GOLDEN_APPLE);
            var1[2] = new ItemStack(Material.GOLD_BLOCK);
            var1[3] = new ItemStack(Material.GOLDEN_APPLE);
            var1[4] = new ItemStack(Material.ENCHANTED_GOLDEN_APPLE);
            var1[5] = new ItemStack(Material.GOLDEN_APPLE);
            var1[6] = new ItemStack(Material.GOLD_BLOCK);
            var1[7] = new ItemStack(Material.GOLDEN_APPLE);
            var1[8] = new ItemStack(Material.GOLD_BLOCK);
            break;
         case E:
            var1[0] = new ItemStack(Material.PRISMARINE_CRYSTALS);
            var1[1] = new ItemStack(Material.HEART_OF_THE_SEA);
            var1[2] = new ItemStack(Material.PRISMARINE_CRYSTALS);
            var1[3] = new ItemStack(Material.HEART_OF_THE_SEA);
            var1[4] = new ItemStack(Material.TRIDENT);
            var1[5] = new ItemStack(Material.HEART_OF_THE_SEA);
            var1[6] = new ItemStack(Material.PRISMARINE_CRYSTALS);
            var1[7] = new ItemStack(Material.HEART_OF_THE_SEA);
            var1[8] = new ItemStack(Material.PRISMARINE_CRYSTALS);
            break;
         case D:
            var1[0] = new ItemStack(Material.NETHERITE_INGOT);
            var1[1] = new ItemStack(Material.NETHERITE_BLOCK);
            var1[2] = new ItemStack(Material.NETHERITE_INGOT);
            var1[3] = new ItemStack(Material.NETHERITE_BLOCK);
            var1[4] = new ItemStack(Material.SHIELD);
            var1[5] = new ItemStack(Material.NETHERITE_BLOCK);
            var1[6] = new ItemStack(Material.NETHERITE_INGOT);
            var1[7] = new ItemStack(Material.NETHERITE_BLOCK);
            var1[8] = new ItemStack(Material.NETHERITE_INGOT);
            break;
         case B:
            var1[0] = new ItemStack(Material.FEATHER);
            var1[1] = new ItemStack(Material.ELYTRA);
            var1[2] = new ItemStack(Material.FEATHER);
            var1[3] = new ItemStack(Material.ELYTRA);
            var1[4] = new ItemStack(Material.WIND_CHARGE);
            var1[5] = new ItemStack(Material.ELYTRA);
            var1[6] = new ItemStack(Material.FEATHER);
            var1[7] = new ItemStack(Material.ELYTRA);
            var1[8] = new ItemStack(Material.FEATHER);
            break;
         case A:
            var1[0] = new ItemStack(Material.BLAZE_ROD);
            var1[1] = new ItemStack(Material.FIRE_CHARGE);
            var1[2] = new ItemStack(Material.BLAZE_ROD);
            var1[3] = new ItemStack(Material.FIRE_CHARGE);
            var1[4] = new ItemStack(Material.LAVA_BUCKET);
            var1[5] = new ItemStack(Material.FIRE_CHARGE);
            var1[6] = new ItemStack(Material.BLAZE_ROD);
            var1[7] = new ItemStack(Material.FIRE_CHARGE);
            var1[8] = new ItemStack(Material.BLAZE_ROD);
            break;
         case w:
            var1[0] = new ItemStack(Material.WIND_CHARGE);
            var1[1] = new ItemStack(Material.BREEZE_ROD);
            var1[2] = new ItemStack(Material.WIND_CHARGE);
            var1[3] = new ItemStack(Material.BREEZE_ROD);
            var1[4] = new ItemStack(Material.RECOVERY_COMPASS);
            var1[5] = new ItemStack(Material.BREEZE_ROD);
            var1[6] = new ItemStack(Material.WIND_CHARGE);
            var1[7] = new ItemStack(Material.BREEZE_ROD);
            var1[8] = new ItemStack(Material.WIND_CHARGE);
            break;
         case v:
            var1[0] = new ItemStack(Material.ENDER_EYE);
            var1[1] = new ItemStack(Material.ENDER_PEARL);
            var1[2] = new ItemStack(Material.ENDER_EYE);
            var1[3] = new ItemStack(Material.ENDER_PEARL);
            var1[4] = new ItemStack(Material.DRAGON_HEAD);
            var1[5] = new ItemStack(Material.ENDER_PEARL);
            var1[6] = new ItemStack(Material.ENDER_EYE);
            var1[7] = new ItemStack(Material.ENDER_PEARL);
            var1[8] = new ItemStack(Material.ENDER_EYE);
            break;
         case u:
            var1[0] = new ItemStack(Material.SCULK);
            var1[1] = new ItemStack(Material.WITHER_SKELETON_SKULL);
            var1[2] = new ItemStack(Material.SCULK);
            var1[3] = new ItemStack(Material.WITHER_SKELETON_SKULL);
            var1[4] = new ItemStack(Material.ECHO_SHARD);
            var1[5] = new ItemStack(Material.WITHER_SKELETON_SKULL);
            var1[6] = new ItemStack(Material.SCULK);
            var1[7] = new ItemStack(Material.WITHER_SKELETON_SKULL);
            var1[8] = new ItemStack(Material.SCULK);
            break;
         case t:
            var1[0] = new ItemStack(Material.TNT);
            var1[1] = new ItemStack(Material.EGG);
            var1[2] = new ItemStack(Material.TNT);
            var1[3] = new ItemStack(Material.EGG);
            var1[4] = new ItemStack(Material.DRAGON_BREATH);
            var1[5] = new ItemStack(Material.EGG);
            var1[6] = new ItemStack(Material.TNT);
            var1[7] = new ItemStack(Material.EGG);
            var1[8] = new ItemStack(Material.TNT);
      }

      return var1;
   }
}
