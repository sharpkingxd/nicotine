import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLSocket;
import org.conscrypt.Conscrypt;

public final class cP implements cR {
   public static final a ps = new a((fP)null);
   private static final cQ.a pt = new cQ.a() {
      public boolean f(SSLSocket var1) {
         fR.c(var1, (String)"");
         return cD.oG.jM() && Conscrypt.isConscrypt(var1);
      }

      public cR g(SSLSocket var1) {
         fR.c(var1, (String)"");
         return new cP();
      }
   };

   public boolean f(SSLSocket var1) {
      fR.c(var1, (String)"");
      return Conscrypt.isConscrypt(var1);
   }

   public boolean jB() {
      return cD.oG.jM();
   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      return this.f(var1) ? Conscrypt.getApplicationProtocol(var1) : null;
   }

   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      if (this.f(var1)) {
         Conscrypt.setUseSessionTickets(var1, true);
         List var4 = cH.oU.h(var3);
         Collection var5 = (Collection)var4;
         boolean var6 = false;
         Conscrypt.setApplicationProtocols(var1, (String[])var5.toArray(new String[0]));
      }

   }

   public static final class a {
      private a() {
      }

      public final cQ.a kq() {
         return cP.pt;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
