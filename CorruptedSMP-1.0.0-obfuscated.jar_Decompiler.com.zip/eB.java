public final class eB {
   public static final <A, B> ez<A, B> b(A var0, B var1) {
      return new ez<A, B>(var0, var1);
   }
}
