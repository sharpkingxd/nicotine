import java.io.IOException;

public final class bO implements bs {
   public static final bO kt = new bO();

   private bO() {
   }

   public by a(bs.a var1) throws IOException {
      fR.c(var1, (String)"");
      ce var2 = (ce)var1;
      bQ var3 = var2.hG().a((ce)var1);
      ce var4 = ce.a(var2, 0, var3, (bw)null, 0, 0, 0, 61, (Object)null);
      return var4.c(var2.hI());
   }
}
