import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

class eM extends eL {
   public static final <T> boolean b(T[] var0, T var1) {
      fR.c(var0, (String)"");
      return eI.c(var0, var1) >= 0;
   }

   public static final <T> int c(T[] var0, T var1) {
      fR.c(var0, (String)"");
      if (var1 == null) {
         int var2 = 0;

         for(int var3 = var0.length; var2 < var3; ++var2) {
            if (var0[var2] == null) {
               return var2;
            }
         }
      } else {
         int var4 = 0;

         for(int var5 = var0.length; var4 < var5; ++var4) {
            if (fR.c(var1, (Object)var0[var4])) {
               return var4;
            }
         }
      }

      return -1;
   }

   public static final char a(char[] var0) {
      fR.c(var0, (String)"");
      switch (var0.length) {
         case 0:
            throw new NoSuchElementException("Array is empty.");
         case 1:
            return var0[0];
         default:
            throw new IllegalArgumentException("Array has more than one element.");
      }
   }

   public static final <T> T d(T[] var0) {
      fR.c(var0, (String)"");
      return (T)(var0.length == 1 ? var0[0] : null);
   }

   public static final <T> List<T> e(T[] var0) {
      fR.c(var0, (String)"");
      return (List)eI.a(var0, (Collection)(new ArrayList()));
   }

   public static final <C extends Collection<? super T>, T> C a(T[] var0, C var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      int var2 = 0;

      for(int var3 = var0.length; var2 < var3; ++var2) {
         Object var4 = var0[var2];
         if (var4 != null) {
            var1.add(var4);
         }
      }

      return (C)var1;
   }

   public static final <T> int f(T[] var0) {
      fR.c(var0, (String)"");
      return var0.length - 1;
   }

   public static final <T> List<T> g(T[] var0) {
      fR.c(var0, (String)"");
      List var10000;
      switch (var0.length) {
         case 0:
            var10000 = eO.nk();
            break;
         case 1:
            var10000 = eO.i(var0[0]);
            break;
         default:
            var10000 = eI.h(var0);
      }

      return var10000;
   }

   public static final <T> List<T> h(T[] var0) {
      fR.c(var0, (String)"");
      return (List)(new ArrayList(eO.i(var0)));
   }
}
