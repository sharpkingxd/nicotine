import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;

public final class de implements df, dg, Cloneable, ByteChannel {
   public dv pR;
   private long jE;

   public final long kH() {
      return this.jE;
   }

   public final void t(long var1) {
      this.jE = var1;
   }

   public de kI() {
      return this;
   }

   public de kJ() {
      return this;
   }

   public boolean kK() {
      return this.jE == 0L;
   }

   public void u(long var1) throws EOFException {
      if (this.jE < var1) {
         throw new EOFException();
      }
   }

   public InputStream kL() {
      return new InputStream() {
         public int read() {
            int var10000;
            if (de.this.kH() > 0L) {
               byte var1 = de.this.kN();
               short var2 = 255;
               boolean var3 = false;
               var10000 = var1 & var2;
            } else {
               var10000 = -1;
            }

            return var10000;
         }

         public int read(byte[] var1, int var2, int var3) {
            fR.c(var1, (String)"");
            return de.this.read(var1, var2, var3);
         }

         public int available() {
            long var1 = de.this.kH();
            int var3 = Integer.MAX_VALUE;
            boolean var4 = false;
            return (int)Math.min(var1, (long)var3);
         }

         public void close() {
         }

         public String toString() {
            return de.this + ".inputStream()";
         }
      };
   }

   public final de a(de var1, long var2, long var4) {
      fR.c(var1, (String)"");
      boolean var7 = false;
      long var8 = var2;
      long var10 = var4;
      db.b(this.kH(), var2, var4);
      de var10000;
      if (var4 == 0L) {
         var10000 = this;
      } else {
         var1.t(var1.kH() + var4);
         dv var12 = this.pR;

         while(true) {
            fR.m(var12);
            if (var8 < (long)(var12.dI - var12.dH)) {
               while(var10 > 0L) {
                  fR.m(var12);
                  dv var13 = var12.lH();
                  var13.dH += (int)var8;
                  var13.dI = Math.min(var13.dH + (int)var10, var13.dI);
                  if (var1.pR == null) {
                     var13.qw = var13;
                     var13.qv = var13.qw;
                     var1.pR = var13.qv;
                  } else {
                     dv var14 = var1.pR;
                     fR.m(var14);
                     var14 = var14.qw;
                     fR.m(var14);
                     var14.b(var13);
                  }

                  var10 -= (long)(var13.dI - var13.dH);
                  var8 = 0L;
                  var12 = var12.qv;
               }

               var10000 = this;
               break;
            }

            var8 -= (long)(var12.dI - var12.dH);
            var12 = var12.qv;
         }
      }

      return var10000;
   }

   public final long kM() {
      boolean var2 = false;
      long var3 = this.kH();
      long var10000;
      if (var3 == 0L) {
         var10000 = 0L;
      } else {
         dv var6 = this.pR;
         fR.m(var6);
         var6 = var6.qw;
         fR.m(var6);
         dv var5 = var6;
         if (var5.dI < 8192 && var5.qu) {
            var3 -= (long)(var5.dI - var5.dH);
         }

         var10000 = var3;
      }

      return var10000;
   }

   public byte kN() throws EOFException {
      boolean var2 = false;
      if (this.kH() == 0L) {
         throw new EOFException();
      } else {
         dv var10000 = this.pR;
         fR.m(var10000);
         dv var3 = var10000;
         int var4 = var3.dH;
         int var5 = var3.dI;
         byte[] var6 = var3.qs;
         byte var7 = var6[var4++];
         this.t(this.kH() - 1L);
         if (var4 == var5) {
            this.pR = var3.lI();
            dw.c(var3);
         } else {
            var3.dH = var4;
         }

         return var7;
      }
   }

   public final byte v(long var1) {
      boolean var4 = false;
      db.b(this.kH(), var1, 1L);
      boolean var6 = false;
      dv var10000 = this.pR;
      byte var23;
      if (var10000 == null) {
         long var7 = -1L;
         Object var9 = null;
         boolean var10 = false;
         fR.m(var9);
         var23 = ((dv)var9).qs[(int)((long)((dv)var9).dH + var1 - var7)];
      } else {
         dv var11 = var10000;
         if (this.kH() - var1 < var1) {
            long var12;
            for(var12 = this.kH(); var12 > var1; var12 -= (long)(var11.dI - var11.dH)) {
               dv var24 = var11.qw;
               fR.m(var24);
               var11 = var24;
            }

            boolean var17 = false;
            fR.m(var11);
            var23 = var11.qs[(int)((long)var11.dH + var1 - var12)];
         } else {
            long var22 = 0L;

            while(true) {
               long var21 = var22 + (long)(var11.dI - var11.dH);
               if (var21 > var1) {
                  boolean var20 = false;
                  fR.m(var11);
                  var23 = var11.qs[(int)((long)var11.dH + var1 - var22)];
                  break;
               }

               dv var25 = var11.qv;
               fR.m(var25);
               var11 = var25;
               var22 = var21;
            }
         }
      }

      return var23;
   }

   public short kO() throws EOFException {
      boolean var2 = false;
      if (this.kH() < 2L) {
         throw new EOFException();
      } else {
         dv var10000 = this.pR;
         fR.m(var10000);
         dv var3 = var10000;
         int var4 = var3.dH;
         int var5 = var3.dI;
         short var24;
         if (var5 - var4 < 2) {
            byte var6 = this.kN();
            short var7 = 255;
            boolean var8 = false;
            var24 = (var6 & var7) << 8;
            var6 = this.kN();
            var7 = 255;
            var8 = false;
            int var9 = var24 | var6 & var7;
            var24 = (short)var9;
         } else {
            byte[] var21 = var3.qs;
            byte var16 = var21[var4++];
            short var19 = 255;
            boolean var10 = false;
            var24 = (var16 & var19) << 8;
            var16 = var21[var4++];
            var19 = 255;
            var10 = false;
            int var14 = var24 | var16 & var19;
            this.t(this.kH() - 2L);
            if (var4 == var5) {
               this.pR = var3.lI();
               dw.c(var3);
            } else {
               var3.dH = var4;
            }

            var24 = (short)var14;
         }

         return (short)var24;
      }
   }

   public int kP() throws EOFException {
      boolean var2 = false;
      if (this.kH() < 4L) {
         throw new EOFException();
      } else {
         dv var10000 = this.pR;
         fR.m(var10000);
         dv var3 = var10000;
         int var4 = var3.dH;
         int var5 = var3.dI;
         int var39;
         if ((long)(var5 - var4) < 4L) {
            byte var6 = this.kN();
            short var7 = 255;
            boolean var8 = false;
            var39 = (var6 & var7) << 24;
            var6 = this.kN();
            var7 = 255;
            var8 = false;
            var39 |= (var6 & var7) << 16;
            var6 = this.kN();
            var7 = 255;
            var8 = false;
            var39 |= (var6 & var7) << 8;
            var6 = this.kN();
            var7 = 255;
            var8 = false;
            var39 |= var6 & var7;
         } else {
            byte[] var18 = var3.qs;
            byte var26 = var18[var4++];
            short var9 = 255;
            boolean var10 = false;
            var39 = (var26 & var9) << 24;
            var26 = var18[var4++];
            var9 = 255;
            var10 = false;
            var39 |= (var26 & var9) << 16;
            var26 = var18[var4++];
            var9 = 255;
            var10 = false;
            var39 |= (var26 & var9) << 8;
            var26 = var18[var4++];
            var9 = 255;
            var10 = false;
            int var22 = var39 | var26 & var9;
            this.t(this.kH() - 4L);
            if (var4 == var5) {
               this.pR = var3.lI();
               dw.c(var3);
            } else {
               var3.dH = var4;
            }

            var39 = var22;
         }

         return var39;
      }
   }

   public short kQ() throws EOFException {
      return db.a(this.kO());
   }

   public int kR() throws EOFException {
      return db.S(this.kP());
   }

   public long kS() throws EOFException {
      de var1 = this;
      boolean var2 = false;
      if (this.kH() == 0L) {
         throw new EOFException();
      } else {
         long var3 = 0L;
         int var5 = 0;
         boolean var6 = false;
         boolean var7 = false;
         long var8 = -7L;

         while(true) {
            dv var10000 = var1.pR;
            fR.m(var10000);
            dv var10 = var10000;
            byte[] var11 = var10.qs;
            int var12 = var10.dH;
            int var13 = var10.dI;

            while(true) {
               label86: {
                  if (var12 < var13) {
                     byte var14 = var11[var12];
                     if (var14 >= 48 && var14 <= 57) {
                        int var15 = 48 - var14;
                        if (var3 < -922337203685477580L || var3 == -922337203685477580L && (long)var15 < var8) {
                           de var16 = (new de()).B(var3).V(var14);
                           if (!var6) {
                              var16.kN();
                           }

                           throw new NumberFormatException("Number too large: " + var16.kU());
                        }

                        var3 *= 10L;
                        var3 += (long)var15;
                        break label86;
                     }

                     if (var14 == 45 && var5 == 0) {
                        var6 = true;
                        --var8;
                        break label86;
                     }

                     var7 = true;
                  }

                  if (var12 == var13) {
                     var1.pR = var10.lI();
                     dw.c(var10);
                  } else {
                     var10.dH = var12;
                  }

                  if (!var7 && var1.pR != null) {
                     break;
                  }

                  var1.t(var1.kH() - (long)var5);
                  int var18 = var6 ? 2 : 1;
                  if (var5 < var18) {
                     if (var1.kH() == 0L) {
                        throw new EOFException();
                     }

                     String var19 = var6 ? "Expected a digit" : "Expected a digit or '-'";
                     throw new NumberFormatException(var19 + " but was 0x" + db.a(var1.v(0L)));
                  }

                  return var6 ? var3 : -var3;
               }

               ++var12;
               ++var5;
            }
         }
      }
   }

   public long kT() throws EOFException {
      de var1 = this;
      boolean var2 = false;
      if (this.kH() == 0L) {
         throw new EOFException();
      } else {
         long var3 = 0L;
         int var5 = 0;
         boolean var6 = false;

         do {
            dv var10000 = var1.pR;
            fR.m(var10000);
            dv var7 = var10000;
            byte[] var8 = var7.qs;
            int var9 = var7.dH;

            int var10;
            for(var10 = var7.dI; var9 < var10; ++var5) {
               int var11 = 0;
               byte var12 = var8[var9];
               if (var12 >= 48 && var12 <= 57) {
                  var11 = var12 - 48;
               } else if (var12 >= 97 && var12 <= 102) {
                  var11 = var12 - 97 + 10;
               } else {
                  if (var12 < 65 || var12 > 70) {
                     if (var5 == 0) {
                        throw new NumberFormatException("Expected leading [0-9a-fA-F] character but was 0x" + db.a(var12));
                     }

                     var6 = true;
                     break;
                  }

                  var11 = var12 - 65 + 10;
               }

               if ((var3 & -1152921504606846976L) != 0L) {
                  de var13 = (new de()).C(var3).V(var12);
                  throw new NumberFormatException("Number too large: " + var13.kU());
               }

               var3 <<= 4;
               var3 |= (long)var11;
               ++var9;
            }

            if (var9 == var10) {
               var1.pR = var7.lI();
               dw.c(var7);
            } else {
               var7.dH = var9;
            }
         } while(!var6 && var1.pR != null);

         var1.t(var1.kH() - (long)var5);
         return var3;
      }
   }

   public dh ii() {
      boolean var2 = false;
      return this.w(this.kH());
   }

   public dh w(long var1) throws EOFException {
      boolean var4 = false;
      if (var1 < 0L || var1 > 2147483647L) {
         boolean var5 = false;
         String var8 = "byteCount: " + var1;
         throw new IllegalArgumentException(var8.toString());
      } else if (this.kH() < var1) {
         throw new EOFException();
      } else {
         dh var10000;
         if (var1 >= 4096L) {
            dh var6 = this.Z((int)var1);
            boolean var7 = false;
            this.A(var1);
            var10000 = var6;
         } else {
            var10000 = new dh(this.z(var1));
         }

         return var10000;
      }
   }

   public int a(dr var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      int var4 = dE.a(this, var1, false, 2, (Object)null);
      int var10000;
      if (var4 == -1) {
         var10000 = -1;
      } else {
         int var5 = var1.lF()[var4].lm();
         this.A((long)var5);
         var10000 = var4;
      }

      return var10000;
   }

   public String kU() {
      return this.a(this.jE, gx.tn);
   }

   public String x(long var1) throws EOFException {
      return this.a(var1, gx.tn);
   }

   public String b(Charset var1) {
      fR.c(var1, (String)"");
      return this.a(this.jE, var1);
   }

   public String a(long var1, Charset var3) throws EOFException {
      fR.c(var3, (String)"");
      if (var1 < 0L || var1 > 2147483647L) {
         boolean var6 = false;
         String var7 = "byteCount: " + var1;
         throw new IllegalArgumentException(var7.toString());
      } else if (this.jE < var1) {
         throw new EOFException();
      } else if (var1 == 0L) {
         return "";
      } else {
         dv var10000 = this.pR;
         fR.m(var10000);
         dv var4 = var10000;
         if ((long)var4.dH + var1 > (long)var4.dI) {
            return new String(this.z(var1), var3);
         } else {
            String var5 = new String(var4.qs, var4.dH, (int)var1, var3);
            var4.dH += (int)var1;
            this.jE -= var1;
            if (var4.dH == var4.dI) {
               this.pR = var4.lI();
               dw.c(var4);
            }

            return var5;
         }
      }
   }

   public String kV() throws EOFException {
      return this.y(Long.MAX_VALUE);
   }

   public String y(long var1) throws EOFException {
      boolean var4 = false;
      if (var1 < 0L) {
         boolean var5 = false;
         String var15 = "limit < 0: " + var1;
         throw new IllegalArgumentException(var15.toString());
      } else {
         long var6 = var1 == Long.MAX_VALUE ? Long.MAX_VALUE : var1 + 1L;
         long var8 = this.a((byte)10, 0L, var6);
         String var10000;
         if (var8 != -1L) {
            var10000 = dE.d(this, var8);
         } else {
            if (var6 >= this.kH() || this.v(var6 - 1L) != 13 || this.v(var6) != 10) {
               de var10 = new de();
               byte var11 = 32;
               long var12 = this.kH();
               boolean var14 = false;
               this.a(var10, 0L, Math.min((long)var11, var12));
               throw new EOFException("\\n not found: limit=" + Math.min(this.kH(), var1) + " content=" + var10.ii().lk() + '…');
            }

            var10000 = dE.d(this, var6);
         }

         return var10000;
      }
   }

   public byte[] kW() {
      boolean var2 = false;
      return this.z(this.kH());
   }

   public byte[] z(long var1) throws EOFException {
      boolean var4 = false;
      if (var1 < 0L || var1 > 2147483647L) {
         boolean var5 = false;
         String var7 = "byteCount: " + var1;
         throw new IllegalArgumentException(var7.toString());
      } else if (this.kH() < var1) {
         throw new EOFException();
      } else {
         byte[] var6 = new byte[(int)var1];
         this.b(var6);
         return var6;
      }
   }

   public void b(byte[] var1) throws EOFException {
      fR.c(var1, (String)"");
      de var2 = this;
      boolean var3 = false;

      int var5;
      for(int var4 = 0; var4 < var1.length; var4 += var5) {
         var5 = var2.read(var1, var4, var1.length - var4);
         if (var5 == -1) {
            throw new EOFException();
         }
      }

   }

   public int read(byte[] var1, int var2, int var3) {
      fR.c(var1, (String)"");
      boolean var5 = false;
      db.b((long)var1.length, (long)var2, (long)var3);
      dv var10000 = this.pR;
      int var8;
      if (var10000 == null) {
         var8 = -1;
      } else {
         dv var6 = var10000;
         int var7 = Math.min(var3, var6.dI - var6.dH);
         eI.a(var6.qs, var1, var2, var6.dH, var6.dH + var7);
         var6.dH += var7;
         this.t(this.kH() - (long)var7);
         if (var6.dH == var6.dI) {
            this.pR = var6.lI();
            dw.c(var6);
         }

         var8 = var7;
      }

      return var8;
   }

   public int read(ByteBuffer var1) throws IOException {
      fR.c(var1, (String)"");
      dv var10000 = this.pR;
      if (var10000 == null) {
         return -1;
      } else {
         dv var2 = var10000;
         int var3 = Math.min(var1.remaining(), var2.dI - var2.dH);
         var1.put(var2.qs, var2.dH, var3);
         var2.dH += var3;
         this.jE -= (long)var3;
         if (var2.dH == var2.dI) {
            this.pR = var2.lI();
            dw.c(var2);
         }

         return var3;
      }
   }

   public final void kX() {
      boolean var2 = false;
      this.A(this.kH());
   }

   public void A(long var1) throws EOFException {
      de var3 = this;
      boolean var4 = false;
      long var5 = var1;

      while(var5 > 0L) {
         dv var10000 = var3.pR;
         if (var10000 == null) {
            throw new EOFException();
         }

         dv var7 = var10000;
         int var8 = var7.dI - var7.dH;
         boolean var9 = false;
         int var10 = (int)Math.min(var5, (long)var8);
         var3.t(var3.kH() - (long)var10);
         var5 -= (long)var10;
         var7.dH += var10;
         if (var7.dH == var7.dI) {
            var3.pR = var7.lI();
            dw.c(var7);
         }
      }

   }

   public de d(dh var1) {
      fR.c(var1, (String)"");
      byte var3 = 0;
      int var4 = var1.lm();
      boolean var5 = false;
      var1.a(this, var3, var4);
      return this;
   }

   public de aQ(String var1) {
      fR.c(var1, (String)"");
      return this.m(var1, 0, var1.length());
   }

   public de m(String var1, int var2, int var3) {
      fR.c(var1, (String)"");
      de var4 = this;
      boolean var5 = false;
      if (var2 < 0) {
         boolean var18 = false;
         String var19 = "beginIndex < 0: " + var2;
         throw new IllegalArgumentException(var19.toString());
      } else if (var3 < var2) {
         boolean var16 = false;
         String var17 = "endIndex < beginIndex: " + var3 + " < " + var2;
         throw new IllegalArgumentException(var17.toString());
      } else if (var3 > var1.length()) {
         boolean var14 = false;
         String var15 = "endIndex > string.length: " + var3 + " > " + var1.length();
         throw new IllegalArgumentException(var15.toString());
      } else {
         int var7 = var2;

         while(var7 < var3) {
            char var6 = var1.charAt(var7);
            if (var6 < 128) {
               dv var22 = var4.Y(1);
               byte[] var23 = var22.qs;
               int var24 = var22.dI - var7;
               int var11 = Math.min(var3, 8192 - var24);

               for(var23[var24 + var7++] = (byte)var6; var7 < var11; var23[var24 + var7++] = (byte)var6) {
                  var6 = var1.charAt(var7);
                  if (var6 >= 128) {
                     break;
                  }
               }

               int var12 = var7 + var24 - var22.dI;
               var22.dI += var12;
               var4.t(var4.kH() + (long)var12);
            } else if (var6 < 2048) {
               dv var21 = var4.Y(2);
               var21.qs[var21.dI] = (byte)(var6 >> 6 | 192);
               var21.qs[var21.dI + 1] = (byte)(var6 & 63 | 128);
               var21.dI += 2;
               var4.t(var4.kH() + 2L);
               ++var7;
            } else if (var6 >= '\ud800' && var6 <= '\udfff') {
               char var20 = var7 + 1 < var3 ? var1.charAt(var7 + 1) : 0;
               if (var6 <= '\udbff' && ('\udc00' <= var20 ? var20 < '\ue000' : false)) {
                  int var9 = 65536 + ((var6 & 1023) << 10 | var20 & 1023);
                  dv var10 = var4.Y(4);
                  var10.qs[var10.dI] = (byte)(var9 >> 18 | 240);
                  var10.qs[var10.dI + 1] = (byte)(var9 >> 12 & 63 | 128);
                  var10.qs[var10.dI + 2] = (byte)(var9 >> 6 & 63 | 128);
                  var10.qs[var10.dI + 3] = (byte)(var9 & 63 | 128);
                  var10.dI += 4;
                  var4.t(var4.kH() + 4L);
                  var7 += 2;
               } else {
                  var4.V(63);
                  ++var7;
               }
            } else {
               dv var8 = var4.Y(3);
               var8.qs[var8.dI] = (byte)(var6 >> 12 | 224);
               var8.qs[var8.dI + 1] = (byte)(var6 >> 6 & 63 | 128);
               var8.qs[var8.dI + 2] = (byte)(var6 & 63 | 128);
               var8.dI += 3;
               var4.t(var4.kH() + 3L);
               ++var7;
            }
         }

         return var4;
      }
   }

   public de U(int var1) {
      boolean var3 = false;
      if (var1 < 128) {
         this.V(var1);
      } else if (var1 < 2048) {
         dv var4 = this.Y(2);
         var4.qs[var4.dI] = (byte)(var1 >> 6 | 192);
         var4.qs[var4.dI + 1] = (byte)(var1 & 63 | 128);
         var4.dI += 2;
         this.t(this.kH() + 2L);
      } else if (55296 <= var1 ? var1 < 57344 : false) {
         this.V(63);
      } else if (var1 < 65536) {
         dv var5 = this.Y(3);
         var5.qs[var5.dI] = (byte)(var1 >> 12 | 224);
         var5.qs[var5.dI + 1] = (byte)(var1 >> 6 & 63 | 128);
         var5.qs[var5.dI + 2] = (byte)(var1 & 63 | 128);
         var5.dI += 3;
         this.t(this.kH() + 3L);
      } else {
         if (var1 > 1114111) {
            throw new IllegalArgumentException("Unexpected code point: 0x" + db.T(var1));
         }

         dv var6 = this.Y(4);
         var6.qs[var6.dI] = (byte)(var1 >> 18 | 240);
         var6.qs[var6.dI + 1] = (byte)(var1 >> 12 & 63 | 128);
         var6.qs[var6.dI + 2] = (byte)(var1 >> 6 & 63 | 128);
         var6.qs[var6.dI + 3] = (byte)(var1 & 63 | 128);
         var6.dI += 4;
         this.t(this.kH() + 4L);
      }

      return this;
   }

   public de a(String var1, int var2, int var3, Charset var4) {
      fR.c(var1, (String)"");
      fR.c(var4, (String)"");
      if (var2 < 0) {
         boolean var10 = false;
         String var11 = "beginIndex < 0: " + var2;
         throw new IllegalArgumentException(var11.toString());
      } else if (var3 < var2) {
         boolean var8 = false;
         String var9 = "endIndex < beginIndex: " + var3 + " < " + var2;
         throw new IllegalArgumentException(var9.toString());
      } else if (var3 > var1.length()) {
         boolean var6 = false;
         String var7 = "endIndex > string.length: " + var3 + " > " + var1.length();
         throw new IllegalArgumentException(var7.toString());
      } else if (fR.c(var4, (Object)gx.tn)) {
         return this.m(var1, var2, var3);
      } else {
         String var10000 = var1.substring(var2, var3);
         fR.b(var10000, "");
         byte[] var12 = var10000.getBytes(var4);
         fR.b(var12, "");
         byte[] var5 = var12;
         return this.a(var5, 0, var5.length);
      }
   }

   public de c(byte[] var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      return this.a(var1, 0, var1.length);
   }

   public de a(byte[] var1, int var2, int var3) {
      fR.c(var1, (String)"");
      de var4 = this;
      boolean var5 = false;
      int var6 = var2;
      db.b((long)var1.length, (long)var2, (long)var3);

      dv var8;
      int var9;
      for(int var7 = var2 + var3; var6 < var7; var8.dI += var9) {
         var8 = var4.Y(1);
         var9 = Math.min(var7 - var6, 8192 - var8.dI);
         eI.a(var1, var8.qs, var8.dI, var6, var6 + var9);
         var6 += var9;
      }

      var4.t(var4.kH() + (long)var3);
      return var4;
   }

   public int write(ByteBuffer var1) throws IOException {
      fR.c(var1, (String)"");
      int var2 = var1.remaining();

      dv var4;
      int var5;
      for(int var3 = var2; var3 > 0; var4.dI += var5) {
         var4 = this.Y(1);
         var5 = Math.min(var3, 8192 - var4.dI);
         var1.get(var4.qs, var4.dI, var5);
         var3 -= var5;
      }

      this.jE += (long)var2;
      return var2;
   }

   public long b(dA var1) throws IOException {
      fR.c(var1, (String)"");
      de var2 = this;
      boolean var3 = false;
      long var4 = 0L;

      while(true) {
         long var6 = var1.a(var2, 8192L);
         if (var6 == -1L) {
            return var4;
         }

         var4 += var6;
      }
   }

   public de V(int var1) {
      boolean var3 = false;
      dv var4 = this.Y(1);
      byte[] var10000 = var4.qs;
      int var5 = var4.dI++;
      var10000[var5] = (byte)var1;
      this.t(this.kH() + 1L);
      return this;
   }

   public de W(int var1) {
      boolean var3 = false;
      dv var4 = this.Y(2);
      byte[] var5 = var4.qs;
      int var6 = var4.dI;
      var5[var6++] = (byte)(var1 >>> 8 & 255);
      var5[var6++] = (byte)(var1 & 255);
      var4.dI = var6;
      this.t(this.kH() + 2L);
      return this;
   }

   public de X(int var1) {
      boolean var3 = false;
      dv var4 = this.Y(4);
      byte[] var5 = var4.qs;
      int var6 = var4.dI;
      var5[var6++] = (byte)(var1 >>> 24 & 255);
      var5[var6++] = (byte)(var1 >>> 16 & 255);
      var5[var6++] = (byte)(var1 >>> 8 & 255);
      var5[var6++] = (byte)(var1 & 255);
      var4.dI = var6;
      this.t(this.kH() + 4L);
      return this;
   }

   public de B(long var1) {
      boolean var4 = false;
      long var5 = var1;
      de var10000;
      if (var1 == 0L) {
         var10000 = this.V(48);
      } else {
         boolean var7 = false;
         if (var1 < 0L) {
            var5 = -var1;
            if (var5 < 0L) {
               var10000 = this.aQ("-9223372036854775808");
               return var10000;
            }

            var7 = true;
         }

         int var8 = var5 < 100000000L ? (var5 < 10000L ? (var5 < 100L ? (var5 < 10L ? 1 : 2) : (var5 < 1000L ? 3 : 4)) : (var5 < 1000000L ? (var5 < 100000L ? 5 : 6) : (var5 < 10000000L ? 7 : 8))) : (var5 < 1000000000000L ? (var5 < 10000000000L ? (var5 < 1000000000L ? 9 : 10) : (var5 < 100000000000L ? 11 : 12)) : (var5 < 1000000000000000L ? (var5 < 10000000000000L ? 13 : (var5 < 100000000000000L ? 14 : 15)) : (var5 < 100000000000000000L ? (var5 < 10000000000000000L ? 16 : 17) : (var5 < 1000000000000000000L ? 18 : 19))));
         if (var7) {
            ++var8;
         }

         dv var9 = this.Y(var8);
         byte[] var10 = var9.qs;

         int var11;
         for(var11 = var9.dI + var8; var5 != 0L; var5 /= (long)10) {
            int var12 = (int)(var5 % (long)10);
            --var11;
            var10[var11] = dE.lP()[var12];
         }

         if (var7) {
            --var11;
            var10[var11] = 45;
         }

         var9.dI += var8;
         this.t(this.kH() + (long)var8);
         var10000 = this;
      }

      return var10000;
   }

   public de C(long var1) {
      boolean var4 = false;
      long var5 = var1;
      de var10000;
      if (var1 == 0L) {
         var10000 = this.V(48);
      } else {
         long var7 = var1 | var1 >>> 1;
         var7 |= var7 >>> 2;
         var7 |= var7 >>> 4;
         var7 |= var7 >>> 8;
         var7 |= var7 >>> 16;
         var7 |= var7 >>> 32;
         var7 -= var7 >>> 1 & 6148914691236517205L;
         var7 = (var7 >>> 2 & 3689348814741910323L) + (var7 & 3689348814741910323L);
         var7 = (var7 >>> 4) + var7 & 1085102592571150095L;
         var7 += var7 >>> 8;
         var7 += var7 >>> 16;
         var7 = (var7 & 63L) + (var7 >>> 32 & 63L);
         int var9 = (int)((var7 + (long)3) / (long)4);
         dv var10 = this.Y(var9);
         byte[] var11 = var10.qs;
         int var12 = var10.dI + var9 - 1;

         for(int var13 = var10.dI; var12 >= var13; --var12) {
            var11[var12] = dE.lP()[(int)(var5 & 15L)];
            var5 >>>= 4;
         }

         var10.dI += var9;
         this.t(this.kH() + (long)var9);
         var10000 = this;
      }

      return var10000;
   }

   public final dv Y(int var1) {
      boolean var3 = false;
      if (var1 < 1 || var1 > 8192) {
         boolean var4 = false;
         String var6 = "unexpected capacity";
         throw new IllegalArgumentException(var6.toString());
      } else {
         dv var10000;
         if (this.pR == null) {
            dv var5 = dw.lK();
            this.pR = var5;
            var5.qw = var5;
            var5.qv = var5;
            var10000 = var5;
         } else {
            var10000 = this.pR;
            fR.m(var10000);
            dv var7 = var10000.qw;
            fR.m(var7);
            if (var7.dI + var1 > 8192 || !var7.qu) {
               var7 = var7.b(dw.lK());
            }

            var10000 = var7;
         }

         return var10000;
      }
   }

   public void b(de var1, long var2) {
      fR.c(var1, (String)"");
      de var4 = this;
      boolean var5 = false;
      long var6 = var2;
      if (var1 == this) {
         boolean var8 = false;
         String var13 = "source == this";
         throw new IllegalArgumentException(var13.toString());
      } else {
         db.b(var1.kH(), 0L, var2);

         while(var6 > 0L) {
            dv var10001 = var1.pR;
            fR.m(var10001);
            int var19 = var10001.dI;
            dv var10002 = var1.pR;
            fR.m(var10002);
            if (var6 < (long)(var19 - var10002.dH)) {
               dv var16;
               if (var4.pR != null) {
                  var16 = var4.pR;
                  fR.m(var16);
                  var16 = var16.qw;
               } else {
                  var16 = null;
               }

               dv var9 = var16;
               if (var9 != null && var9.qu && var6 + (long)var9.dI - (long)(var9.qt ? 0 : var9.dH) <= 8192L) {
                  var16 = var1.pR;
                  fR.m(var16);
                  var16.a(var9, (int)var6);
                  var1.t(var1.kH() - var6);
                  var4.t(var4.kH() + var6);
                  break;
               }

               dv var20 = var1.pR;
               fR.m(var20);
               var1.pR = var20.ah((int)var6);
            }

            dv var14 = var1.pR;
            fR.m(var14);
            long var10 = (long)(var14.dI - var14.dH);
            var1.pR = var14.lI();
            if (var4.pR == null) {
               var4.pR = var14;
               var14.qw = var14;
               var14.qv = var14.qw;
            } else {
               dv var17 = var4.pR;
               fR.m(var17);
               dv var12 = var17.qw;
               fR.m(var12);
               var12 = var12.b(var14);
               var12.lJ();
            }

            var1.t(var1.kH() - var10);
            var4.t(var4.kH() + var10);
            var6 -= var10;
         }

      }
   }

   public long a(de var1, long var2) {
      fR.c(var1, (String)"");
      boolean var5 = false;
      long var7 = 0L;
      var7 = var2;
      if (var2 < 0L) {
         boolean var6 = false;
         String var9 = "byteCount < 0: " + var2;
         throw new IllegalArgumentException(var9.toString());
      } else {
         long var10000;
         if (this.kH() == 0L) {
            var10000 = -1L;
         } else {
            if (var2 > this.kH()) {
               var7 = this.kH();
            }

            var1.b(this, var7);
            var10000 = var7;
         }

         return var10000;
      }
   }

   public long a(byte var1, long var2, long var4) {
      boolean var7 = false;
      long var37 = 0L;
      var37 = var2;
      long var39 = 0L;
      var39 = var4;
      if (!(0L <= var2 ? var2 <= var4 : false)) {
         boolean var8 = false;
         String var41 = "size=" + this.kH() + " fromIndex=" + var2 + " toIndex=" + var4;
         throw new IllegalArgumentException(var41.toString());
      } else {
         if (var4 > this.kH()) {
            var39 = this.kH();
         }

         long var10000;
         if (var2 == var39) {
            var10000 = -1L;
         } else {
            long var10 = var2;
            boolean var12 = false;
            dv var47 = this.pR;
            if (var47 == null) {
               long var13 = -1L;
               Object var15 = null;
               boolean var16 = false;
               var10000 = -1L;
            } else {
               dv var23 = var47;
               if (this.kH() - var2 < var2) {
                  long var24;
                  for(var24 = this.kH(); var24 > var10; var24 -= (long)(var23.dI - var23.dH)) {
                     var47 = var23.qw;
                     fR.m(var47);
                     var23 = var47;
                  }

                  boolean var42 = false;
                  if (var23 == null) {
                     var10000 = -1L;
                  } else {
                     dv var17 = var23;

                     for(long var18 = var24; var18 < var39; var17 = var47) {
                        byte[] var20 = var17.qs;
                        int var21 = (int)Math.min((long)var17.dI, (long)var17.dH + var39 - var18);

                        for(int var22 = (int)((long)var17.dH + var37 - var18); var22 < var21; ++var22) {
                           if (var20[var22] == var1) {
                              var10000 = (long)(var22 - var17.dH) + var18;
                              return var10000;
                           }
                        }

                        var18 += (long)(var17.dI - var17.dH);
                        var37 = var18;
                        var47 = var17.qv;
                        fR.m(var47);
                     }

                     var10000 = -1L;
                  }
               } else {
                  long var44 = 0L;

                  while(true) {
                     long var26 = var44 + (long)(var23.dI - var23.dH);
                     if (var26 > var10) {
                        boolean var31 = false;
                        if (var23 == null) {
                           var10000 = -1L;
                        } else {
                           dv var32 = var23;

                           for(long var33 = var44; var33 < var39; var32 = var47) {
                              byte[] var43 = var32.qs;
                              int var35 = (int)Math.min((long)var32.dI, (long)var32.dH + var39 - var33);

                              for(int var36 = (int)((long)var32.dH + var37 - var33); var36 < var35; ++var36) {
                                 if (var43[var36] == var1) {
                                    var10000 = (long)(var36 - var32.dH) + var33;
                                    return var10000;
                                 }
                              }

                              var33 += (long)(var32.dI - var32.dH);
                              var37 = var33;
                              var47 = var32.qv;
                              fR.m(var47);
                           }

                           var10000 = -1L;
                        }
                        break;
                     }

                     var47 = var23.qv;
                     fR.m(var47);
                     var23 = var47;
                     var44 = var26;
                  }
               }
            }
         }

         return var10000;
      }
   }

   public long e(dh var1) {
      fR.c(var1, (String)"");
      return this.a(var1, 0L);
   }

   public long a(dh var1, long var2) {
      fR.c(var1, (String)"");
      de var4 = this;
      boolean var5 = false;
      long var40 = 0L;
      var40 = var2;
      if (var2 < 0L) {
         boolean var6 = false;
         String var42 = "fromIndex < 0: " + var2;
         throw new IllegalArgumentException(var42.toString());
      } else {
         long var8 = var2;
         boolean var10 = false;
         dv var10000 = this.pR;
         long var64;
         if (var10000 == null) {
            long var11 = -1L;
            Object var13 = null;
            boolean var14 = false;
            var64 = -1L;
         } else {
            dv var26 = var10000;
            if (this.kH() - var2 < var2) {
               long var27;
               for(var27 = this.kH(); var27 > var8; var27 -= (long)(var26.dI - var26.dH)) {
                  dv var65 = var26.qw;
                  fR.m(var65);
                  var26 = var65;
               }

               boolean var43 = false;
               if (var26 == null) {
                  var64 = -1L;
               } else {
                  dv var15 = var26;
                  long var16 = var27;
                  dv var67;
                  if (var1.lm() != 2) {
                     for(byte[] var44 = var1.lp(); var16 < var4.kH(); var15 = var67) {
                        byte[] var45 = var15.qs;
                        int var46 = (int)((long)var15.dH + var40 - var16);

                        for(int var49 = var15.dI; var46 < var49; ++var46) {
                           byte var52 = var45[var46];
                           int var55 = 0;

                           for(int var24 = var44.length; var55 < var24; ++var55) {
                              byte var25 = var44[var55];
                              if (var52 == var25) {
                                 var64 = (long)(var46 - var15.dH) + var16;
                                 return var64;
                              }
                           }
                        }

                        var16 += (long)(var15.dI - var15.dH);
                        var40 = var16;
                        var67 = var15.qv;
                        fR.m(var67);
                     }
                  } else {
                     byte var18 = var1.af(0);

                     for(byte var19 = var1.af(1); var16 < var4.kH(); var15 = var67) {
                        byte[] var20 = var15.qs;
                        int var21 = (int)((long)var15.dH + var40 - var16);

                        for(int var22 = var15.dI; var21 < var22; ++var21) {
                           byte var23 = var20[var21];
                           if (var23 == var18 || var23 == var19) {
                              var64 = (long)(var21 - var15.dH) + var16;
                              return var64;
                           }
                        }

                        var16 += (long)(var15.dI - var15.dH);
                        var40 = var16;
                        var67 = var15.qv;
                        fR.m(var67);
                     }
                  }

                  var64 = -1L;
               }
            } else {
               long var62 = 0L;

               while(true) {
                  long var29 = var62 + (long)(var26.dI - var26.dH);
                  if (var29 > var8) {
                     boolean var34 = false;
                     if (var26 == null) {
                        var64 = -1L;
                     } else {
                        dv var35 = var26;
                        long var36 = var62;
                        dv var70;
                        if (var1.lm() != 2) {
                           for(byte[] var48 = var1.lp(); var36 < var4.kH(); var35 = var70) {
                              byte[] var51 = var35.qs;
                              int var54 = (int)((long)var35.dH + var40 - var36);

                              for(int var57 = var35.dI; var54 < var57; ++var54) {
                                 byte var59 = var51[var54];
                                 int var61 = 0;

                                 for(int var38 = var48.length; var61 < var38; ++var61) {
                                    byte var39 = var48[var61];
                                    if (var59 == var39) {
                                       var64 = (long)(var54 - var35.dH) + var36;
                                       return var64;
                                    }
                                 }
                              }

                              var36 += (long)(var35.dI - var35.dH);
                              var40 = var36;
                              var70 = var35.qv;
                              fR.m(var70);
                           }
                        } else {
                           byte var47 = var1.af(0);

                           for(byte var50 = var1.af(1); var36 < var4.kH(); var35 = var70) {
                              byte[] var53 = var35.qs;
                              int var56 = (int)((long)var35.dH + var40 - var36);

                              for(int var58 = var35.dI; var56 < var58; ++var56) {
                                 byte var60 = var53[var56];
                                 if (var60 == var47 || var60 == var50) {
                                    var64 = (long)(var56 - var35.dH) + var36;
                                    return var64;
                                 }
                              }

                              var36 += (long)(var35.dI - var35.dH);
                              var40 = var36;
                              var70 = var35.qv;
                              fR.m(var70);
                           }
                        }

                        var64 = -1L;
                     }
                     break;
                  }

                  dv var68 = var26.qv;
                  fR.m(var68);
                  var26 = var68;
                  var62 = var29;
               }
            }
         }

         return var64;
      }
   }

   public void flush() {
   }

   public boolean isOpen() {
      return true;
   }

   public void close() {
   }

   public dB fu() {
      return dB.NONE;
   }

   public boolean equals(Object var1) {
      de var2 = this;
      boolean var3 = false;
      boolean var10000;
      if (this == var1) {
         var10000 = true;
      } else if (!(var1 instanceof de)) {
         var10000 = false;
      } else if (this.kH() != ((de)var1).kH()) {
         var10000 = false;
      } else if (this.kH() == 0L) {
         var10000 = true;
      } else {
         dv var17 = this.pR;
         fR.m(var17);
         dv var4 = var17;
         var17 = ((de)var1).pR;
         fR.m(var17);
         dv var5 = var17;
         int var6 = var4.dH;
         int var7 = var5.dH;
         long var8 = 0L;

         long var16;
         for(var16 = 0L; var8 < var2.kH(); var8 += var16) {
            var16 = (long)Math.min(var4.dI - var6, var5.dI - var7);
            long var12 = 0L;

            for(long var14 = var16; var12 < var14; ++var12) {
               if (var4.qs[var6++] != var5.qs[var7++]) {
                  var10000 = false;
                  return var10000;
               }
            }

            if (var6 == var4.dI) {
               var17 = var4.qv;
               fR.m(var17);
               var4 = var17;
               var6 = var4.dH;
            }

            if (var7 == var5.dI) {
               var17 = var5.qv;
               fR.m(var17);
               var5 = var17;
               var7 = var5.dH;
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   public int hashCode() {
      de var1 = this;
      boolean var2 = false;
      dv var10000 = this.pR;
      int var7;
      if (var10000 == null) {
         var7 = 0;
      } else {
         dv var3 = var10000;
         int var4 = 1;

         do {
            int var5 = var3.dH;

            for(int var6 = var3.dI; var5 < var6; ++var5) {
               var4 = 31 * var4 + var3.qs[var5];
            }

            dv var8 = var3.qv;
            fR.m(var8);
            var3 = var8;
         } while(var3 != var1.pR);

         var7 = var4;
      }

      return var7;
   }

   public String toString() {
      return this.la().toString();
   }

   public final de kY() {
      boolean var2 = false;
      de var3 = new de();
      de var10000;
      if (this.kH() == 0L) {
         var10000 = var3;
      } else {
         dv var7 = this.pR;
         fR.m(var7);
         dv var4 = var7;
         dv var5 = var4.lH();
         var3.pR = var5;
         var5.qw = var3.pR;
         var5.qv = var5.qw;

         for(dv var6 = var4.qv; var6 != var4; var6 = var6.qv) {
            var7 = var5.qw;
            fR.m(var7);
            fR.m(var6);
            var7.b(var6.lH());
         }

         var3.t(this.kH());
         var10000 = var3;
      }

      return var10000;
   }

   public de kZ() {
      return this.kY();
   }

   public final dh la() {
      boolean var2 = false;
      if (this.kH() > 2147483647L) {
         boolean var3 = false;
         String var4 = "size > Int.MAX_VALUE: " + this.kH();
         throw new IllegalStateException(var4.toString());
      } else {
         return this.Z((int)this.kH());
      }
   }

   public final dh Z(int var1) {
      boolean var3 = false;
      dh var10000;
      if (var1 == 0) {
         var10000 = dh.pV;
      } else {
         db.b(this.kH(), 0L, (long)var1);
         int var4 = 0;
         int var5 = 0;

         for(dv var6 = this.pR; var4 < var1; var6 = var6.qv) {
            fR.m(var6);
            if (var6.dI == var6.dH) {
               throw new AssertionError("s.limit == s.pos");
            }

            var4 += var6.dI - var6.dH;
            ++var5;
         }

         byte[][] var7 = new byte[var5][];
         int[] var8 = new int[var5 * 2];
         var4 = 0;
         var5 = 0;

         for(dv var11 = this.pR; var4 < var1; var11 = var11.qv) {
            fR.m(var11);
            var7[var5] = var11.qs;
            var4 += var11.dI - var11.dH;
            var8[var5] = Math.min(var4, var1);
            var8[var5 + ((Object[])var7).length] = var11.dH;
            var11.qt = true;
            ++var5;
         }

         var10000 = new dx(var7, var8);
      }

      return var10000;
   }

   // $FF: synthetic method
   public df lb() {
      return this.kJ();
   }

   // $FF: synthetic method
   public df f(dh var1) {
      return this.d(var1);
   }

   // $FF: synthetic method
   public df aR(String var1) {
      return this.aQ(var1);
   }

   // $FF: synthetic method
   public df d(byte[] var1) {
      return this.c(var1);
   }

   // $FF: synthetic method
   public df b(byte[] var1, int var2, int var3) {
      return this.a(var1, var2, var3);
   }

   // $FF: synthetic method
   public df aa(int var1) {
      return this.V(var1);
   }

   // $FF: synthetic method
   public df ab(int var1) {
      return this.W(var1);
   }

   // $FF: synthetic method
   public df ac(int var1) {
      return this.X(var1);
   }

   // $FF: synthetic method
   public df D(long var1) {
      return this.B(var1);
   }

   // $FF: synthetic method
   public df E(long var1) {
      return this.C(var1);
   }

   // $FF: synthetic method
   public Object clone() {
      return this.kZ();
   }

   public static final class a implements Closeable {
      public de buffer;
      public boolean readWrite;
      private dv segment;
      public long offset = -1L;
      public byte[] data;
      public int start = -1;
      public int end = -1;

      public final void a(dv var1) {
         this.segment = var1;
      }

      public void close() {
         boolean var2 = false;
         if (this.buffer == null) {
            boolean var3 = false;
            String var4 = "not attached to a buffer";
            throw new IllegalStateException(var4.toString());
         } else {
            this.buffer = null;
            this.a((dv)null);
            this.offset = -1L;
            this.data = null;
            this.start = -1;
            this.end = -1;
         }
      }
   }
}
