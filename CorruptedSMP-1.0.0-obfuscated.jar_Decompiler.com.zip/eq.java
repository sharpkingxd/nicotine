import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class eq {
   public static void e(Player var0, CorruptedSMPPlugin var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 27, "§8§lCorruption Recipes");
      int var3 = 10;

      for(l var7 : l.values()) {
         ItemStack var8 = a(var7);
         var2.setItem(var3, var8);
         ++var3;
         if (var3 == 17) {
            var3 = 19;
         }
      }

      ItemStack var9 = new ItemStack(Material.BOOK);
      ItemMeta var10 = var9.getItemMeta();
      if (var10 != null) {
         var10.setDisplayName("§e§lHow to Use");
         ArrayList var11 = new ArrayList();
         var11.add("§7Click on any corruption core");
         var11.add("§7to view its crafting recipe!");
         var10.setLore(var11);
         var9.setItemMeta(var10);
      }

      var2.setItem(22, var9);
      var0.openInventory(var2);
   }

   public static void b(Player var0, l var1, CorruptedSMPPlugin var2) {
      Inventory var3 = Bukkit.createInventory((InventoryHolder)null, 54, "§8§l" + var1.o() + " §8Recipe");
      ItemStack[] var4 = c(var1, var2);
      var3.setItem(10, var4[0]);
      var3.setItem(11, var4[1]);
      var3.setItem(12, var4[2]);
      var3.setItem(19, var4[3]);
      var3.setItem(20, var4[4]);
      var3.setItem(21, var4[5]);
      var3.setItem(28, var4[6]);
      var3.setItem(29, var4[7]);
      var3.setItem(30, var4[8]);
      ItemStack var5 = new ItemStack(Material.ARROW);
      ItemMeta var6 = var5.getItemMeta();
      if (var6 != null) {
         var6.setDisplayName("§e§lCrafts Into →");
         var5.setItemMeta(var6);
      }

      var3.setItem(23, var5);
      ItemStack var7 = a(var1);
      var3.setItem(25, var7);
      ItemStack var8 = new ItemStack(Material.BARRIER);
      ItemMeta var9 = var8.getItemMeta();
      if (var9 != null) {
         var9.setDisplayName("§c§lBack to Menu");
         var8.setItemMeta(var9);
      }

      var3.setItem(49, var8);
      ItemStack var10 = new ItemStack(Material.CRAFTING_TABLE);
      ItemMeta var11 = var10.getItemMeta();
      if (var11 != null) {
         var11.setDisplayName("§6§lRitual Information");
         ArrayList var12 = new ArrayList();
         var12.add("§7Craft this recipe in a");
         var12.add("§7§lCrafting Table §7to start a ritual!");
         var12.add("");
         var12.add("§eRitual Duration: §f15 minutes");
         var12.add("§eFirst to claim: §fGets the corruption");
         var11.setLore(var12);
         var10.setItemMeta(var11);
      }

      var3.setItem(31, var10);
      var0.openInventory(var3);
   }

   private static ItemStack a(l var0) {
      ItemStack var1 = new ItemStack(Material.FLOW_BANNER_PATTERN);
      ItemMeta var2 = var1.getItemMeta();
      if (var2 != null) {
         var2.setDisplayName(var0.o());
         var2.setCustomModelData(var0.n());
         ArrayList var3 = new ArrayList();
         var3.add("§7Click to view recipe!");
         var2.setLore(var3);
         var2.addEnchant(Enchantment.UNBREAKING, 1, true);
         var2.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         var1.setItemMeta(var2);
      }

      return var1;
   }

   private static ItemStack[] c(l var0, CorruptedSMPPlugin var1) {
      return B.b(var0, var1);
   }
}
