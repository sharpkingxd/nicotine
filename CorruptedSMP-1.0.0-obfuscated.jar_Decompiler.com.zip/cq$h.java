public final class cq$h extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final int $streamId$inlined;
   // $FF: synthetic field
   final cm $errorCode$inlined;

   public cq$h(String var1, boolean var2, cq var3, int var4, cm var5) {
      super(var1, var2);
      this.this$0 = var3;
      this.$streamId$inlined = var4;
      this.$errorCode$inlined = var5;
   }

   public long gg() {
      boolean var1 = false;
      cq.j(this.this$0).f(this.$streamId$inlined, this.$errorCode$inlined);
      cq var2 = this.this$0;
      synchronized(var2) {
         boolean var3 = false;
         cq.i(this.this$0).remove(this.$streamId$inlined);
         eE var5 = eE.sk;
      }

      return -1L;
   }
}
