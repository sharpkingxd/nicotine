public final class dD {
   public static final String e(byte[] var0) {
      fR.c(var0, (String)"");
      return new String(var0, gx.tn);
   }

   public static final byte[] aX(String var0) {
      fR.c(var0, (String)"");
      byte[] var10000 = var0.getBytes(gx.tn);
      fR.b(var10000, "");
      return var10000;
   }
}
