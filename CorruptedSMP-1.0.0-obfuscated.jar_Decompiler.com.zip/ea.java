import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ea implements Listener {
   private final CorruptedSMPPlugin rx;

   public ea(CorruptedSMPPlugin var1) {
      this.rx = var1;
   }

   @EventHandler
   public void a(PlayerDeathEvent var1) {
      D var2 = this.rx.f().g(var1.getEntity().getUniqueId());
      if (this.rx.d().b(var1.getEntity())) {
         l var3 = this.rx.d().c(var1.getEntity());
         if (var3 == l.v) {
            o.t();
         }
      }

      if (this.rx.d().b(var1.getEntity())) {
         l var5 = this.rx.d().c(var1.getEntity());
         if (var5 != null) {
            ItemStack var4 = this.a(var5);
            var1.getDrops().add(var4);
            this.rx.d().a(var1.getEntity());
            this.rx.f().c(var2);
            var1.getEntity().sendMessage("§c§l✗ Your " + var5.o() + " §c§lCore has been dropped!");
         }
      }

      var2.E();
      var2.H();
      var2.L();
      var2.O();
      var2.b(false);
   }

   private ItemStack a(l var1) {
      ItemStack var2 = new ItemStack(Material.FLOW_BANNER_PATTERN);
      ItemMeta var3 = var2.getItemMeta();
      if (var3 != null) {
         var3.setDisplayName(var1.o() + " §fCore");
         var3.setLore(j.b(var1));
         var3.setCustomModelData(var1.n());
         var3.addEnchant(Enchantment.UNBREAKING, 1, true);
         var3.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         var2.setItemMeta(var3);
      }

      return var2;
   }
}
