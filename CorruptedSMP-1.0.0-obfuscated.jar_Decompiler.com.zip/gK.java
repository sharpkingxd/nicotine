import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class gK extends gJ {
   public static final CharSequence c(CharSequence var0) {
      fR.c(var0, (String)"");
      CharSequence var1 = var0;
      boolean var2 = false;
      int var3 = 0;
      int var4 = var0.length() - 1;
      boolean var5 = false;

      while(var3 <= var4) {
         int var6 = !var5 ? var3 : var4;
         char var7 = var1.charAt(var6);
         boolean var8 = false;
         var7 = gu.g(var7);
         if (!var5) {
            if (!var7) {
               var5 = true;
            } else {
               ++var3;
            }
         } else {
            if (!var7) {
               break;
            }

            --var4;
         }
      }

      return var1.subSequence(var3, var4 + 1);
   }

   public static final gf d(CharSequence var0) {
      fR.c(var0, (String)"");
      return new gf(0, var0.length() - 1);
   }

   public static final int e(CharSequence var0) {
      fR.c(var0, (String)"");
      return var0.length() - 1;
   }

   public static final String a(CharSequence var0, gf var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return var0.subSequence(var1.nG(), var1.nH() + 1).toString();
   }

   public static final String a(String var0, CharSequence var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (gA.a((CharSequence)var0, var1, false, 2, (Object)null)) {
         int var3 = var1.length();
         String var10000 = var0.substring(var3);
         fR.b(var10000, "");
         return var10000;
      } else {
         return var0;
      }
   }

   public static final String b(String var0, CharSequence var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (gA.b((CharSequence)var0, var1, false, 2, (Object)null)) {
         byte var3 = 0;
         int var4 = var0.length() - var1.length();
         String var10000 = var0.substring(var3, var4);
         fR.b(var10000, "");
         return var10000;
      } else {
         return var0;
      }
   }

   public static final boolean a(CharSequence var0, int var1, CharSequence var2, int var3, int var4, boolean var5) {
      fR.c(var0, (String)"");
      fR.c(var2, (String)"");
      if (var3 >= 0 && var1 >= 0 && var1 <= var0.length() - var4 && var3 <= var2.length() - var4) {
         for(int var6 = 0; var6 < var4; ++var6) {
            if (!gu.a(var0.charAt(var1 + var6), var2.charAt(var3 + var6), var5)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public static final boolean a(CharSequence var0, CharSequence var1, boolean var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var2 && var0 instanceof String && var1 instanceof String ? gA.a((String)var0, (String)var1, false, 2, (Object)null) : gA.a(var0, 0, var1, 0, var1.length(), var2);
   }

   // $FF: synthetic method
   public static boolean a(CharSequence var0, CharSequence var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return gA.a(var0, var1, var2);
   }

   public static final boolean b(CharSequence var0, CharSequence var1, boolean var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var2 && var0 instanceof String && var1 instanceof String ? gA.b((String)var0, (String)var1, false, 2, (Object)null) : gA.a(var0, var0.length() - var1.length(), var1, 0, var1.length(), var2);
   }

   // $FF: synthetic method
   public static boolean b(CharSequence var0, CharSequence var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return gA.b(var0, var1, var2);
   }

   public static final int a(CharSequence var0, char[] var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (!var3 && var1.length == 1 && var0 instanceof String) {
         char var14 = eI.a(var1);
         return ((String)var0).indexOf(var14, var2);
      } else {
         fd var4 = (new gf(gg.m(var2, 0), gA.e(var0))).nF();

         while(var4.hasNext()) {
            int var5 = var4.aR();
            char var6 = var0.charAt(var5);
            char[] var7 = var1;
            boolean var8 = false;
            int var9 = 0;
            int var10 = var1.length;

            boolean var10000;
            while(true) {
               if (var9 >= var10) {
                  var10000 = false;
                  break;
               }

               char var11 = var7[var9];
               boolean var13 = false;
               if (gu.a(var11, var6, var3)) {
                  var10000 = true;
                  break;
               }

               ++var9;
            }

            if (var10000) {
               return var5;
            }
         }

         return -1;
      }
   }

   public static final int b(CharSequence var0, char[] var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (!var3 && var1.length == 1 && var0 instanceof String) {
         char var13 = eI.a(var1);
         return ((String)var0).lastIndexOf(var13, var2);
      } else {
         for(int var4 = gg.n(var2, gA.e(var0)); -1 < var4; --var4) {
            char var5 = var0.charAt(var4);
            char[] var6 = var1;
            boolean var7 = false;
            int var8 = 0;
            int var9 = var1.length;

            boolean var10000;
            while(true) {
               if (var8 >= var9) {
                  var10000 = false;
                  break;
               }

               char var10 = var6[var8];
               boolean var12 = false;
               if (gu.a(var10, var5, var3)) {
                  var10000 = true;
                  break;
               }

               ++var8;
            }

            if (var10000) {
               return var4;
            }
         }

         return -1;
      }
   }

   private static final int a(CharSequence var0, CharSequence var1, int var2, int var3, boolean var4, boolean var5) {
      gd var6 = !var5 ? (gd)(new gf(gg.m(var2, 0), gg.n(var3, var0.length()))) : gg.k(gg.n(var2, gA.e(var0)), gg.m(var3, 0));
      if (var0 instanceof String && var1 instanceof String) {
         int var10 = var6.nC();
         int var11 = var6.nD();
         int var12 = var6.nE();
         if (var12 > 0 && var10 <= var11 || var12 < 0 && var11 <= var10) {
            while(true) {
               if (gA.a((String)var1, 0, (String)var0, var10, var1.length(), var4)) {
                  return var10;
               }

               if (var10 == var11) {
                  break;
               }

               var10 += var12;
            }
         }
      } else {
         int var7 = var6.nC();
         int var8 = var6.nD();
         int var9 = var6.nE();
         if (var9 > 0 && var7 <= var8 || var9 < 0 && var8 <= var7) {
            while(true) {
               if (gA.a(var1, 0, var0, var7, var1.length(), var4)) {
                  return var7;
               }

               if (var7 == var8) {
                  break;
               }

               var7 += var9;
            }
         }
      }

      return -1;
   }

   // $FF: synthetic method
   static int a(CharSequence var0, CharSequence var1, int var2, int var3, boolean var4, boolean var5, int var6, Object var7) {
      if ((var6 & 16) != 0) {
         var5 = false;
      }

      return a(var0, var1, var2, var3, var4, var5);
   }

   private static final ez<Integer, String> a(CharSequence var0, Collection<String> var1, int var2, boolean var3, boolean var4) {
      if (!var3 && var1.size() == 1) {
         String var16 = (String)eO.b((Iterable)var1);
         int var18 = !var4 ? gA.a(var0, var16, var2, false, 4, (Object)null) : gA.b(var0, var16, var2, false, 4, (Object)null);
         return var18 < 0 ? null : eB.b(var18, var16);
      } else {
         gd var5 = !var4 ? (gd)(new gf(gg.m(var2, 0), var0.length())) : gg.k(gg.n(var2, gA.e(var0)), 0);
         if (var0 instanceof String) {
            int var6 = var5.nC();
            int var7 = var5.nD();
            int var8 = var5.nE();
            if (var8 > 0 && var6 <= var7 || var8 < 0 && var7 <= var6) {
               while(true) {
                  Iterable var10 = (Iterable)var1;
                  boolean var11 = false;
                  Iterator var12 = var10.iterator();

                  Object var10000;
                  while(true) {
                     if (!var12.hasNext()) {
                        var10000 = null;
                        break;
                     }

                     Object var13 = var12.next();
                     String var14 = (String)var13;
                     boolean var15 = false;
                     if (gA.a(var14, 0, (String)var0, var6, var14.length(), var3)) {
                        var10000 = var13;
                        break;
                     }
                  }

                  String var9 = (String)var10000;
                  if (var9 != null) {
                     return eB.<Integer, String>b(var6, var9);
                  }

                  if (var6 == var7) {
                     break;
                  }

                  var6 += var8;
               }
            }
         } else {
            int var17 = var5.nC();
            int var19 = var5.nD();
            int var20 = var5.nE();
            if (var20 > 0 && var17 <= var19 || var20 < 0 && var19 <= var17) {
               while(true) {
                  Iterable var22 = (Iterable)var1;
                  boolean var23 = false;
                  Iterator var24 = var22.iterator();

                  Object var28;
                  while(true) {
                     if (!var24.hasNext()) {
                        var28 = null;
                        break;
                     }

                     Object var25 = var24.next();
                     String var26 = (String)var25;
                     boolean var27 = false;
                     if (gA.a((CharSequence)var26, 0, var0, var17, var26.length(), var3)) {
                        var28 = var25;
                        break;
                     }
                  }

                  String var21 = (String)var28;
                  if (var21 != null) {
                     return eB.<Integer, String>b(var17, var21);
                  }

                  if (var17 == var19) {
                     break;
                  }

                  var17 += var20;
               }
            }
         }

         return null;
      }
   }

   public static final int a(CharSequence var0, char var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      int var10000;
      if (!var3 && var0 instanceof String) {
         var10000 = ((String)var0).indexOf(var1, var2);
      } else {
         char[] var4 = new char[]{var1};
         var10000 = gA.a(var0, var4, var2, var3);
      }

      return var10000;
   }

   // $FF: synthetic method
   public static int a(CharSequence var0, char var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.a(var0, var1, var2, var3);
   }

   public static final int a(CharSequence var0, String var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var3 && var0 instanceof String ? ((String)var0).indexOf(var1, var2) : a(var0, (CharSequence)var1, var2, var0.length(), var3, false, 16, (Object)null);
   }

   // $FF: synthetic method
   public static int a(CharSequence var0, String var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.a(var0, var1, var2, var3);
   }

   public static final int b(CharSequence var0, char var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      int var10000;
      if (!var3 && var0 instanceof String) {
         var10000 = ((String)var0).lastIndexOf(var1, var2);
      } else {
         char[] var4 = new char[]{var1};
         var10000 = gA.b(var0, var4, var2, var3);
      }

      return var10000;
   }

   // $FF: synthetic method
   public static int b(CharSequence var0, char var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = gA.e(var0);
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.b(var0, var1, var2, var3);
   }

   public static final int b(CharSequence var0, String var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var3 && var0 instanceof String ? ((String)var0).lastIndexOf(var1, var2) : a(var0, (CharSequence)var1, var2, 0, var3, true);
   }

   // $FF: synthetic method
   public static int b(CharSequence var0, String var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = gA.e(var0);
      }

      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.b(var0, var1, var2, var3);
   }

   public static final boolean c(CharSequence var0, CharSequence var1, boolean var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return var1 instanceof String ? gA.a(var0, (String)var1, 0, var2, 2, (Object)null) >= 0 : a(var0, var1, 0, var0.length(), var2, false, 16, (Object)null) >= 0;
   }

   // $FF: synthetic method
   public static boolean c(CharSequence var0, CharSequence var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return gA.c(var0, var1, var2);
   }

   public static final boolean a(CharSequence var0, char var1, boolean var2) {
      fR.c(var0, (String)"");
      return gA.a(var0, var1, 0, var2, 2, (Object)null) >= 0;
   }

   // $FF: synthetic method
   public static boolean a(CharSequence var0, char var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return gA.a(var0, var1, var2);
   }

   private static final gm<gf> a(CharSequence var0, final char[] var1, int var2, final boolean var3, int var4) {
      gA.as(var4);
      return new gy(var0, var2, var4, new fL<CharSequence, Integer, ez<? extends Integer, ? extends Integer>>() {
         public final ez<Integer, Integer> b(CharSequence var1x, int var2) {
            fR.c(var1x, (String)"");
            int var3x = gA.a(var1x, var1, var2, var3);
            boolean var5 = false;
            return var3x < 0 ? null : eB.b(var3x, 1);
         }

         // $FF: synthetic method
         public Object invoke(Object var1x, Object var2) {
            return this.b((CharSequence)var1x, ((Number)var2).intValue());
         }
      });
   }

   // $FF: synthetic method
   static gm a(CharSequence var0, char[] var1, int var2, boolean var3, int var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = 0;
      }

      if ((var5 & 4) != 0) {
         var3 = false;
      }

      if ((var5 & 8) != 0) {
         var4 = 0;
      }

      return a(var0, var1, var2, var3, var4);
   }

   private static final gm<gf> a(CharSequence var0, String[] var1, int var2, final boolean var3, int var4) {
      gA.as(var4);
      final List var5 = eI.c(var1);
      return new gy(var0, var2, var4, new fL<CharSequence, Integer, ez<? extends Integer, ? extends Integer>>() {
         public final ez<Integer, Integer> c(CharSequence var1, int var2) {
            fR.c(var1, (String)"");
            ez var10000 = gK.a(var1, (Collection)var5, var2, var3, false);
            if (var10000 != null) {
               ez var3x = var10000;
               boolean var5x = false;
               var10000 = eB.b(var3x.ne(), ((String)var3x.nf()).length());
            } else {
               var10000 = null;
            }

            return var10000;
         }

         // $FF: synthetic method
         public Object invoke(Object var1, Object var2) {
            return this.c((CharSequence)var1, ((Number)var2).intValue());
         }
      });
   }

   // $FF: synthetic method
   static gm a(CharSequence var0, String[] var1, int var2, boolean var3, int var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = 0;
      }

      if ((var5 & 4) != 0) {
         var3 = false;
      }

      if ((var5 & 8) != 0) {
         var4 = 0;
      }

      return a(var0, var1, var2, var3, var4);
   }

   public static final void as(int var0) {
      boolean var1 = var0 >= 0;
      if (!var1) {
         boolean var2 = false;
         String var3 = "Limit must be non-negative, but was " + var0;
         throw new IllegalArgumentException(var3.toString());
      }
   }

   public static final gm<String> a(final CharSequence var0, String[] var1, boolean var2, int var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return gn.a(a(var0, (String[])var1, 0, var2, var3, 2, (Object)null), new fK<gf, String>() {
         public final String a(gf var1) {
            fR.c(var1, (String)"");
            return gA.a(var0, var1);
         }

         // $FF: synthetic method
         public Object invoke(Object var1) {
            return this.a((gf)var1);
         }
      });
   }

   // $FF: synthetic method
   public static gm a(CharSequence var0, String[] var1, boolean var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = false;
      }

      if ((var4 & 4) != 0) {
         var3 = 0;
      }

      return gA.a(var0, var1, var2, var3);
   }

   public static final List<String> a(CharSequence var0, char[] var1, boolean var2, int var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (var1.length == 1) {
         return a(var0, String.valueOf(var1[0]), var2, var3);
      } else {
         Iterable var4 = gn.c(a(var0, (char[])var1, 0, var2, var3, 2, (Object)null));
         boolean var5 = false;
         Collection var7 = (Collection)(new ArrayList(eO.a(var4, 10)));
         boolean var8 = false;

         for(Object var10 : var4) {
            gf var11 = (gf)var10;
            boolean var12 = false;
            var7.add(gA.a(var0, var11));
         }

         return (List)var7;
      }
   }

   // $FF: synthetic method
   public static List a(CharSequence var0, char[] var1, boolean var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = false;
      }

      if ((var4 & 4) != 0) {
         var3 = 0;
      }

      return gA.a(var0, var1, var2, var3);
   }

   private static final List<String> a(CharSequence var0, String var1, boolean var2, int var3) {
      gA.as(var3);
      int var4 = 0;
      int var5 = gA.a(var0, var1, var4, var2);
      if (var5 != -1 && var3 != 1) {
         boolean var6 = var3 > 0;
         ArrayList var7 = new ArrayList(var6 ? gg.n(var3, 10) : 10);

         do {
            var7.add(var0.subSequence(var4, var5).toString());
            var4 = var5 + var1.length();
            if (var6 && var7.size() == var3 - 1) {
               break;
            }

            var5 = gA.a(var0, var1, var4, var2);
         } while(var5 != -1);

         var7.add(var0.subSequence(var4, var0.length()).toString());
         return (List)var7;
      } else {
         return eO.i(var0.toString());
      }
   }

   public static final gm<String> f(CharSequence var0) {
      fR.c(var0, (String)"");
      String[] var1 = new String[]{"\r\n", "\n", "\r"};
      return gA.a(var0, var1, false, 0, 6, (Object)null);
   }

   public static final List<String> g(CharSequence var0) {
      fR.c(var0, (String)"");
      return gn.a(gA.f(var0));
   }
}
