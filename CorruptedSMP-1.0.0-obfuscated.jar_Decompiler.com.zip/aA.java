import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public final class aA<T extends Date> extends ac<T> {
   private final a<T> bG;
   private final List<DateFormat> bH;

   public void a(aV var1, Date var2) throws IOException {
      if (var2 == null) {
         var1.be();
      } else {
         DateFormat var3 = (DateFormat)this.bH.get(0);
         String var4;
         synchronized(this.bH) {
            var4 = var3.format(var2);
         }

         var1.t(var4);
      }
   }

   public T m(aT var1) throws IOException {
      if (var1.aI() == aU.dY) {
         var1.aO();
         return null;
      } else {
         Date var2 = this.n(var1);
         return this.bG.a(var2);
      }
   }

   private Date n(aT var1) throws IOException {
      String var2 = var1.aM();
      synchronized(this.bH) {
         for(DateFormat var5 : this.bH) {
            try {
               Date var10000 = var5.parse(var2);
               return var10000;
            } catch (ParseException var9) {
            }
         }
      }

      try {
         return aM.a(var2, new ParsePosition(0));
      } catch (ParseException var8) {
         throw new X("Failed parsing '" + var2 + "' as Date; at path " + var1.aV(), var8);
      }
   }

   public String toString() {
      DateFormat var1 = (DateFormat)this.bH.get(0);
      return var1 instanceof SimpleDateFormat ? "DefaultDateTypeAdapter(" + ((SimpleDateFormat)var1).toPattern() + ')' : "DefaultDateTypeAdapter(" + var1.getClass().getSimpleName() + ')';
   }

   // $FF: synthetic method
   public Object b(aT var1) throws IOException {
      return this.m(var1);
   }

   public abstract static class a<T extends Date> {
      public static final a<Date> DATE = new a<Date>(Date.class) {
         protected Date a(Date var1) {
            return var1;
         }
      };
      private final Class<T> dateClass;

      protected a(Class<T> var1) {
         this.dateClass = var1;
      }

      protected abstract T a(Date var1);
   }
}
