public interface ev<T> {
   T getValue();
}
