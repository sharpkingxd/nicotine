import java.io.IOException;
import java.lang.ref.Reference;
import java.net.ConnectException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownServiceException;
import java.net.Proxy.Type;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public final class bT extends cq.c implements bg {
   public static final a lf = new a((fP)null);
   private final bU lg;
   private final bA lh;
   private Socket li;
   private Socket socket;
   private bp handshake;
   private bv protocol;
   private cq lj;
   private dg source;
   private df sink;
   private boolean lk;
   private boolean ll;
   private int lm;
   private int ln;
   private int kL;
   private int lo;
   private final List<Reference<bS>> lp;
   private long lq;

   public bT(bU var1, bA var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.lg = var1;
      this.lh = var2;
      this.lo = 1;
      this.lp = (List)(new ArrayList());
      this.lq = Long.MAX_VALUE;
   }

   public final boolean hi() {
      return this.lk;
   }

   public final void t(boolean var1) {
      this.lk = var1;
   }

   public final int hj() {
      return this.lm;
   }

   public final List<Reference<bS>> hk() {
      return this.lp;
   }

   public final long hl() {
      return this.lq;
   }

   public final void i(long var1) {
      this.lq = var1;
   }

   public final boolean hm() {
      return this.lj != null;
   }

   public final synchronized void hn() {
      this.lk = true;
   }

   public final synchronized void ho() {
      this.ll = true;
   }

   public final synchronized void hp() {
      int var1 = this.ln++;
   }

   public final void a(int var1, int var2, int var3, int var4, boolean var5, bb var6, bo var7) {
      fR.c(var6, (String)"");
      fR.c(var7, (String)"");
      if (this.protocol != null) {
         boolean var13 = false;
         String var14 = "already connected";
         throw new IllegalStateException(var14.toString());
      } else {
         bW var8 = null;
         List var9 = this.lh.fo().bM();
         bP var10 = new bP(var9);
         if (this.lh.fo().bE() == null) {
            if (!var9.contains(bi.hi)) {
               throw new bW((IOException)(new UnknownServiceException("CLEARTEXT communication not enabled for client")));
            }

            String var11 = this.lh.fo().bK().cY();
            if (!cH.oU.jZ().aG(var11)) {
               throw new bW((IOException)(new UnknownServiceException("CLEARTEXT communication to " + var11 + " not permitted by network security policy")));
            }
         } else if (this.lh.fo().bL().contains(bv.iK)) {
            throw new bW((IOException)(new UnknownServiceException("H2_PRIOR_KNOWLEDGE cannot be used with HTTPS")));
         }

         while(true) {
            try {
               if (this.lh.fr()) {
                  this.a(var1, var2, var3, var6, var7);
                  if (this.li == null) {
                     break;
                  }
               } else {
                  this.a(var1, var2, var6, var7);
               }

               this.a(var10, var4, var6, var7);
               var7.a(var6, this.lh.fq(), this.lh.fp(), this.protocol);
               break;
            } catch (IOException var12) {
               Socket var10000 = this.socket;
               if (var10000 != null) {
                  bD.a(var10000);
               }

               var10000 = this.li;
               if (var10000 != null) {
                  bD.a(var10000);
               }

               this.socket = null;
               this.li = null;
               this.source = null;
               this.sink = null;
               this.handshake = null;
               this.protocol = null;
               this.lj = null;
               this.lo = 1;
               var7.a(var6, this.lh.fq(), this.lh.fp(), (bv)null, var12);
               if (var8 == null) {
                  var8 = new bW(var12);
               } else {
                  var8.k(var12);
               }

               if (!var5 || !var10.c(var12)) {
                  throw var8;
               }
            }
         }

         if (this.lh.fr() && this.li == null) {
            throw new bW((IOException)(new ProtocolException("Too many tunnel connections attempted: 21")));
         } else {
            this.lq = System.nanoTime();
         }
      }
   }

   private final void a(int var1, int var2, int var3, bb var4, bo var5) throws IOException {
      bw var6 = this.hq();
      br var7 = var6.eI();

      for(int var8 = 0; var8 < 21; ++var8) {
         this.a(var1, var2, var4, var5);
         bw var10000 = this.a(var2, var3, var6, var7);
         if (var10000 == null) {
            break;
         }

         var6 = var10000;
         Socket var9 = this.li;
         if (var9 != null) {
            bD.a(var9);
         }

         this.li = null;
         this.sink = null;
         this.source = null;
         var5.a(var4, this.lh.fq(), this.lh.fp(), (bv)null);
      }

   }

   private final void a(int var1, int var2, bb var3, bo var4) throws IOException {
      Proxy var5 = this.lh.fp();
      aX var6 = this.lh.fo();
      Proxy.Type var10000 = var5.type();
      Socket var14;
      switch (var10000 == null ? -1 : bT.b.$EnumSwitchMapping$0[var10000.ordinal()]) {
         case 1:
         case 2:
            var14 = var6.bD().createSocket();
            fR.m(var14);
            break;
         default:
            var14 = new Socket(var5);
      }

      Socket var7 = var14;
      this.li = var7;
      var4.a(var3, this.lh.fq(), var5);
      var7.setSoTimeout(var2);

      try {
         cH.oU.jZ().a(var7, this.lh.fq(), var1);
      } catch (ConnectException var12) {
         ConnectException var9 = new ConnectException("Failed to connect to " + this.lh.fq());
         boolean var11 = false;
         var9.initCause((Throwable)var12);
         throw (Throwable)var9;
      }

      try {
         this.source = do.c(do.d(var7));
         this.sink = do.b(do.c(var7));
      } catch (NullPointerException var13) {
         if (fR.c(var13.getMessage(), (Object)"throw with null exception")) {
            throw new IOException((Throwable)var13);
         }
      }

   }

   private final void a(bP var1, int var2, bb var3, bo var4) throws IOException {
      if (this.lh.fo().bE() == null) {
         if (this.lh.fo().bL().contains(bv.iK)) {
            this.socket = this.li;
            this.protocol = bv.iK;
            this.s(var2);
         } else {
            this.socket = this.li;
            this.protocol = bv.iH;
         }
      } else {
         var4.b(var3);
         this.a(var1);
         var4.a(var3, this.handshake);
         if (this.protocol == bv.iJ) {
            this.s(var2);
         }

      }
   }

   private final void s(int var1) throws IOException {
      Socket var10000 = this.socket;
      fR.m(var10000);
      Socket var2 = var10000;
      dg var6 = this.source;
      fR.m(var6);
      dg var3 = var6;
      df var7 = this.sink;
      fR.m(var7);
      df var4 = var7;
      var2.setSoTimeout(0);
      cq var5 = (new cq.a(true, bN.kr)).a(var2, this.lh.fo().bK().cY(), var3, var4).a(this).J(var1).iH();
      this.lj = var5;
      this.lo = cq.ne.iI().jz();
      cq.a(var5, false, (bN)null, 3, (Object)null);
   }

   private final void a(bP var1) throws IOException {
      final aX var2 = this.lh.fo();
      SSLSocketFactory var3 = var2.bE();
      boolean var4 = false;
      SSLSocket var5 = null;
      boolean var12 = false;

      try {
         var12 = true;
         fR.m(var3);
         Socket var10000 = var3.createSocket(this.li, var2.bK().cY(), var2.bK().cZ(), true);
         fR.m(var10000);
         var5 = (SSLSocket)var10000;
         bi var6 = var1.b(var5);
         if (var6.cz()) {
            cH.oU.jZ().a(var5, var2.bK().cY(), var2.bL());
         }

         var5.startHandshake();
         SSLSession var7 = var5.getSession();
         bp.a var19 = bp.hJ;
         fR.b(var7, "");
         final bp var8 = var19.a(var7);
         HostnameVerifier var20 = var2.bF();
         fR.m(var20);
         if (!var20.verify(var2.bK().cY(), var7)) {
            List var15 = var8.cP();
            if (!((Collection)var15).isEmpty()) {
               Object var22 = var15.get(0);
               fR.m(var22);
               X509Certificate var16 = (X509Certificate)var22;
               throw new SSLPeerUnverifiedException(gA.a("\n              |Hostname " + var2.bK().cY() + " not verified:\n              |    certificate: " + bd.eB.a((Certificate)var16) + "\n              |    DN: " + var16.getSubjectDN().getName() + "\n              |    subjectAltNames: " + cY.pM.d(var16) + "\n              ", (String)null, 1, (Object)null));
            }

            throw new SSLPeerUnverifiedException("Hostname " + var2.bK().cY() + " not verified (no certificates)");
         }

         bd var21 = var2.bG();
         fR.m(var21);
         final bd var9 = var21;
         this.handshake = new bp(var8.cM(), var8.cN(), var8.cO(), new fJ<List<? extends Certificate>>() {
            public final List<Certificate> hu() {
               cX var10000 = var9.cl();
               fR.m(var10000);
               return var10000.a(var8.cP(), var2.bK().cY());
            }

            // $FF: synthetic method
            public Object invoke() {
               return this.hu();
            }
         });
         var9.a(var2.bK().cY(), new fJ<List<? extends X509Certificate>>() {
            public final List<X509Certificate> hv() {
               bp var10000 = bT.this.handshake;
               fR.m(var10000);
               Iterable var1 = (Iterable)var10000.cP();
               boolean var2 = false;
               Collection var4 = (Collection)(new ArrayList(eO.a(var1, 10)));
               boolean var5 = false;

               for(Object var7 : var1) {
                  Certificate var8 = (Certificate)var7;
                  boolean var9 = false;
                  fR.m(var8);
                  var4.add((X509Certificate)var8);
               }

               return (List)var4;
            }

            // $FF: synthetic method
            public Object invoke() {
               return this.hv();
            }
         });
         String var10 = var6.cz() ? cH.oU.jZ().d(var5) : null;
         this.socket = (Socket)var5;
         this.source = do.c(do.d((Socket)var5));
         this.sink = do.b(do.c((Socket)var5));
         this.protocol = var10 != null ? bv.iE.ag(var10) : bv.iH;
         var4 = true;
         var12 = false;
      } finally {
         if (var12) {
            if (var5 != null) {
               cH.oU.jZ().e(var5);
            }

            if (var5 != null) {
               bD.a((Socket)var5);
            }

         }
      }

      cH.oU.jZ().e(var5);
   }

   private final bw a(int var1, int var2, bw var3, br var4) throws IOException {
      bw var5 = var3;
      String var6 = "CONNECT " + bD.a(var4, true) + " HTTP/1.1";

      label25:
      while(true) {
         dg var10000 = this.source;
         fR.m(var10000);
         dg var7 = var10000;
         df var11 = this.sink;
         fR.m(var11);
         df var8 = var11;
         ck var9 = new ck((bu)null, this, var7, var8);
         var7.fu().d((long)var1, TimeUnit.MILLISECONDS);
         var8.fu().d((long)var2, TimeUnit.MILLISECONDS);
         var9.b(var5.eK(), var6);
         var9.gJ();
         by.a var12 = var9.r(false);
         fR.m(var12);
         by var10 = var12.e(var5).fl();
         var9.p(var10);
         switch (var10.eW()) {
            case 200:
               if (var7.kI().kK() && var8.kI().kK()) {
                  return null;
               }

               throw new IOException("TLS tunnel buffered too many bytes!");
            case 407:
               bw var13 = this.lh.fo().bH().a(this.lh, var10);
               if (var13 == null) {
                  throw new IOException("Failed to authenticate with proxy");
               }

               var5 = var13;
               if (gA.a("close", by.a(var10, "Connection", (String)null, 2, (Object)null), true)) {
                  break label25;
               }
               break;
            default:
               throw new IOException("Unexpected response code for CONNECT: " + var10.eW());
         }
      }

      return var5;
   }

   private final bw hq() throws IOException {
      bw var1 = (new bw.a()).c(this.lh.fo().bK()).a("CONNECT", (bx)null).h("Host", bD.a(this.lh.fo().bK(), true)).h("Proxy-Connection", "Keep-Alive").h("User-Agent", "okhttp/4.12.0").eQ();
      by var2 = (new by.a()).e(var1).b(bv.iH).n(407).al("Preemptive Authenticate").a(bD.ji).d(-1L).e(-1L).k("Proxy-Authenticate", "OkHttp-Preemptive").fl();
      bw var3 = this.lh.fo().bH().a(this.lh, var2);
      bw var10000 = var3;
      if (var3 == null) {
         var10000 = var1;
      }

      return var10000;
   }

   public final boolean a(aX var1, List<bA> var2) {
      fR.c(var1, (String)"");
      boolean var4 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else if (this.lp.size() < this.lo && !this.lk) {
         if (!this.lh.fo().a(var1)) {
            return false;
         } else if (fR.c(var1.bK().cY(), (Object)this.hr().fo().bK().cY())) {
            return true;
         } else if (this.lj == null) {
            return false;
         } else if (var2 != null && this.e(var2)) {
            if (var1.bF() != cY.pM) {
               return false;
            } else if (!this.f(var1.bK())) {
               return false;
            } else {
               try {
                  bd var10000 = var1.bG();
                  fR.m(var10000);
                  String var10001 = var1.bK().cY();
                  bp var10002 = this.eX();
                  fR.m(var10002);
                  var10000.a(var10001, var10002.cP());
                  return true;
               } catch (SSLPeerUnverifiedException var5) {
                  return false;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private final boolean e(List<bA> var1) {
      Iterable var2 = (Iterable)var1;
      boolean var3 = false;
      boolean var10000;
      if (var2 instanceof Collection && ((Collection)var2).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = false;
               break;
            }

            Object var5 = var4.next();
            bA var6 = (bA)var5;
            boolean var7 = false;
            if (var6.fp().type() == Type.DIRECT && this.lh.fp().type() == Type.DIRECT && fR.c(this.lh.fq(), (Object)var6.fq())) {
               var10000 = true;
               break;
            }
         }
      }

      return var10000;
   }

   private final boolean f(br var1) {
      boolean var3 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else {
         br var2 = this.lh.fo().bK();
         if (var1.cZ() != var2.cZ()) {
            return false;
         } else if (fR.c(var1.cY(), (Object)var2.cY())) {
            return true;
         } else {
            boolean var10000;
            if (!this.ll && this.handshake != null) {
               bp var10002 = this.handshake;
               fR.m(var10002);
               if (this.a(var1, var10002)) {
                  var10000 = true;
                  return var10000;
               }
            }

            var10000 = false;
            return var10000;
         }
      }
   }

   private final boolean a(br var1, bp var2) {
      List var3 = var2.cP();
      boolean var4;
      if (!((Collection)var3).isEmpty()) {
         cY var10000 = cY.pM;
         String var10001 = var1.cY();
         Object var10002 = var3.get(0);
         fR.m(var10002);
         if (var10000.a(var10001, (X509Certificate)var10002)) {
            var4 = true;
            return var4;
         }
      }

      var4 = false;
      return var4;
   }

   public final cb b(bu var1, ce var2) throws SocketException {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      Socket var10000 = this.socket;
      fR.m(var10000);
      Socket var3 = var10000;
      dg var7 = this.source;
      fR.m(var7);
      dg var4 = var7;
      df var8 = this.sink;
      fR.m(var8);
      df var5 = var8;
      cq var6 = this.lj;
      cb var9;
      if (var6 != null) {
         var9 = new cr(var1, this, var2, var6);
      } else {
         var3.setSoTimeout(var2.dT());
         var4.fu().d((long)var2.hK(), TimeUnit.MILLISECONDS);
         var5.fu().d((long)var2.hL(), TimeUnit.MILLISECONDS);
         var9 = new ck(var1, this, var4, var5);
      }

      return var9;
   }

   public bA hr() {
      return this.lh;
   }

   public final void hs() {
      Socket var10000 = this.li;
      if (var10000 != null) {
         bD.a(var10000);
      }

   }

   public Socket ht() {
      Socket var10000 = this.socket;
      fR.m(var10000);
      return var10000;
   }

   public final boolean u(boolean param1) {
      // $FF: Couldn't be decompiled
   }

   public void a(ct var1) throws IOException {
      fR.c(var1, (String)"");
      var1.a(cm.mE, (IOException)null);
   }

   public synchronized void a(cq var1, cx var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      this.lo = var2.jz();
   }

   public bp eX() {
      return this.handshake;
   }

   public final void a(bu var1, bA var2, IOException var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      if (var2.fp().type() != Type.DIRECT) {
         aX var4 = var2.fo();
         var4.bJ().connectFailed(var4.bK().dc(), var2.fp().address(), var3);
      }

      var1.dW().a(var2);
   }

   public final synchronized void a(bS var1, IOException var2) {
      fR.c(var1, (String)"");
      if (var2 instanceof cy) {
         if (((cy)var2).ot == cm.mE) {
            int var3 = this.kL++;
            if (this.kL > 1) {
               this.lk = true;
               var3 = this.lm++;
            }
         } else if (((cy)var2).ot != cm.mF || !var1.gX()) {
            this.lk = true;
            int var5 = this.lm++;
         }
      } else if (!this.hm() || var2 instanceof cl) {
         this.lk = true;
         if (this.ln == 0) {
            if (var2 != null) {
               this.a(var1.gS(), this.lh, var2);
            }

            int var6 = this.lm++;
         }
      }

   }

   public String toString() {
      StringBuilder var10000 = (new StringBuilder()).append("Connection{").append(this.lh.fo().bK().cY()).append(':').append(this.lh.fo().bK().cZ()).append(", proxy=").append(this.lh.fp()).append(" hostAddress=").append(this.lh.fq()).append(" cipherSuite=");
      bp var10001 = this.handshake;
      Object var1;
      if (var10001 != null) {
         var1 = var10001.cN();
         if (var1 != null) {
            return var10000.append(var1).append(" protocol=").append(this.protocol).append('}').toString();
         }
      }

      var1 = "none";
      return var10000.append(var1).append(" protocol=").append(this.protocol).append('}').toString();
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   // $FF: synthetic class
   public class b {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[Type.values().length];

         try {
            var0[Type.DIRECT.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[Type.HTTP.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$0 = var0;
      }
   }
}
