import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class bt {
   public static final a ib = new a((fP)null);
   private final String ic;
   private final String ie;
   private final String if;
   private final String[] ig;
   private static final Pattern ih = Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)");
   private static final Pattern ii = Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");

   private bt(String var1, String var2, String var3, String[] var4) {
      this.ic = var1;
      this.ie = var2;
      this.if = var3;
      this.ig = var4;
   }

   public final Charset a(Charset var1) {
      String var10000 = this.ac("charset");
      if (var10000 == null) {
         return var1;
      } else {
         String var2 = var10000;

         Charset var3;
         try {
            var3 = Charset.forName(var2);
         } catch (IllegalArgumentException var5) {
            var3 = var1;
         }

         return var3;
      }
   }

   // $FF: synthetic method
   public static Charset a(bt var0, Charset var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null;
      }

      return var0.a(var1);
   }

   public final String ac(String var1) {
      fR.c(var1, (String)"");
      int var2 = this.ig.length + -1;
      int var3 = 0;
      int var4 = fF.i(0, var2, 2);
      if (var3 <= var4) {
         while(true) {
            if (gA.a(this.ig[var3], var1, true)) {
               return this.ig[var3 + 1];
            }

            if (var3 == var4) {
               break;
            }

            var3 += 2;
         }
      }

      return null;
   }

   public String toString() {
      return this.ic;
   }

   public boolean equals(Object var1) {
      return var1 instanceof bt && fR.c(((bt)var1).ic, (Object)this.ic);
   }

   public int hashCode() {
      return this.ic.hashCode();
   }

   public static final bt ad(String var0) {
      return ib.af(var0);
   }

   // $FF: synthetic method
   public bt(String var1, String var2, String var3, String[] var4, fP var5) {
      this(var1, var2, var3, var4);
   }

   public static final class a {
      private a() {
      }

      public final bt ae(String var1) {
         fR.c(var1, (String)"");
         Matcher var2 = bt.ih.matcher((CharSequence)var1);
         if (!var2.lookingAt()) {
            boolean var12 = false;
            String var13 = "No subtype found for: \"" + var1 + '"';
            throw new IllegalArgumentException(var13.toString());
         } else {
            String var10000 = var2.group(1);
            fR.b(var10000, "");
            String var4 = var10000;
            Locale var20 = Locale.US;
            fR.b(var20, "");
            String var21 = var4.toLowerCase(var20);
            fR.b(var21, "");
            String var3 = var21;
            var21 = var2.group(2);
            fR.b(var21, "");
            String var5 = var21;
            Locale var23 = Locale.US;
            fR.b(var23, "");
            String var24 = var5.toLowerCase(var23);
            fR.b(var24, "");
            var4 = var24;
            List var14 = (List)(new ArrayList());
            Matcher var6 = bt.ii.matcher((CharSequence)var1);
            int var7 = 0;
            var7 = var2.end();

            while(var7 < var1.length()) {
               var6.region(var7, var1.length());
               if (!var6.lookingAt()) {
                  boolean var17 = false;
                  StringBuilder var26 = (new StringBuilder()).append("Parameter is not formatted correctly: \"");
                  String var10001 = var1.substring(var7);
                  fR.b(var10001, "");
                  String var18 = var26.append(var10001).append("\" for: \"").append(var1).append('"').toString();
                  throw new IllegalArgumentException(var18.toString());
               }

               String var8 = var6.group(1);
               if (var8 == null) {
                  var7 = var6.end();
               } else {
                  String var9 = var6.group(2);
                  if (var9 == null) {
                     var24 = var6.group(3);
                  } else if (gA.a(var9, "'", false, 2, (Object)null) && gA.b(var9, "'", false, 2, (Object)null) && var9.length() > 2) {
                     var24 = var9.substring(1, var9.length() - 1);
                     fR.b(var24, "");
                  } else {
                     var24 = var9;
                  }

                  String var10 = var24;
                  ((Collection)var14).add(var8);
                  ((Collection)var14).add(var10);
                  var7 = var6.end();
               }
            }

            Collection var16 = (Collection)var14;
            boolean var19 = false;
            return new bt(var1, var3, var4, (String[])var16.toArray(new String[0]), (fP)null);
         }
      }

      public final bt af(String var1) {
         fR.c(var1, (String)"");

         bt var2;
         try {
            var2 = this.ae(var1);
         } catch (IllegalArgumentException var4) {
            var2 = null;
         }

         return var2;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
