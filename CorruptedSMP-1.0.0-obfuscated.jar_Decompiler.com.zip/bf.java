import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

public final class bf {
   public static final a eF = new a((fP)null);
   private final String eG;
   private static final Comparator<String> eH = new Comparator<String>() {
      public int b(String var1, String var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         int var3 = 4;

         for(int var4 = Math.min(var1.length(), var2.length()); var3 < var4; ++var3) {
            char var5 = var1.charAt(var3);
            char var6 = var2.charAt(var3);
            if (var5 != var6) {
               return fR.j(var5, var6) < 0 ? -1 : 1;
            }
         }

         int var7 = var1.length();
         int var8 = var2.length();
         if (var7 != var8) {
            return var7 < var8 ? -1 : 1;
         } else {
            return 0;
         }
      }

      // $FF: synthetic method
      public int compare(Object var1, Object var2) {
         return this.b((String)var1, (String)var2);
      }
   };
   private static final Map<String, bf> eI = (Map)(new LinkedHashMap());
   public static final bf eJ;
   public static final bf eK;
   public static final bf eL;
   public static final bf eM;
   public static final bf eN;
   public static final bf eO;
   public static final bf eP;
   public static final bf eQ;
   public static final bf eR;
   public static final bf eS;
   public static final bf eT;
   public static final bf eU;
   public static final bf eV;
   public static final bf eW;
   public static final bf eX;
   public static final bf eY;
   public static final bf eZ;
   public static final bf fa;
   public static final bf fb;
   public static final bf fc;
   public static final bf fd;
   public static final bf fe;
   public static final bf ff;
   public static final bf fg;
   public static final bf fh;
   public static final bf fi;
   public static final bf fj;
   public static final bf fk;
   public static final bf fl;
   public static final bf fm;
   public static final bf fn;
   public static final bf fo;
   public static final bf fp;
   public static final bf fq;
   public static final bf fr;
   public static final bf fs;
   public static final bf ft;
   public static final bf fu;
   public static final bf fv;
   public static final bf fw;
   public static final bf fx;
   public static final bf fy;
   public static final bf fz;
   public static final bf fA;
   public static final bf fB;
   public static final bf fC;
   public static final bf fD;
   public static final bf fE;
   public static final bf fF;
   public static final bf fG;
   public static final bf fH;
   public static final bf fI;
   public static final bf fJ;
   public static final bf fK;
   public static final bf fL;
   public static final bf fM;
   public static final bf fN;
   public static final bf fO;
   public static final bf fP;
   public static final bf fQ;
   public static final bf fR;
   public static final bf fS;
   public static final bf fT;
   public static final bf fU;
   public static final bf fV;
   public static final bf fW;
   public static final bf fX;
   public static final bf fY;
   public static final bf fZ;
   public static final bf ga;
   public static final bf gb;
   public static final bf gc;
   public static final bf gd;
   public static final bf ge;
   public static final bf gf;
   public static final bf gg;
   public static final bf gh;
   public static final bf gi;
   public static final bf gj;
   public static final bf gk;
   public static final bf gl;
   public static final bf gm;
   public static final bf gn;
   public static final bf go;
   public static final bf gp;
   public static final bf gq;
   public static final bf gr;
   public static final bf gs;
   public static final bf gt;
   public static final bf gu;
   public static final bf gv;
   public static final bf gw;
   public static final bf gx;
   public static final bf gy;
   public static final bf gz;
   public static final bf gA;
   public static final bf gB;
   public static final bf gC;
   public static final bf gD;
   public static final bf gE;
   public static final bf gF;
   public static final bf gG;
   public static final bf gH;
   public static final bf gI;
   public static final bf gJ;
   public static final bf gK;
   public static final bf gL;
   public static final bf gM;
   public static final bf gN;
   public static final bf gO;
   public static final bf gP;
   public static final bf gQ;
   public static final bf gR;
   public static final bf gS;
   public static final bf gT;
   public static final bf gU;
   public static final bf gV;
   public static final bf gW;
   public static final bf gX;

   private bf(String var1) {
      this.eG = var1;
   }

   public final String ct() {
      return this.eG;
   }

   public String toString() {
      return this.eG;
   }

   // $FF: synthetic method
   public bf(String var1, fP var2) {
      this(var1);
   }

   static {
      eJ = eF.b("SSL_RSA_WITH_NULL_MD5", 1);
      eK = eF.b("SSL_RSA_WITH_NULL_SHA", 2);
      eL = eF.b("SSL_RSA_EXPORT_WITH_RC4_40_MD5", 3);
      eM = eF.b("SSL_RSA_WITH_RC4_128_MD5", 4);
      eN = eF.b("SSL_RSA_WITH_RC4_128_SHA", 5);
      eO = eF.b("SSL_RSA_EXPORT_WITH_DES40_CBC_SHA", 8);
      eP = eF.b("SSL_RSA_WITH_DES_CBC_SHA", 9);
      eQ = eF.b("SSL_RSA_WITH_3DES_EDE_CBC_SHA", 10);
      eR = eF.b("SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA", 17);
      eS = eF.b("SSL_DHE_DSS_WITH_DES_CBC_SHA", 18);
      eT = eF.b("SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA", 19);
      eU = eF.b("SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA", 20);
      eV = eF.b("SSL_DHE_RSA_WITH_DES_CBC_SHA", 21);
      eW = eF.b("SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA", 22);
      eX = eF.b("SSL_DH_anon_EXPORT_WITH_RC4_40_MD5", 23);
      eY = eF.b("SSL_DH_anon_WITH_RC4_128_MD5", 24);
      eZ = eF.b("SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA", 25);
      fa = eF.b("SSL_DH_anon_WITH_DES_CBC_SHA", 26);
      fb = eF.b("SSL_DH_anon_WITH_3DES_EDE_CBC_SHA", 27);
      fc = eF.b("TLS_KRB5_WITH_DES_CBC_SHA", 30);
      fd = eF.b("TLS_KRB5_WITH_3DES_EDE_CBC_SHA", 31);
      fe = eF.b("TLS_KRB5_WITH_RC4_128_SHA", 32);
      ff = eF.b("TLS_KRB5_WITH_DES_CBC_MD5", 34);
      fg = eF.b("TLS_KRB5_WITH_3DES_EDE_CBC_MD5", 35);
      fh = eF.b("TLS_KRB5_WITH_RC4_128_MD5", 36);
      fi = eF.b("TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA", 38);
      fj = eF.b("TLS_KRB5_EXPORT_WITH_RC4_40_SHA", 40);
      fk = eF.b("TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5", 41);
      fl = eF.b("TLS_KRB5_EXPORT_WITH_RC4_40_MD5", 43);
      fm = eF.b("TLS_RSA_WITH_AES_128_CBC_SHA", 47);
      fn = eF.b("TLS_DHE_DSS_WITH_AES_128_CBC_SHA", 50);
      fo = eF.b("TLS_DHE_RSA_WITH_AES_128_CBC_SHA", 51);
      fp = eF.b("TLS_DH_anon_WITH_AES_128_CBC_SHA", 52);
      fq = eF.b("TLS_RSA_WITH_AES_256_CBC_SHA", 53);
      fr = eF.b("TLS_DHE_DSS_WITH_AES_256_CBC_SHA", 56);
      fs = eF.b("TLS_DHE_RSA_WITH_AES_256_CBC_SHA", 57);
      ft = eF.b("TLS_DH_anon_WITH_AES_256_CBC_SHA", 58);
      fu = eF.b("TLS_RSA_WITH_NULL_SHA256", 59);
      fv = eF.b("TLS_RSA_WITH_AES_128_CBC_SHA256", 60);
      fw = eF.b("TLS_RSA_WITH_AES_256_CBC_SHA256", 61);
      fx = eF.b("TLS_DHE_DSS_WITH_AES_128_CBC_SHA256", 64);
      fy = eF.b("TLS_RSA_WITH_CAMELLIA_128_CBC_SHA", 65);
      fz = eF.b("TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA", 68);
      fA = eF.b("TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA", 69);
      fB = eF.b("TLS_DHE_RSA_WITH_AES_128_CBC_SHA256", 103);
      fC = eF.b("TLS_DHE_DSS_WITH_AES_256_CBC_SHA256", 106);
      fD = eF.b("TLS_DHE_RSA_WITH_AES_256_CBC_SHA256", 107);
      fE = eF.b("TLS_DH_anon_WITH_AES_128_CBC_SHA256", 108);
      fF = eF.b("TLS_DH_anon_WITH_AES_256_CBC_SHA256", 109);
      fG = eF.b("TLS_RSA_WITH_CAMELLIA_256_CBC_SHA", 132);
      fH = eF.b("TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA", 135);
      fI = eF.b("TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA", 136);
      fJ = eF.b("TLS_PSK_WITH_RC4_128_SHA", 138);
      fK = eF.b("TLS_PSK_WITH_3DES_EDE_CBC_SHA", 139);
      fL = eF.b("TLS_PSK_WITH_AES_128_CBC_SHA", 140);
      fM = eF.b("TLS_PSK_WITH_AES_256_CBC_SHA", 141);
      fN = eF.b("TLS_RSA_WITH_SEED_CBC_SHA", 150);
      fO = eF.b("TLS_RSA_WITH_AES_128_GCM_SHA256", 156);
      fP = eF.b("TLS_RSA_WITH_AES_256_GCM_SHA384", 157);
      fQ = eF.b("TLS_DHE_RSA_WITH_AES_128_GCM_SHA256", 158);
      fR = eF.b("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384", 159);
      fS = eF.b("TLS_DHE_DSS_WITH_AES_128_GCM_SHA256", 162);
      fT = eF.b("TLS_DHE_DSS_WITH_AES_256_GCM_SHA384", 163);
      fU = eF.b("TLS_DH_anon_WITH_AES_128_GCM_SHA256", 166);
      fV = eF.b("TLS_DH_anon_WITH_AES_256_GCM_SHA384", 167);
      fW = eF.b("TLS_EMPTY_RENEGOTIATION_INFO_SCSV", 255);
      fX = eF.b("TLS_FALLBACK_SCSV", 22016);
      fY = eF.b("TLS_ECDH_ECDSA_WITH_NULL_SHA", 49153);
      fZ = eF.b("TLS_ECDH_ECDSA_WITH_RC4_128_SHA", 49154);
      ga = eF.b("TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA", 49155);
      gb = eF.b("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA", 49156);
      gc = eF.b("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA", 49157);
      gd = eF.b("TLS_ECDHE_ECDSA_WITH_NULL_SHA", 49158);
      ge = eF.b("TLS_ECDHE_ECDSA_WITH_RC4_128_SHA", 49159);
      gf = eF.b("TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA", 49160);
      gg = eF.b("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA", 49161);
      gh = eF.b("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA", 49162);
      gi = eF.b("TLS_ECDH_RSA_WITH_NULL_SHA", 49163);
      gj = eF.b("TLS_ECDH_RSA_WITH_RC4_128_SHA", 49164);
      gk = eF.b("TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA", 49165);
      gl = eF.b("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA", 49166);
      gm = eF.b("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA", 49167);
      gn = eF.b("TLS_ECDHE_RSA_WITH_NULL_SHA", 49168);
      go = eF.b("TLS_ECDHE_RSA_WITH_RC4_128_SHA", 49169);
      gp = eF.b("TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA", 49170);
      gq = eF.b("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA", 49171);
      gr = eF.b("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA", 49172);
      gs = eF.b("TLS_ECDH_anon_WITH_NULL_SHA", 49173);
      gt = eF.b("TLS_ECDH_anon_WITH_RC4_128_SHA", 49174);
      gu = eF.b("TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA", 49175);
      gv = eF.b("TLS_ECDH_anon_WITH_AES_128_CBC_SHA", 49176);
      gw = eF.b("TLS_ECDH_anon_WITH_AES_256_CBC_SHA", 49177);
      gx = eF.b("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256", 49187);
      gy = eF.b("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384", 49188);
      gz = eF.b("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256", 49189);
      gA = eF.b("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384", 49190);
      gB = eF.b("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256", 49191);
      gC = eF.b("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384", 49192);
      gD = eF.b("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256", 49193);
      gE = eF.b("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384", 49194);
      gF = eF.b("TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", 49195);
      gG = eF.b("TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", 49196);
      gH = eF.b("TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256", 49197);
      gI = eF.b("TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384", 49198);
      gJ = eF.b("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", 49199);
      gK = eF.b("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384", 49200);
      gL = eF.b("TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256", 49201);
      gM = eF.b("TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384", 49202);
      gN = eF.b("TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA", 49205);
      gO = eF.b("TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA", 49206);
      gP = eF.b("TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256", 52392);
      gQ = eF.b("TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256", 52393);
      gR = eF.b("TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256", 52394);
      gS = eF.b("TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256", 52396);
      gT = eF.b("TLS_AES_128_GCM_SHA256", 4865);
      gU = eF.b("TLS_AES_256_GCM_SHA384", 4866);
      gV = eF.b("TLS_CHACHA20_POLY1305_SHA256", 4867);
      gW = eF.b("TLS_AES_128_CCM_SHA256", 4868);
      gX = eF.b("TLS_AES_128_CCM_8_SHA256", 4869);
   }

   public static final class a {
      private a() {
      }

      public final Comparator<String> cw() {
         return bf.eH;
      }

      public final synchronized bf z(String var1) {
         fR.c(var1, (String)"");
         bf var2 = (bf)bf.eI.get(var1);
         if (var2 == null) {
            var2 = (bf)bf.eI.get(this.A(var1));
            if (var2 == null) {
               var2 = new bf(var1, (fP)null);
            }

            bf.eI.put(var1, var2);
         }

         return var2;
      }

      private final String A(String var1) {
         String var2;
         if (gA.a(var1, "TLS_", false, 2, (Object)null)) {
            StringBuilder var10000 = (new StringBuilder()).append("SSL_");
            String var10001 = var1.substring(4);
            fR.b(var10001, "");
            var2 = var10000.append(var10001).toString();
         } else if (gA.a(var1, "SSL_", false, 2, (Object)null)) {
            StringBuilder var3 = (new StringBuilder()).append("TLS_");
            String var4 = var1.substring(4);
            fR.b(var4, "");
            var2 = var3.append(var4).toString();
         } else {
            var2 = var1;
         }

         return var2;
      }

      private final bf b(String var1, int var2) {
         bf var3 = new bf(var1, (fP)null);
         bf.eI.put(var1, var3);
         return var3;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
