import java.io.IOException;

public final class cl extends IOException {
}
