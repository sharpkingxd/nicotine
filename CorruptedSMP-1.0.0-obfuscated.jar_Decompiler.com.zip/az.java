import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class az extends ac<Date> {
   public static final ad bE = new ad() {
      public <T> ac<T> a(K var1, aS<T> var2) {
         return var2.bk() == Date.class ? new az() : null;
      }
   };
   private final List<DateFormat> bF = new ArrayList();

   public az() {
      this.bF.add(DateFormat.getDateTimeInstance(2, 2, Locale.US));
      if (!Locale.getDefault().equals(Locale.US)) {
         this.bF.add(DateFormat.getDateTimeInstance(2, 2));
      }

      if (an.ay()) {
         this.bF.add(as.a(2, 2));
      }

   }

   public Date m(aT var1) throws IOException {
      if (var1.aI() == aU.dY) {
         var1.aO();
         return null;
      } else {
         return this.n(var1);
      }
   }

   private Date n(aT var1) throws IOException {
      String var2 = var1.aM();
      synchronized(this.bF) {
         for(DateFormat var5 : this.bF) {
            try {
               Date var10000 = var5.parse(var2);
               return var10000;
            } catch (ParseException var9) {
            }
         }
      }

      try {
         return aM.a(var2, new ParsePosition(0));
      } catch (ParseException var8) {
         throw new X("Failed parsing '" + var2 + "' as Date; at path " + var1.aV(), var8);
      }
   }

   public void a(aV var1, Date var2) throws IOException {
      if (var2 == null) {
         var1.be();
      } else {
         DateFormat var3 = (DateFormat)this.bF.get(0);
         String var4;
         synchronized(this.bF) {
            var4 = var3.format(var2);
         }

         var1.t(var4);
      }
   }

   // $FF: synthetic method
   public Object b(aT var1) throws IOException {
      return this.m(var1);
   }
}
