import java.sql.Timestamp;
import java.util.Date;

public final class aR {
   public static final boolean dw;
   public static final aA.a<? extends Date> dx;
   public static final aA.a<? extends Date> dy;
   public static final ad dz;
   public static final ad dA;
   public static final ad dB;

   static {
      boolean var0;
      try {
         Class.forName("java.sql.Date");
         var0 = true;
      } catch (ClassNotFoundException var2) {
         var0 = false;
      }

      dw = var0;
      if (dw) {
         dx = new aA.a<java.sql.Date>(java.sql.Date.class) {
            protected java.sql.Date b(Date var1) {
               return new java.sql.Date(var1.getTime());
            }

            // $FF: synthetic method
            protected Date a(Date var1) {
               return this.b(var1);
            }
         };
         dy = new aA.a<Timestamp>(Timestamp.class) {
            protected Timestamp c(Date var1) {
               return new Timestamp(var1.getTime());
            }

            // $FF: synthetic method
            protected Date a(Date var1) {
               return this.c(var1);
            }
         };
         dz = aO.dq;
         dA = aP.ds;
         dB = aQ.du;
      } else {
         dx = null;
         dy = null;
         dz = null;
         dA = null;
         dB = null;
      }

   }
}
