import java.io.IOException;

public enum bv {
   public static final a iE = new a((fP)null);
   private final String iF;
   iG("http/1.0"),
   iH("http/1.1"),
   iI("spdy/3.1"),
   iJ("h2"),
   iK("h2_prior_knowledge"),
   iL("quic");

   private bv(String var3) {
      this.iF = var3;
   }

   public String toString() {
      return this.iF;
   }

   // $FF: synthetic method
   private static final bv[] eH() {
      bv[] var0 = new bv[]{iG, iH, iI, iJ, iK, iL};
      return var0;
   }

   public static final class a {
      private a() {
      }

      public final bv ag(String var1) throws IOException {
         fR.c(var1, (String)"");
         bv var10000;
         if (fR.c(var1, (Object)bv.iG.iF)) {
            var10000 = bv.iG;
         } else if (fR.c(var1, (Object)bv.iH.iF)) {
            var10000 = bv.iH;
         } else if (fR.c(var1, (Object)bv.iK.iF)) {
            var10000 = bv.iK;
         } else if (fR.c(var1, (Object)bv.iJ.iF)) {
            var10000 = bv.iJ;
         } else if (fR.c(var1, (Object)bv.iI.iF)) {
            var10000 = bv.iI;
         } else {
            if (!fR.c(var1, (Object)bv.iL.iF)) {
               throw new IOException("Unexpected protocol: " + var1);
            }

            var10000 = bv.iL;
         }

         return var10000;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
