import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public final class bN {
   public static final b kj = new b((fP)null);
   private final a kk;
   private int kl;
   private boolean km;
   private long kn;
   private final List<bM> ko;
   private final List<bM> kp;
   private final Runnable kq;
   public static final bN kr;
   private static final Logger ks;

   public bN(a var1) {
      fR.c(var1, (String)"");
      super();
      this.kk = var1;
      this.kl = 10000;
      this.ko = (List)(new ArrayList());
      this.kp = (List)(new ArrayList());
      this.kq = new Runnable() {
         public void run() {
            // $FF: Couldn't be decompiled
         }
      };
   }

   public final a gu() {
      return this.kk;
   }

   public final void b(bM var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else {
         if (var1.go() == null) {
            if (!((Collection)var1.gp()).isEmpty()) {
               bD.a((List)this.kp, (Object)var1);
            } else {
               this.kp.remove(var1);
            }
         }

         if (this.km) {
            this.kk.a(this);
         } else {
            this.kk.a(this.kq);
         }

      }
   }

   private final void b(bK var1) {
      boolean var3 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else {
         var1.g(-1L);
         bM var10000 = var1.gj();
         fR.m(var10000);
         bM var2 = var10000;
         var2.gp().remove(var1);
         this.kp.remove(var2);
         var2.a(var1);
         this.ko.add(var2);
      }
   }

   private final void c(bK var1) {
      boolean var3 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         Thread var2 = Thread.currentThread();
         String var16 = var2.getName();
         var2.setName(var1.gh());
         long var7 = 0L;
         var7 = -1L;
         boolean var12 = false;

         try {
            var12 = true;
            var7 = var1.gg();
            var12 = false;
         } finally {
            if (var12) {
               synchronized(this) {
                  boolean var6 = false;
                  this.b(var1, var7);
                  eE var18 = eE.sk;
               }

               var2.setName(var16);
            }
         }

         synchronized(this) {
            boolean var5 = false;
            this.b(var1, var7);
            eE var17 = eE.sk;
         }

         var2.setName(var16);
      }
   }

   private final void b(bK var1, long var2) {
      boolean var5 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else {
         bM var10000 = var1.gj();
         fR.m(var10000);
         bM var4 = var10000;
         if (var4.go() != var1) {
            String var6 = "Check failed.";
            throw new IllegalStateException(var6.toString());
         } else {
            var5 = var4.gq();
            var4.q(false);
            var4.a((bK)null);
            this.ko.remove(var4);
            if (var2 != -1L && !var5 && !var4.gn()) {
               var4.a(var1, var2, true);
            }

            if (!((Collection)var4.gp()).isEmpty()) {
               this.kp.add(var4);
            }

         }
      }
   }

   public final bK gv() {
      boolean var2 = false;
      if (bD.jn && !Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
      } else {
         while(!this.kp.isEmpty()) {
            long var1 = this.kk.gz();
            long var3 = Long.MAX_VALUE;
            bK var5 = null;
            boolean var6 = false;

            for(bM var8 : this.kp) {
               bK var9 = (bK)var8.gp().get(0);
               long var10 = Math.max(0L, var9.gk() - var1);
               if (var10 > 0L) {
                  var3 = Math.min(var10, var3);
               } else {
                  if (var5 != null) {
                     var6 = true;
                     break;
                  }

                  var5 = var9;
               }
            }

            if (var5 != null) {
               this.b(var5);
               if (var6 || !this.km && !((Collection)this.kp).isEmpty()) {
                  this.kk.a(this.kq);
               }

               return var5;
            }

            if (this.km) {
               if (var3 < this.kn - var1) {
                  this.kk.a(this);
               }

               return null;
            }

            this.km = true;
            this.kn = var1 + var3;

            try {
               this.kk.a(this, var3);
            } catch (InterruptedException var14) {
               this.gx();
            } finally {
               this.km = false;
            }
         }

         return null;
      }
   }

   public final bM gw() {
      // $FF: Couldn't be decompiled
   }

   public final void gx() {
      for(int var1 = this.ko.size() - 1; -1 < var1; --var1) {
         ((bM)this.ko.get(var1)).gt();
      }

      for(int var3 = this.kp.size() - 1; -1 < var3; --var3) {
         bM var2 = (bM)this.kp.get(var3);
         var2.gt();
         if (var2.gp().isEmpty()) {
            this.kp.remove(var3);
         }
      }

   }

   // $FF: synthetic method
   public static final void a(bN var0, bK var1) {
      var0.c(var1);
   }

   static {
      kr = new bN(new c(bD.a(bD.jo + " TaskRunner", true)));
      Logger var10000 = Logger.getLogger(bN.class.getName());
      fR.b(var10000, "");
      ks = var10000;
   }

   public interface a {
      long gz();

      void a(bN var1);

      void a(bN var1, long var2);

      void a(Runnable var1);
   }

   public static final class b {
      private b() {
      }

      public final Logger gA() {
         return bN.ks;
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }

   public static final class c implements a {
      private final ThreadPoolExecutor executor;

      public c(ThreadFactory var1) {
         fR.c(var1, (String)"");
         super();
         this.executor = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, (BlockingQueue)(new SynchronousQueue()), var1);
      }

      public long gz() {
         return System.nanoTime();
      }

      public void a(bN var1) {
         fR.c(var1, (String)"");
         boolean var3 = false;
         ((Object)var1).notify();
      }

      public void a(bN var1, long var2) throws InterruptedException {
         fR.c(var1, (String)"");
         long var4 = var2 / 1000000L;
         long var6 = var2 - var4 * 1000000L;
         if (var4 > 0L || var2 > 0L) {
            ((Object)var1).wait(var4, (int)var6);
         }

      }

      public void a(Runnable var1) {
         fR.c(var1, (String)"");
         this.executor.execute(var1);
      }
   }
}
