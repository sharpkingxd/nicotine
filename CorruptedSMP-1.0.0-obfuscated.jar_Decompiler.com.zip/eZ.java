import java.util.ListIterator;
import java.util.NoSuchElementException;

public final class eZ implements fY, ListIterator {
   public static final eZ sv = new eZ();

   private eZ() {
   }

   public boolean hasNext() {
      return false;
   }

   public boolean hasPrevious() {
      return false;
   }

   public int nextIndex() {
      return 0;
   }

   public int previousIndex() {
      return -1;
   }

   public Void nm() {
      throw new NoSuchElementException();
   }

   public Void nn() {
      throw new NoSuchElementException();
   }

   public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public Object next() {
      return this.nm();
   }

   // $FF: synthetic method
   public Object previous() {
      return this.nn();
   }

   // $FF: synthetic method
   public void add(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public void set(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}
