final class dd implements dy {
   public dd() {
   }

   public void b(de var1, long var2) {
      fR.c(var1, (String)"");
      var1.A(var2);
   }

   public void flush() {
   }

   public dB fu() {
      return dB.NONE;
   }

   public void close() {
   }
}
