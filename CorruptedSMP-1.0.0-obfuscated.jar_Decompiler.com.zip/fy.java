import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface fy {
   int nw() default 1;

   String nx() default "";

   int[] ny() default {};

   String nz() default "";

   String nA() default "";
}
