import java.io.OutputStream;

final class ds implements dy {
   private final OutputStream ql;
   private final dB qm;

   public ds(OutputStream var1, dB var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.ql = var1;
      this.qm = var2;
   }

   public void b(de var1, long var2) {
      fR.c(var1, (String)"");
      db.b(var1.kH(), 0L, var2);
      long var4 = var2;

      while(var4 > 0L) {
         this.qm.lx();
         dv var10000 = var1.pR;
         fR.m(var10000);
         dv var6 = var10000;
         int var8 = var6.dI - var6.dH;
         boolean var9 = false;
         int var7 = (int)Math.min(var4, (long)var8);
         this.ql.write(var6.qs, var6.dH, var7);
         var6.dH += var7;
         var4 -= (long)var7;
         var1.t(var1.kH() - (long)var7);
         if (var6.dH == var6.dI) {
            var1.pR = var6.lI();
            dw.c(var6);
         }
      }

   }

   public void flush() {
      this.ql.flush();
   }

   public void close() {
      this.ql.close();
   }

   public dB fu() {
      return this.qm;
   }

   public String toString() {
      return "sink(" + this.ql + ')';
   }
}
