public final class cn {
   public static final a mM = new a((fP)null);
   public final dh mN;
   public final dh mO;
   public final int mP;
   public static final dh mQ;
   public static final dh mR;
   public static final dh mS;
   public static final dh mT;
   public static final dh mU;
   public static final dh mV;

   public cn(dh var1, dh var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.mN = var1;
      this.mO = var2;
      this.mP = 32 + this.mN.lm() + this.mO.lm();
   }

   public cn(String var1, String var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      this(dh.pS.aU(var1), dh.pS.aU(var2));
   }

   public cn(dh var1, String var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      this(var1, dh.pS.aU(var2));
   }

   public String toString() {
      return this.mN.lf() + ": " + this.mO.lf();
   }

   public final dh hW() {
      return this.mN;
   }

   public final dh hX() {
      return this.mO;
   }

   public int hashCode() {
      int var1 = this.mN.hashCode();
      var1 = var1 * 31 + this.mO.hashCode();
      return var1;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof cn)) {
         return false;
      } else {
         cn var2 = (cn)var1;
         if (!fR.c(this.mN, (Object)var2.mN)) {
            return false;
         } else {
            return fR.c(this.mO, (Object)var2.mO);
         }
      }
   }

   static {
      mQ = dh.pS.aU(":");
      mR = dh.pS.aU(":status");
      mS = dh.pS.aU(":method");
      mT = dh.pS.aU(":path");
      mU = dh.pS.aU(":scheme");
      mV = dh.pS.aU(":authority");
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
