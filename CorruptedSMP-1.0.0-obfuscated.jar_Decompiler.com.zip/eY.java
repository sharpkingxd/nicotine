import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

class eY extends eX {
   public static final <T> T a(Iterable<? extends T> var0) {
      fR.c(var0, (String)"");
      if (var0 instanceof List) {
         return (T)eO.n((List)var0);
      } else {
         Iterator var1 = var0.iterator();
         if (!var1.hasNext()) {
            throw new NoSuchElementException("Collection is empty.");
         } else {
            return (T)var1.next();
         }
      }
   }

   public static final <T> T n(List<? extends T> var0) {
      fR.c(var0, (String)"");
      if (var0.isEmpty()) {
         throw new NoSuchElementException("List is empty.");
      } else {
         return (T)var0.get(0);
      }
   }

   public static final <T> T o(List<? extends T> var0) {
      fR.c(var0, (String)"");
      if (var0.isEmpty()) {
         throw new NoSuchElementException("List is empty.");
      } else {
         return (T)var0.get(eO.k(var0));
      }
   }

   public static final <T> T b(Iterable<? extends T> var0) {
      fR.c(var0, (String)"");
      if (var0 instanceof List) {
         return (T)eO.p((List)var0);
      } else {
         Iterator var1 = var0.iterator();
         if (!var1.hasNext()) {
            throw new NoSuchElementException("Collection is empty.");
         } else {
            Object var2 = var1.next();
            if (var1.hasNext()) {
               throw new IllegalArgumentException("Collection has more than one element.");
            } else {
               return (T)var2;
            }
         }
      }
   }

   public static final <T> T p(List<? extends T> var0) {
      fR.c(var0, (String)"");
      switch (var0.size()) {
         case 0:
            throw new NoSuchElementException("List is empty.");
         case 1:
            return (T)var0.get(0);
         default:
            throw new IllegalArgumentException("List has more than one element.");
      }
   }

   public static final <T> List<T> a(List<? extends T> var0, int var1) {
      fR.c(var0, (String)"");
      boolean var2 = var1 >= 0;
      if (!var2) {
         boolean var3 = false;
         String var4 = "Requested element count " + var1 + " is less than zero.";
         throw new IllegalArgumentException(var4.toString());
      } else {
         return eO.b((Iterable)var0, gg.m(var0.size() - var1, 0));
      }
   }

   public static final <T> List<T> b(Iterable<? extends T> var0, int var1) {
      fR.c(var0, (String)"");
      int var2 = var1 >= 0;
      if (!var2) {
         boolean var7 = false;
         String var8 = "Requested element count " + var1 + " is less than zero.";
         throw new IllegalArgumentException(var8.toString());
      } else if (var1 == 0) {
         return eO.nk();
      } else {
         if (var0 instanceof Collection) {
            if (var1 >= ((Collection)var0).size()) {
               return eO.c(var0);
            }

            if (var1 == 1) {
               return eO.i(eO.a(var0));
            }
         }

         var2 = 0;
         ArrayList var3 = new ArrayList(var1);

         for(Object var5 : var0) {
            var3.add(var5);
            ++var2;
            if (var2 == var1) {
               break;
            }
         }

         return eO.l((List)var3);
      }
   }

   public static final <T, C extends Collection<? super T>> C a(Iterable<? extends T> var0, C var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");

      for(Object var3 : var0) {
         var1.add(var3);
      }

      return (C)var1;
   }

   public static final <T> List<T> c(Iterable<? extends T> var0) {
      fR.c(var0, (String)"");
      if (var0 instanceof Collection) {
         List var10000;
         switch (((Collection)var0).size()) {
            case 0:
               var10000 = eO.nk();
               break;
            case 1:
               var10000 = eO.i(var0 instanceof List ? ((List)var0).get(0) : var0.iterator().next());
               break;
            default:
               var10000 = eO.b((Collection)var0);
         }

         return var10000;
      } else {
         return eO.l(eO.d(var0));
      }
   }

   public static final <T> List<T> d(Iterable<? extends T> var0) {
      fR.c(var0, (String)"");
      return var0 instanceof Collection ? eO.b((Collection)var0) : (List)eO.a(var0, (Collection)(new ArrayList()));
   }

   public static final <T> List<T> b(Collection<? extends T> var0) {
      fR.c(var0, (String)"");
      return (List)(new ArrayList(var0));
   }

   public static final <T> Set<T> e(Iterable<? extends T> var0) {
      fR.c(var0, (String)"");
      if (var0 instanceof Collection) {
         Set var10000;
         switch (((Collection)var0).size()) {
            case 0:
               var10000 = fk.ns();
               break;
            case 1:
               var10000 = fk.l(var0 instanceof List ? ((List)var0).get(0) : var0.iterator().next());
               break;
            default:
               var10000 = (Set)eO.a(var0, (Collection)(new LinkedHashSet(fe.an(((Collection)var0).size()))));
         }

         return var10000;
      } else {
         return fk.a((Set)eO.a(var0, (Collection)(new LinkedHashSet())));
      }
   }

   public static final <T> List<T> a(Collection<? extends T> var0, T var1) {
      fR.c(var0, (String)"");
      ArrayList var2 = new ArrayList(var0.size() + 1);
      var2.addAll(var0);
      var2.add(var1);
      return (List)var2;
   }

   public static final <T> List<T> b(Collection<? extends T> var0, Iterable<? extends T> var1) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      if (var1 instanceof Collection) {
         ArrayList var3 = new ArrayList(var0.size() + ((Collection)var1).size());
         var3.addAll(var0);
         var3.addAll((Collection)var1);
         return (List)var3;
      } else {
         ArrayList var2 = new ArrayList(var0);
         eO.a((Collection)var2, var1);
         return (List)var2;
      }
   }

   public static final <T, A extends Appendable> A a(Iterable<? extends T> var0, A var1, CharSequence var2, CharSequence var3, CharSequence var4, int var5, CharSequence var6, fK<? super T, ? extends CharSequence> var7) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      fR.c(var6, (String)"");
      var1.append(var3);
      int var8 = 0;

      for(Object var10 : var0) {
         ++var8;
         if (var8 > 1) {
            var1.append(var2);
         }

         if (var5 >= 0 && var8 > var5) {
            break;
         }

         gA.a(var1, var10, var7);
      }

      if (var5 >= 0 && var8 > var5) {
         var1.append(var6);
      }

      var1.append(var4);
      return (A)var1;
   }

   // $FF: synthetic method
   public static Appendable a(Iterable var0, Appendable var1, CharSequence var2, CharSequence var3, CharSequence var4, int var5, CharSequence var6, fK var7, int var8, Object var9) {
      if ((var8 & 2) != 0) {
         var2 = (CharSequence)", ";
      }

      if ((var8 & 4) != 0) {
         var3 = (CharSequence)"";
      }

      if ((var8 & 8) != 0) {
         var4 = (CharSequence)"";
      }

      if ((var8 & 16) != 0) {
         var5 = -1;
      }

      if ((var8 & 32) != 0) {
         var6 = (CharSequence)"...";
      }

      if ((var8 & 64) != 0) {
         var7 = null;
      }

      return eO.a(var0, var1, var2, var3, var4, var5, var6, var7);
   }

   public static final <T> String a(Iterable<? extends T> var0, CharSequence var1, CharSequence var2, CharSequence var3, int var4, CharSequence var5, fK<? super T, ? extends CharSequence> var6) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var5, (String)"");
      String var10000 = ((StringBuilder)eO.a(var0, (Appendable)(new StringBuilder()), var1, var2, var3, var4, var5, var6)).toString();
      fR.b(var10000, "");
      return var10000;
   }

   // $FF: synthetic method
   public static String a(Iterable var0, CharSequence var1, CharSequence var2, CharSequence var3, int var4, CharSequence var5, fK var6, int var7, Object var8) {
      if ((var7 & 1) != 0) {
         var1 = (CharSequence)", ";
      }

      if ((var7 & 2) != 0) {
         var2 = (CharSequence)"";
      }

      if ((var7 & 4) != 0) {
         var3 = (CharSequence)"";
      }

      if ((var7 & 8) != 0) {
         var4 = -1;
      }

      if ((var7 & 16) != 0) {
         var5 = (CharSequence)"...";
      }

      if ((var7 & 32) != 0) {
         var6 = null;
      }

      return eO.a(var0, var1, var2, var3, var4, var5, var6);
   }

   public static final <T> gm<T> f(Iterable<? extends T> var0) {
      fR.c(var0, (String)"");
      return new eY$a(var0);
   }
}
