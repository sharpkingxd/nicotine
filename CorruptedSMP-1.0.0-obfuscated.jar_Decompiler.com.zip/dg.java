import java.io.IOException;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.Charset;

public interface dg extends dA, ReadableByteChannel {
   de kI();

   boolean kK() throws IOException;

   void u(long var1) throws IOException;

   byte kN() throws IOException;

   short kO() throws IOException;

   int kP() throws IOException;

   long kS() throws IOException;

   long kT() throws IOException;

   void A(long var1) throws IOException;

   dh w(long var1) throws IOException;

   int a(dr var1) throws IOException;

   byte[] z(long var1) throws IOException;

   String kV() throws IOException;

   String y(long var1) throws IOException;

   String b(Charset var1) throws IOException;
}
