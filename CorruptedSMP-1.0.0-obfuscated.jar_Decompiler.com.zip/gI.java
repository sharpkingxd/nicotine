class gI extends gH {
   public static final Integer bj(String var0) {
      fR.c(var0, (String)"");
      return gA.g(var0, 10);
   }

   public static final Integer g(String var0, int var1) {
      fR.c(var0, (String)"");
      gu.ar(var1);
      int var2 = var0.length();
      if (var2 == 0) {
         return null;
      } else {
         byte var3 = 0;
         boolean var4 = false;
         int var5 = 0;
         char var6 = var0.charAt(0);
         if (fR.j(var6, 48) < 0) {
            if (var2 == 1) {
               return null;
            }

            var3 = 1;
            if (var6 == '-') {
               var4 = true;
               var5 = Integer.MIN_VALUE;
            } else {
               if (var6 != '+') {
                  return null;
               }

               var4 = false;
               var5 = -2147483647;
            }
         } else {
            var3 = 0;
            var4 = false;
            var5 = -2147483647;
         }

         int var7 = -59652323;
         int var8 = var7;
         int var9 = 0;

         for(int var10 = var3; var10 < var2; ++var10) {
            int var11 = gu.a(var0.charAt(var10), var1);
            if (var11 < 0) {
               return null;
            }

            if (var9 < var8) {
               if (var8 != var7) {
                  return null;
               }

               var8 = var5 / var1;
               if (var9 < var8) {
                  return null;
               }
            }

            var9 *= var1;
            if (var9 < var5 + var11) {
               return null;
            }

            var9 -= var11;
         }

         return var4 ? var9 : -var9;
      }
   }
}
