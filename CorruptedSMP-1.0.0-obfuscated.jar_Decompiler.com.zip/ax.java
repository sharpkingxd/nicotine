import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;

public final class ax<E> extends ac<Object> {
   public static final ad bA = new ad() {
      public <T> ac<T> a(K var1, aS<T> var2) {
         Type var3 = var2.bl();
         if (var3 instanceof GenericArrayType || var3 instanceof Class && ((Class)var3).isArray()) {
            Type var4 = ak.h(var3);
            ac var5 = var1.a(aS.k(var4));
            ax var6 = new ax(var1, var5, ak.f(var4));
            return var6;
         } else {
            return null;
         }
      }
   };
   private final Class<E> bB;
   private final ac<E> bC;

   public ax(K var1, ac<E> var2, Class<E> var3) {
      this.bC = new aK<E>(var1, var2, var3);
      this.bB = var3;
   }

   public Object b(aT var1) throws IOException {
      if (var1.aI() == aU.dY) {
         var1.aO();
         return null;
      } else {
         ArrayList var2 = new ArrayList();
         var1.aE();

         while(var1.hasNext()) {
            Object var3 = this.bC.b(var1);
            var2.add(var3);
         }

         var1.aF();
         int var6 = var2.size();
         if (!this.bB.isPrimitive()) {
            Object[] var7 = Array.newInstance(this.bB, var6);
            return var2.toArray(var7);
         } else {
            Object var4 = Array.newInstance(this.bB, var6);

            for(int var5 = 0; var5 < var6; ++var5) {
               Array.set(var4, var5, var2.get(var5));
            }

            return var4;
         }
      }
   }

   public void a(aV var1, Object var2) throws IOException {
      if (var2 == null) {
         var1.be();
      } else {
         var1.ba();
         int var3 = 0;

         for(int var4 = Array.getLength(var2); var3 < var4; ++var3) {
            Object var5 = Array.get(var2, var3);
            this.bC.a(var1, var5);
         }

         var1.bb();
      }
   }
}
