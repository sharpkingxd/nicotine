import java.util.Comparator;

class fp {
   public static final <T extends Comparable<?>> int b(T var0, T var1) {
      if (var0 == var1) {
         return 0;
      } else if (var0 == null) {
         return -1;
      } else {
         return var1 == null ? 1 : var0.compareTo(var1);
      }
   }

   public static final <T extends Comparable<? super T>> Comparator<T> nt() {
      fs var10000 = fs.sz;
      fR.m(var10000);
      return var10000;
   }
}
