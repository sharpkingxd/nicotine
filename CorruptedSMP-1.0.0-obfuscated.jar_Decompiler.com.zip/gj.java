public interface gj<T> {
}
