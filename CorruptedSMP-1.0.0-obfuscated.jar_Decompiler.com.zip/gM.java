class gM extends gL {
   public static final String h(String var0, int var1) {
      fR.c(var0, (String)"");
      boolean var2 = var1 >= 0;
      if (!var2) {
         boolean var5 = false;
         String var6 = "Requested character count " + var1 + " is less than zero.";
         throw new IllegalArgumentException(var6.toString());
      } else {
         byte var3 = 0;
         int var4 = gg.n(var1, var0.length());
         String var10000 = var0.substring(var3, var4);
         fR.b(var10000, "");
         return var10000;
      }
   }
}
