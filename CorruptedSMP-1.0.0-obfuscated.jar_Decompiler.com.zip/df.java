import java.io.IOException;
import java.nio.channels.WritableByteChannel;

public interface df extends dy, WritableByteChannel {
   de kI();

   df f(dh var1) throws IOException;

   df d(byte[] var1) throws IOException;

   df b(byte[] var1, int var2, int var3) throws IOException;

   df aR(String var1) throws IOException;

   df aa(int var1) throws IOException;

   df ab(int var1) throws IOException;

   df ac(int var1) throws IOException;

   df D(long var1) throws IOException;

   df E(long var1) throws IOException;

   void flush() throws IOException;

   df lb() throws IOException;
}
