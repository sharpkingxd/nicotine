public interface Z {
   Z ba = new Z() {
      public a c(Class<?> var1) {
         return au.k(var1) ? Z.a.BLOCK_INACCESSIBLE : Z.a.INDECISIVE;
      }
   };
   Z bb = new Z() {
      public a c(Class<?> var1) {
         return au.k(var1) ? Z.a.BLOCK_ALL : Z.a.INDECISIVE;
      }
   };
   Z bc = new Z() {
      public a c(Class<?> var1) {
         return au.l(var1) ? Z.a.BLOCK_ALL : Z.a.INDECISIVE;
      }
   };
   Z bd = new Z() {
      public a c(Class<?> var1) {
         return au.m(var1) ? Z.a.BLOCK_ALL : Z.a.INDECISIVE;
      }
   };

   a c(Class<?> var1);

   public static enum a {
      ALLOW,
      INDECISIVE,
      BLOCK_INACCESSIBLE,
      BLOCK_ALL;
   }
}
