import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.Random;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.block.Block;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;

public class dR implements Listener {
   private final CorruptedSMPPlugin rl;
   private final Random rm = new Random();

   public dR(CorruptedSMPPlugin var1) {
      this.rl = var1;
   }

   @EventHandler
   public void a(EntityTargetLivingEntityEvent var1) {
      LivingEntity var3 = var1.getTarget();
      if (var3 instanceof Player var2) {
         if (var1.getEntity() instanceof Monster) {
            if (this.rl.d().b(var2)) {
               if (this.rl.d().c(var2) == l.u) {
                  var1.setCancelled(true);
               }
            }
         }
      }
   }

   @EventHandler
   public void b(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         if (!(var1.getEntity() instanceof Player) || this.rl.j().a(var1)) {
            if (this.rl.d().b(var2)) {
               if (this.rl.d().c(var2) == l.u) {
                  D var5 = this.rl.f().g(var2.getUniqueId());
                  int var4 = this.rl.getConfig().getInt("corruptions.darkness.darkness-bar-max", 20);
                  var5.D();
                  if (var5.C() >= var4) {
                     var2.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2, false, false));
                     var5.E();
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void d(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof Player var8) {
            if (this.rl.j().a(var1)) {
               if (this.rl.d().b(var2)) {
                  if (this.rl.d().c(var2) == l.u) {
                     double var9 = var1.getFinalDamage();
                     double var6 = var8.getHealth();
                     if (var9 >= var6) {
                        var8.setMetadata("darkness_bypass_totem", new FixedMetadataValue(this.rl, true));
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(EntityResurrectEvent var1) {
      LivingEntity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rl.d().b(var2) && this.rl.d().c(var2) == l.u) {
            var1.setCancelled(true);
            var2.sendMessage("§c§lDARKNESS CURSE! §7Totems do not work for you!");
         } else {
            if (var2.hasMetadata("darkness_bypass_totem")) {
               var1.setCancelled(true);
               var2.sendMessage("§0§lTOTEM BYPASSED! §7Darkness corruption negated your totem!");
               var2.removeMetadata("darkness_bypass_totem", this.rl);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void e(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rl.d().b(var2)) {
            if (this.rl.d().c(var2) == l.u) {
               long var5 = var2.getWorld().getTime();
               if (var5 >= 13000L && var5 <= 23000L && this.rm.nextDouble() < 0.15) {
                  var1.setCancelled(true);
                  var2.sendMessage("§0§l✓ §7Enemy attack missed in the darkness!");
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      Block var3 = var1.getBlock();
      if (m.a(var3.getLocation()) && m.c(var2.getUniqueId())) {
         var1.setCancelled(true);
         var2.sendMessage("§8§l[§5SHADOW CAGE§8§l] §cYou cannot break the Shadow Cage!");
         var2.getWorld().spawnParticle(Particle.SMOKE, var3.getLocation().add((double)0.5F, (double)0.5F, (double)0.5F), 10, 0.3, 0.3, 0.3, (double)0.0F);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerTeleportEvent var1) {
      Player var2 = var1.getPlayer();
      if (m.c(var2.getUniqueId())) {
         if (var1.getCause() == TeleportCause.ENDER_PEARL || var1.getCause() == TeleportCause.CHORUS_FRUIT || var1.getCause() == TeleportCause.COMMAND) {
            var1.setCancelled(true);
            var2.sendMessage("§8§l[§5SHADOW CAGE§8§l] §cThe Shadow Cage blocks all teleportation!");
            var2.getWorld().spawnParticle(Particle.SMOKE, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.3, (double)0.5F, 0.3, 0.1);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void b(ProjectileLaunchEvent var1) {
      if (var1.getEntity() instanceof EnderPearl) {
         ProjectileSource var3 = var1.getEntity().getShooter();
         if (var3 instanceof Player) {
            Player var2 = (Player)var3;
            if (m.c(var2.getUniqueId())) {
               var1.setCancelled(true);
               var2.sendMessage("§8§l[§5SHADOW CAGE§8§l] §cYou cannot throw ender pearls while trapped in Shadow Cage!");
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.getItem().getType() == Material.CHORUS_FRUIT) {
         if (m.c(var2.getUniqueId())) {
            var1.setCancelled(true);
            var2.sendMessage("§8§l[§5SHADOW CAGE§8§l] §cYou cannot eat chorus fruit while trapped in Shadow Cage!");
         }

      }
   }
}
