public interface fu<T> {
}
