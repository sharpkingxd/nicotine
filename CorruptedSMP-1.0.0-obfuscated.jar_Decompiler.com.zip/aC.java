import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

public final class aC extends aT {
   private static final Reader bJ = new Reader() {
      public int read(char[] var1, int var2, int var3) {
         throw new AssertionError();
      }

      public void close() {
         throw new AssertionError();
      }
   };
   private static final Object bK = new Object();
   private Object[] bL;
   private int bM;
   private String[] bN;
   private int[] bO;

   public void aE() throws IOException {
      this.a(aU.dQ);
      M var1 = (M)this.aJ();
      this.e(var1.iterator());
      this.bO[this.bM - 1] = 0;
   }

   public void aF() throws IOException {
      this.a(aU.dR);
      this.aK();
      this.aK();
      if (this.bM > 0) {
         int var10002 = this.bO[this.bM - 1]++;
      }

   }

   public void aG() throws IOException {
      this.a(aU.dS);
      S var1 = (S)this.aJ();
      this.e(var1.entrySet().iterator());
   }

   public void aH() throws IOException {
      this.a(aU.dT);
      this.bN[this.bM - 1] = null;
      this.aK();
      this.aK();
      if (this.bM > 0) {
         int var10002 = this.bO[this.bM - 1]++;
      }

   }

   public boolean hasNext() throws IOException {
      aU var1 = this.aI();
      return var1 != aU.dT && var1 != aU.dR && var1 != aU.dZ;
   }

   public aU aI() throws IOException {
      if (this.bM == 0) {
         return aU.dZ;
      } else {
         Object var1 = this.aJ();
         if (var1 instanceof Iterator) {
            boolean var4 = this.bL[this.bM - 2] instanceof S;
            Iterator var3 = (Iterator)var1;
            if (var3.hasNext()) {
               if (var4) {
                  return aU.dU;
               } else {
                  this.e(var3.next());
                  return this.aI();
               }
            } else {
               return var4 ? aU.dT : aU.dR;
            }
         } else if (var1 instanceof S) {
            return aU.dS;
         } else if (var1 instanceof M) {
            return aU.dQ;
         } else if (var1 instanceof U) {
            U var2 = (U)var1;
            if (var2.am()) {
               return aU.dV;
            } else if (var2.ak()) {
               return aU.dX;
            } else if (var2.al()) {
               return aU.dW;
            } else {
               throw new AssertionError();
            }
         } else if (var1 instanceof R) {
            return aU.dY;
         } else if (var1 == bK) {
            throw new IllegalStateException("JsonReader is closed");
         } else {
            throw new aW("Custom JsonElement subclass " + var1.getClass().getName() + " is not supported");
         }
      }
   }

   private Object aJ() {
      return this.bL[this.bM - 1];
   }

   private Object aK() {
      Object var1 = this.bL[--this.bM];
      this.bL[this.bM] = null;
      return var1;
   }

   private void a(aU var1) throws IOException {
      if (this.aI() != var1) {
         throw new IllegalStateException("Expected " + var1 + " but was " + this.aI() + this.aX());
      }
   }

   private String f(boolean var1) throws IOException {
      this.a(aU.dU);
      Iterator var2 = (Iterator)this.aJ();
      Map.Entry var3 = (Map.Entry)var2.next();
      String var4 = (String)var3.getKey();
      this.bN[this.bM - 1] = var1 ? "<skipped>" : var4;
      this.e(var3.getValue());
      return var4;
   }

   public String aL() throws IOException {
      return this.f(false);
   }

   public String aM() throws IOException {
      aU var1 = this.aI();
      if (var1 != aU.dV && var1 != aU.dW) {
         throw new IllegalStateException("Expected " + aU.dV + " but was " + var1 + this.aX());
      } else {
         String var2 = ((U)this.aK()).Y();
         if (this.bM > 0) {
            int var10002 = this.bO[this.bM - 1]++;
         }

         return var2;
      }
   }

   public boolean aN() throws IOException {
      this.a(aU.dX);
      boolean var1 = ((U)this.aK()).ac();
      if (this.bM > 0) {
         int var10002 = this.bO[this.bM - 1]++;
      }

      return var1;
   }

   public void aO() throws IOException {
      this.a(aU.dY);
      this.aK();
      if (this.bM > 0) {
         int var10002 = this.bO[this.bM - 1]++;
      }

   }

   public double aP() throws IOException {
      aU var1 = this.aI();
      if (var1 != aU.dW && var1 != aU.dV) {
         throw new IllegalStateException("Expected " + aU.dW + " but was " + var1 + this.aX());
      } else {
         double var2 = ((U)this.aJ()).Z();
         if (this.bm() || !Double.isNaN(var2) && !Double.isInfinite(var2)) {
            this.aK();
            if (this.bM > 0) {
               int var10002 = this.bO[this.bM - 1]++;
            }

            return var2;
         } else {
            throw new aW("JSON forbids NaN and infinities: " + var2);
         }
      }
   }

   public long aQ() throws IOException {
      aU var1 = this.aI();
      if (var1 != aU.dW && var1 != aU.dV) {
         throw new IllegalStateException("Expected " + aU.dW + " but was " + var1 + this.aX());
      } else {
         long var2 = ((U)this.aJ()).aa();
         this.aK();
         if (this.bM > 0) {
            int var10002 = this.bO[this.bM - 1]++;
         }

         return var2;
      }
   }

   public int aR() throws IOException {
      aU var1 = this.aI();
      if (var1 != aU.dW && var1 != aU.dV) {
         throw new IllegalStateException("Expected " + aU.dW + " but was " + var1 + this.aX());
      } else {
         int var2 = ((U)this.aJ()).ab();
         this.aK();
         if (this.bM > 0) {
            int var10002 = this.bO[this.bM - 1]++;
         }

         return var2;
      }
   }

   P aS() throws IOException {
      aU var1 = this.aI();
      if (var1 != aU.dU && var1 != aU.dR && var1 != aU.dT && var1 != aU.dZ) {
         P var2 = (P)this.aJ();
         this.aT();
         return var2;
      } else {
         throw new IllegalStateException("Unexpected " + var1 + " when reading a JsonElement.");
      }
   }

   public void close() throws IOException {
      this.bL = new Object[]{bK};
      this.bM = 1;
   }

   public void aT() throws IOException {
      aU var1 = this.aI();
      switch (var1) {
         case dU:
            String var2 = this.f(true);
            break;
         case dR:
            this.aF();
            break;
         case dT:
            this.aH();
         case dZ:
            break;
         default:
            this.aK();
            if (this.bM > 0) {
               int var10002 = this.bO[this.bM - 1]++;
            }
      }

   }

   public String toString() {
      return this.getClass().getSimpleName() + this.aX();
   }

   public void aU() throws IOException {
      this.a(aU.dU);
      Iterator var1 = (Iterator)this.aJ();
      Map.Entry var2 = (Map.Entry)var1.next();
      this.e(var2.getValue());
      this.e(new U((String)var2.getKey()));
   }

   private void e(Object var1) {
      if (this.bM == this.bL.length) {
         int var2 = this.bM * 2;
         this.bL = Arrays.copyOf(this.bL, var2);
         this.bO = Arrays.copyOf(this.bO, var2);
         this.bN = (String[])Arrays.copyOf(this.bN, var2);
      }

      this.bL[this.bM++] = var1;
   }

   private String g(boolean var1) {
      StringBuilder var2 = (new StringBuilder()).append('$');

      for(int var3 = 0; var3 < this.bM; ++var3) {
         if (this.bL[var3] instanceof M) {
            ++var3;
            if (var3 < this.bM && this.bL[var3] instanceof Iterator) {
               int var4 = this.bO[var3];
               if (var1 && var4 > 0 && (var3 == this.bM - 1 || var3 == this.bM - 2)) {
                  --var4;
               }

               var2.append('[').append(var4).append(']');
            }
         } else if (this.bL[var3] instanceof S) {
            ++var3;
            if (var3 < this.bM && this.bL[var3] instanceof Iterator) {
               var2.append('.');
               if (this.bN[var3] != null) {
                  var2.append(this.bN[var3]);
               }
            }
         }
      }

      return var2.toString();
   }

   public String aV() {
      return this.g(true);
   }

   public String aW() {
      return this.g(false);
   }

   private String aX() {
      return " at path " + this.aW();
   }
}
