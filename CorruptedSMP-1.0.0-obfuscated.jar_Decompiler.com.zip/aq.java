import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;

public final class aq<K, V> extends AbstractMap<K, V> implements Serializable {
   private static final Comparator<Comparable> bq = new Comparator<Comparable>() {
      public int a(Comparable var1, Comparable var2) {
         return var1.compareTo(var2);
      }

      // $FF: synthetic method
      public int compare(Object var1, Object var2) {
         return this.a((Comparable)var1, (Comparable)var2);
      }
   };
   private final Comparator<? super K> br;
   private final boolean bs;
   d<K, V> bt;
   int bu;
   int bv;
   final d<K, V> bw;
   private aq<K, V>.a bx;
   private aq<K, V>.b by;

   public aq() {
      this(bq, true);
   }

   public aq(boolean var1) {
      this(bq, var1);
   }

   public aq(Comparator<? super K> var1, boolean var2) {
      this.bu = 0;
      this.bv = 0;
      this.br = var1 != null ? var1 : bq;
      this.bs = var2;
      this.bw = new d<K, V>(var2);
   }

   public int size() {
      return this.bu;
   }

   public V get(Object var1) {
      d var2 = this.c(var1);
      return (V)(var2 != null ? var2.value : null);
   }

   public boolean containsKey(Object var1) {
      return this.c(var1) != null;
   }

   public V put(K var1, V var2) {
      if (var1 == null) {
         throw new NullPointerException("key == null");
      } else if (var2 == null && !this.bs) {
         throw new NullPointerException("value == null");
      } else {
         d var3 = this.a(var1, true);
         Object var4 = var3.value;
         var3.value = var2;
         return (V)var4;
      }
   }

   public void clear() {
      this.bt = null;
      this.bu = 0;
      ++this.bv;
      d var1 = this.bw;
      var1.next = var1.prev = var1;
   }

   public V remove(Object var1) {
      d var2 = this.d(var1);
      return (V)(var2 != null ? var2.value : null);
   }

   d<K, V> a(K var1, boolean var2) {
      Comparator var3 = this.br;
      d var4 = this.bt;
      int var5 = 0;
      if (var4 != null) {
         Comparable var6 = var3 == bq ? (Comparable)var1 : null;

         while(true) {
            var5 = var6 != null ? var6.compareTo(var4.key) : var3.compare(var1, var4.key);
            if (var5 == 0) {
               return var4;
            }

            d var7 = var5 < 0 ? var4.left : var4.right;
            if (var7 == null) {
               break;
            }

            var4 = var7;
         }
      }

      if (!var2) {
         return null;
      } else {
         d var8 = this.bw;
         d var9;
         if (var4 == null) {
            if (var3 == bq && !(var1 instanceof Comparable)) {
               throw new ClassCastException(var1.getClass().getName() + " is not Comparable");
            }

            var9 = new d(this.bs, var4, var1, var8, var8.prev);
            this.bt = var9;
         } else {
            var9 = new d(this.bs, var4, var1, var8, var8.prev);
            if (var5 < 0) {
               var4.left = var9;
            } else {
               var4.right = var9;
            }

            this.b(var4, true);
         }

         ++this.bu;
         ++this.bv;
         return var9;
      }
   }

   d<K, V> c(Object var1) {
      try {
         return var1 != null ? this.a(var1, false) : null;
      } catch (ClassCastException var3) {
         return null;
      }
   }

   d<K, V> a(Map.Entry<?, ?> var1) {
      d var2 = this.c(var1.getKey());
      boolean var3 = var2 != null && this.a(var2.value, var1.getValue());
      return var3 ? var2 : null;
   }

   private boolean a(Object var1, Object var2) {
      return Objects.equals(var1, var2);
   }

   void a(d<K, V> var1, boolean var2) {
      if (var2) {
         var1.prev.next = var1.next;
         var1.next.prev = var1.prev;
      }

      d var3 = var1.left;
      d var4 = var1.right;
      d var5 = var1.parent;
      if (var3 != null && var4 != null) {
         d var6 = var3.height > var4.height ? var3.aC() : var4.aB();
         this.a(var6, false);
         int var7 = 0;
         var3 = var1.left;
         if (var3 != null) {
            var7 = var3.height;
            var6.left = var3;
            var3.parent = var6;
            var1.left = null;
         }

         int var8 = 0;
         var4 = var1.right;
         if (var4 != null) {
            var8 = var4.height;
            var6.right = var4;
            var4.parent = var6;
            var1.right = null;
         }

         var6.height = Math.max(var7, var8) + 1;
         this.a(var1, var6);
      } else {
         if (var3 != null) {
            this.a(var1, var3);
            var1.left = null;
         } else if (var4 != null) {
            this.a(var1, var4);
            var1.right = null;
         } else {
            this.a((d)var1, (d)null);
         }

         this.b(var5, false);
         --this.bu;
         ++this.bv;
      }
   }

   d<K, V> d(Object var1) {
      d var2 = this.c(var1);
      if (var2 != null) {
         this.a(var2, true);
      }

      return var2;
   }

   private void a(d<K, V> var1, d<K, V> var2) {
      d var3 = var1.parent;
      var1.parent = null;
      if (var2 != null) {
         var2.parent = var3;
      }

      if (var3 != null) {
         if (var3.left == var1) {
            var3.left = var2;
         } else {
            assert var3.right == var1;

            var3.right = var2;
         }
      } else {
         this.bt = var2;
      }

   }

   private void b(d<K, V> var1, boolean var2) {
      for(d var3 = var1; var3 != null; var3 = var3.parent) {
         d var4 = var3.left;
         d var5 = var3.right;
         int var6 = var4 != null ? var4.height : 0;
         int var7 = var5 != null ? var5.height : 0;
         int var8 = var6 - var7;
         if (var8 == -2) {
            d var9 = var5.left;
            d var10 = var5.right;
            int var11 = var10 != null ? var10.height : 0;
            int var12 = var9 != null ? var9.height : 0;
            int var13 = var12 - var11;
            if (var13 != -1 && (var13 != 0 || var2)) {
               assert var13 == 1;

               this.b(var5);
               this.a(var3);
            } else {
               this.a(var3);
            }

            if (var2) {
               break;
            }
         } else if (var8 == 2) {
            d var14 = var4.left;
            d var15 = var4.right;
            int var16 = var15 != null ? var15.height : 0;
            int var17 = var14 != null ? var14.height : 0;
            int var18 = var17 - var16;
            if (var18 != 1 && (var18 != 0 || var2)) {
               assert var18 == -1;

               this.a(var4);
               this.b(var3);
            } else {
               this.b(var3);
            }

            if (var2) {
               break;
            }
         } else if (var8 == 0) {
            var3.height = var6 + 1;
            if (var2) {
               break;
            }
         } else {
            assert var8 == -1 || var8 == 1;

            var3.height = Math.max(var6, var7) + 1;
            if (!var2) {
               break;
            }
         }
      }

   }

   private void a(d<K, V> var1) {
      d var2 = var1.left;
      d var3 = var1.right;
      d var4 = var3.left;
      d var5 = var3.right;
      var1.right = var4;
      if (var4 != null) {
         var4.parent = var1;
      }

      this.a(var1, var3);
      var3.left = var1;
      var1.parent = var3;
      var1.height = Math.max(var2 != null ? var2.height : 0, var4 != null ? var4.height : 0) + 1;
      var3.height = Math.max(var1.height, var5 != null ? var5.height : 0) + 1;
   }

   private void b(d<K, V> var1) {
      d var2 = var1.left;
      d var3 = var1.right;
      d var4 = var2.left;
      d var5 = var2.right;
      var1.left = var5;
      if (var5 != null) {
         var5.parent = var1;
      }

      this.a(var1, var2);
      var2.right = var1;
      var1.parent = var2;
      var1.height = Math.max(var3 != null ? var3.height : 0, var5 != null ? var5.height : 0) + 1;
      var2.height = Math.max(var1.height, var4 != null ? var4.height : 0) + 1;
   }

   public Set<Map.Entry<K, V>> entrySet() {
      a var1 = this.bx;
      return var1 != null ? var1 : (this.bx = new a());
   }

   public Set<K> keySet() {
      b var1 = this.by;
      return var1 != null ? var1 : (this.by = new b());
   }

   private Object writeReplace() throws ObjectStreamException {
      return new LinkedHashMap(this);
   }

   private void readObject(ObjectInputStream var1) throws IOException {
      throw new InvalidObjectException("Deserialization is unsupported");
   }

   class a extends AbstractSet<Map.Entry<K, V>> {
      public int size() {
         return aq.this.bu;
      }

      public Iterator<Map.Entry<K, V>> iterator() {
         return new c() {
            public Map.Entry<K, V> az() {
               return this.aA();
            }

            // $FF: synthetic method
            public Object next() {
               return this.az();
            }
         };
      }

      public boolean contains(Object var1) {
         return var1 instanceof Map.Entry && aq.this.a((Map.Entry)var1) != null;
      }

      public boolean remove(Object var1) {
         if (!(var1 instanceof Map.Entry)) {
            return false;
         } else {
            d var2 = aq.this.a((Map.Entry)var1);
            if (var2 == null) {
               return false;
            } else {
               aq.this.a(var2, true);
               return true;
            }
         }
      }

      public void clear() {
         aq.this.clear();
      }
   }

   final class b extends AbstractSet<K> {
      public int size() {
         return aq.this.bu;
      }

      public Iterator<K> iterator() {
         return new c() {
            public K next() {
               return this.aA().key;
            }
         };
      }

      public boolean contains(Object var1) {
         return aq.this.containsKey(var1);
      }

      public boolean remove(Object var1) {
         return aq.this.d(var1) != null;
      }

      public void clear() {
         aq.this.clear();
      }
   }

   abstract class c<T> implements Iterator<T> {
      d<K, V> next;
      d<K, V> lastReturned;
      int expectedModCount;

      c() {
         this.next = aq.this.bw.next;
         this.lastReturned = null;
         this.expectedModCount = aq.this.bv;
      }

      public final boolean hasNext() {
         return this.next != aq.this.bw;
      }

      final d<K, V> aA() {
         d var1 = this.next;
         if (var1 == aq.this.bw) {
            throw new NoSuchElementException();
         } else if (aq.this.bv != this.expectedModCount) {
            throw new ConcurrentModificationException();
         } else {
            this.next = var1.next;
            return this.lastReturned = var1;
         }
      }

      public final void remove() {
         if (this.lastReturned == null) {
            throw new IllegalStateException();
         } else {
            aq.this.a(this.lastReturned, true);
            this.lastReturned = null;
            this.expectedModCount = aq.this.bv;
         }
      }
   }

   static final class d<K, V> implements Map.Entry<K, V> {
      d<K, V> parent;
      d<K, V> left;
      d<K, V> right;
      d<K, V> next;
      d<K, V> prev;
      final K key;
      final boolean allowNullValue;
      V value;
      int height;

      d(boolean var1) {
         this.key = null;
         this.allowNullValue = var1;
         this.next = this.prev = this;
      }

      d(boolean var1, d<K, V> var2, K var3, d<K, V> var4, d<K, V> var5) {
         this.parent = var2;
         this.key = var3;
         this.allowNullValue = var1;
         this.height = 1;
         this.next = var4;
         this.prev = var5;
         var5.next = this;
         var4.prev = this;
      }

      public K getKey() {
         return this.key;
      }

      public V getValue() {
         return this.value;
      }

      public V setValue(V var1) {
         if (var1 == null && !this.allowNullValue) {
            throw new NullPointerException("value == null");
         } else {
            Object var2 = this.value;
            this.value = var1;
            return (V)var2;
         }
      }

      public boolean equals(Object var1) {
         if (!(var1 instanceof Map.Entry)) {
            return false;
         } else {
            boolean var10000;
            label38: {
               label27: {
                  Map.Entry var2 = (Map.Entry)var1;
                  if (this.key == null) {
                     if (var2.getKey() != null) {
                        break label27;
                     }
                  } else if (!this.key.equals(var2.getKey())) {
                     break label27;
                  }

                  if (this.value == null) {
                     if (var2.getValue() == null) {
                        break label38;
                     }
                  } else if (this.value.equals(var2.getValue())) {
                     break label38;
                  }
               }

               var10000 = false;
               return var10000;
            }

            var10000 = true;
            return var10000;
         }
      }

      public int hashCode() {
         return (this.key == null ? 0 : this.key.hashCode()) ^ (this.value == null ? 0 : this.value.hashCode());
      }

      public String toString() {
         return this.key + "=" + this.value;
      }

      public d<K, V> aB() {
         d var1 = this;

         for(d var2 = this.left; var2 != null; var2 = var2.left) {
            var1 = var2;
         }

         return var1;
      }

      public d<K, V> aC() {
         d var1 = this;

         for(d var2 = this.right; var2 != null; var2 = var2.right) {
            var1 = var2;
         }

         return var1;
      }
   }
}
