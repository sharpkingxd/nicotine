public final class eu extends RuntimeException {
}
