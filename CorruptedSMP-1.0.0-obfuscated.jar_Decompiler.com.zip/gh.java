class gh {
   public static final void a(boolean var0, Number var1) {
      fR.c(var1, (String)"");
      if (!var0) {
         throw new IllegalArgumentException("Step must be positive, was: " + var1 + '.');
      }
   }
}
