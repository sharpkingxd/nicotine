import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.ArrayList;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;

public class ej implements Listener {
   private final CorruptedSMPPlugin rH;

   public ej(CorruptedSMPPlugin var1) {
      this.rH = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(BlockBreakEvent var1) {
      if (!var1.isCancelled()) {
         Block var2 = var1.getBlock();

         for(el var4 : this.rH.e().nc()) {
            if (!var4.mY()) {
               Location var5 = var4.mX();
               if (this.a(var2.getLocation(), var5)) {
                  var1.setCancelled(true);
                  var1.getPlayer().sendMessage("§c§l✗ You cannot break the crafting table during an active ritual!");
                  var1.getPlayer().sendMessage("§7Wait for the ritual to complete or be cancelled.");
                  return;
               }
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void b(EntityExplodeEvent var1) {
      if (!var1.isCancelled()) {
         ArrayList var2 = new ArrayList();

         for(Block var4 : var1.blockList()) {
            for(el var6 : this.rH.e().nc()) {
               if (!var6.mY()) {
                  Location var7 = var6.mX();
                  if (this.b(var4.getLocation(), var7)) {
                     var2.add(var4);
                     break;
                  }
               }
            }
         }

         if (!var2.isEmpty()) {
            var1.blockList().removeAll(var2);
            String var8 = this.a(var1.getEntity());
            var1.getLocation().getWorld().getNearbyEntities(var1.getLocation(), (double)10.0F, (double)10.0F, (double)10.0F).forEach((var1x) -> {
               if (var1x instanceof Player var2) {
                  var2.sendMessage("§e§l⚠ " + var8 + " explosion blocked near active ritual!");
               }

            });
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void a(BlockExplodeEvent var1) {
      if (!var1.isCancelled()) {
         ArrayList var2 = new ArrayList();

         for(Block var4 : var1.blockList()) {
            for(el var6 : this.rH.e().nc()) {
               if (!var6.mY()) {
                  Location var7 = var6.mX();
                  if (this.b(var4.getLocation(), var7)) {
                     var2.add(var4);
                     break;
                  }
               }
            }
         }

         if (!var2.isEmpty()) {
            var1.blockList().removeAll(var2);
            var1.getBlock().getWorld().getNearbyEntities(var1.getBlock().getLocation(), (double)10.0F, (double)10.0F, (double)10.0F).forEach((var0) -> {
               if (var0 instanceof Player var1) {
                  var1.sendMessage("§e§l⚠ Block explosion blocked near active ritual!");
               }

            });
         }

      }
   }

   private boolean a(Location var1, Location var2) {
      return var1.getWorld().equals(var2.getWorld()) && var1.getBlockX() == var2.getBlockX() && var1.getBlockY() == var2.getBlockY() && var1.getBlockZ() == var2.getBlockZ();
   }

   private boolean b(Location var1, Location var2) {
      if (!var1.getWorld().equals(var2.getWorld())) {
         return false;
      } else {
         double var3 = var1.distance(var2);
         return var3 <= (double)5.0F;
      }
   }

   private String a(Entity var1) {
      String var10000;
      switch (var1.getType()) {
         case TNT -> var10000 = "TNT";
         case END_CRYSTAL -> var10000 = "End Crystal";
         case CREEPER -> var10000 = "Creeper";
         case WITHER_SKULL -> var10000 = "Wither Skull";
         case FIREBALL -> var10000 = "Fireball";
         case SMALL_FIREBALL -> var10000 = "Small Fireball";
         case DRAGON_FIREBALL -> var10000 = "Dragon Fireball";
         case WITHER -> var10000 = "Wither";
         default -> var10000 = var1.getType().name();
      }

      return var10000;
   }
}
