import java.net.Proxy;
import java.net.ProxySelector;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

public class bu implements Cloneable {
   public static final b ij = new b((fP)null);
   private final bm dispatcher;
   private final bh connectionPool;
   private final List<bs> ik;
   private final List<bs> il;
   private final bo.c eventListenerFactory;
   private final boolean retryOnConnectionFailure;
   private final aY authenticator;
   private final boolean followRedirects;
   private final boolean followSslRedirects;
   private final bk cookieJar;
   private final aZ cache;
   private final bn im;
   private final Proxy in;
   private final ProxySelector io;
   private final aY iq;
   private final SocketFactory ir;
   private final SSLSocketFactory sslSocketFactoryOrNull;
   private final X509TrustManager is;
   private final List<bi> it;
   private final List<bv> iu;
   private final HostnameVerifier iv;
   private final bd iw;
   private final cX ix;
   private final int iy;
   private final int iz;
   private final int iA;
   private final int iB;
   private final int pingIntervalMillis;
   private final long minWebSocketMessageToCompress;
   private final bV routeDatabase;
   private static final List<bv> iC;
   private static final List<bi> iD;

   public bu(a var1) {
      fR.c(var1, (String)"");
      super();
      this.dispatcher = var1.ea();
      this.connectionPool = var1.eb();
      this.ik = bD.b(var1.ec());
      this.il = bD.b(var1.ed());
      this.eventListenerFactory = var1.ee();
      this.retryOnConnectionFailure = var1.ef();
      this.authenticator = var1.eg();
      this.followRedirects = var1.eh();
      this.followSslRedirects = var1.ei();
      this.cookieJar = var1.ej();
      this.cache = var1.ek();
      this.im = var1.el();
      this.in = var1.em();
      ProxySelector var10001;
      if (var1.em() != null) {
         var10001 = cT.pz;
      } else {
         var10001 = var1.en();
         if (var10001 == null) {
            var10001 = ProxySelector.getDefault();
         }

         if (var10001 == null) {
            var10001 = cT.pz;
         }
      }

      this.io = var10001;
      this.iq = var1.eo();
      this.ir = var1.ep();
      this.it = var1.es();
      this.iu = var1.et();
      this.iv = var1.eu();
      this.iy = var1.ex();
      this.iz = var1.ey();
      this.iA = var1.ez();
      this.iB = var1.eA();
      this.pingIntervalMillis = var1.eB();
      this.minWebSocketMessageToCompress = var1.eC();
      bV var8 = var1.eD();
      if (var8 == null) {
         var8 = new bV();
      }

      this.routeDatabase = var8;
      Iterable var2 = (Iterable)this.it;
      boolean var3 = false;
      boolean var10000;
      if (var2 instanceof Collection && ((Collection)var2).isEmpty()) {
         var10000 = true;
      } else {
         Iterator var4 = var2.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = true;
               break;
            }

            Object var5 = var4.next();
            bi var6 = (bi)var5;
            boolean var7 = false;
            if (var6.cy()) {
               var10000 = false;
               break;
            }
         }
      }

      if (var10000) {
         this.sslSocketFactoryOrNull = null;
         this.ix = null;
         this.is = null;
         this.iw = bd.eD;
      } else if (var1.eq() != null) {
         this.sslSocketFactoryOrNull = var1.eq();
         cX var9 = var1.ew();
         fR.m(var9);
         this.ix = var9;
         X509TrustManager var10 = var1.er();
         fR.m(var10);
         this.is = var10;
         bd var11 = var1.ev();
         cX var10002 = this.ix;
         fR.m(var10002);
         this.iw = var11.a(var10002);
      } else {
         this.is = cH.oU.jZ().jH();
         cH var12 = cH.oU.jZ();
         X509TrustManager var15 = this.is;
         fR.m(var15);
         this.sslSocketFactoryOrNull = var12.c(var15);
         cX.a var13 = cX.pL;
         var15 = this.is;
         fR.m(var15);
         this.ix = var13.e(var15);
         bd var14 = var1.ev();
         cX var17 = this.ix;
         fR.m(var17);
         this.iw = var14.a(var17);
      }

      this.dX();
   }

   public final bm dw() {
      return this.dispatcher;
   }

   public final bh dx() {
      return this.connectionPool;
   }

   public final List<bs> dy() {
      return this.ik;
   }

   public final List<bs> dz() {
      return this.il;
   }

   public final bo.c dA() {
      return this.eventListenerFactory;
   }

   public final boolean dB() {
      return this.retryOnConnectionFailure;
   }

   public final aY dC() {
      return this.authenticator;
   }

   public final boolean dD() {
      return this.followRedirects;
   }

   public final boolean dE() {
      return this.followSslRedirects;
   }

   public final bk dF() {
      return this.cookieJar;
   }

   public final aZ dG() {
      return this.cache;
   }

   public final bn dH() {
      return this.im;
   }

   public final Proxy dI() {
      return this.in;
   }

   public final ProxySelector dJ() {
      return this.io;
   }

   public final aY dK() {
      return this.iq;
   }

   public final SocketFactory dL() {
      return this.ir;
   }

   public final SSLSocketFactory dM() {
      SSLSocketFactory var10000 = this.sslSocketFactoryOrNull;
      if (var10000 == null) {
         throw new IllegalStateException("CLEARTEXT-only client");
      } else {
         return var10000;
      }
   }

   public final List<bi> dN() {
      return this.it;
   }

   public final List<bv> dO() {
      return this.iu;
   }

   public final HostnameVerifier dP() {
      return this.iv;
   }

   public final bd dQ() {
      return this.iw;
   }

   public final int dR() {
      return this.iy;
   }

   public final int dS() {
      return this.iz;
   }

   public final int dT() {
      return this.iA;
   }

   public final int dU() {
      return this.iB;
   }

   public final int dV() {
      return this.pingIntervalMillis;
   }

   public final bV dW() {
      return this.routeDatabase;
   }

   public bu() {
      this(new a());
   }

   private final void dX() {
      List var10000 = this.ik;
      fR.m(var10000);
      if (var10000.contains((Object)null)) {
         boolean var19 = false;
         String var20 = "Null interceptor: " + this.ik;
         throw new IllegalStateException(var20.toString());
      } else {
         var10000 = this.il;
         fR.m(var10000);
         if (var10000.contains((Object)null)) {
            boolean var17 = false;
            String var18 = "Null network interceptor: " + this.il;
            throw new IllegalStateException(var18.toString());
         } else {
            Iterable var1 = (Iterable)this.it;
            boolean var2 = false;
            boolean var22;
            if (var1 instanceof Collection && ((Collection)var1).isEmpty()) {
               var22 = true;
            } else {
               Iterator var3 = var1.iterator();

               while(true) {
                  if (!var3.hasNext()) {
                     var22 = true;
                     break;
                  }

                  Object var4 = var3.next();
                  bi var5 = (bi)var4;
                  boolean var6 = false;
                  if (var5.cy()) {
                     var22 = false;
                     break;
                  }
               }
            }

            if (var22) {
               if (this.sslSocketFactoryOrNull != null) {
                  String var10 = "Check failed.";
                  throw new IllegalStateException(var10.toString());
               }

               if (this.ix != null) {
                  String var9 = "Check failed.";
                  throw new IllegalStateException(var9.toString());
               }

               if (this.is != null) {
                  String var8 = "Check failed.";
                  throw new IllegalStateException(var8.toString());
               }

               if (!fR.c(this.iw, (Object)bd.eD)) {
                  String var7 = "Check failed.";
                  throw new IllegalStateException(var7.toString());
               }
            } else {
               if (this.sslSocketFactoryOrNull == null) {
                  var2 = false;
                  String var16 = "sslSocketFactory == null";
                  throw new IllegalStateException(var16.toString());
               }

               if (this.ix == null) {
                  var2 = false;
                  String var14 = "certificateChainCleaner == null";
                  throw new IllegalStateException(var14.toString());
               }

               if (this.is == null) {
                  var2 = false;
                  String var12 = "x509TrustManager == null";
                  throw new IllegalStateException(var12.toString());
               }
            }

         }
      }
   }

   public bb d(bw var1) {
      fR.c(var1, (String)"");
      return new bS(this, var1, false);
   }

   public Object clone() {
      return super.clone();
   }

   static {
      bv[] var0 = new bv[]{bv.iJ, bv.iH};
      iC = bD.b(var0);
      bi[] var1 = new bi[]{bi.hg, bi.hi};
      iD = bD.b(var1);
   }

   public static final class a {
      private bm dispatcher = new bm();
      private bh connectionPool = new bh();
      private final List<bs> interceptors = (List)(new ArrayList());
      private final List<bs> networkInterceptors = (List)(new ArrayList());
      private bo.c eventListenerFactory;
      private boolean retryOnConnectionFailure;
      private aY authenticator;
      private boolean followRedirects;
      private boolean followSslRedirects;
      private bk cookieJar;
      private aZ cache;
      private bn dns;
      private Proxy proxy;
      private ProxySelector proxySelector;
      private aY proxyAuthenticator;
      private SocketFactory socketFactory;
      private SSLSocketFactory sslSocketFactoryOrNull;
      private X509TrustManager x509TrustManagerOrNull;
      private List<bi> connectionSpecs;
      private List<? extends bv> protocols;
      private HostnameVerifier hostnameVerifier;
      private bd certificatePinner;
      private cX certificateChainCleaner;
      private int callTimeout;
      private int connectTimeout;
      private int readTimeout;
      private int writeTimeout;
      private int pingInterval;
      private long minWebSocketMessageToCompress;
      private bV routeDatabase;

      public a() {
         this.eventListenerFactory = bD.a(bo.NONE);
         this.retryOnConnectionFailure = true;
         this.authenticator = aY.ek;
         this.followRedirects = true;
         this.followSslRedirects = true;
         this.cookieJar = bk.hy;
         this.dns = bn.hI;
         this.proxyAuthenticator = aY.ek;
         SocketFactory var10001 = SocketFactory.getDefault();
         fR.b(var10001, "");
         this.socketFactory = var10001;
         this.connectionSpecs = bu.ij.eG();
         this.protocols = bu.ij.eF();
         this.hostnameVerifier = cY.pM;
         this.certificatePinner = bd.eD;
         this.connectTimeout = 10000;
         this.readTimeout = 10000;
         this.writeTimeout = 10000;
         this.minWebSocketMessageToCompress = 1024L;
      }

      public final bm ea() {
         return this.dispatcher;
      }

      public final bh eb() {
         return this.connectionPool;
      }

      public final List<bs> ec() {
         return this.interceptors;
      }

      public final List<bs> ed() {
         return this.networkInterceptors;
      }

      public final bo.c ee() {
         return this.eventListenerFactory;
      }

      public final boolean ef() {
         return this.retryOnConnectionFailure;
      }

      public final aY eg() {
         return this.authenticator;
      }

      public final boolean eh() {
         return this.followRedirects;
      }

      public final boolean ei() {
         return this.followSslRedirects;
      }

      public final bk ej() {
         return this.cookieJar;
      }

      public final aZ ek() {
         return this.cache;
      }

      public final bn el() {
         return this.dns;
      }

      public final Proxy em() {
         return this.proxy;
      }

      public final ProxySelector en() {
         return this.proxySelector;
      }

      public final aY eo() {
         return this.proxyAuthenticator;
      }

      public final SocketFactory ep() {
         return this.socketFactory;
      }

      public final SSLSocketFactory eq() {
         return this.sslSocketFactoryOrNull;
      }

      public final X509TrustManager er() {
         return this.x509TrustManagerOrNull;
      }

      public final List<bi> es() {
         return this.connectionSpecs;
      }

      public final List<bv> et() {
         return this.protocols;
      }

      public final HostnameVerifier eu() {
         return this.hostnameVerifier;
      }

      public final bd ev() {
         return this.certificatePinner;
      }

      public final cX ew() {
         return this.certificateChainCleaner;
      }

      public final int ex() {
         return this.callTimeout;
      }

      public final int ey() {
         return this.connectTimeout;
      }

      public final int ez() {
         return this.readTimeout;
      }

      public final int eA() {
         return this.writeTimeout;
      }

      public final int eB() {
         return this.pingInterval;
      }

      public final long eC() {
         return this.minWebSocketMessageToCompress;
      }

      public final bV eD() {
         return this.routeDatabase;
      }

      public final a a(long var1, TimeUnit var3) {
         fR.c(var3, (String)"");
         a var5 = this;
         boolean var6 = false;
         var5.connectTimeout = bD.a("timeout", var1, var3);
         return this;
      }

      public final a b(long var1, TimeUnit var3) {
         fR.c(var3, (String)"");
         a var5 = this;
         boolean var6 = false;
         var5.readTimeout = bD.a("timeout", var1, var3);
         return this;
      }

      public final a c(long var1, TimeUnit var3) {
         fR.c(var3, (String)"");
         a var5 = this;
         boolean var6 = false;
         var5.writeTimeout = bD.a("timeout", var1, var3);
         return this;
      }

      public final bu eE() {
         return new bu(this);
      }
   }

   public static final class b {
      private b() {
      }

      public final List<bv> eF() {
         return bu.iC;
      }

      public final List<bi> eG() {
         return bu.iD;
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }
}
