import java.io.IOException;

public abstract class dj implements dA {
   private final dA delegate;

   public dj(dA var1) {
      fR.c(var1, (String)"");
      super();
      this.delegate = var1;
   }

   public final dA lq() {
      return this.delegate;
   }

   public long a(de var1, long var2) throws IOException {
      fR.c(var1, (String)"");
      return this.delegate.a(var1, var2);
   }

   public dB fu() {
      return this.delegate.fu();
   }

   public void close() throws IOException {
      this.delegate.close();
   }

   public String toString() {
      return this.getClass().getSimpleName() + '(' + this.delegate + ')';
   }
}
