import java.security.KeyStore;
import java.security.Provider;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.bouncycastle.jsse.BCSSLParameters;
import org.bouncycastle.jsse.BCSSLSocket;
import org.bouncycastle.jsse.provider.BouncyCastleJsseProvider;

public final class cC extends cH {
   public static final a oD = new a((fP)null);
   private final Provider oE;
   private static final boolean oF;

   private cC() {
      this.oE = (Provider)(new BouncyCastleJsseProvider());
   }

   public SSLContext jG() {
      SSLContext var10000 = SSLContext.getInstance("TLS", this.oE);
      fR.b(var10000, "");
      return var10000;
   }

   public X509TrustManager jH() {
      TrustManagerFactory var1 = TrustManagerFactory.getInstance("PKIX", "BCJSSE");
      var1.init((KeyStore)null);
      TrustManager var10000 = var1.getTrustManagers();
      fR.m(var10000);
      TrustManager[] var2 = var10000;
      if (var2.length != 1 || !(var2[0] instanceof X509TrustManager)) {
         boolean var3 = false;
         StringBuilder var6 = (new StringBuilder()).append("Unexpected default trust managers: ");
         String var10001 = Arrays.toString(var2);
         fR.b(var10001, "");
         String var4 = var6.append(var10001).toString();
         throw new IllegalStateException(var4.toString());
      } else {
         var10000 = var2[0];
         fR.m(var2[0]);
         return (X509TrustManager)var10000;
      }
   }

   public void a(SSLSocket var1, String var2, List<bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      if (var1 instanceof BCSSLSocket) {
         BCSSLParameters var4 = ((BCSSLSocket)var1).getParameters();
         List var5 = cH.oU.h(var3);
         Collection var6 = (Collection)var5;
         boolean var7 = false;
         var4.setApplicationProtocols((String[])var6.toArray(new String[0]));
         ((BCSSLSocket)var1).setParameters(var4);
      } else {
         super.a(var1, var2, var3);
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      String var10000;
      if (var1 instanceof BCSSLSocket) {
         String var2 = ((BCSSLSocket)var1).getApplicationProtocol();
         var10000 = (var2 == null ? true : fR.c(var2, (Object)"")) ? null : var2;
      } else {
         var10000 = super.d(var1);
      }

      return var10000;
   }

   // $FF: synthetic method
   public cC(fP var1) {
      this();
   }

   static {
      boolean var0;
      try {
         Class.forName("org.bouncycastle.jsse.provider.BouncyCastleJsseProvider", false, oD.getClass().getClassLoader());
         var0 = true;
      } catch (ClassNotFoundException var2) {
         var0 = false;
      }

      oF = var0;
   }

   public static final class a {
      private a() {
      }

      public final boolean jJ() {
         return cC.oF;
      }

      public final cC jK() {
         return this.jJ() ? new cC((fP)null) : null;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
