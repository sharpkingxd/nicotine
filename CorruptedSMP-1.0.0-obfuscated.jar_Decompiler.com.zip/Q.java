public final class Q extends T {
   private static final long serialVersionUID = 1L;

   public Q(String var1) {
      super(var1);
   }

   public Q(String var1, Throwable var2) {
      super(var1, var2);
   }

   public Q(Throwable var1) {
      super(var1);
   }
}
