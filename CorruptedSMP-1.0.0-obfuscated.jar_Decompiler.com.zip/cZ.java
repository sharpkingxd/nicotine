import java.security.cert.X509Certificate;

public interface cZ {
   X509Certificate c(X509Certificate var1);
}
