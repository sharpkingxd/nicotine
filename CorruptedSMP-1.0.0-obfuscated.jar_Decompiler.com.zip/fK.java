public interface fK<P1, R> {
   R invoke(P1 var1);
}
