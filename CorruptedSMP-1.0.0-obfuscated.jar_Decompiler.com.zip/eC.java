public final class eC {
   public static final eC sj = new eC();

   private eC() {
   }
}
