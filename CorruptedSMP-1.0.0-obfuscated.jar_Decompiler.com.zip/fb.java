import java.io.Serializable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

final class fb implements fY, Serializable, Map {
   public static final fb sx = new fb();
   private static final long serialVersionUID = 8246714829545688274L;

   private fb() {
   }

   public boolean equals(Object var1) {
      return var1 instanceof Map && ((Map)var1).isEmpty();
   }

   public int hashCode() {
      return 0;
   }

   public String toString() {
      return "{}";
   }

   public int getSize() {
      return 0;
   }

   public boolean isEmpty() {
      return true;
   }

   public boolean containsKey(Object var1) {
      return false;
   }

   public boolean d(Void var1) {
      fR.c(var1, (String)"");
      return false;
   }

   public Void j(Object var1) {
      return null;
   }

   public Set<Map.Entry> no() {
      return fc.sy;
   }

   public Set<Object> np() {
      return fc.sy;
   }

   public Collection nq() {
      return (Collection)fa.sw;
   }

   private final Object readResolve() {
      return sx;
   }

   public void clear() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void putAll(Map var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public Void k(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public final int size() {
      return this.getSize();
   }

   public final boolean containsValue(Object var1) {
      return !(var1 instanceof Void) ? false : this.d((Void)var1);
   }

   // $FF: synthetic method
   public Object get(Object var1) {
      return this.j(var1);
   }

   public final Set<Map.Entry> entrySet() {
      return this.no();
   }

   public final Set<Object> keySet() {
      return this.np();
   }

   public final Collection values() {
      return this.nq();
   }

   // $FF: synthetic method
   public Object put(Object var1, Object var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public Object remove(Object var1) {
      return this.k(var1);
   }
}
