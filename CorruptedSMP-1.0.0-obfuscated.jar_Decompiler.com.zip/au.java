import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import java.util.List;

public class au {
   public static boolean k(Class<?> var0) {
      return q(var0.getName());
   }

   private static boolean q(String var0) {
      return var0.startsWith("java.") || var0.startsWith("javax.");
   }

   public static boolean l(Class<?> var0) {
      return r(var0.getName());
   }

   private static boolean r(String var0) {
      return var0.startsWith("android.") || var0.startsWith("androidx.") || q(var0);
   }

   public static boolean m(Class<?> var0) {
      String var1 = var0.getName();
      return r(var1) || var1.startsWith("kotlin.") || var1.startsWith("kotlinx.") || var1.startsWith("scala.");
   }

   public static Z.a a(List<Z> var0, Class<?> var1) {
      for(Z var3 : var0) {
         Z.a var4 = var3.c(var1);
         if (var4 != Z.a.INDECISIVE) {
            return var4;
         }
      }

      return Z.a.ALLOW;
   }

   public static boolean a(AccessibleObject var0, Object var1) {
      return au.a.INSTANCE.a(var0, var1);
   }

   abstract static class a {
      public static final a INSTANCE;

      private a() {
      }

      public abstract boolean a(AccessibleObject var1, Object var2);

      static {
         a var0 = null;
         if (an.ay()) {
            try {
               final Method var1 = AccessibleObject.class.getDeclaredMethod("canAccess", Object.class);
               var0 = new a() {
                  public boolean a(AccessibleObject var1x, Object var2) {
                     try {
                        return (Boolean)var1.invoke(var1x, var2);
                     } catch (Exception var4) {
                        throw new RuntimeException("Failed invoking canAccess", var4);
                     }
                  }
               };
            } catch (NoSuchMethodException var2) {
            }
         }

         if (var0 == null) {
            var0 = new a() {
               public boolean a(AccessibleObject var1, Object var2) {
                  return true;
               }
            };
         }

         INSTANCE = var0;
      }
   }
}
