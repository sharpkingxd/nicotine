import java.security.KeyStore;
import java.security.Provider;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.openjsse.net.ssl.OpenJSSE;

public final class cG extends cH {
   public static final a oR = new a((fP)null);
   private final Provider oS;
   private static final boolean oT;

   private cG() {
      this.oS = (Provider)(new OpenJSSE());
   }

   public SSLContext jG() {
      SSLContext var10000 = SSLContext.getInstance("TLSv1.3", this.oS);
      fR.b(var10000, "");
      return var10000;
   }

   public X509TrustManager jH() {
      TrustManagerFactory var1 = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm(), this.oS);
      var1.init((KeyStore)null);
      TrustManager var10000 = var1.getTrustManagers();
      fR.m(var10000);
      TrustManager[] var2 = var10000;
      if (var2.length != 1 || !(var2[0] instanceof X509TrustManager)) {
         boolean var3 = false;
         StringBuilder var6 = (new StringBuilder()).append("Unexpected default trust managers: ");
         String var10001 = Arrays.toString(var2);
         fR.b(var10001, "");
         String var4 = var6.append(var10001).toString();
         throw new IllegalStateException(var4.toString());
      } else {
         var10000 = var2[0];
         fR.m(var2[0]);
         return (X509TrustManager)var10000;
      }
   }

   public void a(SSLSocket var1, String var2, List<bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
      if (var1 instanceof org.openjsse.javax.net.ssl.SSLSocket) {
         SSLParameters var4 = ((org.openjsse.javax.net.ssl.SSLSocket)var1).getSSLParameters();
         if (var4 instanceof org.openjsse.javax.net.ssl.SSLParameters) {
            List var5 = cH.oU.h(var3);
            org.openjsse.javax.net.ssl.SSLParameters var10000 = (org.openjsse.javax.net.ssl.SSLParameters)var4;
            Collection var6 = (Collection)var5;
            boolean var7 = false;
            var10000.setApplicationProtocols((String[])var6.toArray(new String[0]));
            ((org.openjsse.javax.net.ssl.SSLSocket)var1).setSSLParameters(var4);
         }
      } else {
         super.a(var1, var2, var3);
      }

   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      String var10000;
      if (var1 instanceof org.openjsse.javax.net.ssl.SSLSocket) {
         String var2 = ((org.openjsse.javax.net.ssl.SSLSocket)var1).getApplicationProtocol();
         var10000 = (var2 == null ? true : fR.c(var2, (Object)"")) ? null : var2;
      } else {
         var10000 = super.d(var1);
      }

      return var10000;
   }

   // $FF: synthetic method
   public cG(fP var1) {
      this();
   }

   static {
      boolean var0;
      try {
         Class.forName("org.openjsse.net.ssl.OpenJSSE", false, oR.getClass().getClassLoader());
         var0 = true;
      } catch (ClassNotFoundException var2) {
         var0 = false;
      }

      oT = var0;
   }

   public static final class a {
      private a() {
      }

      public final boolean jV() {
         return cG.oT;
      }

      public final cG jW() {
         return this.jV() ? new cG((fP)null) : null;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
