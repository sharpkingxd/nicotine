import java.io.IOException;
import java.nio.charset.Charset;

public abstract class bx {
   public static final a Companion = new a((fP)null);

   public abstract bt bR();

   public long bS() throws IOException {
      return -1L;
   }

   public abstract void a(df var1) throws IOException;

   public boolean eR() {
      return false;
   }

   public boolean eS() {
      return false;
   }

   public static final bx a(String var0, bt var1) {
      return Companion.b(var0, var1);
   }

   public static final class a {
      private a() {
      }

      public final bx b(String var1, bt var2) {
         fR.c(var1, (String)"");
         Charset var3 = gx.tn;
         bt var4 = var2;
         if (var2 != null) {
            Charset var5 = bt.a(var2, (Charset)null, 1, (Object)null);
            if (var5 == null) {
               var3 = gx.tn;
               var4 = bt.ib.af(var2 + "; charset=utf-8");
            } else {
               var3 = var5;
            }
         }

         byte[] var10000 = var1.getBytes(var3);
         fR.b(var10000, "");
         byte[] var6 = var10000;
         return this.a(var6, var4, 0, var6.length);
      }

      public final bx a(final byte[] var1, final bt var2, final int var3, final int var4) {
         fR.c(var1, (String)"");
         bD.a((long)var1.length, (long)var3, (long)var4);
         return new bx() {
            public bt bR() {
               return var2;
            }

            public long bS() {
               return (long)var4;
            }

            public void a(df var1x) {
               fR.c(var1x, (String)"");
               var1x.b(var1, var3, var4);
            }
         };
      }

      // $FF: synthetic method
      public static bx a(a var0, byte[] var1, bt var2, int var3, int var4, int var5, Object var6) {
         if ((var5 & 1) != 0) {
            var2 = null;
         }

         if ((var5 & 2) != 0) {
            var3 = 0;
         }

         if ((var5 & 4) != 0) {
            var4 = var1.length;
         }

         return var0.a(var1, var2, var3, var4);
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
