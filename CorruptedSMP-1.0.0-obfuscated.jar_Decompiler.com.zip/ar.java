public interface ar<T> {
   T av();
}
