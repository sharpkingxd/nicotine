import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;

public interface dy extends Closeable, Flushable {
   void b(de var1, long var2) throws IOException;

   void flush() throws IOException;

   dB fu();

   void close() throws IOException;
}
