import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class dN implements Listener {
   private final CorruptedSMPPlugin rg;

   public dN(CorruptedSMPPlugin var1) {
      this.rg = var1;
   }

   @EventHandler
   public void b(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
         if (var3 != null && var3.getType() == Material.FLOW_BANNER_PATTERN) {
            ItemMeta var4 = var3.getItemMeta();
            if (var4 != null && var4.hasCustomModelData()) {
               int var5 = var4.getCustomModelData();
               if (var5 >= 401 && var5 <= 409) {
                  l var6 = null;

                  for(l var10 : l.values()) {
                     if (var10.n() == var5) {
                        var6 = var10;
                        break;
                     }
                  }

                  if (var6 != null) {
                     var1.setCancelled(true);
                     if (this.rg.d().b(var2)) {
                        l var11 = this.rg.d().c(var2);
                        var2.sendMessage(this.a("§cYou already have " + var11.o() + " §cequipped!"));
                        var2.sendMessage(this.a("§7Use §e/withdraw §7to unequip it first."));
                     } else {
                        this.rg.d().a(var2, var6);
                        if (var3.getAmount() > 1) {
                           var3.setAmount(var3.getAmount() - 1);
                        } else {
                           var2.getInventory().setItemInMainHand((ItemStack)null);
                        }

                        var2.playSound(var2.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
                        var2.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                        var2.sendMessage(this.a("§a§l✓ EQUIPPED! §a" + var6.o()));
                        var2.sendMessage(this.a("§7Your corruption is now active in the action bar slot!"));
                        var2.sendMessage(this.a("§7Use §eShift + Right-Click §7to activate abilities."));
                        var2.sendMessage(this.a("§7Use §e/withdraw §7to unequip and get the core back."));
                     }
                  }
               }
            }
         }
      }
   }

   private String a(String var1) {
      String var2 = this.rg.getConfig().getString("messages.prefix", "");
      return (var2 + var1).replace("&", "§");
   }
}
