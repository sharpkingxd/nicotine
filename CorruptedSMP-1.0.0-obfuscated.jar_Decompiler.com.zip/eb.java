import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public class eb implements Listener {
   private final CorruptedSMPPlugin ry;

   public eb(CorruptedSMPPlugin var1) {
      this.ry = var1;
   }

   @EventHandler
   public void a(PlayerInteractEvent var1) {
   }
}
