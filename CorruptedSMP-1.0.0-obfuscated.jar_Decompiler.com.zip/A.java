import com.corruptedsmp.CorruptedSMPPlugin;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class A {
   private final CorruptedSMPPlugin S;
   private final File T;
   private final File U;
   private FileConfiguration V;
   private final Map<String, Integer> W;
   private final Map<String, Set<String>> X;

   public A(CorruptedSMPPlugin var1) {
      this.S = var1;
      this.W = new HashMap();
      this.X = new HashMap();
      this.T = new File(var1.getDataFolder(), "crafting-data.yml");
      this.U = new File(var1.getDataFolder(), "crafting-data-backup.yml");
      this.u();
   }

   public boolean d(Player var1, l var2) {
      if (!this.S.getConfig().getBoolean("crafting-limits.enabled", false)) {
         this.S.getLogger().info("[Crafting Limit] Limits disabled, allowing craft");
         return true;
      } else {
         String var3 = var2.name().toLowerCase();
         int var4 = this.e(var3);
         this.S.getLogger().info("[Crafting Limit] Checking " + var3 + " - Limit: " + var4);
         if (var4 == -1) {
            this.S.getLogger().info("[Crafting Limit] Unlimited, allowing craft");
            return true;
         } else if (var4 == 0) {
            this.S.getLogger().info("[Crafting Limit] Disabled, blocking craft");
            return false;
         } else {
            int var5 = this.d(var3);
            boolean var6 = var5 < var4;
            this.S.getLogger().info("[Crafting Limit] Current count: " + var5 + "/" + var4 + " - Can craft: " + var6);
            return var6;
         }
      }
   }

   public void e(Player var1, l var2) {
      if (!this.S.getConfig().getBoolean("crafting-limits.enabled", false)) {
         this.f(var1, var2);
      } else {
         String var3 = var2.name().toLowerCase();
         int var4 = (Integer)this.W.getOrDefault(var3, 0);
         this.W.put(var3, var4 + 1);
         this.f(var1, var2);
         this.S.getLogger().info("[Crafting Limit] Incremented " + var3 + " count: " + (var4 + 1));
         Logger var10000 = this.S.getLogger();
         String var10001 = var1.getName();
         var10000.info("[Crafting Limit] Player " + var10001 + " crafted " + var3);
         this.v();
         this.h(var1, var2);
      }
   }

   private void f(Player var1, l var2) {
      String var3 = var2.name().toLowerCase();
      String var4 = var1.getUniqueId().toString();
      ((Set)this.X.computeIfAbsent(var3, (var0) -> new HashSet())).add(var4);
   }

   public int d(String var1) {
      return (Integer)this.W.getOrDefault(var1, 0);
   }

   public int c(l var1) {
      String var2 = var1.name().toLowerCase();
      int var3 = this.e(var2);
      if (var3 == -1) {
         return -1;
      } else {
         int var4 = this.d(var2);
         return Math.max(0, var3 - var4);
      }
   }

   private int e(String var1) {
      int var2 = this.S.getConfig().getInt("crafting-limits.per-corruption." + var1, -999);
      return var2 != -999 ? var2 : this.S.getConfig().getInt("crafting-limits.global-limit", -1);
   }

   public void g(Player var1, l var2) {
      String var3 = this.S.getConfig().getString("messages.prefix", "").replace("&", "§");
      String var4 = this.S.getConfig().getString("crafting-limits.limit-reached-message", "&cThe server has reached the crafting limit for {corruption}!");
      var4 = var4.replace("{corruption}", var2.name()).replace("&", "§");
      var1.sendMessage(var3 + var4);
   }

   private void h(Player var1, l var2) {
      int var3 = this.c(var2);
      if (var3 != -1) {
         String var4 = this.S.getConfig().getString("messages.prefix", "").replace("&", "§");
         String var5 = this.S.getConfig().getString("crafting-limits.remaining-crafts-message", "&eThe server has &a{remaining}&e crafts remaining for {corruption}.");
         var5 = var5.replace("{corruption}", var2.name()).replace("{remaining}", String.valueOf(var3)).replace("&", "§");
         var1.sendMessage(var4 + var5);
      }
   }

   private void u() {
      if (this.S.getConfig().getBoolean("crafting-limits.reset-on-restart", false)) {
         this.S.getLogger().info("[Crafting Limit] Craft counts will be reset on restart (reset-on-restart: true)");
      } else {
         this.S.getLogger().info("[Crafting Limit] Loading crafting data from: " + this.T.getAbsolutePath());
         if (!this.T.getParentFile().exists()) {
            if (!this.T.getParentFile().mkdirs()) {
               this.S.getLogger().severe("[Crafting Limit] Failed to create data folder!");
               return;
            }

            this.S.getLogger().info("[Crafting Limit] Created data folder: " + this.T.getParentFile().getAbsolutePath());
         }

         File var1 = this.T;
         if (!this.T.exists() && this.U.exists()) {
            this.S.getLogger().warning("[Crafting Limit] Main data file missing, attempting to restore from backup...");

            try {
               Files.copy(this.U.toPath(), this.T.toPath(), StandardCopyOption.REPLACE_EXISTING);
               this.S.getLogger().info("[Crafting Limit] Successfully restored from backup!");
               var1 = this.T;
            } catch (IOException var14) {
               this.S.getLogger().severe("[Crafting Limit] Failed to restore from backup: " + var14.getMessage());
               return;
            }
         }

         if (!var1.exists()) {
            try {
               if (var1.createNewFile()) {
                  this.S.getLogger().info("[Crafting Limit] Created new crafting-data.yml file");
               }
            } catch (IOException var13) {
               this.S.getLogger().severe("[Crafting Limit] Could not create crafting-data.yml: " + var13.getMessage());
               var13.printStackTrace();
               return;
            }
         }

         try {
            this.V = YamlConfiguration.loadConfiguration(var1);
            this.S.getLogger().info("[Crafting Limit] Successfully loaded crafting-data.yml");
         } catch (Exception var12) {
            this.S.getLogger().severe("[Crafting Limit] Failed to load crafting-data.yml: " + var12.getMessage());
            var12.printStackTrace();
            this.V = new YamlConfiguration();
            return;
         }

         int var2 = 0;

         for(String var4 : this.V.getKeys(false)) {
            if (!var4.startsWith("players_")) {
               try {
                  int var5 = this.V.getInt(var4, 0);
                  this.W.put(var4, var5);
                  ++var2;
                  this.S.getLogger().info("[Crafting Limit] Loaded " + var4 + ": " + var5 + " crafts");
               } catch (Exception var11) {
                  this.S.getLogger().warning("[Crafting Limit] Error loading craft count for " + var4 + ": " + var11.getMessage());
               }
            }
         }

         int var15 = 0;

         for(l var7 : l.values()) {
            String var8 = "players_" + var7.name().toLowerCase();
            if (this.V.contains(var8)) {
               try {
                  List var9 = this.V.getStringList(var8);
                  if (!var9.isEmpty()) {
                     this.X.put(var7.name().toLowerCase(), new HashSet(var9));
                     ++var15;
                     Logger var10000 = this.S.getLogger();
                     String var10001 = var7.m();
                     var10000.info("[Crafting Limit] Loaded player history for " + var10001 + ": " + var9.size() + " players");
                  }
               } catch (Exception var10) {
                  this.S.getLogger().warning("[Crafting Limit] Error loading player history for " + var8 + ": " + var10.getMessage());
               }
            }
         }

         this.S.getLogger().info("[Crafting Limit] Data loaded successfully - " + var2 + " corruption counts, " + var15 + " player histories");
      }
   }

   private void v() {
      this.S.getServer().getScheduler().runTaskAsynchronously(this.S, this::w);
   }

   private void w() {
      if (this.V == null) {
         this.V = new YamlConfiguration();
      }

      for(String var2 : new HashSet(this.V.getKeys(false))) {
         this.V.set(var2, (Object)null);
      }

      for(Map.Entry var8 : this.W.entrySet()) {
         this.V.set((String)var8.getKey(), var8.getValue());
      }

      for(Map.Entry var9 : this.X.entrySet()) {
         String var3 = "players_" + (String)var9.getKey();
         this.V.set(var3, new ArrayList((Collection)var9.getValue()));
      }

      try {
         if (this.T.exists()) {
            Files.copy(this.T.toPath(), this.U.toPath(), StandardCopyOption.REPLACE_EXISTING);
            this.S.getLogger().info("[Crafting Limit] Backup created: " + this.U.getName());
         }
      } catch (IOException var5) {
         this.S.getLogger().warning("[Crafting Limit] Failed to create backup: " + var5.getMessage());
      }

      try {
         this.V.save(this.T);
         this.S.getLogger().info("[Crafting Limit] Successfully saved crafting-data.yml");
      } catch (IOException var4) {
         this.S.getLogger().severe("[Crafting Limit] Failed to save crafting-data.yml: " + var4.getMessage());
         var4.printStackTrace();
      }

   }

   public void f(String var1) {
      String var2 = var1.toLowerCase();
      this.W.put(var2, 0);
      this.S.getLogger().info("[Crafting Limit] Reset " + var2 + " craft count to 0");
      this.v();
   }
}
