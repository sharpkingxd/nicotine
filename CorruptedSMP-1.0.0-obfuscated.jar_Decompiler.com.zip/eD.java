public final class eD extends RuntimeException {
   public eD() {
   }

   public eD(String var1) {
      super(var1);
   }
}
