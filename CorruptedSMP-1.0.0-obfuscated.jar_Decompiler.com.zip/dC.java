public final class dC {
   public static final long o(String var0, int var1, int var2) {
      fR.c(var0, (String)"");
      if (var1 < 0) {
         boolean var13 = false;
         String var14 = "beginIndex < 0: " + var1;
         throw new IllegalArgumentException(var14.toString());
      } else if (var2 < var1) {
         boolean var11 = false;
         String var12 = "endIndex < beginIndex: " + var2 + " < " + var1;
         throw new IllegalArgumentException(var12.toString());
      } else if (var2 > var0.length()) {
         boolean var4 = false;
         String var10 = "endIndex > string.length: " + var2 + " > " + var0.length();
         throw new IllegalArgumentException(var10.toString());
      } else {
         long var3 = 0L;
         int var5 = var1;

         while(var5 < var2) {
            char var6 = var0.charAt(var5);
            if (var6 < 128) {
               ++var3;
               ++var5;
            } else if (var6 < 2048) {
               var3 += (long)2;
               ++var5;
            } else if (var6 >= '\ud800' && var6 <= '\udfff') {
               char var7 = var5 + 1 < var2 ? var0.charAt(var5 + 1) : 0;
               if (var6 <= '\udbff' && var7 >= '\udc00' && var7 <= '\udfff') {
                  var3 += (long)4;
                  var5 += 2;
               } else {
                  ++var3;
                  ++var5;
               }
            } else {
               var3 += (long)3;
               ++var5;
            }
         }

         return var3;
      }
   }

   // $FF: synthetic method
   public static long d(String var0, int var1, int var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = 0;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.length();
      }

      return o(var0, var1, var2);
   }
}
