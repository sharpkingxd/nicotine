import java.io.EOFException;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public final class dm implements dA {
   private final dg qc;
   private final Inflater qd;
   private int qe;
   private boolean closed;

   public dm(dg var1, Inflater var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.qc = var1;
      this.qd = var2;
   }

   public long a(de var1, long var2) throws IOException {
      fR.c(var1, (String)"");

      do {
         long var4 = this.c(var1, var2);
         if (var4 > 0L) {
            return var4;
         }

         if (this.qd.finished() || this.qd.needsDictionary()) {
            return -1L;
         }
      } while(!this.qc.kK());

      throw new EOFException("source exhausted prematurely");
   }

   public final long c(de var1, long var2) throws IOException {
      fR.c(var1, (String)"");
      if (var2 < 0L) {
         boolean var11 = false;
         String var12 = "byteCount < 0: " + var2;
         throw new IllegalArgumentException(var12.toString());
      } else if (this.closed) {
         boolean var9 = false;
         String var10 = "closed";
         throw new IllegalStateException(var10.toString());
      } else if (var2 == 0L) {
         return 0L;
      } else {
         try {
            dv var4 = var1.Y(1);
            int var6 = 8192 - var4.dI;
            boolean var7 = false;
            int var5 = (int)Math.min(var2, (long)var6);
            this.lA();
            var6 = this.qd.inflate(var4.qs, var4.dI, var5);
            this.lB();
            if (var6 > 0) {
               var4.dI += var6;
               var1.t(var1.kH() + (long)var6);
               return (long)var6;
            } else {
               if (var4.dH == var4.dI) {
                  var1.pR = var4.lI();
                  dw.c(var4);
               }

               return 0L;
            }
         } catch (DataFormatException var8) {
            throw new IOException((Throwable)var8);
         }
      }
   }

   public final boolean lA() throws IOException {
      if (!this.qd.needsInput()) {
         return false;
      } else if (this.qc.kK()) {
         return true;
      } else {
         dv var10000 = this.qc.kI().pR;
         fR.m(var10000);
         dv var1 = var10000;
         this.qe = var1.dI - var1.dH;
         this.qd.setInput(var1.qs, var1.dH, this.qe);
         return false;
      }
   }

   private final void lB() {
      if (this.qe != 0) {
         int var1 = this.qe - this.qd.getRemaining();
         this.qe -= var1;
         this.qc.A((long)var1);
      }
   }

   public dB fu() {
      return this.qc.fu();
   }

   public void close() throws IOException {
      if (!this.closed) {
         this.qd.end();
         this.closed = true;
         this.qc.close();
      }
   }
}
