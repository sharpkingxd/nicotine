import java.util.LinkedHashSet;
import java.util.Set;

public final class bV {
   private final Set<bA> lx = (Set)(new LinkedHashSet());

   public final synchronized void a(bA var1) {
      fR.c(var1, (String)"");
      this.lx.add(var1);
   }

   public final synchronized void b(bA var1) {
      fR.c(var1, (String)"");
      this.lx.remove(var1);
   }

   public final synchronized boolean c(bA var1) {
      fR.c(var1, (String)"");
      return this.lx.contains(var1);
   }
}
