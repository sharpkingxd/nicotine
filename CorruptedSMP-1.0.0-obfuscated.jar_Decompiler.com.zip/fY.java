public interface fY {
}
