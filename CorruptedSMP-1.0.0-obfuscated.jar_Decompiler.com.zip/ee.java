import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class ee implements Listener {
   private final CorruptedSMPPlugin rB;

   public ee(CorruptedSMPPlugin var1) {
      this.rB = var1;
   }

   @EventHandler
   public void a(PlayerQuitEvent var1) {
      if (this.rB.d().b(var1.getPlayer())) {
         l var2 = this.rB.d().c(var1.getPlayer());
         if (var2 == l.v) {
            o.t();
         }

         if (var2 == l.u) {
            m.e(var1.getPlayer().getUniqueId());
         }
      }

      this.rB.f().h(var1.getPlayer().getUniqueId());

      for(el var3 : this.rB.e().nc()) {
         var3.i(var1.getPlayer());
      }

      this.rB.h().k(var1.getPlayer());
   }
}
