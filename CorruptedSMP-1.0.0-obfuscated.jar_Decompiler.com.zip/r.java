import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class r {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      var0.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 40, 0, false, false));
   }
}
