import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.List;

public abstract class bo {
   public static final a Companion = new a((fP)null);
   public static final bo NONE = new bo() {
   };

   public void a(bb var1) {
      fR.c(var1, (String)"");
   }

   public void a(bb var1, br var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void a(bb var1, br var2, List<Proxy> var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
   }

   public void a(bb var1, String var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void a(bb var1, String var2, List<InetAddress> var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
   }

   public void a(bb var1, InetSocketAddress var2, Proxy var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
   }

   public void b(bb var1) {
      fR.c(var1, (String)"");
   }

   public void a(bb var1, bp var2) {
      fR.c(var1, (String)"");
   }

   public void a(bb var1, InetSocketAddress var2, Proxy var3, bv var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
   }

   public void a(bb var1, InetSocketAddress var2, Proxy var3, bv var4, IOException var5) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var5, (String)"");
   }

   public void a(bb var1, bg var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void b(bb var1, bg var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void c(bb var1) {
      fR.c(var1, (String)"");
   }

   public void a(bb var1, bw var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void d(bb var1) {
      fR.c(var1, (String)"");
   }

   public void a(bb var1, long var2) {
      fR.c(var1, (String)"");
   }

   public void b(bb var1, IOException var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void e(bb var1) {
      fR.c(var1, (String)"");
   }

   public void b(bb var1, by var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void f(bb var1) {
      fR.c(var1, (String)"");
   }

   public void b(bb var1, long var2) {
      fR.c(var1, (String)"");
   }

   public void c(bb var1, IOException var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void g(bb var1) {
      fR.c(var1, (String)"");
   }

   public void d(bb var1, IOException var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void h(bb var1) {
      fR.c(var1, (String)"");
   }

   public void c(bb var1, by var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void d(bb var1, by var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public void i(bb var1) {
      fR.c(var1, (String)"");
   }

   public void e(bb var1, by var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public interface c {
      bo create(bb var1);
   }
}
