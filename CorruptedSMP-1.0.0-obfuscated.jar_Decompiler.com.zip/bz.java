import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;

public abstract class bz implements Closeable {
   public static final a Companion = new a((fP)null);
   private Reader reader;

   public abstract bt bR();

   public abstract long bS();

   public abstract dg bT();

   public final String fm() throws IOException {
      Closeable var1 = this.bT();
      Throwable var2 = null;

      String var9;
      try {
         dg var3 = (dg)var1;
         boolean var4 = false;
         var9 = var3.b(bD.a(var3, this.fn()));
      } catch (Throwable var7) {
         var2 = var7;
         throw var7;
      } finally {
         fI.a(var1, var2);
      }

      return var9;
   }

   private final Charset fn() {
      bt var10000 = this.bR();
      Charset var1;
      if (var10000 != null) {
         var1 = var10000.a(gx.tn);
         if (var1 != null) {
            return var1;
         }
      }

      var1 = gx.tn;
      return var1;
   }

   public void close() {
      bD.a(this.bT());
   }

   public static final class a {
      private a() {
      }

      public final bz a(byte[] var1, bt var2) {
         fR.c(var1, (String)"");
         return this.a((new de()).c(var1), var2, (long)var1.length);
      }

      // $FF: synthetic method
      public static bz a(a var0, byte[] var1, bt var2, int var3, Object var4) {
         if ((var3 & 1) != 0) {
            var2 = null;
         }

         return var0.a(var1, var2);
      }

      public final bz a(final dg var1, final bt var2, final long var3) {
         fR.c(var1, (String)"");
         return new bz() {
            public bt bR() {
               return var2;
            }

            public long bS() {
               return var3;
            }

            public dg bT() {
               return var1;
            }
         };
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
