import java.io.Serializable;
import java.util.regex.Pattern;

public final class gz implements Serializable {
   public static final a tF = new a((fP)null);
   private final Pattern tG;

   public gz(Pattern var1) {
      fR.c(var1, (String)"");
      super();
      this.tG = var1;
   }

   public gz(String var1) {
      fR.c(var1, (String)"");
      Pattern var10001 = Pattern.compile(var1);
      fR.b(var10001, "");
      this(var10001);
   }

   public final boolean a(CharSequence var1) {
      fR.c(var1, (String)"");
      return this.tG.matcher(var1).matches();
   }

   public final String a(CharSequence var1, String var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      String var10000 = this.tG.matcher(var1).replaceAll(var2);
      fR.b(var10000, "");
      return var10000;
   }

   public String toString() {
      String var10000 = this.tG.toString();
      fR.b(var10000, "");
      return var10000;
   }

   private final Object writeReplace() {
      String var10002 = this.tG.pattern();
      fR.b(var10002, "");
      return new b(var10002, this.tG.flags());
   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   static final class b implements Serializable {
      public static final a tH = new a((fP)null);
      private final String tI;
      private final int tJ;
      private static final long serialVersionUID = 0L;

      public b(String var1, int var2) {
         fR.c(var1, (String)"");
         super();
         this.tI = var1;
         this.tJ = var2;
      }

      private final Object readResolve() {
         Pattern var10002 = Pattern.compile(this.tI, this.tJ);
         fR.b(var10002, "");
         return new gz(var10002);
      }

      public static final class a {
         private a() {
         }

         // $FF: synthetic method
         public a(fP var1) {
            this();
         }
      }
   }
}
