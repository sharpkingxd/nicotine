import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.security.auth.x500.X500Principal;

public final class cW implements cZ {
   private final Map<X500Principal, Set<X509Certificate>> pK;

   public cW(X509Certificate... var1) {
      fR.c(var1, (String)"");
      super();
      Map var2 = (Map)(new LinkedHashMap());
      int var3 = 0;

      for(int var4 = var1.length; var3 < var4; ++var3) {
         X509Certificate var5 = var1[var3];
         X500Principal var10000 = var5.getSubjectX500Principal();
         fR.b(var10000, "");
         X500Principal var7 = var10000;
         boolean var8 = false;
         Object var9 = var2.get(var7);
         Object var12;
         if (var9 == null) {
            boolean var10 = false;
            Set var11 = (Set)(new LinkedHashSet());
            var2.put(var7, var11);
            var12 = var11;
         } else {
            var12 = var9;
         }

         ((Set)var12).add(var5);
      }

      this.pK = var2;
   }

   public X509Certificate c(X509Certificate var1) {
      fR.c(var1, (String)"");
      X500Principal var2 = var1.getIssuerX500Principal();
      Set var10000 = (Set)this.pK.get(var2);
      if (var10000 == null) {
         return null;
      } else {
         Set var3 = var10000;
         Iterable var4 = (Iterable)var3;
         boolean var5 = false;
         Iterator var6 = var4.iterator();

         while(true) {
            if (var6.hasNext()) {
               Object var7 = var6.next();
               X509Certificate var8 = (X509Certificate)var7;
               boolean var9 = false;

               try {
                  var1.verify(var8.getPublicKey());
                  var13 = true;
               } catch (Exception var11) {
                  var13 = false;
               }

               if (!var13) {
                  continue;
               }

               var12 = var7;
               break;
            }

            var12 = null;
            break;
         }

         return (X509Certificate)var12;
      }
   }

   public boolean equals(Object var1) {
      return var1 == this || var1 instanceof cW && fR.c(((cW)var1).pK, (Object)this.pK);
   }

   public int hashCode() {
      return this.pK.hashCode();
   }
}
