public interface fL<P1, P2, R> {
   R invoke(P1 var1, P2 var2);
}
