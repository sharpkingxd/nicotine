public final class cq$i extends bK {
   // $FF: synthetic field
   final cq this$0;

   public cq$i(String var1, boolean var2, cq var3) {
      super(var1, var2);
      this.this$0 = var3;
   }

   public long gg() {
      boolean var1 = false;
      this.this$0.a(false, 2, 0);
      return -1L;
   }
}
