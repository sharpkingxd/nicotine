import java.net.Proxy;
import java.net.Proxy.Type;

public final class cg {
   public static final cg me = new cg();

   private cg() {
   }

   public final String a(bw var1, Proxy.Type var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      StringBuilder var3 = new StringBuilder();
      boolean var5 = false;
      var3.append(var1.eJ());
      var3.append(' ');
      if (me.b(var1, var2)) {
         var3.append(var1.eI());
      } else {
         var3.append(me.g(var1.eI()));
      }

      var3.append(" HTTP/1.1");
      String var10000 = var3.toString();
      fR.b(var10000, "");
      return var10000;
   }

   private final boolean b(bw var1, Proxy.Type var2) {
      return !var1.eN() && var2 == Type.HTTP;
   }

   public final String g(br var1) {
      fR.c(var1, (String)"");
      String var2 = var1.df();
      String var3 = var1.dh();
      return var3 != null ? var2 + '?' + var3 : var2;
   }
}
