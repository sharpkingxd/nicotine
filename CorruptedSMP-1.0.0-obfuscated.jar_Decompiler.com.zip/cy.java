import java.io.IOException;

public final class cy extends IOException {
   public final cm ot;

   public cy(cm var1) {
      fR.c(var1, (String)"");
      super("stream was reset: " + var1);
      this.ot = var1;
   }
}
