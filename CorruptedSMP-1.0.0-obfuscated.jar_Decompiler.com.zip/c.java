import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class c implements CommandExecutor {
   private final CorruptedSMPPlugin m;

   public c(CorruptedSMPPlugin var1) {
      this.m = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.isOp()) {
            var5.sendMessage("§cYou must be an operator to use this command!");
            return true;
         } else {
            ep.e(var5, this.m);
            return true;
         }
      } else {
         var1.sendMessage("§cThis command can only be used by players!");
         return true;
      }
   }
}
