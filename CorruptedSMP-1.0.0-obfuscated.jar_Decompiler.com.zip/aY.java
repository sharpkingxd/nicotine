import java.io.IOException;

public interface aY {
   a ej = aY.a.$$INSTANCE;
   aY ek = new a.a();
   aY el = new bE((bn)null, 1, (fP)null);

   bw a(bA var1, by var2) throws IOException;

   public static final class a {
      // $FF: synthetic field
      static final a $$INSTANCE = new a();

      private a() {
      }

      static final class a implements aY {
         public a() {
         }

         public bw a(bA var1, by var2) {
            fR.c(var2, (String)"");
            return null;
         }
      }
   }
}
