import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class eP {
   public static final <T> List<T> i(T var0) {
      List var10000 = Collections.singletonList(var0);
      fR.b(var10000, "");
      return var10000;
   }

   public static final <T> Object[] a(T[] var0, boolean var1) {
      fR.c(var0, (String)"");
      Object[] var10000;
      if (var1 && fR.c(var0.getClass(), (Object)Object[].class)) {
         var10000 = var0;
      } else {
         var10000 = Arrays.copyOf(var0, var0.length, Object[].class);
         fR.b(var10000, "");
      }

      return var10000;
   }
}
