import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class dK implements Listener {
   private final CorruptedSMPPlugin ra;

   public dK(CorruptedSMPPlugin var1) {
      this.ra = var1;
   }

   @EventHandler
   public void a(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      if (var2.isSneaking()) {
         if (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (this.ra.d().b(var2)) {
               if (!this.ra.j().d(var2.getLocation())) {
                  this.ra.j().e(var2);
                  var1.setCancelled(true);
               } else {
                  boolean var3 = this.ra.d().d(var2);
                  if (var3) {
                     var1.setCancelled(true);
                  }

               }
            }
         }
      }
   }
}
