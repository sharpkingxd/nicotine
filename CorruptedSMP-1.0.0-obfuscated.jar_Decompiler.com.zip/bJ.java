import java.io.IOException;

public class bJ extends di {
   private final fK<IOException, eE> kb;
   private boolean kc;

   public bJ(dy var1, fK<? super IOException, eE> var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super(var1);
      this.kb = var2;
   }

   public void b(de var1, long var2) {
      fR.c(var1, (String)"");
      if (this.kc) {
         var1.A(var2);
      } else {
         try {
            super.b(var1, var2);
         } catch (IOException var5) {
            this.kc = true;
            this.kb.invoke(var5);
         }

      }
   }

   public void flush() {
      if (!this.kc) {
         try {
            super.flush();
         } catch (IOException var2) {
            this.kc = true;
            this.kb.invoke(var2);
         }

      }
   }

   public void close() {
      if (!this.kc) {
         try {
            super.close();
         } catch (IOException var2) {
            this.kc = true;
            this.kb.invoke(var2);
         }

      }
   }
}
