class gv {
   public static final boolean g(char var0) {
      return Character.isWhitespace(var0) || Character.isSpaceChar(var0);
   }

   public static final int a(char var0, int var1) {
      return Character.digit(var0, var1);
   }

   public static final int ar(int var0) {
      if (!(new gf(2, 36)).ap(var0)) {
         throw new IllegalArgumentException("radix " + var0 + " was not in valid range " + new gf(2, 36));
      } else {
         return var0;
      }
   }
}
