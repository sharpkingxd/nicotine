public class fU {
   private static final fV sR;
   private static final gj[] sS;

   public static String a(fS var0) {
      return sR.a(var0);
   }

   public static String a(fQ var0) {
      return sR.a(var0);
   }

   static {
      fV var0;
      try {
         Class var1 = Class.forName("kotlin.reflect.jvm.internal.ReflectionFactoryImpl");
         var0 = (fV)var1.newInstance();
      } catch (ClassCastException var2) {
         var0 = null;
      } catch (ClassNotFoundException var3) {
         var0 = null;
      } catch (InstantiationException var4) {
         var0 = null;
      } catch (IllegalAccessException var5) {
         var0 = null;
      }

      sR = var0 != null ? var0 : new fV();
      sS = new gj[0];
   }
}
