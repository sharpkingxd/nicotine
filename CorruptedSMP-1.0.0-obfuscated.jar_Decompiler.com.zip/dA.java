import java.io.Closeable;
import java.io.IOException;

public interface dA extends Closeable {
   long a(de var1, long var2) throws IOException;

   dB fu();

   void close() throws IOException;
}
