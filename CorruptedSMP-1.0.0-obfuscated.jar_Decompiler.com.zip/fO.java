import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

public final class fO {
   private static final Object[] sO;

   public static final Object[] c(Collection<?> var0) {
      fR.c(var0, (String)"");
      boolean var1 = false;
      int var2 = var0.size();
      Object[] var10000;
      if (var2 == 0) {
         boolean var3 = false;
         var10000 = sO;
      } else {
         Iterator var10 = var0.iterator();
         if (!var10.hasNext()) {
            boolean var4 = false;
            var10000 = sO;
         } else {
            int var5 = 0;
            Object[] var11 = new Object[var2];
            var5 = 0;

            while(true) {
               var11[var5++] = var10.next();
               if (var5 >= var11.length) {
                  if (!var10.hasNext()) {
                     var10000 = var11;
                     break;
                  }

                  int var6 = var5 * 3 + 1 >>> 1;
                  if (var6 <= var5) {
                     if (var5 >= 2147483645) {
                        throw new OutOfMemoryError();
                     }

                     var6 = 2147483645;
                  }

                  var10000 = Arrays.copyOf(var11, var6);
                  fR.b(var10000, "");
                  var11 = var10000;
               } else if (!var10.hasNext()) {
                  boolean var9 = false;
                  var10000 = Arrays.copyOf(var11, var5);
                  fR.b(var10000, "");
                  break;
               }
            }
         }
      }

      return var10000;
   }

   public static final Object[] b(Collection<?> var0, Object[] var1) {
      fR.c(var0, (String)"");
      if (var1 == null) {
         throw new NullPointerException();
      } else {
         boolean var2 = false;
         int var3 = var0.size();
         Object[] var10000;
         if (var3 == 0) {
            boolean var4 = false;
            if (var1.length > 0) {
               var1[0] = null;
            }

            var10000 = var1;
         } else {
            Iterator var5 = var0.iterator();
            if (!var5.hasNext()) {
               boolean var11 = false;
               if (var1.length > 0) {
                  var1[0] = null;
               }

               var10000 = var1;
            } else {
               int var6 = 0;
               if (var3 <= var1.length) {
                  var10000 = var1;
               } else {
                  var10000 = Array.newInstance(var1.getClass().getComponentType(), var3);
                  fR.m(var10000);
                  var10000 = var10000;
               }

               Object[] var7 = var10000;
               int var12 = 0;

               while(true) {
                  var7[var12++] = var5.next();
                  if (var12 >= var7.length) {
                     if (!var5.hasNext()) {
                        var10000 = var7;
                        break;
                     }

                     var6 = var12 * 3 + 1 >>> 1;
                     if (var6 <= var12) {
                        if (var12 >= 2147483645) {
                           throw new OutOfMemoryError();
                        }

                        var6 = 2147483645;
                     }

                     Object[] var16 = Arrays.copyOf(var7, var6);
                     fR.b(var16, "");
                     var7 = var16;
                  } else if (!var5.hasNext()) {
                     boolean var10 = false;
                     if (var7 == var1) {
                        var1[var12] = null;
                        var10000 = var1;
                     } else {
                        var10000 = Arrays.copyOf(var7, var12);
                        fR.b(var10000, "");
                     }
                     break;
                  }
               }
            }
         }

         return (Object[])var10000;
      }
   }

   static {
      boolean var0 = false;
      sO = new Object[0];
   }
}
