import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.UnknownServiceException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;

public final class bP {
   private final List<bi> ku;
   private int kv;
   private boolean kw;
   private boolean kx;

   public bP(List<bi> var1) {
      fR.c(var1, (String)"");
      super();
      this.ku = var1;
   }

   public final bi b(SSLSocket var1) throws IOException {
      fR.c(var1, (String)"");
      bi var2 = null;
      int var3 = this.kv;

      for(int var4 = this.ku.size(); var3 < var4; ++var3) {
         bi var5 = (bi)this.ku.get(var3);
         if (var5.a(var1)) {
            var2 = var5;
            this.kv = var3 + 1;
            break;
         }
      }

      if (var2 == null) {
         StringBuilder var10002 = (new StringBuilder()).append("Unable to find acceptable protocols. isFallback=").append(this.kx).append(", modes=").append(this.ku).append(", supported protocols=");
         String var10003 = var1.getEnabledProtocols();
         fR.m(var10003);
         var10003 = Arrays.toString(var10003);
         fR.b(var10003, "");
         throw new UnknownServiceException(var10002.append(var10003).toString());
      } else {
         this.kw = this.c(var1);
         var2.a(var1, this.kx);
         return var2;
      }
   }

   public final boolean c(IOException var1) {
      fR.c(var1, (String)"");
      this.kx = true;
      return !this.kw ? false : (var1 instanceof ProtocolException ? false : (var1 instanceof InterruptedIOException ? false : (var1 instanceof SSLHandshakeException && var1.getCause() instanceof CertificateException ? false : (var1 instanceof SSLPeerUnverifiedException ? false : var1 instanceof SSLException))));
   }

   private final boolean c(SSLSocket var1) {
      int var2 = this.kv;

      for(int var3 = this.ku.size(); var2 < var3; ++var2) {
         if (((bi)this.ku.get(var2)).a(var1)) {
            return true;
         }
      }

      return false;
   }
}
