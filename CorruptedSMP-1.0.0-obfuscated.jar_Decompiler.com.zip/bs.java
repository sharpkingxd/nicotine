import java.io.IOException;

public interface bs {
   b ia = bs.b.$$INSTANCE;

   by a(a var1) throws IOException;

   public interface a {
      bw ds();

      by c(bw var1) throws IOException;

      bb dt();
   }

   public static final class b {
      // $FF: synthetic field
      static final b $$INSTANCE = new b();

      private b() {
      }
   }
}
