import com.corruptedsmp.CorruptedSMPPlugin;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class E {
   private final CorruptedSMPPlugin an;
   private final Map<UUID, D> ao;
   private final File ap;

   public E(CorruptedSMPPlugin var1) {
      this.an = var1;
      this.ao = new HashMap();
      this.ap = new File(var1.getDataFolder(), "playerdata");
      if (!this.ap.exists()) {
         this.ap.mkdirs();
      }

   }

   public D g(UUID var1) {
      return (D)this.ao.computeIfAbsent(var1, (var2) -> {
         D var3 = new D(var1);
         this.b(var3);
         return var3;
      });
   }

   public void b(D var1) {
      File var2 = new File(this.ap, var1.z().toString() + ".yml");
      if (var2.exists()) {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         if (((FileConfiguration)var3).contains("corruption")) {
            String var4 = ((FileConfiguration)var3).getString("corruption");
            l var5 = l.b(var4);
            var1.g(var5);
            var1.a(var5 != null);
         }

         var1.a(((FileConfiguration)var3).getInt("darkness-bar-hits", 0));
         var1.b(((FileConfiguration)var3).getInt("velocity-hit-streak", 0));
         var1.a(((FileConfiguration)var3).getLong("last-armor-repair", 0L));
         var1.a(((FileConfiguration)var3).getDouble("fire-temperature", (double)0.0F));
      }
   }

   public void c(D var1) {
      File var2 = new File(this.ap, var1.z().toString() + ".yml");
      YamlConfiguration var3 = new YamlConfiguration();
      if (var1.B() && var1.A() != null) {
         ((FileConfiguration)var3).set("corruption", var1.A().m());
      } else {
         ((FileConfiguration)var3).set("corruption", (Object)null);
      }

      ((FileConfiguration)var3).set("darkness-bar-hits", var1.C());
      ((FileConfiguration)var3).set("velocity-hit-streak", var1.F());
      ((FileConfiguration)var3).set("last-armor-repair", var1.I());
      ((FileConfiguration)var3).set("fire-temperature", var1.P());

      try {
         ((FileConfiguration)var3).save(var2);
      } catch (IOException var5) {
         this.an.getLogger().severe("Failed to save player data for " + String.valueOf(var1.z()));
         var5.printStackTrace();
      }

   }

   public void S() {
      for(D var2 : this.ao.values()) {
         this.c(var2);
      }

   }

   public void h(UUID var1) {
      D var2 = (D)this.ao.get(var1);
      if (var2 != null) {
         this.c(var2);
         this.ao.remove(var1);
      }

   }
}
