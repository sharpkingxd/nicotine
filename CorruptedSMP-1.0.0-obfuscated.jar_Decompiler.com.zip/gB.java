class gB {
   public static final <T> void a(Appendable var0, T var1, fK<? super T, ? extends CharSequence> var2) {
      fR.c(var0, (String)"");
      if (var2 != null) {
         var0.append((CharSequence)var2.invoke(var1));
      } else if (var1 == null ? true : var1 instanceof CharSequence) {
         var0.append((CharSequence)var1);
      } else if (var1 instanceof Character) {
         var0.append((Character)var1);
      } else {
         var0.append((CharSequence)String.valueOf(var1));
      }

   }
}
