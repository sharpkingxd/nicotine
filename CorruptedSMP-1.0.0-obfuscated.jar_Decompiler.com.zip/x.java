import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class x {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      if (var0.isInWater() || var0.getWorld().hasStorm()) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 40, 0, false, false));
         var0.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 40, 0, false, false));
      }

   }
}
