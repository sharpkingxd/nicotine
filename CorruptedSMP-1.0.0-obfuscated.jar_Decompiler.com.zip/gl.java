public interface gl<T> extends gm<T> {
   gm<T> aq(int var1);
}
