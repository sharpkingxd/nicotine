import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;

public final class am implements ad, Cloneable {
   public static final am bh = new am();
   private double bi = (double)-1.0F;
   private int bj = 136;
   private boolean bk = true;
   private boolean bl;
   private List<G> bm = Collections.emptyList();
   private List<G> bn = Collections.emptyList();

   protected am aw() {
      try {
         return (am)super.clone();
      } catch (CloneNotSupportedException var2) {
         throw new AssertionError(var2);
      }
   }

   public <T> ac<T> a(final K var1, final aS<T> var2) {
      Class var3 = var2.bk();
      boolean var4 = this.f(var3);
      final boolean var5 = var4 || this.b(var3, true);
      final boolean var6 = var4 || this.b(var3, false);
      return !var5 && !var6 ? null : new ac<T>() {
         private ac<T> delegate;

         public T b(aT var1x) throws IOException {
            if (var6) {
               var1x.aT();
               return null;
            } else {
               return (T)this.U().b(var1x);
            }
         }

         public void a(aV var1x, T var2x) throws IOException {
            if (var5) {
               var1x.be();
            } else {
               this.U().a(var1x, var2x);
            }
         }

         private ac<T> U() {
            ac var1x = this.delegate;
            return var1x != null ? var1x : (this.delegate = var1.a((ad)am.this, var2));
         }
      };
   }

   public boolean a(Field var1, boolean var2) {
      if ((this.bj & var1.getModifiers()) != 0) {
         return true;
      } else if (this.bi != (double)-1.0F && !this.a((ah)var1.getAnnotation(ah.class), (ai)var1.getAnnotation(ai.class))) {
         return true;
      } else if (var1.isSynthetic()) {
         return true;
      } else {
         if (this.bl) {
            ae var3 = (ae)var1.getAnnotation(ae.class);
            if (var3 == null) {
               return true;
            }

            if (var2) {
               if (!var3.ao()) {
                  return true;
               }
            } else if (!var3.ap()) {
               return true;
            }
         }

         if (!this.bk && this.h(var1.getType())) {
            return true;
         } else if (this.g(var1.getType())) {
            return true;
         } else {
            List var7 = var2 ? this.bm : this.bn;
            if (!var7.isEmpty()) {
               H var4 = new H(var1);

               for(G var6 : var7) {
                  if (var6.a(var4)) {
                     return true;
                  }
               }
            }

            return false;
         }
      }
   }

   private boolean f(Class<?> var1) {
      if (this.bi != (double)-1.0F && !this.a((ah)var1.getAnnotation(ah.class), (ai)var1.getAnnotation(ai.class))) {
         return true;
      } else {
         return !this.bk && this.h(var1) ? true : this.g(var1);
      }
   }

   public boolean a(Class<?> var1, boolean var2) {
      return this.f(var1) || this.b(var1, var2);
   }

   private boolean b(Class<?> var1, boolean var2) {
      for(G var5 : var2 ? this.bm : this.bn) {
         if (var5.a(var1)) {
            return true;
         }
      }

      return false;
   }

   private boolean g(Class<?> var1) {
      return !Enum.class.isAssignableFrom(var1) && !this.i(var1) && (var1.isAnonymousClass() || var1.isLocalClass());
   }

   private boolean h(Class<?> var1) {
      return var1.isMemberClass() && !this.i(var1);
   }

   private boolean i(Class<?> var1) {
      return (var1.getModifiers() & 8) != 0;
   }

   private boolean a(ah var1, ai var2) {
      return this.a(var1) && this.a(var2);
   }

   private boolean a(ah var1) {
      if (var1 != null) {
         double var2 = var1.au();
         return this.bi >= var2;
      } else {
         return true;
      }
   }

   private boolean a(ai var1) {
      if (var1 != null) {
         double var2 = var1.au();
         return this.bi < var2;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   protected Object clone() throws CloneNotSupportedException {
      return this.aw();
   }
}
