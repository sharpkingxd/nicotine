import java.nio.ByteBuffer;

public final class dt implements df {
   public final dy qn;
   public final de qo;
   public boolean closed;

   public dt(dy var1) {
      fR.c(var1, (String)"");
      super();
      this.qn = var1;
      this.qo = new de();
   }

   public de kI() {
      boolean var1 = false;
      return this.qo;
   }

   public void b(de var1, long var2) {
      fR.c(var1, (String)"");
      boolean var5 = false;
      if (this.closed) {
         boolean var8 = false;
         String var9 = "closed";
         throw new IllegalStateException(var9.toString());
      } else {
         boolean var6 = false;
         this.qo.b(var1, var2);
         this.lb();
      }
   }

   public df f(dh var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var4 = false;
         this.qo.d(var1);
         return this.lb();
      }
   }

   public df aR(String var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var4 = false;
         this.qo.aQ(var1);
         return this.lb();
      }
   }

   public df d(byte[] var1) {
      fR.c(var1, (String)"");
      boolean var3 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var4 = false;
         this.qo.c(var1);
         return this.lb();
      }
   }

   public df b(byte[] var1, int var2, int var3) {
      fR.c(var1, (String)"");
      boolean var5 = false;
      if (this.closed) {
         boolean var8 = false;
         String var9 = "closed";
         throw new IllegalStateException(var9.toString());
      } else {
         boolean var6 = false;
         this.qo.a(var1, var2, var3);
         return this.lb();
      }
   }

   public int write(ByteBuffer var1) {
      fR.c(var1, (String)"");
      if (this.closed) {
         boolean var3 = false;
         String var5 = "closed";
         throw new IllegalStateException(var5.toString());
      } else {
         boolean var4 = false;
         int var2 = this.qo.write(var1);
         this.lb();
         return var2;
      }
   }

   public df aa(int var1) {
      boolean var3 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var4 = false;
         this.qo.V(var1);
         return this.lb();
      }
   }

   public df ab(int var1) {
      boolean var3 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var4 = false;
         this.qo.W(var1);
         return this.lb();
      }
   }

   public df ac(int var1) {
      boolean var3 = false;
      if (this.closed) {
         boolean var6 = false;
         String var7 = "closed";
         throw new IllegalStateException(var7.toString());
      } else {
         boolean var4 = false;
         this.qo.X(var1);
         return this.lb();
      }
   }

   public df D(long var1) {
      boolean var4 = false;
      if (this.closed) {
         boolean var7 = false;
         String var8 = "closed";
         throw new IllegalStateException(var8.toString());
      } else {
         boolean var5 = false;
         this.qo.B(var1);
         return this.lb();
      }
   }

   public df E(long var1) {
      boolean var4 = false;
      if (this.closed) {
         boolean var7 = false;
         String var8 = "closed";
         throw new IllegalStateException(var8.toString());
      } else {
         boolean var5 = false;
         this.qo.C(var1);
         return this.lb();
      }
   }

   public df lb() {
      boolean var2 = false;
      if (this.closed) {
         boolean var3 = false;
         String var8 = "closed";
         throw new IllegalStateException(var8.toString());
      } else {
         boolean var5 = false;
         long var6 = this.qo.kM();
         if (var6 > 0L) {
            var5 = false;
            this.qn.b(this.qo, var6);
         }

         return this;
      }
   }

   public void flush() {
      boolean var2 = false;
      if (this.closed) {
         boolean var7 = false;
         String var8 = "closed";
         throw new IllegalStateException(var8.toString());
      } else {
         boolean var3 = false;
         if (this.qo.kH() > 0L) {
            var3 = false;
            var3 = false;
            this.qn.b(this.qo, this.qo.kH());
         }

         this.qn.flush();
      }
   }

   public boolean isOpen() {
      return !this.closed;
   }

   public void close() {
      dt var1 = this;
      boolean var2 = false;
      if (!this.closed) {
         Throwable var3 = null;

         try {
            boolean var5 = false;
            if (var1.qo.kH() > 0L) {
               var5 = false;
               var5 = false;
               var1.qn.b(var1.qo, var1.qo.kH());
            }
         } catch (Throwable var6) {
            var3 = var6;
         }

         try {
            var1.qn.close();
         } catch (Throwable var7) {
            if (var3 == null) {
               var3 = var7;
            }
         }

         this.closed = true;
         if (var3 != null) {
            throw var3;
         }
      }

   }

   public dB fu() {
      boolean var2 = false;
      return this.qn.fu();
   }

   public String toString() {
      boolean var2 = false;
      return "buffer(" + this.qn + ')';
   }
}
