public interface N {
}
