import [Ljava.lang.reflect.Type;;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Properties;

public final class ak {
   static final Type[] EMPTY_TYPE_ARRAY = new Type[0];

   private ak() {
      throw new UnsupportedOperationException();
   }

   public static ParameterizedType a(Type var0, Type var1, Type... var2) {
      return new b(var0, var1, var2);
   }

   public static GenericArrayType b(Type var0) {
      return new a(var0);
   }

   public static WildcardType c(Type var0) {
      Type[] var1;
      if (var0 instanceof WildcardType) {
         var1 = ((WildcardType)var0).getUpperBounds();
      } else {
         var1 = new Type[]{var0};
      }

      return new c(var1, EMPTY_TYPE_ARRAY);
   }

   public static WildcardType d(Type var0) {
      Type[] var1;
      if (var0 instanceof WildcardType) {
         var1 = ((WildcardType)var0).getLowerBounds();
      } else {
         var1 = new Type[]{var0};
      }

      return new c(new Type[]{Object.class}, var1);
   }

   public static Type e(Type var0) {
      if (var0 instanceof Class) {
         Class var4 = (Class)var0;
         return (Type)(var4.isArray() ? new a(e(var4.getComponentType())) : var4);
      } else if (var0 instanceof ParameterizedType) {
         ParameterizedType var3 = (ParameterizedType)var0;
         return new b(var3.getOwnerType(), var3.getRawType(), var3.getActualTypeArguments());
      } else if (var0 instanceof GenericArrayType) {
         GenericArrayType var2 = (GenericArrayType)var0;
         return new a(var2.getGenericComponentType());
      } else if (var0 instanceof WildcardType) {
         WildcardType var1 = (WildcardType)var0;
         return new c(var1.getUpperBounds(), var1.getLowerBounds());
      } else {
         return var0;
      }
   }

   public static Class<?> f(Type var0) {
      if (var0 instanceof Class) {
         return (Class)var0;
      } else if (var0 instanceof ParameterizedType) {
         ParameterizedType var5 = (ParameterizedType)var0;
         Type var2 = var5.getRawType();
         aj.e(var2 instanceof Class);
         return (Class)var2;
      } else if (var0 instanceof GenericArrayType) {
         Type var4 = ((GenericArrayType)var0).getGenericComponentType();
         return Array.newInstance(f(var4), 0).getClass();
      } else if (var0 instanceof TypeVariable) {
         return Object.class;
      } else if (var0 instanceof WildcardType) {
         Type[] var3 = ((WildcardType)var0).getUpperBounds();

         assert var3.length == 1;

         return f(var3[0]);
      } else {
         String var1 = var0 == null ? "null" : var0.getClass().getName();
         throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + var0 + "> is of type " + var1);
      }
   }

   private static boolean a(Object var0, Object var1) {
      return Objects.equals(var0, var1);
   }

   public static boolean a(Type var0, Type var1) {
      if (var0 == var1) {
         return true;
      } else if (var0 instanceof Class) {
         return var0.equals(var1);
      } else if (var0 instanceof ParameterizedType) {
         if (!(var1 instanceof ParameterizedType)) {
            return false;
         } else {
            ParameterizedType var6 = (ParameterizedType)var0;
            ParameterizedType var9 = (ParameterizedType)var1;
            return a((Object)var6.getOwnerType(), (Object)var9.getOwnerType()) && var6.getRawType().equals(var9.getRawType()) && Arrays.equals(var6.getActualTypeArguments(), var9.getActualTypeArguments());
         }
      } else if (var0 instanceof GenericArrayType) {
         if (!(var1 instanceof GenericArrayType)) {
            return false;
         } else {
            GenericArrayType var5 = (GenericArrayType)var0;
            GenericArrayType var8 = (GenericArrayType)var1;
            return a(var5.getGenericComponentType(), var8.getGenericComponentType());
         }
      } else if (var0 instanceof WildcardType) {
         if (!(var1 instanceof WildcardType)) {
            return false;
         } else {
            WildcardType var4 = (WildcardType)var0;
            WildcardType var7 = (WildcardType)var1;
            return Arrays.equals(var4.getUpperBounds(), var7.getUpperBounds()) && Arrays.equals(var4.getLowerBounds(), var7.getLowerBounds());
         }
      } else if (var0 instanceof TypeVariable) {
         if (!(var1 instanceof TypeVariable)) {
            return false;
         } else {
            TypeVariable var2 = (TypeVariable)var0;
            TypeVariable var3 = (TypeVariable)var1;
            return var2.getGenericDeclaration() == var3.getGenericDeclaration() && var2.getName().equals(var3.getName());
         }
      } else {
         return false;
      }
   }

   public static String g(Type var0) {
      return var0 instanceof Class ? ((Class)var0).getName() : var0.toString();
   }

   private static Type a(Type var0, Class<?> var1, Class<?> var2) {
      if (var2 == var1) {
         return var0;
      } else {
         if (var2.isInterface()) {
            Class[] var3 = var1.getInterfaces();
            int var4 = 0;

            for(int var5 = var3.length; var4 < var5; ++var4) {
               if (var3[var4] == var2) {
                  return var1.getGenericInterfaces()[var4];
               }

               if (var2.isAssignableFrom(var3[var4])) {
                  return a(var1.getGenericInterfaces()[var4], var3[var4], var2);
               }
            }
         }

         if (!var1.isInterface()) {
            while(var1 != Object.class) {
               Class var6 = var1.getSuperclass();
               if (var6 == var2) {
                  return var1.getGenericSuperclass();
               }

               if (var2.isAssignableFrom(var6)) {
                  return a(var1.getGenericSuperclass(), var6, var2);
               }

               var1 = var6;
            }
         }

         return var2;
      }
   }

   private static Type b(Type var0, Class<?> var1, Class<?> var2) {
      if (var0 instanceof WildcardType) {
         Type[] var3 = ((WildcardType)var0).getUpperBounds();

         assert var3.length == 1;

         var0 = var3[0];
      }

      aj.e(var2.isAssignableFrom(var1));
      return a(var0, var1, a(var0, var1, var2));
   }

   public static Type h(Type var0) {
      return (Type)(var0 instanceof GenericArrayType ? ((GenericArrayType)var0).getGenericComponentType() : ((Class)var0).getComponentType());
   }

   public static Type a(Type var0, Class<?> var1) {
      Type var2 = b(var0, var1, Collection.class);
      return (Type)(var2 instanceof ParameterizedType ? ((ParameterizedType)var2).getActualTypeArguments()[0] : Object.class);
   }

   public static Type[] b(Type var0, Class<?> var1) {
      if (var0 == Properties.class) {
         return new Type[]{String.class, String.class};
      } else {
         Type var2 = b(var0, var1, Map.class);
         if (var2 instanceof ParameterizedType) {
            ParameterizedType var3 = (ParameterizedType)var2;
            return var3.getActualTypeArguments();
         } else {
            return new Type[]{Object.class, Object.class};
         }
      }
   }

   public static Type a(Type var0, Class<?> var1, Type var2) {
      return a(var0, var1, var2, new HashMap());
   }

   private static Type a(Type var0, Class<?> var1, Type var2, Map<TypeVariable<?>, Type> var3) {
      TypeVariable var4 = null;

      while(true) {
         if (var2 instanceof TypeVariable) {
            TypeVariable var5 = (TypeVariable)var2;
            Type var6 = (Type)var3.get(var5);
            if (var6 != null) {
               return (Type)(var6 == Void.TYPE ? var2 : var6);
            }

            var3.put(var5, Void.TYPE);
            if (var4 == null) {
               var4 = var5;
            }

            var2 = a(var0, var1, var5);
            if (var2 != var5) {
               continue;
            }
         } else if (var2 instanceof Class && ((Class)var2).isArray()) {
            Class var16 = (Class)var2;
            Class var20 = var16.getComponentType();
            Type var23 = a(var0, var1, var20, var3);
            var2 = a((Object)var20, (Object)var23) ? var16 : b(var23);
         } else if (var2 instanceof GenericArrayType) {
            GenericArrayType var13 = (GenericArrayType)var2;
            Type var17 = var13.getGenericComponentType();
            Type var7 = a(var0, var1, var17, var3);
            var2 = a((Object)var17, (Object)var7) ? var13 : b(var7);
         } else if (var2 instanceof ParameterizedType) {
            ParameterizedType var14 = (ParameterizedType)var2;
            Type var18 = var14.getOwnerType();
            Type var21 = a(var0, var1, var18, var3);
            boolean var8 = !a((Object)var21, (Object)var18);
            Type[] var9 = var14.getActualTypeArguments();
            int var10 = 0;

            for(int var11 = var9.length; var10 < var11; ++var10) {
               Type var12 = a(var0, var1, var9[var10], var3);
               if (!a((Object)var12, (Object)var9[var10])) {
                  if (!var8) {
                     var9 = (Type[])((Type;)var9).clone();
                     var8 = true;
                  }

                  var9[var10] = var12;
               }
            }

            var2 = var8 ? a(var21, var14.getRawType(), var9) : var14;
         } else if (var2 instanceof WildcardType) {
            label82: {
               WildcardType var15 = (WildcardType)var2;
               Type[] var19 = var15.getLowerBounds();
               Type[] var22 = var15.getUpperBounds();
               if (var19.length == 1) {
                  Type var24 = a(var0, var1, var19[0], var3);
                  if (var24 != var19[0]) {
                     var2 = d(var24);
                     break label82;
                  }
               } else if (var22.length == 1) {
                  Type var25 = a(var0, var1, var22[0], var3);
                  if (var25 != var22[0]) {
                     var2 = c(var25);
                     break label82;
                  }
               }

               var2 = var15;
            }
         }

         if (var4 != null) {
            var3.put(var4, var2);
         }

         return (Type)var2;
      }
   }

   private static Type a(Type var0, Class<?> var1, TypeVariable<?> var2) {
      Class var3 = a(var2);
      if (var3 == null) {
         return var2;
      } else {
         Type var4 = a(var0, var1, var3);
         if (var4 instanceof ParameterizedType) {
            int var5 = a((Object[])var3.getTypeParameters(), (Object)var2);
            return ((ParameterizedType)var4).getActualTypeArguments()[var5];
         } else {
            return var2;
         }
      }
   }

   private static int a(Object[] var0, Object var1) {
      int var2 = 0;

      for(int var3 = var0.length; var2 < var3; ++var2) {
         if (var1.equals(var0[var2])) {
            return var2;
         }
      }

      throw new NoSuchElementException();
   }

   private static Class<?> a(TypeVariable<?> var0) {
      GenericDeclaration var1 = var0.getGenericDeclaration();
      return var1 instanceof Class ? (Class)var1 : null;
   }

   static void i(Type var0) {
      aj.e(!(var0 instanceof Class) || !((Class)var0).isPrimitive());
   }

   static final class a implements Serializable, GenericArrayType {
      private final Type componentType;
      private static final long serialVersionUID = 0L;

      public a(Type var1) {
         Objects.requireNonNull(var1);
         this.componentType = ak.e(var1);
      }

      public Type getGenericComponentType() {
         return this.componentType;
      }

      public boolean equals(Object var1) {
         return var1 instanceof GenericArrayType && ak.a((Type)this, (Type)((GenericArrayType)var1));
      }

      public int hashCode() {
         return this.componentType.hashCode();
      }

      public String toString() {
         return ak.g(this.componentType) + "[]";
      }
   }

   static final class b implements Serializable, ParameterizedType {
      private final Type ownerType;
      private final Type rawType;
      private final Type[] typeArguments;
      private static final long serialVersionUID = 0L;

      public b(Type var1, Type var2, Type... var3) {
         Objects.requireNonNull(var2);
         if (var2 instanceof Class) {
            Class var4 = (Class)var2;
            boolean var5 = Modifier.isStatic(var4.getModifiers()) || var4.getEnclosingClass() == null;
            aj.e(var1 != null || var5);
         }

         this.ownerType = var1 == null ? null : ak.e(var1);
         this.rawType = ak.e(var2);
         this.typeArguments = (Type[])((Type;)var3).clone();
         int var6 = 0;

         for(int var7 = this.typeArguments.length; var6 < var7; ++var6) {
            Objects.requireNonNull(this.typeArguments[var6]);
            ak.i(this.typeArguments[var6]);
            this.typeArguments[var6] = ak.e(this.typeArguments[var6]);
         }

      }

      public Type[] getActualTypeArguments() {
         return (Type[])this.typeArguments.clone();
      }

      public Type getRawType() {
         return this.rawType;
      }

      public Type getOwnerType() {
         return this.ownerType;
      }

      public boolean equals(Object var1) {
         return var1 instanceof ParameterizedType && ak.a((Type)this, (Type)((ParameterizedType)var1));
      }

      private static int b(Object var0) {
         return var0 != null ? var0.hashCode() : 0;
      }

      public int hashCode() {
         return Arrays.hashCode(this.typeArguments) ^ this.rawType.hashCode() ^ b(this.ownerType);
      }

      public String toString() {
         int var1 = this.typeArguments.length;
         if (var1 == 0) {
            return ak.g(this.rawType);
         } else {
            StringBuilder var2 = new StringBuilder(30 * (var1 + 1));
            var2.append(ak.g(this.rawType)).append("<").append(ak.g(this.typeArguments[0]));

            for(int var3 = 1; var3 < var1; ++var3) {
               var2.append(", ").append(ak.g(this.typeArguments[var3]));
            }

            return var2.append(">").toString();
         }
      }
   }

   static final class c implements Serializable, WildcardType {
      private final Type upperBound;
      private final Type lowerBound;
      private static final long serialVersionUID = 0L;

      public c(Type[] var1, Type[] var2) {
         aj.e(var2.length <= 1);
         aj.e(var1.length == 1);
         if (var2.length == 1) {
            Objects.requireNonNull(var2[0]);
            ak.i(var2[0]);
            aj.e(var1[0] == Object.class);
            this.lowerBound = ak.e(var2[0]);
            this.upperBound = Object.class;
         } else {
            Objects.requireNonNull(var1[0]);
            ak.i(var1[0]);
            this.lowerBound = null;
            this.upperBound = ak.e(var1[0]);
         }

      }

      public Type[] getUpperBounds() {
         return new Type[]{this.upperBound};
      }

      public Type[] getLowerBounds() {
         return this.lowerBound != null ? new Type[]{this.lowerBound} : ak.EMPTY_TYPE_ARRAY;
      }

      public boolean equals(Object var1) {
         return var1 instanceof WildcardType && ak.a((Type)this, (Type)((WildcardType)var1));
      }

      public int hashCode() {
         return (this.lowerBound != null ? 31 + this.lowerBound.hashCode() : 1) ^ 31 + this.upperBound.hashCode();
      }

      public String toString() {
         if (this.lowerBound != null) {
            return "? super " + ak.g(this.lowerBound);
         } else {
            return this.upperBound == Object.class ? "?" : "? extends " + ak.g(this.upperBound);
         }
      }
   }
}
