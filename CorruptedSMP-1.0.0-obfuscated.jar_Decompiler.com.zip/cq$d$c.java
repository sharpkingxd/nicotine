public final class cq$d$c extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final int $payload1$inlined;
   // $FF: synthetic field
   final int $payload2$inlined;

   public cq$d$c(String var1, boolean var2, cq var3, int var4, int var5) {
      super(var1, var2);
      this.this$0 = var3;
      this.$payload1$inlined = var4;
      this.$payload2$inlined = var5;
   }

   public long gg() {
      boolean var1 = false;
      this.this$0.a(true, this.$payload1$inlined, this.$payload2$inlined);
      return -1L;
   }
}
