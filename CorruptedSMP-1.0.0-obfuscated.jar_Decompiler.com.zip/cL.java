import java.util.logging.Handler;

public final class cL extends Handler {
   public static final cL pe = new cL();

   private cL() {
   }
}
