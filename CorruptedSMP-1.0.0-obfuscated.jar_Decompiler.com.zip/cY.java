import java.security.cert.Certificate;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;

public final class cY implements HostnameVerifier {
   public static final cY pM = new cY();

   private cY() {
   }

   public boolean verify(String var1, SSLSession var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      boolean var10000;
      if (!this.aO(var1)) {
         var10000 = false;
      } else {
         boolean var3;
         try {
            Certificate var10002 = var2.getPeerCertificates()[0];
            fR.m(var10002);
            var3 = this.a(var1, (X509Certificate)var10002);
         } catch (SSLException var5) {
            var3 = false;
         }

         var10000 = var3;
      }

      return var10000;
   }

   public final boolean a(String var1, X509Certificate var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      return bD.aq(var1) ? this.b(var1, var2) : this.c(var1, var2);
   }

   private final boolean b(String var1, X509Certificate var2) {
      String var3 = bC.an(var1);
      Iterable var4 = (Iterable)this.a(var2, 7);
      boolean var5 = false;
      boolean var10000;
      if (var4 instanceof Collection && ((Collection)var4).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var6 = var4.iterator();

         while(true) {
            if (!var6.hasNext()) {
               var10000 = false;
               break;
            }

            Object var7 = var6.next();
            String var8 = (String)var7;
            boolean var9 = false;
            if (fR.c(var3, (Object)bC.an(var8))) {
               var10000 = true;
               break;
            }
         }
      }

      return var10000;
   }

   private final boolean c(String var1, X509Certificate var2) {
      String var3 = this.aN(var1);
      Iterable var4 = (Iterable)this.a(var2, 2);
      boolean var5 = false;
      boolean var10000;
      if (var4 instanceof Collection && ((Collection)var4).isEmpty()) {
         var10000 = false;
      } else {
         Iterator var6 = var4.iterator();

         while(true) {
            if (!var6.hasNext()) {
               var10000 = false;
               break;
            }

            Object var7 = var6.next();
            String var8 = (String)var7;
            boolean var9 = false;
            if (pM.n(var3, var8)) {
               var10000 = true;
               break;
            }
         }
      }

      return var10000;
   }

   private final String aN(String var1) {
      String var3;
      if (this.aO(var1)) {
         Locale var10000 = Locale.US;
         fR.b(var10000, "");
         var3 = var1.toLowerCase(var10000);
         fR.b(var3, "");
      } else {
         var3 = var1;
      }

      return var3;
   }

   private final boolean aO(String var1) {
      return var1.length() == (int)dC.d(var1, 0, 0, 3, (Object)null);
   }

   private final boolean n(String var1, String var2) {
      String var3 = var1;
      String var4 = var2;
      CharSequence var5 = (CharSequence)var1;
      if (var5 != null && var5.length() != 0 && !gA.a(var1, ".", false, 2, (Object)null) && !gA.b(var1, "..", false, 2, (Object)null)) {
         var5 = (CharSequence)var2;
         if (var5 != null && var5.length() != 0 && !gA.a(var2, ".", false, 2, (Object)null) && !gA.b(var2, "..", false, 2, (Object)null)) {
            if (!gA.b(var1, ".", false, 2, (Object)null)) {
               var3 = var1 + '.';
            }

            if (!gA.b(var2, ".", false, 2, (Object)null)) {
               var4 = var2 + '.';
            }

            var4 = this.aN(var4);
            if (!gA.c((CharSequence)var4, (CharSequence)"*", false, 2, (Object)null)) {
               return fR.c(var3, (Object)var4);
            } else if (gA.a(var4, "*.", false, 2, (Object)null) && gA.a((CharSequence)var4, '*', 1, false, 4, (Object)null) == -1) {
               if (var3.length() < var4.length()) {
                  return false;
               } else if (fR.c("*.", (Object)var4)) {
                  return false;
               } else {
                  String var10000 = var4.substring(1);
                  fR.b(var10000, "");
                  String var9 = var10000;
                  if (!gA.b(var3, var9, false, 2, (Object)null)) {
                     return false;
                  } else {
                     int var6 = var3.length() - var9.length();
                     return var6 <= 0 || gA.b((CharSequence)var3, '.', var6 - 1, false, 4, (Object)null) == -1;
                  }
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public final List<String> d(X509Certificate var1) {
      fR.c(var1, (String)"");
      List var2 = this.a(var1, 7);
      List var3 = this.a(var1, 2);
      return eO.b((Collection)var2, (Iterable)var3);
   }

   private final List<String> a(X509Certificate var1, int var2) {
      try {
         Collection var10000 = var1.getSubjectAlternativeNames();
         if (var10000 == null) {
            return eO.nk();
         } else {
            Collection var3 = var10000;
            List var4 = (List)(new ArrayList());

            for(List var6 : var3) {
               if (var6 != null && var6.size() >= 2 && fR.c(var6.get(0), (Object)var2)) {
                  Object var9 = var6.get(1);
                  if (var9 != null) {
                     Object var7 = var9;
                     var4.add((String)var7);
                  }
               }
            }

            return var4;
         }
      } catch (CertificateParsingException var8) {
         return eO.nk();
      }
   }
}
