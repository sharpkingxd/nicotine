import java.io.IOException;

public interface bb extends Cloneable {
   by ck() throws IOException;
}
