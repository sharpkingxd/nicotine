import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class cH {
   public static final a oU = new a((fP)null);
   private static volatile cH oV;
   private static final Logger oW;

   public final String jX() {
      return "OkHttp";
   }

   public SSLContext jG() {
      SSLContext var10000 = SSLContext.getInstance("TLS");
      fR.b(var10000, "");
      return var10000;
   }

   public X509TrustManager jH() {
      TrustManagerFactory var1 = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      var1.init((KeyStore)null);
      TrustManager var10000 = var1.getTrustManagers();
      fR.m(var10000);
      TrustManager[] var2 = var10000;
      if (var2.length != 1 || !(var2[0] instanceof X509TrustManager)) {
         boolean var3 = false;
         StringBuilder var6 = (new StringBuilder()).append("Unexpected default trust managers: ");
         String var10001 = Arrays.toString(var2);
         fR.b(var10001, "");
         String var4 = var6.append(var10001).toString();
         throw new IllegalStateException(var4.toString());
      } else {
         var10000 = var2[0];
         fR.m(var2[0]);
         return (X509TrustManager)var10000;
      }
   }

   public void a(SSLSocket var1, String var2, List<bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");
   }

   public void e(SSLSocket var1) {
      fR.c(var1, (String)"");
   }

   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      return null;
   }

   public void a(Socket var1, InetSocketAddress var2, int var3) throws IOException {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      var1.connect((SocketAddress)var2, var3);
   }

   public void a(String var1, int var2, Throwable var3) {
      fR.c(var1, (String)"");
      Level var4 = var2 == 5 ? Level.WARNING : Level.INFO;
      oW.log(var4, var1, var3);
   }

   // $FF: synthetic method
   public static void a(cH var0, String var1, int var2, Throwable var3, int var4, Object var5) {
      if (var5 != null) {
         throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: log");
      } else {
         if ((var4 & 2) != 0) {
            var2 = 4;
         }

         if ((var4 & 4) != 0) {
            var3 = null;
         }

         var0.a(var1, var2, var3);
      }
   }

   public boolean aG(String var1) {
      fR.c(var1, (String)"");
      return true;
   }

   public Object aH(String var1) {
      fR.c(var1, (String)"");
      return oW.isLoggable(Level.FINE) ? new Throwable(var1) : null;
   }

   public void b(String var1, Object var2) {
      fR.c(var1, (String)"");
      String var3 = var1;
      if (var2 == null) {
         var3 = var1 + " To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);";
      }

      this.a(var3, 5, (Throwable)var2);
   }

   public cX a(X509TrustManager var1) {
      fR.c(var1, (String)"");
      return new cV(this.b(var1));
   }

   public cZ b(X509TrustManager var1) {
      fR.c(var1, (String)"");
      X509Certificate[] var10002 = var1.getAcceptedIssuers();
      fR.b(var10002, "");
      X509Certificate[] var2 = var10002;
      return new cW((X509Certificate[])Arrays.copyOf(var2, var2.length));
   }

   public SSLSocketFactory c(X509TrustManager var1) {
      fR.c(var1, (String)"");

      try {
         SSLContext var3 = this.jG();
         boolean var5 = false;
         TrustManager[] var6 = new TrustManager[]{var1};
         var3.init((KeyManager[])null, var6, (SecureRandom)null);
         SSLSocketFactory var10000 = var3.getSocketFactory();
         fR.b(var10000, "");
         return var10000;
      } catch (GeneralSecurityException var7) {
         throw new AssertionError("No System TLS: " + var7, (Throwable)var7);
      }
   }

   public String toString() {
      String var10000 = this.getClass().getSimpleName();
      fR.b(var10000, "");
      return var10000;
   }

   static {
      oV = oU.ke();
      oW = Logger.getLogger(bu.class.getName());
   }

   public static final class a {
      private a() {
      }

      public final cH jZ() {
         return cH.oV;
      }

      public final List<String> h(List<? extends bv> var1) {
         fR.c(var1, (String)"");
         Iterable var2 = (Iterable)var1;
         boolean var3 = false;
         Collection var5 = (Collection)(new ArrayList());
         boolean var6 = false;

         for(Object var8 : var2) {
            bv var9 = (bv)var8;
            boolean var10 = false;
            if (var9 != bv.iG) {
               var5.add(var8);
            }
         }

         var2 = (Iterable)((List)var5);
         var3 = false;
         var5 = (Collection)(new ArrayList(eO.a(var2, 10)));
         var6 = false;

         for(Object var17 : var2) {
            bv var18 = (bv)var17;
            boolean var19 = false;
            var5.add(var18.toString());
         }

         return (List)var5;
      }

      public final boolean ka() {
         return fR.c("Dalvik", (Object)System.getProperty("java.vm.name"));
      }

      private final boolean kb() {
         String var1 = Security.getProviders()[0].getName();
         return fR.c("Conscrypt", (Object)var1);
      }

      private final boolean kc() {
         String var1 = Security.getProviders()[0].getName();
         return fR.c("OpenJSSE", (Object)var1);
      }

      private final boolean kd() {
         String var1 = Security.getProviders()[0].getName();
         return fR.c("BC", (Object)var1);
      }

      private final cH ke() {
         return this.ka() ? this.kf() : this.kg();
      }

      private final cH kf() {
         cK.pb.kj();
         cH var10000 = cA.ow.jC();
         if (var10000 == null) {
            var10000 = cB.oz.jF();
            fR.m(var10000);
         }

         return var10000;
      }

      private final cH kg() {
         if (this.kb()) {
            cD var1 = cD.oG.jN();
            if (var1 != null) {
               return var1;
            }
         }

         if (this.kd()) {
            cC var3 = cC.oD.jK();
            if (var3 != null) {
               return var3;
            }
         }

         if (this.kc()) {
            cG var4 = cG.oR.jW();
            if (var4 != null) {
               return var4;
            }
         }

         cF var5 = cF.oP.jT();
         if (var5 != null) {
            return var5;
         } else {
            cH var2 = cE.oJ.jQ();
            return var2 != null ? var2 : new cH();
         }
      }

      public final byte[] i(List<? extends bv> var1) {
         fR.c(var1, (String)"");
         de var2 = new de();

         for(String var4 : this.h(var1)) {
            var2.V(var4.length());
            var2.aQ(var4);
         }

         return var2.kW();
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
