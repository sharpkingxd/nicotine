import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;

public final class bA {
   private final aX iV;
   private final Proxy iW;
   private final InetSocketAddress iX;

   public bA(aX var1, Proxy var2, InetSocketAddress var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      super();
      this.iV = var1;
      this.iW = var2;
      this.iX = var3;
   }

   public final aX fo() {
      return this.iV;
   }

   public final Proxy fp() {
      return this.iW;
   }

   public final InetSocketAddress fq() {
      return this.iX;
   }

   public final boolean fr() {
      return this.iV.bE() != null && this.iW.type() == Type.HTTP;
   }

   public boolean equals(Object var1) {
      return var1 instanceof bA && fR.c(((bA)var1).iV, (Object)this.iV) && fR.c(((bA)var1).iW, (Object)this.iW) && fR.c(((bA)var1).iX, (Object)this.iX);
   }

   public int hashCode() {
      int var1 = 17;
      var1 = 31 * var1 + this.iV.hashCode();
      var1 = 31 * var1 + this.iW.hashCode();
      var1 = 31 * var1 + this.iX.hashCode();
      return var1;
   }

   public String toString() {
      return "Route{" + this.iX + '}';
   }
}
