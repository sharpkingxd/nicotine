import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import java.util.logging.Level;

public final class bM {
   private final bN kd;
   private final String ke;
   private boolean kf;
   private bK kg;
   private final List<bK> kh;
   private boolean ki;

   public bM(bN var1, String var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.kd = var1;
      this.ke = var2;
      this.kh = (List)(new ArrayList());
   }

   public final bN gl() {
      return this.kd;
   }

   public final String gm() {
      return this.ke;
   }

   public final boolean gn() {
      return this.kf;
   }

   public final bK go() {
      return this.kg;
   }

   public final void a(bK var1) {
      this.kg = var1;
   }

   public final List<bK> gp() {
      return this.kh;
   }

   public final boolean gq() {
      return this.ki;
   }

   public final void q(boolean var1) {
      this.ki = var1;
   }

   public final void a(bK var1, long var2) {
      fR.c(var1, (String)"");
      bN var4 = this.kd;
      synchronized(var4){}

      try {
         boolean var5 = false;
         if (!this.kf) {
            if (this.a(var1, var2, false)) {
               this.kd.b(this);
            }

            eE var13 = eE.sk;
            return;
         }

         if (!var1.gi()) {
            boolean var14 = false;
            if (bN.kj.gA().isLoggable(Level.FINE)) {
               boolean var15 = false;
               String var16 = "schedule failed (queue is shutdown)";
               bL.b(var1, this, var16);
            }

            throw new RejectedExecutionException();
         }

         boolean var6 = false;
         if (bN.kj.gA().isLoggable(Level.FINE)) {
            boolean var9 = false;
            String var10 = "schedule canceled (queue is shutdown)";
            bL.b(var1, this, var10);
         }
      } finally {
         ;
      }

   }

   // $FF: synthetic method
   public static void a(bM var0, bK var1, long var2, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0L;
      }

      var0.a(var1, var2);
   }

   public final boolean a(bK var1, long var2, boolean var4) {
      fR.c(var1, (String)"");
      var1.a(this);
      long var5 = this.kd.gu().gz();
      long var7 = var5 + var2;
      int var9 = this.kh.indexOf(var1);
      if (var9 != -1) {
         if (var1.gk() <= var7) {
            boolean var22 = false;
            if (bN.kj.gA().isLoggable(Level.FINE)) {
               boolean var24 = false;
               String var25 = "already scheduled";
               bL.b(var1, this, var25);
            }

            return false;
         }

         this.kh.remove(var9);
      }

      var1.g(var7);
      int var10 = 0;
      if (bN.kj.gA().isLoggable(Level.FINE)) {
         boolean var11 = false;
         String var20 = var4 ? "run again after " + bL.h(var7 - var5) : "scheduled after " + bL.h(var7 - var5);
         bL.b(var1, this, var20);
      }

      List var23 = this.kh;
      boolean var12 = false;
      int var13 = 0;
      Iterator var14 = var23.iterator();

      int var10000;
      while(true) {
         if (!var14.hasNext()) {
            var10000 = -1;
            break;
         }

         Object var15 = var14.next();
         bK var16 = (bK)var15;
         boolean var17 = false;
         if (var16.gk() - var5 > var2) {
            var10000 = var13;
            break;
         }

         ++var13;
      }

      var10 = var10000;
      if (var10 == -1) {
         var10 = this.kh.size();
      }

      this.kh.add(var10, var1);
      return var10 == 0;
   }

   public final void gr() {
      boolean var2 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         bN var5 = this.kd;
         synchronized(var5) {
            boolean var3 = false;
            if (this.gt()) {
               this.kd.b(this);
            }

            eE var6 = eE.sk;
         }
      }
   }

   public final void gs() {
      boolean var2 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         bN var5 = this.kd;
         synchronized(var5) {
            boolean var3 = false;
            this.kf = true;
            if (this.gt()) {
               this.kd.b(this);
            }

            eE var6 = eE.sk;
         }
      }
   }

   public final boolean gt() {
      if (this.kg != null) {
         bK var10000 = this.kg;
         fR.m(var10000);
         if (var10000.gi()) {
            this.ki = true;
         }
      }

      boolean var1 = false;

      for(int var2 = this.kh.size() - 1; -1 < var2; --var2) {
         if (((bK)this.kh.get(var2)).gi()) {
            bK var3 = (bK)this.kh.get(var2);
            boolean var4 = false;
            if (bN.kj.gA().isLoggable(Level.FINE)) {
               boolean var5 = false;
               String var8 = "canceled";
               bL.b(var3, this, var8);
            }

            var1 = true;
            this.kh.remove(var2);
         }
      }

      return var1;
   }

   public String toString() {
      return this.ke;
   }
}
