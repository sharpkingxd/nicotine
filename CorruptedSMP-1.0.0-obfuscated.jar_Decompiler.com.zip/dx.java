import java.security.MessageDigest;

public final class dx extends dh {
   private final transient byte[][] qC;
   private final transient int[] qD;

   public dx(byte[][] var1, int[] var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super(dh.pV.lc());
      this.qC = var1;
      this.qD = var2;
   }

   public final byte[][] lM() {
      return this.qC;
   }

   public final int[] lN() {
      return this.qD;
   }

   public String lg() {
      return this.lO().lg();
   }

   public String lk() {
      return this.lO().lk();
   }

   public dh ll() {
      return this.lO().ll();
   }

   public dh aT(String var1) {
      fR.c(var1, (String)"");
      MessageDigest var3 = MessageDigest.getInstance(var1);
      boolean var4 = false;
      dx var5 = this;
      boolean var6 = false;
      int var7 = ((Object[])this.lM()).length;
      int var8 = 0;

      for(int var9 = 0; var8 < var7; ++var8) {
         int var10 = var5.lN()[var7 + var8];
         int var11 = var5.lN()[var8];
         byte[] var10000 = var5.lM()[var8];
         int var12 = var11 - var9;
         byte[] var14 = var10000;
         boolean var15 = false;
         var3.update(var14, var10, var12);
         var9 = var11;
      }

      byte[] var2 = var3.digest();
      fR.m(var2);
      return new dh(var2);
   }

   public byte ae(int var1) {
      boolean var3 = false;
      db.b((long)this.lN()[((Object[])this.lM()).length - 1], (long)var1, 1L);
      int var4 = dG.a(this, var1);
      int var5 = var4 == 0 ? 0 : this.lN()[var4 - 1];
      int var6 = this.lN()[var4 + ((Object[])this.lM()).length];
      return this.lM()[var4][var1 - var5 + var6];
   }

   public int ln() {
      boolean var2 = false;
      return this.lN()[((Object[])this.lM()).length - 1];
   }

   public byte[] lo() {
      boolean var2 = false;
      byte[] var3 = new byte[this.lm()];
      int var4 = 0;
      dx var5 = this;
      boolean var6 = false;
      int var7 = ((Object[])this.lM()).length;
      int var8 = 0;

      for(int var9 = 0; var8 < var7; ++var8) {
         int var10 = var5.lN()[var7 + var8];
         int var11 = var5.lN()[var8];
         byte[] var10000 = var5.lM()[var8];
         int var12 = var11 - var9;
         byte[] var14 = var10000;
         boolean var15 = false;
         eI.a(var14, var3, var4, var10, var10 + var12);
         var4 += var12;
         var9 = var11;
      }

      return var3;
   }

   public void a(de var1, int var2, int var3) {
      fR.c(var1, (String)"");
      boolean var5 = false;
      dx var6 = this;
      int var7 = var2 + var3;
      boolean var8 = false;
      int var9 = dG.a(this, var2);

      for(int var10 = var2; var10 < var7; ++var9) {
         int var11 = var9 == 0 ? 0 : var6.lN()[var9 - 1];
         int var12 = var6.lN()[var9] - var11;
         int var13 = var6.lN()[((Object[])var6.lM()).length + var9];
         int var14 = Math.min(var7, var11 + var12) - var10;
         int var15 = var13 + (var10 - var11);
         byte[] var18 = var6.lM()[var9];
         boolean var19 = false;
         dv var20 = new dv(var18, var15, var15 + var14, true, false);
         if (var1.pR == null) {
            var20.qw = var20;
            var20.qv = var20.qw;
            var1.pR = var20.qv;
         } else {
            dv var10000 = var1.pR;
            fR.m(var10000);
            var10000 = var10000.qw;
            fR.m(var10000);
            var10000.b(var20);
         }

         var10 += var14;
      }

      var1.t(var1.kH() + (long)var3);
   }

   public boolean a(int var1, dh var2, int var3, int var4) {
      fR.c(var2, (String)"");
      boolean var6 = false;
      boolean var10000;
      if (var1 >= 0 && var1 <= this.lm() - var4) {
         int var7 = 0;
         var7 = var3;
         dx var8 = this;
         int var9 = var1 + var4;
         boolean var10 = false;
         int var11 = dG.a(this, var1);

         for(int var12 = var1; var12 < var9; ++var11) {
            int var13 = var11 == 0 ? 0 : var8.lN()[var11 - 1];
            int var14 = var8.lN()[var11] - var13;
            int var15 = var8.lN()[((Object[])var8.lM()).length + var11];
            int var16 = Math.min(var9, var13 + var14) - var12;
            int var17 = var15 + (var12 - var13);
            byte[] var20 = var8.lM()[var11];
            boolean var21 = false;
            if (!var2.a(var7, var20, var17, var16)) {
               var10000 = false;
               return var10000;
            }

            var7 += var16;
            var12 += var16;
         }

         var10000 = true;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean a(int var1, byte[] var2, int var3, int var4) {
      fR.c(var2, (String)"");
      boolean var6 = false;
      boolean var10000;
      if (var1 >= 0 && var1 <= this.lm() - var4 && var3 >= 0 && var3 <= var2.length - var4) {
         int var7 = 0;
         var7 = var3;
         dx var8 = this;
         int var9 = var1 + var4;
         boolean var10 = false;
         int var11 = dG.a(this, var1);

         for(int var12 = var1; var12 < var9; ++var11) {
            int var13 = var11 == 0 ? 0 : var8.lN()[var11 - 1];
            int var14 = var8.lN()[var11] - var13;
            int var15 = var8.lN()[((Object[])var8.lM()).length + var11];
            int var16 = Math.min(var9, var13 + var14) - var12;
            int var17 = var15 + (var12 - var13);
            byte[] var20 = var8.lM()[var11];
            boolean var21 = false;
            if (!db.a(var20, var17, var2, var7, var16)) {
               var10000 = false;
               return var10000;
            }

            var7 += var16;
            var12 += var16;
         }

         var10000 = true;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private final dh lO() {
      return new dh(this.lo());
   }

   public byte[] lp() {
      return this.lo();
   }

   public boolean equals(Object var1) {
      boolean var3 = false;
      return var1 == this ? true : (var1 instanceof dh ? ((dh)var1).lm() == this.lm() && this.a(0, (dh)((dh)var1), 0, this.lm()) : false);
   }

   public int hashCode() {
      boolean var2 = false;
      int var3 = 0;
      var3 = this.ld();
      int var10000;
      if (var3 != 0) {
         var10000 = var3;
      } else {
         var3 = 1;
         dx var4 = this;
         boolean var5 = false;
         int var6 = ((Object[])this.lM()).length;
         int var7 = 0;

         for(int var8 = 0; var7 < var6; ++var7) {
            int var9 = var4.lN()[var6 + var7];
            int var10 = var4.lN()[var7];
            byte[] var19 = var4.lM()[var7];
            int var11 = var10 - var8;
            byte[] var13 = var19;
            boolean var14 = false;
            int var15 = var9;

            for(int var16 = var9 + var11; var15 < var16; ++var15) {
               var3 = 31 * var3 + var13[var15];
            }

            var8 = var10;
         }

         this.ad(var3);
         var10000 = var3;
      }

      return var10000;
   }

   public String toString() {
      return this.lO().toString();
   }

   private final Object writeReplace() {
      dh var10000 = this.lO();
      fR.m(var10000);
      return var10000;
   }
}
