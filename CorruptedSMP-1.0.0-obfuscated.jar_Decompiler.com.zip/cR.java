import java.util.List;
import javax.net.ssl.SSLSocket;

public interface cR {
   boolean jB();

   boolean f(SSLSocket var1);

   void a(SSLSocket var1, String var2, List<? extends bv> var3);

   String d(SSLSocket var1);
}
