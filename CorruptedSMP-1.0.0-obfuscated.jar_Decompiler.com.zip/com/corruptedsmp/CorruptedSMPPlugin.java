package com.corruptedsmp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class CorruptedSMPPlugin extends JavaPlugin {
   private static CorruptedSMPPlugin a;
   private .dH b;
   private .dJ c;
   private .k d;
   private .en e;
   private .E f;
   private .C g;
   private .A h;
   private .eo i;
   private .F j;

   public void onEnable() {
      a = this;
      this.a();
      this.saveDefaultConfig();
      this.getLogger().info("Initializing license and trial system...");
      this.c = new .dJ(this);
      this.b = new .dH(this);
      if (!this.b.lR()) {
         this.getLogger().severe("╔════════════════════════════════════════════════════════╗");
         this.getLogger().severe("║                                                        ║");
         this.getLogger().severe("║          ✗ LICENSE VERIFICATION FAILED!                ║");
         this.getLogger().severe("║                                                        ║");
         this.getLogger().severe("║  The plugin will not load without a valid license     ║");
         this.getLogger().severe("║  or active trial.                                      ║");
         this.getLogger().severe("║                                                        ║");
         this.getLogger().severe("╚════════════════════════════════════════════════════════╝");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         if (!this.b.lX()) {
            this.b.lS();
         }

         this.f = new .E(this);
         this.d = new .k(this);
         this.e = new .en(this);
         this.g = new .C(this);
         this.h = new .A(this);
         this.i = new .eo(this);
         this.j = new .F(this);
         .B.a(this);
         this.g.x();
         this.b();
         this.c();
         this.d.l();

         for(Player var2 : Bukkit.getOnlinePlayers()) {
            if (this.d.b(var2)) {
               this.i.j(var2);
            }
         }

         this.getLogger().info("CorruptedSMP Plugin has been enabled!");
         this.getLogger().info("Loaded " + .l.values().length + " corruption types.");
         this.getLogger().info("Registered 9 corruption crafting recipes!");
      }
   }

   private void a() {
      String[] var1 = new String[]{"", "§5╔═══════════════════════════════════════════════════════════════╗", "§5║                                                               ║", "§5║   §d ██████╗ ██████╗ ██████╗ ██████╗ ██╗   ██╗██████╗ ████████╗§5 ║", "§5║   §d██╔════╝██╔═══██╗██╔══██╗██╔══██╗██║   ██║██╔══██╗╚══██╔══╝§5 ║", "§5║   §d██║     ██║   ██║██████╔╝██████╔╝██║   ██║██████╔╝   ██║   §5 ║", "§5║   §d██║     ██║   ██║██╔══██╗██╔══██╗██║   ██║██╔═══╝    ██║   §5 ║", "§5║   §d╚██████╗╚██████╔╝██║  ██║██║  ██║╚██████╔╝██║        ██║   §5 ║", "§5║   §d ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝        ╚═╝   §5 ║", "§5║                                                               ║", "§5║              §6███████╗███╗   ███╗██████╗                       §5 ║", "§5║              §6██╔════╝████╗ ████║██╔══██╗                      §5 ║", "§5║              §6███████╗██╔████╔██║██████╔╝                      §5 ║", "§5║              §6╚════██║██║╚██╔╝██║██╔═══╝                       §5 ║", "§5║              §6███████║██║ ╚═╝ ██║██║                           §5 ║", "§5║              §6╚══════╝╚═╝     ╚═╝╚═╝                           §5 ║", "§5║                                                               ║", "§5║                    §b▄▄▄       ██▓    ▄▄▄      ▓█████▄ ▓█████▄  ██▓ ███▄    █ §5 ║", "§5║                   §b▒████▄    ▓██▒   ▒████▄    ▒██▀ ██▌▒██▀ ██▌▓██▒ ██ ▀█   █ §5 ║", "§5║                   §b▒██  ▀█▄  ▒██░   ▒██  ▀█▄  ░██   █▌░██   █▌▒██▒▓██  ▀█ ██▒§5 ║", "§5║                   §b░██▄▄▄▄██ ▒██░   ░██▄▄▄▄██ ░▓█▄   ▌░▓█▄   ▌░██░▓██▒  ▐▌██▒§5 ║", "§5║                   §b ▓█   ▓██▒░██████▒▓█   ▓██▒░▒████▓ ░▒████▓ ░██░▒██░   ▓██░§5 ║", "§5║                   §b ▒▒   ▓▒█░░ ▒░▓  ░▒▒   ▓▒█░ ▒▒▓  ▒  ▒▒▓  ▒ ░▓  ░ ▒░   ▒ ▒ §5 ║", "§5║                   §b  ▒   ▒▒ ░░ ░ ▒  ░ ▒   ▒▒ ░ ░ ▒  ▒  ░ ▒  ▒  ▒ ░░ ░░   ░ ▒░§5 ║", "§5║                   §b  ░   ▒     ░ ░    ░   ▒    ░ ░  ░  ░ ░  ░  ▒ ░   ░   ░ ░ §5 ║", "§5║                   §b      ░  ░    ░  ░     ░  ░   ░       ░     ░           ░ §5 ║", "§5║                   §b                           ░       ░                      §5 ║", "§5║                                                               ║", "§5║                    §a✦ Made by Aladdin ✦                      §5 ║", "§5║                    §7Version: 1.0.0                           §5 ║", "§5║                    §79 Corruptions | Rituals | Abilities      §5 ║", "§5║                                                               ║", "§5╚═══════════════════════════════════════════════════════════════╝", ""};

      for(String var5 : var1) {
         String var6 = var5.replaceAll("§[0-9a-fk-or]", "");
         Bukkit.getConsoleSender().sendMessage(var6);
      }

   }

   public void onDisable() {
      if (this.b != null) {
         this.b.lU();
      }

      if (this.f != null) {
         this.f.S();
      }

      if (this.e != null) {
         this.e.nb();
      }

      if (this.i != null) {
         this.i.nd();
      }

      if (this.g != null) {
         this.g.y();
      }

      Bukkit.getScheduler().cancelTasks(this);
      this.getLogger().info("CorruptedSMP Plugin has been disabled!");
   }

   private void b() {
      this.getCommand("corrupt").setExecutor(new .b(this));
      this.getCommand("ability").setExecutor(new .a(this));
      this.getCommand("withdraw").setExecutor(new .e(this));
      this.getCommand("recipes").setExecutor(new .d(this));
      this.getCommand("recipeeditor").setExecutor(new .c(this));
      this.getCommand("corrupt").setTabCompleter(new .b(this));
   }

   private void c() {
      PluginManager var1 = this.getServer().getPluginManager();
      var1.registerEvents(new .ec(this), this);
      var1.registerEvents(new .ee(this), this);
      var1.registerEvents(new .ea(this), this);
      var1.registerEvents(new .dZ(this), this);
      var1.registerEvents(new .dX(this), this);
      var1.registerEvents(new .ef(this), this);
      var1.registerEvents(new .eb(this), this);
      var1.registerEvents(new .dY(this), this);
      var1.registerEvents(new .ed(this), this);
      var1.registerEvents(new .dK(this), this);
      var1.registerEvents(new .dN(this), this);
      var1.registerEvents(new .dO(this), this);
      var1.registerEvents(new .dQ(this), this);
      var1.registerEvents(new .dU(this), this);
      var1.registerEvents(new .dW(this), this);
      var1.registerEvents(new .dV(this), this);
      var1.registerEvents(new .ek(this), this);
      var1.registerEvents(new .dT(this), this);
      var1.registerEvents(new .dL(this), this);
      var1.registerEvents(new .dS(this), this);
      var1.registerEvents(new .dR(this), this);
      var1.registerEvents(new .dM(this), this);
      var1.registerEvents(new .dP(this), this);
      var1.registerEvents(new .eh(this), this);
      var1.registerEvents(new .eg(this), this);
      var1.registerEvents(new .ej(this), this);
      var1.registerEvents(new .ei(this), this);
   }

   public .k d() {
      return this.d;
   }

   public .en e() {
      return this.e;
   }

   public .E f() {
      return this.f;
   }

   public .C g() {
      return this.g;
   }

   public .eo h() {
      return this.i;
   }

   public .A i() {
      return this.h;
   }

   public .F j() {
      return this.j;
   }

   public .dJ k() {
      return this.c;
   }
}
