import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class b implements CommandExecutor, TabCompleter {
   private final CorruptedSMPPlugin l;

   public b(CorruptedSMPPlugin var1) {
      this.l = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length >= 2 && var4[0].equalsIgnoreCase("craftlimit") && var4[1].equalsIgnoreCase("info")) {
         if (var4.length < 3) {
            var1.sendMessage(this.a("§cUsage: /corrupt craftlimit info <corruption>"));
            return true;
         } else {
            return this.d(var1, var4[2]);
         }
      } else if (!var1.hasPermission("corruptedsmp.admin")) {
         var1.sendMessage(this.a("§cYou don't have permission to use this command!"));
         return true;
      } else if (var4.length == 0) {
         this.d(var1);
         return true;
      } else {
         switch (var4[0].toLowerCase()) {
            case "reset":
               if (var4.length < 2) {
                  var1.sendMessage(this.a("§cUsage: /corrupt reset <player>"));
                  return true;
               }

               return this.a(var1, var4[1]);
            case "set":
               if (var4.length < 3) {
                  var1.sendMessage(this.a("§cUsage: /corrupt set <player> <corruption>"));
                  return true;
               }

               return this.b(var1, var4[1], var4[2]);
            case "give":
               if (var4.length < 3) {
                  var1.sendMessage(this.a("§cUsage: /corrupt give <player> <corruption>"));
                  return true;
               }

               return this.a(var1, var4[1], var4[2]);
            case "reload":
               return this.a(var1);
            case "info":
               if (var4.length < 2) {
                  if (var1 instanceof Player) {
                     return this.b(var1, var1.getName());
                  }

                  var1.sendMessage(this.a("§cUsage: /corrupt info <player>"));
                  return true;
               }

               return this.b(var1, var4[1]);
            case "list":
               return this.b(var1);
            case "clearcooldown":
               if (var4.length < 2) {
                  var1.sendMessage(this.a("§cUsage: /corrupt clearcooldown <player>"));
                  return true;
               }

               return this.c(var1, var4[1]);
            case "craftlimit":
               if (var4.length < 2) {
                  this.c(var1);
                  return true;
               }

               return this.a(var1, var4);
            case "darkness":
               if (var4.length < 2) {
                  this.f(var1);
                  return true;
               }

               return this.b(var1, var4);
            default:
               this.d(var1);
               return true;
         }
      }
   }

   private boolean a(CommandSender var1, String var2, String var3) {
      Player var4 = Bukkit.getPlayer(var2);
      if (var4 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else {
         l var5 = l.b(var3);
         if (var5 == null) {
            var1.sendMessage(this.a("§cInvalid corruption type! Use /corrupt list to see available types."));
            return true;
         } else {
            ItemStack var6 = this.a(var5);
            var4.getInventory().addItem(new ItemStack[]{var6});
            String var10002 = var5.o();
            var1.sendMessage(this.a("§aGave " + var10002 + " §aCore to " + var4.getName()));
            var4.sendMessage(this.a("§aYou received a " + var5.o() + " §aCore!"));
            return true;
         }
      }
   }

   private boolean b(CommandSender var1, String var2, String var3) {
      Player var4 = Bukkit.getPlayer(var2);
      if (var4 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else {
         l var5 = l.b(var3);
         if (var5 == null) {
            var1.sendMessage(this.a("§cInvalid corruption type! Use /corrupt list to see available types."));
            return true;
         } else if (this.l.d().b(var4)) {
            var1.sendMessage(this.a("§c" + var4.getName() + " already has a corruption equipped!"));
            var1.sendMessage(this.a("§7Use /corrupt reset first or tell them to use /withdraw."));
            return true;
         } else {
            this.l.d().a(var4, var5);
            String var10002 = var5.o();
            var1.sendMessage(this.a("§aEquipped " + var10002 + " §aon " + var4.getName()));
            var4.sendMessage(this.a("§aAn admin has equipped " + var5.o() + " §aon you!"));
            return true;
         }
      }
   }

   private ItemStack a(l var1) {
      ItemStack var2 = new ItemStack(Material.FLOW_BANNER_PATTERN);
      ItemMeta var3 = var2.getItemMeta();
      if (var3 != null) {
         var3.setDisplayName(var1.o() + " §fCore");
         var3.setLore(j.b(var1));
         var3.setCustomModelData(var1.n());
         var3.addEnchant(Enchantment.UNBREAKING, 1, true);
         var3.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         var2.setItemMeta(var3);
      }

      return var2;
   }

   private boolean a(CommandSender var1, String var2) {
      Player var3 = Bukkit.getPlayer(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else if (!this.l.d().b(var3)) {
         var1.sendMessage(this.a("§c" + var3.getName() + " doesn't have a corruption equipped!"));
         return true;
      } else {
         this.l.d().a(var3);
         var1.sendMessage(this.a("§aReset corruption for " + var3.getName()));
         return true;
      }
   }

   private boolean a(CommandSender var1) {
      this.l.reloadConfig();
      var1.sendMessage(this.a(this.l.getConfig().getString("messages.reload-success")));
      return true;
   }

   private boolean b(CommandSender var1, String var2) {
      Player var3 = Bukkit.getPlayer(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else if (!this.l.d().b(var3)) {
         var1.sendMessage(this.a("§e" + var3.getName() + " §7does not have a corruption."));
         return true;
      } else {
         l var4 = this.l.d().c(var3);
         long var5 = this.l.d().b(var3.getUniqueId());
         var1.sendMessage(this.a("§7§m                                    "));
         var1.sendMessage(this.a("§eCorruption Info: §f" + var3.getName()));
         var1.sendMessage(this.a("§7Type: " + var4.o()));
         var1.sendMessage(this.a("§7Ability Cooldown: §e" + var5 + "s"));
         var1.sendMessage(this.a("§7§m                                    "));
         return true;
      }
   }

   private boolean b(CommandSender var1) {
      var1.sendMessage(this.a("§7§m                                    "));
      var1.sendMessage(this.a("§eAvailable Corruptions:"));

      for(l var5 : l.values()) {
         String var10002 = var5.o();
         var1.sendMessage(this.a("§7- " + var10002 + " §8(" + var5.m() + ")"));
      }

      var1.sendMessage(this.a("§7§m                                    "));
      return true;
   }

   private boolean c(CommandSender var1, String var2) {
      Player var3 = Bukkit.getPlayer(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else {
         this.l.d().a(var3.getUniqueId());
         var1.sendMessage(this.a("§aCleared ability cooldown for " + var3.getName()));
         return true;
      }
   }

   private boolean a(CommandSender var1, String[] var2) {
      if (var2.length < 2) {
         this.c(var1);
         return true;
      } else {
         switch (var2[1].toLowerCase()) {
            case "info":
               if (var2.length < 3) {
                  var1.sendMessage(this.a("§cUsage: /corrupt craftlimit info <corruption>"));
                  return true;
               }

               return this.d(var1, var2[2]);
            case "reset":
               if (var2.length < 3) {
                  var1.sendMessage(this.a("§cUsage: /corrupt craftlimit reset <corruption>"));
                  return true;
               }

               return this.e(var1, var2[2]);
            default:
               this.c(var1);
               return true;
         }
      }
   }

   private boolean d(CommandSender var1, String var2) {
      l var3 = l.b(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cInvalid corruption type! Use /corrupt list to see available types."));
         return true;
      } else {
         String var4 = var3.name().toLowerCase();
         int var5 = this.l.i().d(var4);
         int var6 = this.l.getConfig().getInt("crafting-limits.per-corruption." + var4, this.l.getConfig().getInt("crafting-limits.global-limit", -1));
         int var7 = this.l.i().c(var3);
         String var8 = var6 == -1 ? "Unlimited" : String.valueOf(var6);
         String var9 = var7 == -1 ? "Unlimited" : String.valueOf(var7);
         var1.sendMessage(this.a("§7§m                                    "));
         var1.sendMessage(this.a("§e" + var3.o() + " §fCrafting Info"));
         var1.sendMessage(this.a("§7Current Crafts: §e" + var5));
         var1.sendMessage(this.a("§7Craft Limit: §e" + var8));
         var1.sendMessage(this.a("§7Remaining: §a" + var9));
         var1.sendMessage(this.a("§7§m                                    "));
         return true;
      }
   }

   private boolean e(CommandSender var1, String var2) {
      l var3 = l.b(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cInvalid corruption type! Use /corrupt list to see available types."));
         return true;
      } else {
         this.l.i().f(var3.name().toLowerCase());
         var1.sendMessage(this.a("§aReset " + var3.o() + " §acraft count to 0"));
         return true;
      }
   }

   private void c(CommandSender var1) {
      var1.sendMessage(this.a("§7§m                                    "));
      var1.sendMessage(this.a("§eCrafting Limit Commands:"));
      var1.sendMessage(this.a("§7/corrupt craftlimit info <type> §8- View craft limit info §a(Everyone)"));
      var1.sendMessage(this.a("§7/corrupt craftlimit reset <type> §8- Reset craft count §c(OP Only)"));
      var1.sendMessage(this.a("§7§m                                    "));
   }

   private void d(CommandSender var1) {
      var1.sendMessage(this.a("§7§m                                    "));
      var1.sendMessage(this.a("§eCorruptedSMP Commands:"));
      var1.sendMessage(this.a("§7/corrupt give <player> <type> §8- Give corruption core item"));
      var1.sendMessage(this.a("§7/corrupt set <player> <type> §8- Directly equip corruption"));
      var1.sendMessage(this.a("§7/corrupt reset <player> §8- Remove equipped corruption"));
      var1.sendMessage(this.a("§7/corrupt info [player] §8- View corruption info"));
      var1.sendMessage(this.a("§7/corrupt list §8- List all corruptions"));
      var1.sendMessage(this.a("§7/corrupt clearcooldown <player> §8- Clear ability cooldown"));
      var1.sendMessage(this.a("§7/corrupt craftlimit §8- Manage crafting limits"));
      var1.sendMessage(this.a("§7/corrupt darkness §8- Darkness corruption utilities"));
      var1.sendMessage(this.a("§7/corrupt reload §8- Reload configuration"));
      var1.sendMessage(this.a("§7§m                                    "));
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      ArrayList var5 = new ArrayList();
      if (var4.length == 1) {
         var5.addAll(Arrays.asList("give", "set", "reset", "reload", "info", "list", "clearcooldown", "craftlimit", "darkness"));
      } else if (var4.length == 2) {
         if (var4[0].equalsIgnoreCase("reset") || var4[0].equalsIgnoreCase("set") || var4[0].equalsIgnoreCase("give") || var4[0].equalsIgnoreCase("info") || var4[0].equalsIgnoreCase("clearcooldown")) {
            return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
         }

         if (var4[0].equalsIgnoreCase("craftlimit")) {
            var5.addAll(Arrays.asList("info", "reset"));
         } else if (var4[0].equalsIgnoreCase("darkness")) {
            var5.addAll(Arrays.asList("cleanup", "cleanupall", "info"));
         }
      } else if (var4.length == 3) {
         if ((var4[0].equalsIgnoreCase("set") || var4[0].equalsIgnoreCase("give")) && var4.length == 3) {
            return (List)Arrays.stream(l.values()).map(l::m).collect(Collectors.toList());
         }

         if (var4[0].equalsIgnoreCase("craftlimit") && (var4[1].equalsIgnoreCase("info") || var4[1].equalsIgnoreCase("reset"))) {
            return (List)Arrays.stream(l.values()).map(l::m).collect(Collectors.toList());
         }

         if (var4[0].equalsIgnoreCase("darkness") && (var4[1].equalsIgnoreCase("cleanup") || var4[1].equalsIgnoreCase("info"))) {
            return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
         }
      }

      return (List)var5.stream().filter((var1x) -> var1x.toLowerCase().startsWith(var4[var4.length - 1].toLowerCase())).collect(Collectors.toList());
   }

   private boolean b(CommandSender var1, String[] var2) {
      if (var2.length < 2) {
         this.f(var1);
         return true;
      } else {
         switch (var2[1].toLowerCase()) {
            case "cleanup":
               if (var2.length < 3) {
                  var1.sendMessage(this.a("§cUsage: /corrupt darkness cleanup <player>"));
                  return true;
               }

               return this.f(var1, var2[2]);
            case "cleanupall":
               return this.e(var1);
            case "info":
               if (var2.length < 3) {
                  var1.sendMessage(this.a("§cUsage: /corrupt darkness info <player>"));
                  return true;
               }

               return this.g(var1, var2[2]);
            default:
               this.f(var1);
               return true;
         }
      }
   }

   private boolean f(CommandSender var1, String var2) {
      Player var3 = Bukkit.getPlayer(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else {
         m.e(var3.getUniqueId());
         var1.sendMessage(this.a("§a✓ Cleaned up Shadow Cage for " + var3.getName()));
         var3.sendMessage(this.a("§a✓ Your Shadow Cage was cleaned up by an admin!"));
         return true;
      }
   }

   private boolean e(CommandSender var1) {
      m.q();
      var1.sendMessage(this.a("§a✓ Cleaned up all active Shadow Cages!"));
      return true;
   }

   private boolean g(CommandSender var1, String var2) {
      Player var3 = Bukkit.getPlayer(var2);
      if (var3 == null) {
         var1.sendMessage(this.a("§cPlayer not found!"));
         return true;
      } else {
         m.b var4 = m.d(var3.getUniqueId());
         if (var4 == null) {
            var1.sendMessage(this.a("§7" + var3.getName() + " does not have an active Shadow Cage."));
            return true;
         } else {
            long var5 = System.currentTimeMillis() - var4.createdTime;
            long var7 = var5 / 1000L;
            var1.sendMessage(this.a("§7§m                                    "));
            var1.sendMessage(this.a("§eShadow Cage Info - " + var3.getName()));
            int var10002 = var4.center.getBlockX();
            var1.sendMessage(this.a("§7Cage Center: §e" + var10002 + ", " + var4.center.getBlockY() + ", " + var4.center.getBlockZ()));
            var1.sendMessage(this.a("§7Cage Radius: §e" + var4.radius + " blocks"));
            var1.sendMessage(this.a("§7Blocks Placed: §e" + var4.placedBlocks.size()));
            var1.sendMessage(this.a("§7Trapped Players: §e" + var4.trappedInThisCage.size()));
            var1.sendMessage(this.a("§7Elapsed Time: §e" + var7 + "s"));
            var10002 = var4.task != null && !var4.task.isCancelled();
            var1.sendMessage(this.a("§7Task Active: §e" + var10002));
            var1.sendMessage(this.a("§7§m                                    "));
            return true;
         }
      }
   }

   private void f(CommandSender var1) {
      var1.sendMessage(this.a("§7§m                                    "));
      var1.sendMessage(this.a("§eDarkness Corruption Commands:"));
      var1.sendMessage(this.a("§7/corrupt darkness cleanup <player> §8- Cleanup stuck cage"));
      var1.sendMessage(this.a("§7/corrupt darkness cleanupall §8- Cleanup all cages"));
      var1.sendMessage(this.a("§7/corrupt darkness info <player> §8- View cage info"));
      var1.sendMessage(this.a("§7§m                                    "));
   }

   private String a(String var1) {
      String var2 = this.l.getConfig().getString("messages.prefix", "");
      return (var2 + var1).replace("&", "§");
   }
}
