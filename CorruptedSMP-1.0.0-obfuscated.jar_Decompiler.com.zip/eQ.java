import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class eQ extends eP {
   public static final <T> Collection<T> i(T[] var0) {
      fR.c(var0, (String)"");
      return new eH<T>(var0, false);
   }

   public static final <T> List<T> nk() {
      return fa.sw;
   }

   public static final <T> List<T> j(T... var0) {
      fR.c(var0, (String)"");
      return var0.length > 0 ? eI.c(var0) : eO.nk();
   }

   public static final <T> List<T> k(T... var0) {
      fR.c(var0, (String)"");
      return var0.length == 0 ? (List)(new ArrayList()) : (List)(new ArrayList(new eH(var0, true)));
   }

   public static final <T> List<T> l(T... var0) {
      fR.c(var0, (String)"");
      return eI.e(var0);
   }

   public static final <T> int k(List<? extends T> var0) {
      fR.c(var0, (String)"");
      return var0.size() - 1;
   }

   public static final <T> List<T> l(List<? extends T> var0) {
      fR.c(var0, (String)"");
      List var10000;
      switch (var0.size()) {
         case 0:
            var10000 = eO.nk();
            break;
         case 1:
            var10000 = eO.i(var0.get(0));
            break;
         default:
            var10000 = var0;
      }

      return var10000;
   }

   public static final <T extends Comparable<? super T>> int a(List<? extends T> var0, T var1, int var2, int var3) {
      fR.c(var0, (String)"");
      g(var0.size(), var2, var3);
      int var4 = var2;
      int var5 = var3 - 1;

      while(var4 <= var5) {
         int var6 = var4 + var5 >>> 1;
         Comparable var7 = (Comparable)var0.get(var6);
         int var8 = fo.b(var7, var1);
         if (var8 < 0) {
            var4 = var6 + 1;
         } else {
            if (var8 <= 0) {
               return var6;
            }

            var5 = var6 - 1;
         }
      }

      return -(var4 + 1);
   }

   // $FF: synthetic method
   public static int a(List var0, Comparable var1, int var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = var0.size();
      }

      return eO.a(var0, var1, var2, var3);
   }

   private static final void g(int var0, int var1, int var2) {
      if (var1 > var2) {
         throw new IllegalArgumentException("fromIndex (" + var1 + ") is greater than toIndex (" + var2 + ").");
      } else if (var1 < 0) {
         throw new IndexOutOfBoundsException("fromIndex (" + var1 + ") is less than zero.");
      } else if (var2 > var0) {
         throw new IndexOutOfBoundsException("toIndex (" + var2 + ") is greater than size (" + var0 + ").");
      }
   }

   public static final void nl() {
      throw new ArithmeticException("Index overflow has happened.");
   }
}
