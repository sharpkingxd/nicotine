import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.ShulkerBullet;
import org.bukkit.entity.WindCharge;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;

public class dS implements Listener {
   private final CorruptedSMPPlugin rn;

   public dS(CorruptedSMPPlugin var1) {
      this.rn = var1;
   }

   @EventHandler
   public void d(EntityDamageEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.rn.d().b(var2)) {
            if (this.rn.d().c(var2) == l.v) {
               if (var1.getCause() == DamageCause.VOID) {
                  var1.setCancelled(true);
                  Location var4 = var2.getWorld().getSpawnLocation();
                  var2.teleport(var4);
                  var2.sendMessage("§5§lENDER SAVE! §7Teleported to spawn!");
               }

            }
         }
      }
   }

   @EventHandler
   public void b(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.rn.d().b(var2)) {
         if (this.rn.d().c(var2) == l.v) {
            if (var1.getItem().getType().isEdible()) {
               D var3 = this.rn.f().g(var2.getUniqueId());
               if (var3.i("shulkerBulletStored") && (Boolean)var3.h("shulkerBulletStored")) {
                  return;
               }

               long var4 = System.currentTimeMillis();
               if (var3.i("shulkerBulletCooldown")) {
                  long var6 = (Long)var3.h("shulkerBulletCooldown");
                  long var8 = 120000L - (var4 - var6);
                  if (var8 > 0L) {
                     return;
                  }
               }

               var3.a("shulkerBulletStored", true);
               var2.sendMessage("§5§l✓ §7Shulker Bullet stored! §5Shift + Left-click §7to shoot.");
            }

         }
      }
   }

   @EventHandler
   public void c(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.LEFT_CLICK_AIR || var1.getAction() == Action.LEFT_CLICK_BLOCK) {
         Player var2 = var1.getPlayer();
         if (this.rn.d().b(var2)) {
            if (this.rn.d().c(var2) == l.v) {
               if (var2.isSneaking()) {
                  D var3 = this.rn.f().g(var2.getUniqueId());
                  if (var3.i("shulkerBulletStored") && (Boolean)var3.h("shulkerBulletStored")) {
                     long var4 = System.currentTimeMillis();
                     if (var3.i("shulkerBulletCooldown")) {
                        long var6 = (Long)var3.h("shulkerBulletCooldown");
                        long var8 = 120000L - (var4 - var6);
                        if (var8 > 0L) {
                           int var16 = (int)(var8 / 1000L);
                           var2.sendMessage("§5§l✗ §7Cooldown: §5" + var16 + "s");
                           return;
                        }
                     }

                     ShulkerBullet var14 = (ShulkerBullet)var2.getWorld().spawn(var2.getEyeLocation().add(var2.getLocation().getDirection()), ShulkerBullet.class);
                     var14.setShooter(var2);
                     Player var7 = null;
                     double var15 = Double.MAX_VALUE;

                     for(Player var11 : var2.getWorld().getPlayers()) {
                        if (!var11.equals(var2)) {
                           double var12 = var11.getLocation().distance(var2.getLocation());
                           if (var12 < var15 && var12 < (double)30.0F) {
                              var7 = var11;
                              var15 = var12;
                           }
                        }
                     }

                     if (var7 != null) {
                        var14.setTarget(var7);
                     }

                     var3.a("shulkerBulletStored", false);
                     var3.a("shulkerBulletCooldown", var4);
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void f(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof ShulkerBullet var2) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof Player var7) {
            ProjectileSource var5 = var2.getShooter();
            if (var5 instanceof Player var8) {
               if (this.rn.d().b(var8)) {
                  if (this.rn.d().c(var8) == l.v) {
                     var7.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 100, 0, false, false));
                     var7.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0, false, false));
                     double var9 = Math.min(var8.getHealth() + (double)4.0F, var8.getMaxHealth());
                     var8.setHealth(var9);
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void g(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (!(var1.getDamager() instanceof Player)) {
            if (!(var1.getDamager() instanceof ShulkerBullet)) {
               if (this.rn.d().b(var2)) {
                  if (this.rn.d().c(var2) == l.v) {
                     var1.setDamage(var1.getDamage() * (double)1.5F);
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void b(ProjectileLaunchEvent var1) {
      ProjectileSource var3 = var1.getEntity().getShooter();
      if (var3 instanceof Player var2) {
         if (o.c(var2.getUniqueId())) {
            var1.setCancelled(true);
            var2.sendMessage("§5§l✗ §7You cannot use ender pearls while trapped in Ender Border!");
         }

      }
   }

   @EventHandler
   public void c(ProjectileLaunchEvent var1) {
      if (var1.getEntity() instanceof WindCharge) {
         ProjectileSource var3 = var1.getEntity().getShooter();
         if (var3 instanceof Player) {
            Player var2 = (Player)var3;
            if (o.c(var2.getUniqueId())) {
               var1.setCancelled(true);
               var2.sendMessage("§5§l✗ §7You cannot use wind charges while trapped in Ender Border!");
            }

         }
      }
   }

   @EventHandler
   public void b(PlayerTeleportEvent var1) {
      if (var1.getCause() == TeleportCause.CHORUS_FRUIT) {
         Player var2 = var1.getPlayer();
         if (o.c(var2.getUniqueId())) {
            var1.setCancelled(true);
            var2.sendMessage("§5§l✗ §7You cannot use chorus fruit while trapped in Ender Border!");
         }

      }
   }

   @EventHandler
   public void a(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.getItem().getType() == Material.CHORUS_FRUIT) {
         if (o.c(var2.getUniqueId())) {
            var1.setCancelled(true);
            var2.sendMessage("§5§l✗ §7You cannot eat chorus fruit while trapped in Ender Border!");
         }

      }
   }
}
