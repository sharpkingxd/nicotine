import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class cs implements Closeable {
   public static final a nM = new a((fP)null);
   private final dg nN;
   private final boolean nO;
   private final b nP;
   private final co.a nQ;
   private static final Logger nR;

   public cs(dg var1, boolean var2) {
      fR.c(var1, (String)"");
      super();
      this.nN = var1;
      this.nO = var2;
      this.nP = new b(this.nN);
      this.nQ = new co.a(this.nP, 4096, 0, 4, (fP)null);
   }

   public final void a(c var1) throws IOException {
      fR.c(var1, (String)"");
      if (this.nO) {
         if (!this.a(true, var1)) {
            throw new IOException("Required SETTINGS preface not received");
         }
      } else {
         dh var2 = this.nN.w((long)cp.na.lm());
         if (nR.isLoggable(Level.FINE)) {
            nR.fine(bD.a("<< CONNECTION " + var2.lk()));
         }

         if (!fR.c(cp.na, (Object)var2)) {
            throw new IOException("Expected a connection header but was " + var2.lf());
         }
      }

   }

   public final boolean a(boolean var1, c var2) throws IOException {
      fR.c(var2, (String)"");

      try {
         this.nN.u(9L);
      } catch (EOFException var7) {
         return false;
      }

      int var3 = bD.c(this.nN);
      if (var3 > 16384) {
         throw new IOException("FRAME_SIZE_ERROR: " + var3);
      } else {
         int var4 = bD.a((byte)this.nN.kN(), 255);
         int var5 = bD.a((byte)this.nN.kN(), 255);
         int var6 = this.nN.kP() & Integer.MAX_VALUE;
         if (nR.isLoggable(Level.FINE)) {
            nR.fine(cp.mZ.a(true, var6, var3, var4, var5));
         }

         if (var1 && var4 != 4) {
            throw new IOException("Expected a SETTINGS frame but was " + cp.mZ.E(var4));
         } else {
            switch (var4) {
               case 0:
                  this.b(var2, var3, var5, var6);
                  break;
               case 1:
                  this.a(var2, var3, var5, var6);
                  break;
               case 2:
                  this.c(var2, var3, var5, var6);
                  break;
               case 3:
                  this.d(var2, var3, var5, var6);
                  break;
               case 4:
                  this.e(var2, var3, var5, var6);
                  break;
               case 5:
                  this.f(var2, var3, var5, var6);
                  break;
               case 6:
                  this.g(var2, var3, var5, var6);
                  break;
               case 7:
                  this.h(var2, var3, var5, var6);
                  break;
               case 8:
                  this.i(var2, var3, var5, var6);
                  break;
               default:
                  this.nN.A((long)var3);
            }

            return true;
         }
      }
   }

   private final void a(c var1, int var2, int var3, int var4) throws IOException {
      if (var4 == 0) {
         throw new IOException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0");
      } else {
         boolean var5 = (var3 & 1) != 0;
         int var6 = (var3 & 8) != 0 ? bD.a((byte)this.nN.kN(), 255) : 0;
         int var7 = var2;
         if ((var3 & 32) != 0) {
            this.a(var1, var4);
            var7 = var2 - 5;
         }

         var7 = nM.b(var7, var3, var6);
         List var8 = this.a(var7, var6, var3, var4);
         var1.a(var5, var4, -1, var8);
      }
   }

   private final List<cn> a(int var1, int var2, int var3, int var4) throws IOException {
      this.nP.N(var1);
      this.nP.K(this.nP.iP());
      this.nP.O(var2);
      this.nP.L(var3);
      this.nP.M(var4);
      this.nQ.ie();
      return this.nQ.ib();
   }

   private final void b(c var1, int var2, int var3, int var4) throws IOException {
      if (var4 == 0) {
         throw new IOException("PROTOCOL_ERROR: TYPE_DATA streamId == 0");
      } else {
         boolean var5 = (var3 & 1) != 0;
         boolean var6 = (var3 & 32) != 0;
         if (var6) {
            throw new IOException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA");
         } else {
            int var7 = (var3 & 8) != 0 ? bD.a((byte)this.nN.kN(), 255) : 0;
            int var8 = nM.b(var2, var3, var7);
            var1.a(var5, var4, this.nN, var8);
            this.nN.A((long)var7);
         }
      }
   }

   private final void c(c var1, int var2, int var3, int var4) throws IOException {
      if (var2 != 5) {
         throw new IOException("TYPE_PRIORITY length: " + var2 + " != 5");
      } else if (var4 == 0) {
         throw new IOException("TYPE_PRIORITY streamId == 0");
      } else {
         this.a(var1, var4);
      }
   }

   private final void a(c var1, int var2) throws IOException {
      int var3 = this.nN.kP();
      boolean var4 = (var3 & Integer.MIN_VALUE) != 0;
      int var5 = var3 & Integer.MAX_VALUE;
      int var6 = bD.a((byte)this.nN.kN(), 255) + 1;
      var1.a(var2, var5, var6, var4);
   }

   private final void d(c var1, int var2, int var3, int var4) throws IOException {
      if (var2 != 4) {
         throw new IOException("TYPE_RST_STREAM length: " + var2 + " != 4");
      } else if (var4 == 0) {
         throw new IOException("TYPE_RST_STREAM streamId == 0");
      } else {
         int var5 = this.nN.kP();
         cm var10000 = cm.mv.u(var5);
         if (var10000 == null) {
            throw new IOException("TYPE_RST_STREAM unexpected error code: " + var5);
         } else {
            cm var6 = var10000;
            var1.d(var4, var6);
         }
      }
   }

   private final void e(c var1, int var2, int var3, int var4) throws IOException {
      if (var4 != 0) {
         throw new IOException("TYPE_SETTINGS streamId != 0");
      } else if ((var3 & 1) != 0) {
         if (var2 != 0) {
            throw new IOException("FRAME_SIZE_ERROR ack frame should be empty!");
         } else {
            var1.iK();
         }
      } else if (var2 % 6 != 0) {
         throw new IOException("TYPE_SETTINGS length % 6 != 0: " + var2);
      } else {
         cx var5 = new cx();
         gd var6 = gg.a(gg.l(0, var2), 6);
         int var7 = var6.nC();
         int var8 = var6.nD();
         int var9 = var6.nE();
         if (var9 > 0 && var7 <= var8 || var9 < 0 && var8 <= var7) {
            while(true) {
               int var10 = bD.a((short)this.nN.kO(), 65535);
               int var11 = this.nN.kP();
               switch (var10) {
                  case 1:
                  case 6:
                  default:
                     break;
                  case 2:
                     if (var11 != 0 && var11 != 1) {
                        throw new IOException("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1");
                     }
                     break;
                  case 3:
                     var10 = 4;
                     break;
                  case 4:
                     var10 = 7;
                     if (var11 < 0) {
                        throw new IOException("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1");
                     }
                     break;
                  case 5:
                     if (var11 < 16384 || var11 > 16777215) {
                        throw new IOException("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: " + var11);
                     }
               }

               var5.d(var10, var11);
               if (var7 == var8) {
                  break;
               }

               var7 += var9;
            }
         }

         var1.a(false, var5);
      }
   }

   private final void f(c var1, int var2, int var3, int var4) throws IOException {
      if (var4 == 0) {
         throw new IOException("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0");
      } else {
         int var5 = (var3 & 8) != 0 ? bD.a((byte)this.nN.kN(), 255) : 0;
         int var6 = this.nN.kP() & Integer.MAX_VALUE;
         int var7 = nM.b(var2 - 4, var3, var5);
         List var8 = this.a(var7, var5, var3, var4);
         var1.a(var4, var6, var8);
      }
   }

   private final void g(c var1, int var2, int var3, int var4) throws IOException {
      if (var2 != 8) {
         throw new IOException("TYPE_PING length != 8: " + var2);
      } else if (var4 != 0) {
         throw new IOException("TYPE_PING streamId != 0");
      } else {
         int var5 = this.nN.kP();
         int var6 = this.nN.kP();
         boolean var7 = (var3 & 1) != 0;
         var1.b(var7, var5, var6);
      }
   }

   private final void h(c var1, int var2, int var3, int var4) throws IOException {
      if (var2 < 8) {
         throw new IOException("TYPE_GOAWAY length < 8: " + var2);
      } else if (var4 != 0) {
         throw new IOException("TYPE_GOAWAY streamId != 0");
      } else {
         int var5 = this.nN.kP();
         int var6 = this.nN.kP();
         int var7 = var2 - 8;
         cm var10000 = cm.mv.u(var6);
         if (var10000 == null) {
            throw new IOException("TYPE_GOAWAY unexpected error code: " + var6);
         } else {
            cm var8 = var10000;
            dh var9 = dh.pV;
            if (var7 > 0) {
               var9 = this.nN.w((long)var7);
            }

            var1.a(var5, var8, var9);
         }
      }
   }

   private final void i(c var1, int var2, int var3, int var4) throws IOException {
      if (var2 != 4) {
         throw new IOException("TYPE_WINDOW_UPDATE length !=4: " + var2);
      } else {
         long var5 = bD.a(this.nN.kP(), 2147483647L);
         if (var5 == 0L) {
            throw new IOException("windowSizeIncrement was 0");
         } else {
            var1.c(var4, var5);
         }
      }
   }

   public void close() throws IOException {
      this.nN.close();
   }

   static {
      Logger var10000 = Logger.getLogger(cp.class.getName());
      fR.b(var10000, "");
      nR = var10000;
   }

   public static final class a {
      private a() {
      }

      public final Logger iO() {
         return cs.nR;
      }

      public final int b(int var1, int var2, int var3) throws IOException {
         int var4 = var1;
         if ((var2 & 8) != 0) {
            var4 = var1 - 1;
         }

         if (var3 > var4) {
            throw new IOException("PROTOCOL_ERROR padding " + var3 + " > remaining length " + var4);
         } else {
            var4 -= var3;
            return var4;
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public static final class b implements dA {
      private final dg source;
      private int length;
      private int flags;
      private int streamId;
      private int left;
      private int padding;

      public b(dg var1) {
         fR.c(var1, (String)"");
         super();
         this.source = var1;
      }

      public final void K(int var1) {
         this.length = var1;
      }

      public final void L(int var1) {
         this.flags = var1;
      }

      public final void M(int var1) {
         this.streamId = var1;
      }

      public final int iP() {
         return this.left;
      }

      public final void N(int var1) {
         this.left = var1;
      }

      public final void O(int var1) {
         this.padding = var1;
      }

      public long a(de var1, long var2) throws IOException {
         fR.c(var1, (String)"");

         while(this.left == 0) {
            this.source.A((long)this.padding);
            this.padding = 0;
            if ((this.flags & 4) != 0) {
               return -1L;
            }

            this.iQ();
         }

         long var4 = this.source.a(var1, Math.min(var2, (long)this.left));
         if (var4 == -1L) {
            return -1L;
         } else {
            this.left -= (int)var4;
            return var4;
         }
      }

      public dB fu() {
         return this.source.fu();
      }

      public void close() throws IOException {
      }

      private final void iQ() throws IOException {
         int var1 = this.streamId;
         this.left = bD.c(this.source);
         this.length = this.left;
         int var2 = bD.a((byte)this.source.kN(), 255);
         this.flags = bD.a((byte)this.source.kN(), 255);
         if (cs.nM.iO().isLoggable(Level.FINE)) {
            cs.nM.iO().fine(cp.mZ.a(true, this.streamId, this.length, var2, this.flags));
         }

         this.streamId = this.source.kP() & Integer.MAX_VALUE;
         if (var2 != 9) {
            throw new IOException(var2 + " != TYPE_CONTINUATION");
         } else if (this.streamId != var1) {
            throw new IOException("TYPE_CONTINUATION streamId changed");
         }
      }
   }

   public interface c {
      void a(boolean var1, int var2, dg var3, int var4) throws IOException;

      void a(boolean var1, int var2, int var3, List<cn> var4);

      void d(int var1, cm var2);

      void a(boolean var1, cx var2);

      void iK();

      void b(boolean var1, int var2, int var3);

      void a(int var1, cm var2, dh var3);

      void c(int var1, long var2);

      void a(int var1, int var2, int var3, boolean var4);

      void a(int var1, int var2, List<cn> var3) throws IOException;
   }
}
