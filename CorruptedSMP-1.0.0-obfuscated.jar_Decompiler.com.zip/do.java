import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public final class do {
   public static final dy a(OutputStream var0) {
      return dp.b(var0);
   }

   public static final dA a(InputStream var0) {
      return dp.b(var0);
   }

   public static final dy c(Socket var0) throws IOException {
      return dp.e(var0);
   }

   public static final dA d(Socket var0) throws IOException {
      return dp.f(var0);
   }

   public static final dy a(File var0, boolean var1) throws FileNotFoundException {
      return dp.b(var0, var1);
   }

   // $FF: synthetic method
   public static dy a(File var0, boolean var1, int var2, Object var3) throws FileNotFoundException {
      return dp.a(var0, var1, var2, var3);
   }

   public static final dy h(File var0) throws FileNotFoundException {
      return dp.j(var0);
   }

   public static final dA i(File var0) throws FileNotFoundException {
      return dp.k(var0);
   }

   public static final boolean a(AssertionError var0) {
      return dp.b(var0);
   }

   public static final dg c(dA var0) {
      return dq.d(var0);
   }

   public static final df b(dy var0) {
      return dq.c(var0);
   }

   public static final dy lC() {
      return dq.lE();
   }
}
