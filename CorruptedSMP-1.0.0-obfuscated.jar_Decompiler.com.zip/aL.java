import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class aL {
   public static final ac<Class> cq = (new ac<Class>() {
      public void a(aV var1, Class var2) throws IOException {
         throw new UnsupportedOperationException("Attempted to serialize java.lang.Class: " + var2.getName() + ". Forgot to register a type adapter?");
      }

      public Class p(aT var1) throws IOException {
         throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
      }

      // $FF: synthetic method
      public Object b(aT var1) throws IOException {
         return this.p(var1);
      }
   }).an();
   public static final ad cr;
   public static final ac<BitSet> cs;
   public static final ad ct;
   public static final ac<Boolean> cu;
   public static final ac<Boolean> cv;
   public static final ad cw;
   public static final ac<Number> cx;
   public static final ad cy;
   public static final ac<Number> cz;
   public static final ad cA;
   public static final ac<Number> cB;
   public static final ad cC;
   public static final ac<AtomicInteger> cD;
   public static final ad cE;
   public static final ac<AtomicBoolean> cF;
   public static final ad cG;
   public static final ac<AtomicIntegerArray> cH;
   public static final ad cI;
   public static final ac<Number> cJ;
   public static final ac<Number> cK;
   public static final ac<Number> cL;
   public static final ac<Character> cM;
   public static final ad cN;
   public static final ac<String> cO;
   public static final ac<BigDecimal> cP;
   public static final ac<BigInteger> cQ;
   public static final ac<ap> cR;
   public static final ad cS;
   public static final ac<StringBuilder> cT;
   public static final ad cU;
   public static final ac<StringBuffer> cV;
   public static final ad cW;
   public static final ac<URL> cX;
   public static final ad cY;
   public static final ac<URI> cZ;
   public static final ad da;
   public static final ac<InetAddress> db;
   public static final ad dc;
   public static final ac<UUID> dd;
   public static final ad de;
   public static final ac<Currency> df;
   public static final ad dg;
   public static final ac<Calendar> dh;
   public static final ad di;
   public static final ac<Locale> dj;
   public static final ad dk;
   public static final ac<P> dl;
   public static final ad dm;
   public static final ad dn;

   public static <TT> ad a(final Class<TT> var0, final ac<TT> var1) {
      return new ad() {
         public <T> ac<T> a(K var1x, aS<T> var2) {
            return var2.bk() == var0 ? var1 : null;
         }

         public String toString() {
            return "Factory[type=" + var0.getName() + ",adapter=" + var1 + "]";
         }
      };
   }

   public static <TT> ad a(final Class<TT> var0, final Class<TT> var1, final ac<? super TT> var2) {
      return new ad() {
         public <T> ac<T> a(K var1x, aS<T> var2x) {
            Class var3 = var2x.bk();
            return var3 != var0 && var3 != var1 ? null : var2;
         }

         public String toString() {
            return "Factory[type=" + var1.getName() + "+" + var0.getName() + ",adapter=" + var2 + "]";
         }
      };
   }

   public static <TT> ad b(final Class<TT> var0, final Class<? extends TT> var1, final ac<? super TT> var2) {
      return new ad() {
         public <T> ac<T> a(K var1x, aS<T> var2x) {
            Class var3 = var2x.bk();
            return var3 != var0 && var3 != var1 ? null : var2;
         }

         public String toString() {
            return "Factory[type=" + var0.getName() + "+" + var1.getName() + ",adapter=" + var2 + "]";
         }
      };
   }

   public static <T1> ad b(final Class<T1> var0, final ac<T1> var1) {
      return new ad() {
         public <T2> ac<T2> a(K var1x, aS<T2> var2) {
            final Class var3 = var2.bk();
            return !var0.isAssignableFrom(var3) ? null : new ac<T1>() {
               public void a(aV var1x, T1 var2) throws IOException {
                  var1.a(var1x, var2);
               }

               public T1 b(aT var1x) throws IOException {
                  Object var2 = var1.b(var1x);
                  if (var2 != null && !var3.isInstance(var2)) {
                     throw new X("Expected a " + var3.getName() + " but was " + var2.getClass().getName() + "; at path " + var1x.aV());
                  } else {
                     return (T1)var2;
                  }
               }
            };
         }

         public String toString() {
            return "Factory[typeHierarchy=" + var0.getName() + ",adapter=" + var1 + "]";
         }
      };
   }

   static {
      cr = a(Class.class, cq);
      cs = (new ac<BitSet>() {
         public BitSet x(aT var1) throws IOException {
            BitSet var2 = new BitSet();
            var1.aE();
            int var3 = 0;

            for(aU var4 = var1.aI(); var4 != aU.dR; var4 = var1.aI()) {
               boolean var5;
               switch (var4) {
                  case dW:
                  case dV:
                     int var6 = var1.aR();
                     if (var6 == 0) {
                        var5 = false;
                     } else {
                        if (var6 != 1) {
                           throw new X("Invalid bitset value " + var6 + ", expected 0 or 1; at path " + var1.aV());
                        }

                        var5 = true;
                     }
                     break;
                  case dX:
                     var5 = var1.aN();
                     break;
                  default:
                     throw new X("Invalid bitset value type: " + var4 + "; at path " + var1.aW());
               }

               if (var5) {
                  var2.set(var3);
               }

               ++var3;
            }

            var1.aF();
            return var2;
         }

         public void a(aV var1, BitSet var2) throws IOException {
            var1.ba();
            int var3 = 0;

            for(int var4 = var2.length(); var3 < var4; ++var3) {
               int var5 = var2.get(var3) ? 1 : 0;
               var1.b((long)var5);
            }

            var1.bb();
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.x(var1);
         }
      }).an();
      ct = a(BitSet.class, cs);
      cu = new ac<Boolean>() {
         public Boolean H(aT var1) throws IOException {
            aU var2 = var1.aI();
            if (var2 == aU.dY) {
               var1.aO();
               return null;
            } else {
               return var2 == aU.dV ? Boolean.parseBoolean(var1.aM()) : var1.aN();
            }
         }

         public void a(aV var1, Boolean var2) throws IOException {
            var1.a(var2);
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.H(var1);
         }
      };
      cv = new ac<Boolean>() {
         public Boolean H(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return Boolean.valueOf(var1.aM());
            }
         }

         public void a(aV var1, Boolean var2) throws IOException {
            var1.t(var2 == null ? "null" : var2.toString());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.H(var1);
         }
      };
      cw = a(Boolean.TYPE, Boolean.class, cu);
      cx = new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               int var2;
               try {
                  var2 = var1.aR();
               } catch (NumberFormatException var4) {
                  throw new X(var4);
               }

               if (var2 <= 255 && var2 >= -128) {
                  return (byte)var2;
               } else {
                  throw new X("Lossy conversion from " + var2 + " to byte; at path " + var1.aV());
               }
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.b((long)var2.byteValue());
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
      cy = a(Byte.TYPE, Byte.class, cx);
      cz = new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               int var2;
               try {
                  var2 = var1.aR();
               } catch (NumberFormatException var4) {
                  throw new X(var4);
               }

               if (var2 <= 65535 && var2 >= -32768) {
                  return (short)var2;
               } else {
                  throw new X("Lossy conversion from " + var2 + " to short; at path " + var1.aV());
               }
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.b((long)var2.shortValue());
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
      cA = a(Short.TYPE, Short.class, cz);
      cB = new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               try {
                  return var1.aR();
               } catch (NumberFormatException var3) {
                  throw new X(var3);
               }
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.b((long)var2.intValue());
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
      cC = a(Integer.TYPE, Integer.class, cB);
      cD = (new ac<AtomicInteger>() {
         public AtomicInteger I(aT var1) throws IOException {
            try {
               return new AtomicInteger(var1.aR());
            } catch (NumberFormatException var3) {
               throw new X(var3);
            }
         }

         public void a(aV var1, AtomicInteger var2) throws IOException {
            var1.b((long)var2.get());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.I(var1);
         }
      }).an();
      cE = a(AtomicInteger.class, cD);
      cF = (new ac<AtomicBoolean>() {
         public AtomicBoolean J(aT var1) throws IOException {
            return new AtomicBoolean(var1.aN());
         }

         public void a(aV var1, AtomicBoolean var2) throws IOException {
            var1.h(var2.get());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.J(var1);
         }
      }).an();
      cG = a(AtomicBoolean.class, cF);
      cH = (new ac<AtomicIntegerArray>() {
         public AtomicIntegerArray q(aT var1) throws IOException {
            ArrayList var2 = new ArrayList();
            var1.aE();

            while(var1.hasNext()) {
               try {
                  int var3 = var1.aR();
                  var2.add(var3);
               } catch (NumberFormatException var6) {
                  throw new X(var6);
               }
            }

            var1.aF();
            int var7 = var2.size();
            AtomicIntegerArray var4 = new AtomicIntegerArray(var7);

            for(int var5 = 0; var5 < var7; ++var5) {
               var4.set(var5, (Integer)var2.get(var5));
            }

            return var4;
         }

         public void a(aV var1, AtomicIntegerArray var2) throws IOException {
            var1.ba();
            int var3 = 0;

            for(int var4 = var2.length(); var3 < var4; ++var3) {
               var1.b((long)var2.get(var3));
            }

            var1.bb();
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.q(var1);
         }
      }).an();
      cI = a(AtomicIntegerArray.class, cH);
      cJ = new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               try {
                  return var1.aQ();
               } catch (NumberFormatException var3) {
                  throw new X(var3);
               }
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.b(var2.longValue());
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
      cK = new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return (float)var1.aP();
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               Object var3 = var2 instanceof Float ? var2 : var2.floatValue();
               var1.a((Number)var3);
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
      cL = new ac<Number>() {
         public Number d(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return var1.aP();
            }
         }

         public void a(aV var1, Number var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.d(var2.doubleValue());
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.d(var1);
         }
      };
      cM = new ac<Character>() {
         public Character r(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               String var2 = var1.aM();
               if (var2.length() != 1) {
                  throw new X("Expecting character, got: " + var2 + "; at " + var1.aV());
               } else {
                  return var2.charAt(0);
               }
            }
         }

         public void a(aV var1, Character var2) throws IOException {
            var1.t(var2 == null ? null : String.valueOf(var2));
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.r(var1);
         }
      };
      cN = a(Character.TYPE, Character.class, cM);
      cO = new ac<String>() {
         public String s(aT var1) throws IOException {
            aU var2 = var1.aI();
            if (var2 == aU.dY) {
               var1.aO();
               return null;
            } else {
               return var2 == aU.dX ? Boolean.toString(var1.aN()) : var1.aM();
            }
         }

         public void a(aV var1, String var2) throws IOException {
            var1.t(var2);
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.s(var1);
         }
      };
      cP = new ac<BigDecimal>() {
         public BigDecimal t(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               String var2 = var1.aM();

               try {
                  return new BigDecimal(var2);
               } catch (NumberFormatException var4) {
                  throw new X("Failed parsing '" + var2 + "' as BigDecimal; at path " + var1.aV(), var4);
               }
            }
         }

         public void a(aV var1, BigDecimal var2) throws IOException {
            var1.a((Number)var2);
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.t(var1);
         }
      };
      cQ = new ac<BigInteger>() {
         public BigInteger u(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               String var2 = var1.aM();

               try {
                  return new BigInteger(var2);
               } catch (NumberFormatException var4) {
                  throw new X("Failed parsing '" + var2 + "' as BigInteger; at path " + var1.aV(), var4);
               }
            }
         }

         public void a(aV var1, BigInteger var2) throws IOException {
            var1.a((Number)var2);
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.u(var1);
         }
      };
      cR = new ac<ap>() {
         public ap v(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return new ap(var1.aM());
            }
         }

         public void a(aV var1, ap var2) throws IOException {
            var1.a((Number)var2);
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.v(var1);
         }
      };
      cS = a(String.class, cO);
      cT = new ac<StringBuilder>() {
         public StringBuilder w(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return new StringBuilder(var1.aM());
            }
         }

         public void a(aV var1, StringBuilder var2) throws IOException {
            var1.t(var2 == null ? null : var2.toString());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.w(var1);
         }
      };
      cU = a(StringBuilder.class, cT);
      cV = new ac<StringBuffer>() {
         public StringBuffer y(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return new StringBuffer(var1.aM());
            }
         }

         public void a(aV var1, StringBuffer var2) throws IOException {
            var1.t(var2 == null ? null : var2.toString());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.y(var1);
         }
      };
      cW = a(StringBuffer.class, cV);
      cX = new ac<URL>() {
         public URL z(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               String var2 = var1.aM();
               return "null".equals(var2) ? null : new URL(var2);
            }
         }

         public void a(aV var1, URL var2) throws IOException {
            var1.t(var2 == null ? null : var2.toExternalForm());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.z(var1);
         }
      };
      cY = a(URL.class, cX);
      cZ = new ac<URI>() {
         public URI A(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               try {
                  String var2 = var1.aM();
                  return "null".equals(var2) ? null : new URI(var2);
               } catch (URISyntaxException var3) {
                  throw new Q(var3);
               }
            }
         }

         public void a(aV var1, URI var2) throws IOException {
            var1.t(var2 == null ? null : var2.toASCIIString());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.A(var1);
         }
      };
      da = a(URI.class, cZ);
      db = new ac<InetAddress>() {
         public InetAddress B(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               return InetAddress.getByName(var1.aM());
            }
         }

         public void a(aV var1, InetAddress var2) throws IOException {
            var1.t(var2 == null ? null : var2.getHostAddress());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.B(var1);
         }
      };
      dc = b(InetAddress.class, db);
      dd = new ac<UUID>() {
         public UUID C(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               String var2 = var1.aM();

               try {
                  return UUID.fromString(var2);
               } catch (IllegalArgumentException var4) {
                  throw new X("Failed parsing '" + var2 + "' as UUID; at path " + var1.aV(), var4);
               }
            }
         }

         public void a(aV var1, UUID var2) throws IOException {
            var1.t(var2 == null ? null : var2.toString());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.C(var1);
         }
      };
      de = a(UUID.class, dd);
      df = (new ac<Currency>() {
         public Currency D(aT var1) throws IOException {
            String var2 = var1.aM();

            try {
               return Currency.getInstance(var2);
            } catch (IllegalArgumentException var4) {
               throw new X("Failed parsing '" + var2 + "' as Currency; at path " + var1.aV(), var4);
            }
         }

         public void a(aV var1, Currency var2) throws IOException {
            var1.t(var2.getCurrencyCode());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.D(var1);
         }
      }).an();
      dg = a(Currency.class, df);
      dh = new ac<Calendar>() {
         private static final String YEAR = "year";
         private static final String MONTH = "month";
         private static final String DAY_OF_MONTH = "dayOfMonth";
         private static final String HOUR_OF_DAY = "hourOfDay";
         private static final String MINUTE = "minute";
         private static final String SECOND = "second";

         public Calendar E(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               var1.aG();
               int var2 = 0;
               int var3 = 0;
               int var4 = 0;
               int var5 = 0;
               int var6 = 0;
               int var7 = 0;

               while(var1.aI() != aU.dT) {
                  String var8 = var1.aL();
                  int var9 = var1.aR();
                  if ("year".equals(var8)) {
                     var2 = var9;
                  } else if ("month".equals(var8)) {
                     var3 = var9;
                  } else if ("dayOfMonth".equals(var8)) {
                     var4 = var9;
                  } else if ("hourOfDay".equals(var8)) {
                     var5 = var9;
                  } else if ("minute".equals(var8)) {
                     var6 = var9;
                  } else if ("second".equals(var8)) {
                     var7 = var9;
                  }
               }

               var1.aH();
               return new GregorianCalendar(var2, var3, var4, var5, var6, var7);
            }
         }

         public void a(aV var1, Calendar var2) throws IOException {
            if (var2 == null) {
               var1.be();
            } else {
               var1.bc();
               var1.s("year");
               var1.b((long)var2.get(1));
               var1.s("month");
               var1.b((long)var2.get(2));
               var1.s("dayOfMonth");
               var1.b((long)var2.get(5));
               var1.s("hourOfDay");
               var1.b((long)var2.get(11));
               var1.s("minute");
               var1.b((long)var2.get(12));
               var1.s("second");
               var1.b((long)var2.get(13));
               var1.bd();
            }
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.E(var1);
         }
      };
      di = b(Calendar.class, GregorianCalendar.class, dh);
      dj = new ac<Locale>() {
         public Locale F(aT var1) throws IOException {
            if (var1.aI() == aU.dY) {
               var1.aO();
               return null;
            } else {
               String var2 = var1.aM();
               StringTokenizer var3 = new StringTokenizer(var2, "_");
               String var4 = null;
               String var5 = null;
               String var6 = null;
               if (var3.hasMoreElements()) {
                  var4 = var3.nextToken();
               }

               if (var3.hasMoreElements()) {
                  var5 = var3.nextToken();
               }

               if (var3.hasMoreElements()) {
                  var6 = var3.nextToken();
               }

               if (var5 == null && var6 == null) {
                  return new Locale(var4);
               } else {
                  return var6 == null ? new Locale(var4, var5) : new Locale(var4, var5, var6);
               }
            }
         }

         public void a(aV var1, Locale var2) throws IOException {
            var1.t(var2 == null ? null : var2.toString());
         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.F(var1);
         }
      };
      dk = a(Locale.class, dj);
      dl = new ac<P>() {
         private P c(aT var1, aU var2) throws IOException {
            switch (var2) {
               case dQ:
                  var1.aE();
                  return new M();
               case dS:
                  var1.aG();
                  return new S();
               default:
                  return null;
            }
         }

         private P d(aT var1, aU var2) throws IOException {
            switch (var2) {
               case dW:
                  String var3 = var1.aM();
                  return new U(new ap(var3));
               case dV:
                  return new U(var1.aM());
               case dX:
                  return new U(var1.aN());
               case dQ:
               case dS:
               default:
                  throw new IllegalStateException("Unexpected token: " + var2);
               case dY:
                  var1.aO();
                  return R.aY;
            }
         }

         public P G(aT var1) throws IOException {
            if (var1 instanceof aC) {
               return ((aC)var1).aS();
            } else {
               aU var3 = var1.aI();
               P var2 = this.c(var1, var3);
               if (var2 == null) {
                  return this.d(var1, var3);
               } else {
                  ArrayDeque var4 = new ArrayDeque();

                  while(true) {
                     while(!var1.hasNext()) {
                        if (var2 instanceof M) {
                           var1.aF();
                        } else {
                           var1.aH();
                        }

                        if (var4.isEmpty()) {
                           return var2;
                        }

                        var2 = (P)var4.removeLast();
                     }

                     String var5 = null;
                     if (var2 instanceof S) {
                        var5 = var1.aL();
                     }

                     var3 = var1.aI();
                     P var6 = this.c(var1, var3);
                     boolean var7 = var6 != null;
                     if (var6 == null) {
                        var6 = this.d(var1, var3);
                     }

                     if (var2 instanceof M) {
                        ((M)var2).a(var6);
                     } else {
                        ((S)var2).a(var5, var6);
                     }

                     if (var7) {
                        var4.addLast(var2);
                        var2 = var6;
                     }
                  }
               }
            }
         }

         public void a(aV var1, P var2) throws IOException {
            if (var2 != null && !var2.ag()) {
               if (var2.af()) {
                  U var3 = var2.aj();
                  if (var3.al()) {
                     var1.a(var3.X());
                  } else if (var3.ak()) {
                     var1.h(var3.ac());
                  } else {
                     var1.t(var3.Y());
                  }
               } else if (var2.ad()) {
                  var1.ba();

                  for(P var4 : var2.ai()) {
                     this.a(var1, var4);
                  }

                  var1.bb();
               } else {
                  if (!var2.ae()) {
                     throw new IllegalArgumentException("Couldn't write " + var2.getClass());
                  }

                  var1.bc();

                  for(Map.Entry var7 : var2.ah().entrySet()) {
                     var1.s((String)var7.getKey());
                     this.a(var1, (P)var7.getValue());
                  }

                  var1.bd();
               }
            } else {
               var1.be();
            }

         }

         // $FF: synthetic method
         public Object b(aT var1) throws IOException {
            return this.G(var1);
         }
      };
      dm = b(P.class, dl);
      dn = new ad() {
         public <T> ac<T> a(K var1, aS<T> var2) {
            Class var3 = var2.bk();
            if (Enum.class.isAssignableFrom(var3) && var3 != Enum.class) {
               if (!var3.isEnum()) {
                  var3 = var3.getSuperclass();
               }

               a var4 = new a(var3);
               return var4;
            } else {
               return null;
            }
         }
      };
   }

   static final class a<T extends Enum<T>> extends ac<T> {
      private final Map<String, T> nameToConstant = new HashMap();
      private final Map<String, T> stringToConstant = new HashMap();
      private final Map<T, String> constantToName = new HashMap();

      public a(final Class<T> var1) {
         try {
            Field[] var2 = (Field[])AccessController.doPrivileged(new PrivilegedAction<Field[]>() {
               public Field[] bi() {
                  Field[] var1x = var1.getDeclaredFields();
                  ArrayList var2 = new ArrayList(var1x.length);

                  for(Field var6 : var1x) {
                     if (var6.isEnumConstant()) {
                        var2.add(var6);
                     }
                  }

                  Field[] var7 = (Field[])var2.toArray(new Field[0]);
                  AccessibleObject.setAccessible(var7, true);
                  return var7;
               }

               // $FF: synthetic method
               public Object run() {
                  return this.bi();
               }
            });

            for(Field var6 : var2) {
               Enum var7 = (Enum)var6.get((Object)null);
               String var8 = var7.name();
               String var9 = var7.toString();
               ag var10 = (ag)var6.getAnnotation(ag.class);
               if (var10 != null) {
                  var8 = var10.as();

                  for(String var14 : var10.at()) {
                     this.nameToConstant.put(var14, var7);
                  }
               }

               this.nameToConstant.put(var8, var7);
               this.stringToConstant.put(var9, var7);
               this.constantToName.put(var7, var8);
            }

         } catch (IllegalAccessException var15) {
            throw new AssertionError(var15);
         }
      }

      public T K(aT var1) throws IOException {
         if (var1.aI() == aU.dY) {
            var1.aO();
            return null;
         } else {
            String var2 = var1.aM();
            Enum var3 = (Enum)this.nameToConstant.get(var2);
            return (T)(var3 == null ? (Enum)this.stringToConstant.get(var2) : var3);
         }
      }

      public void a(aV var1, T var2) throws IOException {
         var1.t(var2 == null ? null : (String)this.constantToName.get(var2));
      }

      // $FF: synthetic method
      public Object b(aT var1) throws IOException {
         return this.K(var1);
      }
   }
}
