import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class dT implements Listener {
   private final CorruptedSMPPlugin ro;

   public dT(CorruptedSMPPlugin var1) {
      this.ro = var1;
   }

   @EventHandler
   public void b(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof Player var5) {
            if (this.ro.j().a(var1)) {
               if (this.ro.d().b(var2)) {
                  if (this.ro.d().c(var2) == l.A) {
                     D var6 = this.ro.f().g(var2.getUniqueId());
                     var6.K();
                     if (var6.J() == 15) {
                        var5.setFireTicks(200);
                        var5.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 0, false, true));
                        var2.sendMessage("§9§lBLUE FIRE! §7Applied radioactive fire!");
                        var6.L();
                     }

                     if (var5.getFireTicks() > 0) {
                        var1.setDamage(var1.getDamage() * 1.3);
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void e(EntityDamageEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.ro.d().b(var2)) {
            if (this.ro.d().c(var2) == l.A) {
               if (var2.isInWater()) {
                  var1.setDamage(var1.getDamage() * 1.3);
               }

            }
         }
      }
   }

   @EventHandler
   public void h(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getEntity();
      if (var3 instanceof Player var2) {
         if (this.ro.d().b(var2)) {
            if (this.ro.d().c(var2) == l.A) {
               if (var2.isBlocking()) {
                  ItemStack var8 = var2.getInventory().getItemInMainHand();
                  if (var8.getType() == Material.SHIELD) {
                     ItemMeta var4 = var8.getItemMeta();
                     if (var4 instanceof Damageable) {
                        Damageable var5 = (Damageable)var4;
                        int var6 = var5.getDamage();
                        var5.setDamage(var6 + 3);
                        var8.setItemMeta(var4);
                        var2.getWorld().spawnParticle(Particle.FLAME, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 5, 0.3, 0.3, 0.3, 0.02);
                     }
                  }

                  ItemStack var9 = var2.getInventory().getItemInOffHand();
                  if (var9.getType() == Material.SHIELD) {
                     ItemMeta var10 = var9.getItemMeta();
                     if (var10 instanceof Damageable) {
                        Damageable var11 = (Damageable)var10;
                        int var7 = var11.getDamage();
                        var11.setDamage(var7 + 3);
                        var9.setItemMeta(var10);
                        var2.getWorld().spawnParticle(Particle.FLAME, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 5, 0.3, 0.3, 0.3, 0.02);
                     }
                  }
               }

            }
         }
      }
   }
}
