import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

public class C {
   private final CorruptedSMPPlugin ab;

   public C(CorruptedSMPPlugin var1) {
      this.ab = var1;
   }

   public void x() {
      for(l var4 : l.values()) {
         ItemStack[] var5 = B.b(var4, this.ab);
         this.a(var4, var5);
      }

      this.ab.getLogger().info("Registered 9 corruption crafting recipes!");
   }

   public void a(l var1, ItemStack[] var2) {
      ItemStack var3 = this.f(var1);
      NamespacedKey var4 = new NamespacedKey(this.ab, var1.name().toLowerCase() + "_corruption");
      ShapedRecipe var5 = new ShapedRecipe(var4, var3);
      var5.shape(new String[]{"ABC", "DEF", "GHI"});
      char[] var6 = new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'};

      for(int var7 = 0; var7 < 9; ++var7) {
         if (var2[var7] != null && var2[var7].getType() != Material.AIR) {
            var5.setIngredient(var6[var7], var2[var7].getType());
         } else {
            var5.setIngredient(var6[var7], Material.AIR);
         }
      }

      this.ab.getServer().addRecipe(var5);
   }

   public void e(l var1) {
      NamespacedKey var2 = new NamespacedKey(this.ab, var1.name().toLowerCase() + "_corruption");
      this.ab.getServer().removeRecipe(var2);
   }

   private ItemStack f(l var1) {
      ItemStack var2 = new ItemStack(Material.PAPER);
      ItemMeta var3 = var2.getItemMeta();
      if (var3 != null) {
         var3.setDisplayName(var1.o() + " §fCore");
         var3.setLore(j.b(var1));
         var3.setCustomModelData(var1.n());
         var2.setItemMeta(var3);
      }

      return var2;
   }

   public void y() {
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "health_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "ocean_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "invincibility_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "velocity_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "fire_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "breeze_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "ender_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "darkness_corruption"));
      this.ab.getServer().removeRecipe(new NamespacedKey(this.ab, "clown_corruption"));
   }
}
