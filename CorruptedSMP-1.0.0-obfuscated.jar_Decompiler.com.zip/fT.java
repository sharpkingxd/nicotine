import java.io.Serializable;

public class fT {
   public static final class a implements Serializable {
      public int sP;

      public String toString() {
         return String.valueOf(this.sP);
      }
   }

   public static final class b<T> implements Serializable {
      public T sQ;

      public String toString() {
         return String.valueOf(this.sQ);
      }
   }
}
