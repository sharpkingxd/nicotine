import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public interface cz {
   a ou = cz.a.$$INSTANCE;
   cz ov = new a.a();

   dA a(File var1) throws FileNotFoundException;

   dy b(File var1) throws FileNotFoundException;

   dy c(File var1) throws FileNotFoundException;

   void d(File var1) throws IOException;

   boolean e(File var1);

   long f(File var1);

   void a(File var1, File var2) throws IOException;

   void g(File var1) throws IOException;

   public static final class a {
      // $FF: synthetic field
      static final a $$INSTANCE = new a();

      private a() {
      }

      static final class a implements cz {
         public a() {
         }

         public dA a(File var1) throws FileNotFoundException {
            fR.c(var1, (String)"");
            return do.i(var1);
         }

         public dy b(File var1) throws FileNotFoundException {
            fR.c(var1, (String)"");

            dy var2;
            try {
               var2 = do.a(var1, false, 1, (Object)null);
            } catch (FileNotFoundException var4) {
               var1.getParentFile().mkdirs();
               var2 = do.a(var1, false, 1, (Object)null);
            }

            return var2;
         }

         public dy c(File var1) throws FileNotFoundException {
            fR.c(var1, (String)"");

            dy var2;
            try {
               var2 = do.h(var1);
            } catch (FileNotFoundException var4) {
               var1.getParentFile().mkdirs();
               var2 = do.h(var1);
            }

            return var2;
         }

         public void d(File var1) throws IOException {
            fR.c(var1, (String)"");
            if (!var1.delete() && var1.exists()) {
               throw new IOException("failed to delete " + var1);
            }
         }

         public boolean e(File var1) {
            fR.c(var1, (String)"");
            return var1.exists();
         }

         public long f(File var1) {
            fR.c(var1, (String)"");
            return var1.length();
         }

         public void a(File var1, File var2) throws IOException {
            fR.c(var1, (String)"");
            fR.c(var2, (String)"");
            this.d(var2);
            if (!var1.renameTo(var2)) {
               throw new IOException("failed to rename " + var1 + " to " + var2);
            }
         }

         public void g(File var1) throws IOException {
            fR.c(var1, (String)"");
            File[] var10000 = var1.listFiles();
            if (var10000 == null) {
               throw new IOException("not a readable directory: " + var1);
            } else {
               File[] var2 = var10000;
               int var3 = 0;

               for(int var4 = var2.length; var3 < var4; ++var3) {
                  File var5 = var2[var3];
                  if (var5.isDirectory()) {
                     fR.b(var5, "");
                     this.g(var5);
                  }

                  if (!var5.delete()) {
                     throw new IOException("failed to delete " + var5);
                  }
               }

            }
         }

         public String toString() {
            return "FileSystem.SYSTEM";
         }
      }
   }
}
