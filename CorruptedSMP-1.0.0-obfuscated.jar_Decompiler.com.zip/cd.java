public final class cd {
   public static final cd lR = new cd();

   private cd() {
   }

   public final boolean az(String var1) {
      fR.c(var1, (String)"");
      return fR.c(var1, (Object)"POST") || fR.c(var1, (Object)"PATCH") || fR.c(var1, (Object)"PUT") || fR.c(var1, (Object)"DELETE") || fR.c(var1, (Object)"MOVE");
   }

   public static final boolean aA(String var0) {
      fR.c(var0, (String)"");
      return fR.c(var0, (Object)"POST") || fR.c(var0, (Object)"PUT") || fR.c(var0, (Object)"PATCH") || fR.c(var0, (Object)"PROPPATCH") || fR.c(var0, (Object)"REPORT");
   }

   public static final boolean aB(String var0) {
      fR.c(var0, (String)"");
      return !fR.c(var0, (Object)"GET") && !fR.c(var0, (Object)"HEAD");
   }

   public final boolean aC(String var1) {
      fR.c(var1, (String)"");
      return fR.c(var1, (Object)"PROPFIND");
   }

   public final boolean aD(String var1) {
      fR.c(var1, (String)"");
      return !fR.c(var1, (Object)"PROPFIND");
   }
}
