import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class bm {
   private int hA = 64;
   private int hB = 5;
   private Runnable hC;
   private ExecutorService hD;
   private final ArrayDeque<bS.a> hE = new ArrayDeque();
   private final ArrayDeque<bS.a> hF = new ArrayDeque();
   private final ArrayDeque<bS> hG = new ArrayDeque();

   public final synchronized ExecutorService cJ() {
      if (this.hD == null) {
         this.hD = (ExecutorService)(new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, (BlockingQueue)(new SynchronousQueue()), bD.a(bD.jo + " Dispatcher", false)));
      }

      ExecutorService var10000 = this.hD;
      fR.m(var10000);
      return var10000;
   }

   private final boolean cK() {
      boolean var2 = false;
      if (bD.jn && Thread.holdsLock(this)) {
         throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
      } else {
         List var1 = (List)(new ArrayList());
         var2 = false;
         synchronized(this) {
            boolean var4 = false;
            Iterator var10000 = this.hE.iterator();
            fR.b(var10000, "");
            Iterator var5 = var10000;

            while(var5.hasNext()) {
               bS.a var6 = (bS.a)var5.next();
               if (this.hF.size() >= this.hA) {
                  break;
               }

               if (var6.hf().get() < this.hB) {
                  var5.remove();
                  var6.hf().incrementAndGet();
                  fR.b(var6, "");
                  var1.add(var6);
                  this.hF.add(var6);
               }
            }

            var2 = this.cL() > 0;
            eE var10 = eE.sk;
         }

         int var3 = 0;

         for(int var11 = var1.size(); var3 < var11; ++var3) {
            bS.a var12 = (bS.a)var1.get(var3);
            var12.a(this.cJ());
         }

         return var2;
      }
   }

   public final synchronized void a(bS var1) {
      fR.c(var1, (String)"");
      this.hG.add(var1);
   }

   public final void a(bS.a var1) {
      fR.c(var1, (String)"");
      var1.hf().decrementAndGet();
      this.a((Deque)this.hF, var1);
   }

   public final void b(bS var1) {
      fR.c(var1, (String)"");
      this.a((Deque)this.hG, var1);
   }

   private final <T> void a(Deque<T> var1, T var2) {
      Runnable var3 = null;
      synchronized(this){}

      try {
         boolean var5 = false;
         if (!var1.remove(var2)) {
            throw new AssertionError("Call wasn't in-flight!");
         }

         var3 = this.hC;
         eE var9 = eE.sk;
      } finally {
         ;
      }

      boolean var4 = this.cK();
      if (!var4 && var3 != null) {
         var3.run();
      }

   }

   public final synchronized int cL() {
      return this.hF.size() + this.hG.size();
   }
}
