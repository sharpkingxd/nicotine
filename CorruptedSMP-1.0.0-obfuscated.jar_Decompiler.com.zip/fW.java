public final class fW {
   public static final fW sT = new fW();

   private fW() {
   }
}
