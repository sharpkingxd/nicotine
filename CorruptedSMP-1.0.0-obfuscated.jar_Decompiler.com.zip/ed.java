import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ed implements Listener {
   private final CorruptedSMPPlugin rA;

   public ed(CorruptedSMPPlugin var1) {
      this.rA = var1;
   }

   @EventHandler
   public void a(PlayerMoveEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.rA.d().b(var2)) {
         l var3 = this.rA.d().c(var2);
         if (var3 != null) {
            if (var3 == l.B && (var1.getFrom().getX() != var1.getTo().getX() || var1.getFrom().getZ() != var1.getTo().getZ())) {
               var2.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, 40, 1, false, false));
            }

         }
      }
   }
}
