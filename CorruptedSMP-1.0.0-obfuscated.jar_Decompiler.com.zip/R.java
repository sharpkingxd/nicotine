public final class R extends P {
   public static final R aY = new R();

   public int hashCode() {
      return R.class.hashCode();
   }

   public boolean equals(Object var1) {
      return var1 instanceof R;
   }
}
