import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;

final class dz extends dc {
   private final Socket qE;

   public dz(Socket var1) {
      fR.c(var1, (String)"");
      super();
      this.qE = var1;
   }

   protected IOException m(IOException var1) {
      SocketTimeoutException var2 = new SocketTimeoutException("timeout");
      if (var1 != null) {
         var2.initCause((Throwable)var1);
      }

      return (IOException)var2;
   }

   protected void hh() {
      try {
         this.qE.close();
      } catch (Exception var2) {
         dp.lD().log(Level.WARNING, "Failed to close timed out socket " + this.qE, (Throwable)var2);
      } catch (AssertionError var3) {
         if (!do.a(var3)) {
            throw var3;
         }

         dp.lD().log(Level.WARNING, "Failed to close timed out socket " + this.qE, (Throwable)var3);
      }

   }
}
