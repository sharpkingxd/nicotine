import java.io.IOException;

public interface cb {
   a lO = cb.a.$$INSTANCE;

   bT gU();

   dy a(bw var1, long var2) throws IOException;

   void g(bw var1) throws IOException;

   void gI() throws IOException;

   void gJ() throws IOException;

   by.a r(boolean var1) throws IOException;

   long l(by var1) throws IOException;

   dA m(by var1) throws IOException;

   void gM();

   public static final class a {
      // $FF: synthetic field
      static final a $$INSTANCE = new a();
      public static final int DISCARD_STREAM_TIMEOUT_MILLIS = 100;

      private a() {
      }
   }
}
