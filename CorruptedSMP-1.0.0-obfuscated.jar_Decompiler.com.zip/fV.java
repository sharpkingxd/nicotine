public class fV {
   public String a(fS var1) {
      return this.a((fQ)var1);
   }

   public String a(fQ var1) {
      String var2 = var1.getClass().getGenericInterfaces()[0].toString();
      return var2.startsWith("kotlin.jvm.functions.") ? var2.substring("kotlin.jvm.functions.".length()) : var2;
   }
}
