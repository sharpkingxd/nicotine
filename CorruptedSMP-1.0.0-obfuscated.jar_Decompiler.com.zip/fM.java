import java.util.Iterator;
import java.util.NoSuchElementException;

final class fM<T> implements fY, Iterator<T> {
   private final T[] sN;
   private int lU;

   public fM(T[] var1) {
      fR.c(var1, (String)"");
      super();
      this.sN = (T[])var1;
   }

   public boolean hasNext() {
      return this.lU < this.sN.length;
   }

   public T next() {
      try {
         Object[] var10000 = this.sN;
         int var1 = this.lU++;
         Object var4 = var10000[var1];
         return (T)var4;
      } catch (ArrayIndexOutOfBoundsException var3) {
         --this.lU;
         throw new NoSuchElementException(var3.getMessage());
      }
   }

   public void remove() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }
}
