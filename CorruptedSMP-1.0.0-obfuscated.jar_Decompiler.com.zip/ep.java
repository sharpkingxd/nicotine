import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ep {
   private static final Map<UUID, Map<l, ItemStack[]>> sc = new HashMap();

   public static void e(Player var0, CorruptedSMPPlugin var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 27, "§8§lRecipe Editor");
      int var3 = 10;

      for(l var7 : l.values()) {
         ItemStack var8 = a(var7);
         var2.setItem(var3, var8);
         ++var3;
         if (var3 == 17) {
            var3 = 19;
         }
      }

      ItemStack var9 = new ItemStack(Material.WRITABLE_BOOK);
      ItemMeta var10 = var9.getItemMeta();
      if (var10 != null) {
         var10.setDisplayName("§e§lRecipe Editor");
         ArrayList var11 = new ArrayList();
         var11.add("§7Click on any corruption core");
         var11.add("§7to edit its crafting recipe!");
         var11.add("");
         var11.add("§c§lWARNING:");
         var11.add("§7Changes affect all players!");
         var10.setLore(var11);
         var9.setItemMeta(var10);
      }

      var2.setItem(22, var9);
      var0.openInventory(var2);
   }

   public static void a(Player var0, l var1, CorruptedSMPPlugin var2) {
      Inventory var3 = Bukkit.createInventory((InventoryHolder)null, 54, "§8§lEdit: " + var1.o());
      ItemStack[] var4 = B.b(var1, var2);
      UUID var5 = var0.getUniqueId();
      if (sc.containsKey(var5) && ((Map)sc.get(var5)).containsKey(var1)) {
         var4 = (ItemStack[])((Map)sc.get(var5)).get(var1);
      }

      var3.setItem(10, var4[0]);
      var3.setItem(11, var4[1]);
      var3.setItem(12, var4[2]);
      var3.setItem(19, var4[3]);
      var3.setItem(20, var4[4]);
      var3.setItem(21, var4[5]);
      var3.setItem(28, var4[6]);
      var3.setItem(29, var4[7]);
      var3.setItem(30, var4[8]);
      ItemStack var6 = new ItemStack(Material.ARROW);
      ItemMeta var7 = var6.getItemMeta();
      if (var7 != null) {
         var7.setDisplayName("§e§lCrafts Into →");
         var6.setItemMeta(var7);
      }

      var3.setItem(23, var6);
      ItemStack var8 = a(var1);
      var3.setItem(25, var8);
      ItemStack var9 = new ItemStack(Material.LIME_CONCRETE);
      ItemMeta var10 = var9.getItemMeta();
      if (var10 != null) {
         var10.setDisplayName("§a§l✔ SAVE RECIPE");
         ArrayList var11 = new ArrayList();
         var11.add("§7Click to save this recipe");
         var11.add("§7and apply it to the server!");
         var11.add("");
         var11.add("§eThis will update:");
         var11.add("§7• Crafting table recipes");
         var11.add("§7• /recipes GUI display");
         var10.setLore(var11);
         var9.setItemMeta(var10);
      }

      var3.setItem(48, var9);
      ItemStack var18 = new ItemStack(Material.ORANGE_CONCRETE);
      ItemMeta var12 = var18.getItemMeta();
      if (var12 != null) {
         var12.setDisplayName("§6§l↻ RESET TO DEFAULT");
         ArrayList var13 = new ArrayList();
         var13.add("§7Click to restore the");
         var13.add("§7original default recipe");
         var12.setLore(var13);
         var18.setItemMeta(var12);
      }

      var3.setItem(49, var18);
      ItemStack var19 = new ItemStack(Material.RED_CONCRETE);
      ItemMeta var14 = var19.getItemMeta();
      if (var14 != null) {
         var14.setDisplayName("§c§l✖ CANCEL");
         ArrayList var15 = new ArrayList();
         var15.add("§7Discard changes and");
         var15.add("§7return to main menu");
         var14.setLore(var15);
         var19.setItemMeta(var14);
      }

      var3.setItem(50, var19);
      ItemStack var20 = new ItemStack(Material.BOOK);
      ItemMeta var16 = var20.getItemMeta();
      if (var16 != null) {
         var16.setDisplayName("§e§lHow to Edit");
         ArrayList var17 = new ArrayList();
         var17.add("§71. §fPlace items from your");
         var17.add("§7   inventory into the 3x3 grid");
         var17.add("");
         var17.add("§72. §fArrange them in the");
         var17.add("§7   desired crafting pattern");
         var17.add("");
         var17.add("§73. §fClick §a§lSAVE §7to apply");
         var17.add("");
         var17.add("§7• Use §6RESET §7for default recipe");
         var17.add("§7• Use §cCANCEL §7to discard changes");
         var16.setLore(var17);
         var20.setItemMeta(var16);
      }

      var3.setItem(16, var20);
      var0.openInventory(var3);
   }

   public static void a(Player var0, l var1, ItemStack[] var2) {
      UUID var3 = var0.getUniqueId();
      sc.putIfAbsent(var3, new HashMap());
      ((Map)sc.get(var3)).put(var1, var2);
   }

   public static void i(Player var0, l var1) {
      UUID var2 = var0.getUniqueId();
      if (sc.containsKey(var2)) {
         ((Map)sc.get(var2)).remove(var1);
         if (((Map)sc.get(var2)).isEmpty()) {
            sc.remove(var2);
         }
      }

   }

   private static ItemStack a(l var0) {
      ItemStack var1 = new ItemStack(Material.FLOW_BANNER_PATTERN);
      ItemMeta var2 = var1.getItemMeta();
      if (var2 != null) {
         var2.setDisplayName(var0.o());
         var2.setCustomModelData(var0.n());
         ArrayList var3 = new ArrayList();
         var3.add("§7Click to edit recipe!");
         var2.setLore(var3);
         var2.addEnchant(Enchantment.UNBREAKING, 1, true);
         var2.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         var1.setItemMeta(var2);
      }

      return var1;
   }
}
