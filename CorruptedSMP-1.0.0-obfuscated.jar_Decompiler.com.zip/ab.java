import java.io.IOException;

public interface ab {
   Number h(aT var1) throws IOException;
}
