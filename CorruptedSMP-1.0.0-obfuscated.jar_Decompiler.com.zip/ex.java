class ex {
   public static final <T> ev<T> a(fJ<? extends T> var0) {
      fR.c(var0, (String)"");
      return new eA<T>(var0, (Object)null, 2, (fP)null);
   }
}
