public final class cq$j extends bK {
   // $FF: synthetic field
   final cq this$0;
   // $FF: synthetic field
   final long $pingIntervalNanos$inlined;

   public cq$j(String var1, cq var2, long var3) {
      super(var1, false, 2, (fP)null);
      this.this$0 = var2;
      this.$pingIntervalNanos$inlined = var3;
   }

   public long gg() {
      // $FF: Couldn't be decompiled
   }
}
