import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class t {
   public static void b(Player var0, CorruptedSMPPlugin var1) {
      double var2 = var0.getHealth();
      double var4 = var0.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
      if (var2 < (double)14.0F) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, false));
      }

      if (var2 < (double)8.0F) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 40, 0, false, false));
      }

      if (var0.hasPotionEffect(PotionEffectType.REGENERATION)) {
         var0.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 2, false, false));
      }

   }
}
