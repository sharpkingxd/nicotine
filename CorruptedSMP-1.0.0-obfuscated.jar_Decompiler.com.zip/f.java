import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class f {
   public static boolean a(final Player var0, final CorruptedSMPPlugin var1) {
      final D var2 = var1.f().g(var0.getUniqueId());
      var2.b(true);
      var0.sendMessage("§f§l☁ TORNADO ACTIVATED!");
      var0.sendMessage("§7- Spawning tornado on target");
      var0.sendMessage("§7- Lifts target into the sky");
      var0.sendMessage("§7- Throws them with massive knockback");
      final Player var3 = null;
      double var4 = (double)10.0F;
      Vector var6 = var0.getEyeLocation().getDirection();
      Location var7 = var0.getEyeLocation();

      for(double var8 = (double)0.0F; var8 <= var4; var8 += (double)0.5F) {
         Location var10 = var7.clone().add(var6.clone().multiply(var8));

         for(Entity var12 : var10.getWorld().getNearbyEntities(var10, (double)0.5F, (double)0.5F, (double)0.5F)) {
            if (var12 instanceof Player var13) {
               if (!var13.equals(var0)) {
                  var3 = var13;
                  break;
               }
            }
         }

         if (var3 != null) {
            break;
         }
      }

      if (var3 == null) {
         double var15 = var4;

         for(Entity var18 : var0.getNearbyEntities(var4, var4, var4)) {
            if (var18 instanceof Player) {
               Player var20 = (Player)var18;
               if (!var20.equals(var0)) {
                  double var21 = var0.getLocation().distance(var20.getLocation());
                  if (var21 < var15) {
                     var3 = var20;
                     var15 = var21;
                  }
               }
            }
         }
      }

      if (var3 == null) {
         var0.sendMessage("§c§lNo target found within 10 blocks!");
         var2.b(false);
         return false;
      } else {
         final Location var9 = var3.getLocation().clone();
         final Random var17 = new Random();
         var0.sendMessage("§a§lTornado spawned on " + var3.getName() + "!");
         var3.sendMessage("§c§l✗ You've been caught in a TORNADO!");
         var3.sendMessage("§c§l✗ Teleportation disabled!");
         var2.a("inTornado", true);
         var1.f().g(var3.getUniqueId()).a("inTornado", true);
         (new BukkitRunnable() {
            int ticks = 0;
            double currentHeight = (double)0.0F;
            final double maxHeight = (double)15.0F;
            final double radius = (double)2.5F;
            double angle = (double)0.0F;

            public void run() {
               if (this.ticks >= 200) {
                  var1.f().g(var3.getUniqueId()).j("inTornado");
                  var2.b(false);
                  Vector var30 = new Vector((var17.nextDouble() - (double)0.5F) * (double)4.0F, (double)2.5F, (var17.nextDouble() - (double)0.5F) * (double)4.0F);
                  var3.setVelocity(var30);
                  var3.getWorld().spawnParticle(Particle.EXPLOSION, var3.getLocation(), 10, (double)2.0F, (double)2.0F, (double)2.0F, (double)0.0F);
                  var3.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, var3.getLocation(), 5);
                  var3.getWorld().playSound(var3.getLocation(), Sound.ENTITY_WIND_CHARGE_WIND_BURST, 2.0F, 0.5F);
                  var3.sendMessage("§c§l✗ The tornado threw you away!");
                  var0.sendMessage("§a§lTornado ended!");
                  var2.b(false);
                  this.cancel();
               } else {
                  this.currentHeight = (double)this.ticks / (double)200.0F * (double)15.0F;
                  this.angle += (double)15.0F;
                  if (this.angle >= (double)360.0F) {
                     this.angle -= (double)360.0F;
                  }

                  double var1x = Math.toRadians(this.angle);
                  double var3x = (double)2.5F * ((double)1.0F - this.currentHeight / (double)15.0F * (double)0.5F);
                  double var5 = var9.getX() + var3x * Math.cos(var1x);
                  double var7 = var9.getZ() + var3x * Math.sin(var1x);
                  double var9x = var9.getY() + this.currentHeight;
                  Location var11 = new Location(var9.getWorld(), var5, var9x, var7);
                  var11.setYaw(var3.getLocation().getYaw());
                  var11.setPitch(var3.getLocation().getPitch());
                  var3.teleport(var11);

                  for(double var12 = (double)0.0F; var12 <= this.currentHeight + (double)2.0F; var12 += (double)0.5F) {
                     double var14 = var12 / (double)15.0F;
                     double var16 = (double)2.5F * ((double)1.0F - var14 * 0.3);

                     for(int var18 = 0; var18 < 3; ++var18) {
                        double var19 = this.angle + (double)(var18 * 120) + var12 * (double)20.0F;
                        double var21 = Math.toRadians(var19);
                        double var23 = var9.getX() + var16 * Math.cos(var21);
                        double var25 = var9.getZ() + var16 * Math.sin(var21);
                        double var27 = var9.getY() + var12;
                        Location var29 = new Location(var9.getWorld(), var23, var27, var25);
                        var9.getWorld().spawnParticle(Particle.END_ROD, var29, 1, 0.05, 0.05, 0.05, 0.01);
                        if (var12 % (double)1.0F == (double)0.0F) {
                           var9.getWorld().spawnParticle(Particle.CLOUD, var29, 2, 0.1, 0.1, 0.1, 0.02);
                        }

                        if (var18 == 0 && var12 % (double)1.5F == (double)0.0F) {
                           var9.getWorld().spawnParticle(Particle.GUST, var29, 1, 0.1, 0.1, 0.1, 0.05);
                        }
                     }
                  }

                  for(int var31 = 0; var31 < 360; var31 += 20) {
                     double var13 = Math.toRadians((double)(var31 + this.ticks * 10));
                     double var15 = var9.getX() + (double)3.75F * Math.cos(var13);
                     double var17x = var9.getZ() + (double)3.75F * Math.sin(var13);
                     Location var36 = new Location(var9.getWorld(), var15, var9.getY() + 0.2, var17x);
                     var9.getWorld().spawnParticle(Particle.SWEEP_ATTACK, var36, 1);
                     var9.getWorld().spawnParticle(Particle.CLOUD, var36, 1, 0.1, 0.1, 0.1, 0.01);
                  }

                  if (this.ticks % 3 == 0) {
                     for(int var32 = 0; var32 < 5; ++var32) {
                        double var33 = var9.getX() + (var17.nextDouble() - (double)0.5F) * (double)2.5F * (double)2.0F;
                        double var34 = var9.getZ() + (var17.nextDouble() - (double)0.5F) * (double)2.5F * (double)2.0F;
                        double var35 = var9.getY() + var17.nextDouble() * this.currentHeight;
                        Location var37 = new Location(var9.getWorld(), var33, var35, var34);
                        var9.getWorld().spawnParticle(Particle.ITEM, var37, 1, 0.1, 0.1, 0.1, 0.05, new ItemStack(Material.DIRT));
                     }
                  }

                  var9.getWorld().spawnParticle(Particle.GUST, var3.getLocation(), 5, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                  var9.getWorld().spawnParticle(Particle.CLOUD, var3.getLocation(), 3, 0.3, 0.3, 0.3, 0.05);
                  if (this.ticks % 20 == 0) {
                     var3.damage((double)3.0F);
                     var3.sendMessage("§7§o*The tornado is tearing you apart!*");
                  }

                  if (this.ticks % 30 == 0) {
                     var9.getWorld().playSound(var9, Sound.ENTITY_BREEZE_WIND_BURST, 1.5F, 0.8F);
                  }

                  if (this.ticks % 40 == 0) {
                     var9.getWorld().playSound(var9, Sound.ITEM_ELYTRA_FLYING, 1.0F, 0.6F);
                  }

                  ++this.ticks;
               }
            }
         }).runTaskTimer(var1, 0L, 1L);
         var1.getServer().getScheduler().runTaskLater(var1, () -> var2.j("inTornado"), 200L);
         var0.playSound(var0.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 2.0F, 1.0F);
         var0.getWorld().playSound(var9, Sound.ENTITY_WIND_CHARGE_WIND_BURST, 2.0F, 0.8F);
         String var19 = var1.getConfig().getString("messages.ability-activated").replace("{ability}", "Tornado");
         var0.sendMessage(a(var19, var1));
         return true;
      }
   }

   private static String a(String var0, CorruptedSMPPlugin var1) {
      String var2 = var1.getConfig().getString("messages.prefix", "");
      return (var2 + var0).replace("&", "§");
   }
}
