import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ca {
   private static final <undefinedtype> lL = new ThreadLocal<DateFormat>() {
      protected DateFormat hF() {
         SimpleDateFormat var1 = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US);
         boolean var3 = false;
         var1.setLenient(false);
         var1.setTimeZone(bD.jl);
         return (DateFormat)var1;
      }

      // $FF: synthetic method
      public Object initialValue() {
         return this.hF();
      }
   };
   private static final String[] lM;
   private static final DateFormat[] lN;

   public static final Date ay(String var0) {
      fR.c(var0, (String)"");
      if (((CharSequence)var0).length() == 0) {
         return null;
      } else {
         ParsePosition var1 = new ParsePosition(0);
         Object var2 = null;
         Date var14 = ((DateFormat)lL.get()).parse(var0, var1);
         if (var1.getIndex() == var0.length()) {
            return var14;
         } else {
            String[] var3 = lM;
            synchronized(var3){}

            try {
               boolean var4 = false;
               int var5 = 0;

               for(int var6 = lM.length; var5 < var6; ++var5) {
                  DateFormat var7 = lN[var5];
                  if (var7 == null) {
                     SimpleDateFormat var8 = new SimpleDateFormat(lM[var5], Locale.US);
                     boolean var10 = false;
                     var8.setTimeZone(bD.jl);
                     var7 = (DateFormat)var8;
                     lN[var5] = var7;
                  }

                  var1.setIndex(0);
                  var14 = var7.parse(var0, var1);
                  if (var1.getIndex() != 0) {
                     Date var11 = var14;
                     return var11;
                  }
               }

               eE var16 = eE.sk;
               return null;
            } finally {
               ;
            }
         }
      }
   }

   public static final String d(Date var0) {
      fR.c(var0, (String)"");
      String var10000 = ((DateFormat)lL.get()).format(var0);
      fR.b(var10000, "");
      return var10000;
   }

   static {
      String[] var0 = new String[]{"EEE, dd MMM yyyy HH:mm:ss zzz", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy", "EEE, dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MMM-yyyy HH-mm-ss z", "EEE, dd MMM yy HH:mm:ss z", "EEE dd-MMM-yyyy HH:mm:ss z", "EEE dd MMM yyyy HH:mm:ss z", "EEE dd-MMM-yyyy HH-mm-ss z", "EEE dd-MMM-yy HH:mm:ss z", "EEE dd MMM yy HH:mm:ss z", "EEE,dd-MMM-yy HH:mm:ss z", "EEE,dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MM-yyyy HH:mm:ss z", "EEE MMM d yyyy HH:mm:ss z"};
      lM = var0;
      lN = new DateFormat[lM.length];
   }
}
