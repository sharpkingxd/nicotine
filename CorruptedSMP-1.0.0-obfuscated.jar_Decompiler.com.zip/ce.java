import java.io.IOException;
import java.util.List;

public final class ce implements bs.a {
   private final bS lS;
   private final List<bs> lT;
   private final int lU;
   private final bQ lV;
   private final bw lW;
   private final int lX;
   private final int lY;
   private final int lZ;
   private int ma;

   public ce(bS var1, List<? extends bs> var2, int var3, bQ var4, bw var5, int var6, int var7, int var8) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var5, (String)"");
      super();
      this.lS = var1;
      this.lT = var2;
      this.lU = var3;
      this.lV = var4;
      this.lW = var5;
      this.lX = var6;
      this.lY = var7;
      this.lZ = var8;
   }

   public final bS hG() {
      return this.lS;
   }

   public final bQ hH() {
      return this.lV;
   }

   public final bw hI() {
      return this.lW;
   }

   public final int hJ() {
      return this.lX;
   }

   public final int hK() {
      return this.lY;
   }

   public final int hL() {
      return this.lZ;
   }

   public final ce a(int var1, bQ var2, bw var3, int var4, int var5, int var6) {
      fR.c(var3, (String)"");
      return new ce(this.lS, this.lT, var1, var2, var3, var4, var5, var6);
   }

   // $FF: synthetic method
   public static ce a(ce var0, int var1, bQ var2, bw var3, int var4, int var5, int var6, int var7, Object var8) {
      if ((var7 & 1) != 0) {
         var1 = var0.lU;
      }

      if ((var7 & 2) != 0) {
         var2 = var0.lV;
      }

      if ((var7 & 4) != 0) {
         var3 = var0.lW;
      }

      if ((var7 & 8) != 0) {
         var4 = var0.lX;
      }

      if ((var7 & 16) != 0) {
         var5 = var0.lY;
      }

      if ((var7 & 32) != 0) {
         var6 = var0.lZ;
      }

      return var0.a(var1, var2, var3, var4, var5, var6);
   }

   public int dT() {
      return this.lY;
   }

   public bb dt() {
      return this.lS;
   }

   public bw ds() {
      return this.lW;
   }

   public by c(bw var1) throws IOException {
      fR.c(var1, (String)"");
      if (this.lU >= this.lT.size()) {
         String var11 = "Check failed.";
         throw new IllegalStateException(var11.toString());
      } else {
         int var2 = this.ma++;
         if (this.lV != null) {
            if (!this.lV.gD().d(var1.eI())) {
               boolean var9 = false;
               String var10 = "network interceptor " + this.lT.get(this.lU - 1) + " must retain the same host and port";
               throw new IllegalStateException(var10.toString());
            }

            if (this.ma != 1) {
               boolean var7 = false;
               String var8 = "network interceptor " + this.lT.get(this.lU - 1) + " must call proceed() exactly once";
               throw new IllegalStateException(var8.toString());
            }
         }

         ce var6 = a(this, this.lU + 1, (bQ)null, var1, 0, 0, 0, 58, (Object)null);
         bs var3 = (bs)this.lT.get(this.lU);
         by var10000 = var3.a(var6);
         if (var10000 == null) {
            throw new NullPointerException("interceptor " + var3 + " returned null");
         } else {
            by var4 = var10000;
            if (this.lV != null && this.lU + 1 < this.lT.size() && var6.ma != 1) {
               boolean var13 = false;
               String var14 = "network interceptor " + var3 + " must call proceed() exactly once";
               throw new IllegalStateException(var14.toString());
            } else if (var4.eZ() == null) {
               boolean var5 = false;
               String var12 = "interceptor " + var3 + " returned a response with no body";
               throw new IllegalStateException(var12.toString());
            } else {
               return var4;
            }
         }
      }
   }
}
