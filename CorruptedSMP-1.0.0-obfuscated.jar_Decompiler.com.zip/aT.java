import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Objects;

public class aT implements Closeable {
   private final Reader dF;
   private boolean aL = false;
   private final char[] dG = new char[1024];
   private int dH = 0;
   private int dI = 0;
   private int dJ = 0;
   private int dK = 0;
   int dL = 0;
   private long dM;
   private int dN;
   private String dO;
   private int[] dP = new int[32];
   private int bM = 0;
   private String[] bN;
   private int[] bO;

   public aT(Reader var1) {
      this.dP[this.bM++] = 6;
      this.bN = new String[32];
      this.bO = new int[32];
      this.dF = (Reader)Objects.requireNonNull(var1, "in == null");
   }

   public final void i(boolean var1) {
      this.aL = var1;
   }

   public final boolean bm() {
      return this.aL;
   }

   public void aE() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 3) {
         this.e(1);
         this.bO[this.bM - 1] = 0;
         this.dL = 0;
      } else {
         throw new IllegalStateException("Expected BEGIN_ARRAY but was " + this.aI() + this.aX());
      }
   }

   public void aF() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 4) {
         --this.bM;
         int var10002 = this.bO[this.bM - 1]++;
         this.dL = 0;
      } else {
         throw new IllegalStateException("Expected END_ARRAY but was " + this.aI() + this.aX());
      }
   }

   public void aG() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 1) {
         this.e(3);
         this.dL = 0;
      } else {
         throw new IllegalStateException("Expected BEGIN_OBJECT but was " + this.aI() + this.aX());
      }
   }

   public void aH() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 2) {
         --this.bM;
         this.bN[this.bM] = null;
         int var10002 = this.bO[this.bM - 1]++;
         this.dL = 0;
      } else {
         throw new IllegalStateException("Expected END_OBJECT but was " + this.aI() + this.aX());
      }
   }

   public boolean hasNext() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      return var1 != 2 && var1 != 4 && var1 != 17;
   }

   public aU aI() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      switch (var1) {
         case 1:
            return aU.dS;
         case 2:
            return aU.dT;
         case 3:
            return aU.dQ;
         case 4:
            return aU.dR;
         case 5:
         case 6:
            return aU.dX;
         case 7:
            return aU.dY;
         case 8:
         case 9:
         case 10:
         case 11:
            return aU.dV;
         case 12:
         case 13:
         case 14:
            return aU.dU;
         case 15:
         case 16:
            return aU.dW;
         case 17:
            return aU.dZ;
         default:
            throw new AssertionError();
      }
   }

   int bn() throws IOException {
      int var1 = this.dP[this.bM - 1];
      if (var1 == 1) {
         this.dP[this.bM - 1] = 2;
      } else if (var1 == 2) {
         int var7 = this.j(true);
         switch (var7) {
            case 44:
               break;
            case 59:
               this.bs();
               break;
            case 93:
               return this.dL = 4;
            default:
               throw this.v("Unterminated array");
         }
      } else {
         if (var1 == 3 || var1 == 5) {
            this.dP[this.bM - 1] = 4;
            if (var1 == 5) {
               int var5 = this.j(true);
               switch (var5) {
                  case 44:
                     break;
                  case 59:
                     this.bs();
                     break;
                  case 125:
                     return this.dL = 2;
                  default:
                     throw this.v("Unterminated object");
               }
            }

            int var6 = this.j(true);
            switch (var6) {
               case 34:
                  return this.dL = 13;
               case 39:
                  this.bs();
                  return this.dL = 12;
               case 125:
                  if (var1 != 5) {
                     return this.dL = 2;
                  }

                  throw this.v("Expected name");
               default:
                  this.bs();
                  --this.dH;
                  if (this.a((char)var6)) {
                     return this.dL = 14;
                  }

                  throw this.v("Expected name");
            }
         }

         if (var1 == 4) {
            this.dP[this.bM - 1] = 5;
            int var2 = this.j(true);
            switch (var2) {
               case 58:
                  break;
               case 61:
                  this.bs();
                  if ((this.dH < this.dI || this.f(1)) && this.dG[this.dH] == '>') {
                     ++this.dH;
                  }
                  break;
               default:
                  throw this.v("Expected ':'");
            }
         } else if (var1 == 6) {
            if (this.aL) {
               this.bv();
            }

            this.dP[this.bM - 1] = 7;
         } else if (var1 == 7) {
            int var4 = this.j(false);
            if (var4 == -1) {
               return this.dL = 17;
            }

            this.bs();
            --this.dH;
         } else if (var1 == 8) {
            throw new IllegalStateException("JsonReader is closed");
         }
      }

      int var8 = this.j(true);
      switch (var8) {
         case 34:
            return this.dL = 9;
         case 39:
            this.bs();
            return this.dL = 8;
         case 91:
            return this.dL = 3;
         case 93:
            if (var1 == 1) {
               return this.dL = 4;
            }
         case 44:
         case 59:
            if (var1 != 1 && var1 != 2) {
               throw this.v("Unexpected value");
            }

            this.bs();
            --this.dH;
            return this.dL = 7;
         case 123:
            return this.dL = 1;
         default:
            --this.dH;
            int var3 = this.bo();
            if (var3 != 0) {
               return var3;
            } else {
               var3 = this.bp();
               if (var3 != 0) {
                  return var3;
               } else if (!this.a(this.dG[this.dH])) {
                  throw this.v("Expected value");
               } else {
                  this.bs();
                  return this.dL = 10;
               }
            }
      }
   }

   private int bo() throws IOException {
      char var1 = this.dG[this.dH];
      String var2;
      String var3;
      byte var4;
      if (var1 != 't' && var1 != 'T') {
         if (var1 != 'f' && var1 != 'F') {
            if (var1 != 'n' && var1 != 'N') {
               return 0;
            }

            var2 = "null";
            var3 = "NULL";
            var4 = 7;
         } else {
            var2 = "false";
            var3 = "FALSE";
            var4 = 6;
         }
      } else {
         var2 = "true";
         var3 = "TRUE";
         var4 = 5;
      }

      int var5 = var2.length();

      for(int var6 = 1; var6 < var5; ++var6) {
         if (this.dH + var6 >= this.dI && !this.f(var6 + 1)) {
            return 0;
         }

         var1 = this.dG[this.dH + var6];
         if (var1 != var2.charAt(var6) && var1 != var3.charAt(var6)) {
            return 0;
         }
      }

      if ((this.dH + var5 < this.dI || this.f(var5 + 1)) && this.a(this.dG[this.dH + var5])) {
         return 0;
      } else {
         this.dH += var5;
         return this.dL = var4;
      }
   }

   private int bp() throws IOException {
      char[] var1 = this.dG;
      int var2 = this.dH;
      int var3 = this.dI;
      long var4 = 0L;
      boolean var6 = false;
      boolean var7 = true;
      byte var8 = 0;
      int var9 = 0;

      label132:
      while(true) {
         if (var2 + var9 == var3) {
            if (var9 == var1.length) {
               return 0;
            }

            if (!this.f(var9 + 1)) {
               break;
            }

            var2 = this.dH;
            var3 = this.dI;
         }

         char var10 = var1[var2 + var9];
         switch (var10) {
            case '+':
               if (var8 != 5) {
                  return 0;
               }

               var8 = 6;
               break;
            case '-':
               if (var8 == 0) {
                  var6 = true;
                  var8 = 1;
               } else {
                  if (var8 != 5) {
                     return 0;
                  }

                  var8 = 6;
               }
               break;
            case '.':
               if (var8 != 2) {
                  return 0;
               }

               var8 = 3;
               break;
            case 'E':
            case 'e':
               if (var8 != 2 && var8 != 4) {
                  return 0;
               }

               var8 = 5;
               break;
            default:
               if (var10 < '0' || var10 > '9') {
                  if (this.a(var10)) {
                     return 0;
                  }
                  break label132;
               }

               if (var8 != 1 && var8 != 0) {
                  if (var8 == 2) {
                     if (var4 == 0L) {
                        return 0;
                     }

                     long var11 = var4 * 10L - (long)(var10 - 48);
                     var7 &= var4 > -922337203685477580L || var4 == -922337203685477580L && var11 < var4;
                     var4 = var11;
                  } else if (var8 == 3) {
                     var8 = 4;
                  } else if (var8 == 5 || var8 == 6) {
                     var8 = 7;
                  }
               } else {
                  var4 = (long)(-(var10 - 48));
                  var8 = 2;
               }
         }

         ++var9;
      }

      if (var8 != 2 || !var7 || var4 == Long.MIN_VALUE && !var6 || var4 == 0L && var6) {
         if (var8 != 2 && var8 != 4 && var8 != 7) {
            return 0;
         } else {
            this.dN = var9;
            return this.dL = 16;
         }
      } else {
         this.dM = var6 ? var4 : -var4;
         this.dH += var9;
         return this.dL = 15;
      }
   }

   private boolean a(char var1) throws IOException {
      switch (var1) {
         case '#':
         case '/':
         case ';':
         case '=':
         case '\\':
            this.bs();
         case '\t':
         case '\n':
         case '\f':
         case '\r':
         case ' ':
         case ',':
         case ':':
         case '[':
         case ']':
         case '{':
         case '}':
            return false;
         default:
            return true;
      }
   }

   public String aL() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      String var2;
      if (var1 == 14) {
         var2 = this.bq();
      } else if (var1 == 12) {
         var2 = this.b('\'');
      } else {
         if (var1 != 13) {
            throw new IllegalStateException("Expected a name but was " + this.aI() + this.aX());
         }

         var2 = this.b('"');
      }

      this.dL = 0;
      this.bN[this.bM - 1] = var2;
      return var2;
   }

   public String aM() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      String var2;
      if (var1 == 10) {
         var2 = this.bq();
      } else if (var1 == 8) {
         var2 = this.b('\'');
      } else if (var1 == 9) {
         var2 = this.b('"');
      } else if (var1 == 11) {
         var2 = this.dO;
         this.dO = null;
      } else if (var1 == 15) {
         var2 = Long.toString(this.dM);
      } else {
         if (var1 != 16) {
            throw new IllegalStateException("Expected a string but was " + this.aI() + this.aX());
         }

         var2 = new String(this.dG, this.dH, this.dN);
         this.dH += this.dN;
      }

      this.dL = 0;
      int var10002 = this.bO[this.bM - 1]++;
      return var2;
   }

   public boolean aN() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 5) {
         this.dL = 0;
         int var2 = this.bO[this.bM - 1]++;
         return true;
      } else if (var1 == 6) {
         this.dL = 0;
         int var10002 = this.bO[this.bM - 1]++;
         return false;
      } else {
         throw new IllegalStateException("Expected a boolean but was " + this.aI() + this.aX());
      }
   }

   public void aO() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 7) {
         this.dL = 0;
         int var10002 = this.bO[this.bM - 1]++;
      } else {
         throw new IllegalStateException("Expected null but was " + this.aI() + this.aX());
      }
   }

   public double aP() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 15) {
         this.dL = 0;
         int var4 = this.bO[this.bM - 1]++;
         return (double)this.dM;
      } else {
         if (var1 == 16) {
            this.dO = new String(this.dG, this.dH, this.dN);
            this.dH += this.dN;
         } else if (var1 != 8 && var1 != 9) {
            if (var1 == 10) {
               this.dO = this.bq();
            } else if (var1 != 11) {
               throw new IllegalStateException("Expected a double but was " + this.aI() + this.aX());
            }
         } else {
            this.dO = this.b((char)(var1 == 8 ? '\'' : '"'));
         }

         this.dL = 11;
         double var2 = Double.parseDouble(this.dO);
         if (this.aL || !Double.isNaN(var2) && !Double.isInfinite(var2)) {
            this.dO = null;
            this.dL = 0;
            int var10002 = this.bO[this.bM - 1]++;
            return var2;
         } else {
            throw new aW("JSON forbids NaN and infinities: " + var2 + this.aX());
         }
      }
   }

   public long aQ() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 15) {
         this.dL = 0;
         int var9 = this.bO[this.bM - 1]++;
         return this.dM;
      } else {
         if (var1 == 16) {
            this.dO = new String(this.dG, this.dH, this.dN);
            this.dH += this.dN;
         } else {
            if (var1 != 8 && var1 != 9 && var1 != 10) {
               throw new IllegalStateException("Expected a long but was " + this.aI() + this.aX());
            }

            if (var1 == 10) {
               this.dO = this.bq();
            } else {
               this.dO = this.b((char)(var1 == 8 ? '\'' : '"'));
            }

            try {
               long var7 = Long.parseLong(this.dO);
               this.dL = 0;
               int var8 = this.bO[this.bM - 1]++;
               return var7;
            } catch (NumberFormatException var6) {
            }
         }

         this.dL = 11;
         double var2 = Double.parseDouble(this.dO);
         long var4 = (long)var2;
         if ((double)var4 != var2) {
            throw new NumberFormatException("Expected a long but was " + this.dO + this.aX());
         } else {
            this.dO = null;
            this.dL = 0;
            int var10002 = this.bO[this.bM - 1]++;
            return var4;
         }
      }
   }

   private String b(char var1) throws IOException {
      char[] var2 = this.dG;
      StringBuilder var3 = null;

      do {
         int var4 = this.dH;
         int var5 = this.dI;
         int var6 = var4;

         while(var4 < var5) {
            char var7 = var2[var4++];
            if (var7 == var1) {
               this.dH = var4;
               int var11 = var4 - var6 - 1;
               if (var3 == null) {
                  return new String(var2, var6, var11);
               }

               var3.append(var2, var6, var11);
               return var3.toString();
            }

            if (var7 == '\\') {
               this.dH = var4;
               int var8 = var4 - var6 - 1;
               if (var3 == null) {
                  int var9 = (var8 + 1) * 2;
                  var3 = new StringBuilder(Math.max(var9, 16));
               }

               var3.append(var2, var6, var8);
               var3.append(this.bu());
               var4 = this.dH;
               var5 = this.dI;
               var6 = var4;
            } else if (var7 == '\n') {
               ++this.dJ;
               this.dK = var4;
            }
         }

         if (var3 == null) {
            int var10 = (var4 - var6) * 2;
            var3 = new StringBuilder(Math.max(var10, 16));
         }

         var3.append(var2, var6, var4 - var6);
         this.dH = var4;
      } while(this.f(1));

      throw this.v("Unterminated string");
   }

   private String bq() throws IOException {
      StringBuilder var1 = null;
      int var2 = 0;

      label35:
      while(true) {
         if (this.dH + var2 < this.dI) {
            switch (this.dG[this.dH + var2]) {
               case '\t':
               case '\n':
               case '\f':
               case '\r':
               case ' ':
               case ',':
               case ':':
               case '[':
               case ']':
               case '{':
               case '}':
                  break label35;
               case '#':
               case '/':
               case ';':
               case '=':
               case '\\':
                  this.bs();
                  break label35;
               default:
                  ++var2;
            }
         } else if (var2 < this.dG.length) {
            if (this.f(var2 + 1)) {
               continue;
            }
            break;
         } else {
            if (var1 == null) {
               var1 = new StringBuilder(Math.max(var2, 16));
            }

            var1.append(this.dG, this.dH, var2);
            this.dH += var2;
            var2 = 0;
            if (!this.f(1)) {
               break;
            }
         }
      }

      String var3 = null == var1 ? new String(this.dG, this.dH, var2) : var1.append(this.dG, this.dH, var2).toString();
      this.dH += var2;
      return var3;
   }

   private void c(char var1) throws IOException {
      char[] var2 = this.dG;

      do {
         int var3 = this.dH;
         int var4 = this.dI;

         while(var3 < var4) {
            char var5 = var2[var3++];
            if (var5 == var1) {
               this.dH = var3;
               return;
            }

            if (var5 == '\\') {
               this.dH = var3;
               this.bu();
               var3 = this.dH;
               var4 = this.dI;
            } else if (var5 == '\n') {
               ++this.dJ;
               this.dK = var3;
            }
         }

         this.dH = var3;
      } while(this.f(1));

      throw this.v("Unterminated string");
   }

   private void br() throws IOException {
      do {
         int var1;
         for(var1 = 0; this.dH + var1 < this.dI; ++var1) {
            switch (this.dG[this.dH + var1]) {
               case '#':
               case '/':
               case ';':
               case '=':
               case '\\':
                  this.bs();
               case '\t':
               case '\n':
               case '\f':
               case '\r':
               case ' ':
               case ',':
               case ':':
               case '[':
               case ']':
               case '{':
               case '}':
                  this.dH += var1;
                  return;
               default:
            }
         }

         this.dH += var1;
      } while(this.f(1));

   }

   public int aR() throws IOException {
      int var1 = this.dL;
      if (var1 == 0) {
         var1 = this.bn();
      }

      if (var1 == 15) {
         int var7 = (int)this.dM;
         if (this.dM != (long)var7) {
            throw new NumberFormatException("Expected an int but was " + this.dM + this.aX());
         } else {
            this.dL = 0;
            int var9 = this.bO[this.bM - 1]++;
            return var7;
         }
      } else {
         if (var1 == 16) {
            this.dO = new String(this.dG, this.dH, this.dN);
            this.dH += this.dN;
         } else {
            if (var1 != 8 && var1 != 9 && var1 != 10) {
               throw new IllegalStateException("Expected an int but was " + this.aI() + this.aX());
            }

            if (var1 == 10) {
               this.dO = this.bq();
            } else {
               this.dO = this.b((char)(var1 == 8 ? '\'' : '"'));
            }

            try {
               int var6 = Integer.parseInt(this.dO);
               this.dL = 0;
               int var8 = this.bO[this.bM - 1]++;
               return var6;
            } catch (NumberFormatException var5) {
            }
         }

         this.dL = 11;
         double var3 = Double.parseDouble(this.dO);
         int var2 = (int)var3;
         if ((double)var2 != var3) {
            throw new NumberFormatException("Expected an int but was " + this.dO + this.aX());
         } else {
            this.dO = null;
            this.dL = 0;
            int var10002 = this.bO[this.bM - 1]++;
            return var2;
         }
      }
   }

   public void close() throws IOException {
      this.dL = 0;
      this.dP[0] = 8;
      this.bM = 1;
      this.dF.close();
   }

   public void aT() throws IOException {
      int var1 = 0;

      do {
         int var2 = this.dL;
         if (var2 == 0) {
            var2 = this.bn();
         }

         switch (var2) {
            case 1:
               this.e(3);
               ++var1;
               break;
            case 2:
               if (var1 == 0) {
                  this.bN[this.bM - 1] = null;
               }

               --this.bM;
               --var1;
               break;
            case 3:
               this.e(1);
               ++var1;
               break;
            case 4:
               --this.bM;
               --var1;
            case 5:
            case 6:
            case 7:
            case 11:
            case 15:
            default:
               break;
            case 8:
               this.c('\'');
               break;
            case 9:
               this.c('"');
               break;
            case 10:
               this.br();
               break;
            case 12:
               this.c('\'');
               if (var1 == 0) {
                  this.bN[this.bM - 1] = "<skipped>";
               }
               break;
            case 13:
               this.c('"');
               if (var1 == 0) {
                  this.bN[this.bM - 1] = "<skipped>";
               }
               break;
            case 14:
               this.br();
               if (var1 == 0) {
                  this.bN[this.bM - 1] = "<skipped>";
               }
               break;
            case 16:
               this.dH += this.dN;
               break;
            case 17:
               return;
         }

         this.dL = 0;
      } while(var1 > 0);

      int var10002 = this.bO[this.bM - 1]++;
   }

   private void e(int var1) {
      if (this.bM == this.dP.length) {
         int var2 = this.bM * 2;
         this.dP = Arrays.copyOf(this.dP, var2);
         this.bO = Arrays.copyOf(this.bO, var2);
         this.bN = (String[])Arrays.copyOf(this.bN, var2);
      }

      this.dP[this.bM++] = var1;
   }

   private boolean f(int var1) throws IOException {
      char[] var2 = this.dG;
      this.dK -= this.dH;
      if (this.dI != this.dH) {
         this.dI -= this.dH;
         System.arraycopy(var2, this.dH, var2, 0, this.dI);
      } else {
         this.dI = 0;
      }

      this.dH = 0;

      int var3;
      while((var3 = this.dF.read(var2, this.dI, var2.length - this.dI)) != -1) {
         this.dI += var3;
         if (this.dJ == 0 && this.dK == 0 && this.dI > 0 && var2[0] == '\ufeff') {
            ++this.dH;
            ++this.dK;
            ++var1;
         }

         if (this.dI >= var1) {
            return true;
         }
      }

      return false;
   }

   private int j(boolean var1) throws IOException {
      char[] var2 = this.dG;
      int var3 = this.dH;
      int var4 = this.dI;

      while(true) {
         if (var3 == var4) {
            this.dH = var3;
            if (!this.f(1)) {
               if (var1) {
                  throw new EOFException("End of input" + this.aX());
               }

               return -1;
            }

            var3 = this.dH;
            var4 = this.dI;
         }

         char var5 = var2[var3++];
         if (var5 == '\n') {
            ++this.dJ;
            this.dK = var3;
         } else if (var5 != ' ' && var5 != '\r' && var5 != '\t') {
            if (var5 == '/') {
               this.dH = var3;
               if (var3 == var4) {
                  --this.dH;
                  boolean var6 = this.f(2);
                  ++this.dH;
                  if (!var6) {
                     return var5;
                  }
               }

               this.bs();
               char var7 = var2[this.dH];
               switch (var7) {
                  case '*':
                     ++this.dH;
                     if (!this.u("*/")) {
                        throw this.v("Unterminated comment");
                     }

                     var3 = this.dH + 2;
                     var4 = this.dI;
                     break;
                  case '/':
                     ++this.dH;
                     this.bt();
                     var3 = this.dH;
                     var4 = this.dI;
                     break;
                  default:
                     return var5;
               }
            } else {
               if (var5 != '#') {
                  this.dH = var3;
                  return var5;
               }

               this.dH = var3;
               this.bs();
               this.bt();
               var3 = this.dH;
               var4 = this.dI;
            }
         }
      }
   }

   private void bs() throws IOException {
      if (!this.aL) {
         throw this.v("Use JsonReader.setLenient(true) to accept malformed JSON");
      }
   }

   private void bt() throws IOException {
      while(this.dH < this.dI || this.f(1)) {
         char var1 = this.dG[this.dH++];
         if (var1 == '\n') {
            ++this.dJ;
            this.dK = this.dH;
         } else if (var1 != '\r') {
            continue;
         }
         break;
      }

   }

   private boolean u(String var1) throws IOException {
      label30:
      for(int var2 = var1.length(); this.dH + var2 <= this.dI || this.f(var2); ++this.dH) {
         if (this.dG[this.dH] == '\n') {
            ++this.dJ;
            this.dK = this.dH + 1;
         } else {
            for(int var3 = 0; var3 < var2; ++var3) {
               if (this.dG[this.dH + var3] != var1.charAt(var3)) {
                  continue label30;
               }
            }

            return true;
         }
      }

      return false;
   }

   public String toString() {
      return this.getClass().getSimpleName() + this.aX();
   }

   String aX() {
      int var1 = this.dJ + 1;
      int var2 = this.dH - this.dK + 1;
      return " at line " + var1 + " column " + var2 + " path " + this.aW();
   }

   private String g(boolean var1) {
      StringBuilder var2 = (new StringBuilder()).append('$');

      for(int var3 = 0; var3 < this.bM; ++var3) {
         switch (this.dP[var3]) {
            case 1:
            case 2:
               int var4 = this.bO[var3];
               if (var1 && var4 > 0 && var3 == this.bM - 1) {
                  --var4;
               }

               var2.append('[').append(var4).append(']');
               break;
            case 3:
            case 4:
            case 5:
               var2.append('.');
               if (this.bN[var3] != null) {
                  var2.append(this.bN[var3]);
               }
            case 6:
            case 7:
            case 8:
         }
      }

      return var2.toString();
   }

   public String aV() {
      return this.g(true);
   }

   public String aW() {
      return this.g(false);
   }

   private char bu() throws IOException {
      if (this.dH == this.dI && !this.f(1)) {
         throw this.v("Unterminated escape sequence");
      } else {
         char var1 = this.dG[this.dH++];
         switch (var1) {
            case '\n':
               ++this.dJ;
               this.dK = this.dH;
            case '"':
            case '\'':
            case '/':
            case '\\':
               return var1;
            case 'b':
               return '\b';
            case 'f':
               return '\f';
            case 'n':
               return '\n';
            case 'r':
               return '\r';
            case 't':
               return '\t';
            case 'u':
               if (this.dH + 4 > this.dI && !this.f(4)) {
                  throw this.v("Unterminated escape sequence");
               } else {
                  char var2 = '\u0000';
                  int var3 = this.dH;

                  for(int var4 = var3 + 4; var3 < var4; ++var3) {
                     char var5 = this.dG[var3];
                     var2 = (char)(var2 << 4);
                     if (var5 >= '0' && var5 <= '9') {
                        var2 = (char)(var2 + (var5 - 48));
                     } else if (var5 >= 'a' && var5 <= 'f') {
                        var2 = (char)(var2 + var5 - 97 + 10);
                     } else {
                        if (var5 < 'A' || var5 > 'F') {
                           throw new NumberFormatException("\\u" + new String(this.dG, this.dH, 4));
                        }

                        var2 = (char)(var2 + var5 - 65 + 10);
                     }
                  }

                  this.dH += 4;
                  return var2;
               }
            default:
               throw this.v("Invalid escape sequence");
         }
      }
   }

   private IOException v(String var1) throws IOException {
      throw new aW(var1 + this.aX());
   }

   private void bv() throws IOException {
      this.j(true);
      --this.dH;
      if (this.dH + 5 <= this.dI || this.f(5)) {
         int var1 = this.dH;
         char[] var2 = this.dG;
         if (var2[var1] == ')' && var2[var1 + 1] == ']' && var2[var1 + 2] == '}' && var2[var1 + 3] == '\'' && var2[var1 + 4] == '\n') {
            this.dH += 5;
         }
      }
   }

   static {
      ao.INSTANCE = new ao() {
         public void j(aT var1) throws IOException {
            if (var1 instanceof aC) {
               ((aC)var1).aU();
            } else {
               int var2 = var1.dL;
               if (var2 == 0) {
                  var2 = var1.bn();
               }

               if (var2 == 13) {
                  var1.dL = 9;
               } else if (var2 == 12) {
                  var1.dL = 8;
               } else {
                  if (var2 != 14) {
                     throw new IllegalStateException("Expected a name but was " + var1.aI() + var1.aX());
                  }

                  var1.dL = 10;
               }

            }
         }
      };
   }
}
