import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class be {
   private final String scheme;
   private final Map<String, String> eE;

   public be(String var1, Map<String, String> var2) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      super();
      this.scheme = var1;
      Map var3 = (Map)(new LinkedHashMap());

      for(Map.Entry var5 : var2.entrySet()) {
         String var6 = (String)var5.getKey();
         String var7 = (String)var5.getValue();
         String var10;
         if (var6 != null) {
            Locale var10000 = Locale.US;
            fR.b(var10000, "");
            var10 = var6.toLowerCase(var10000);
            fR.b(var10, "");
         } else {
            var10 = null;
         }

         String var8 = var10;
         var3.put(var8, var7);
      }

      Map var10001 = Collections.unmodifiableMap(var3);
      fR.b(var10001, "");
      this.eE = var10001;
   }

   public final String cq() {
      return this.scheme;
   }

   public final String cr() {
      return (String)this.eE.get("realm");
   }

   public final Charset cs() {
      String var1 = (String)this.eE.get("charset");
      if (var1 != null) {
         try {
            Charset var4 = Charset.forName(var1);
            fR.b(var4, "");
            return var4;
         } catch (Exception var3) {
         }
      }

      Charset var10000 = StandardCharsets.ISO_8859_1;
      fR.b(var10000, "");
      return var10000;
   }

   public boolean equals(Object var1) {
      return var1 instanceof be && fR.c(((be)var1).scheme, (Object)this.scheme) && fR.c(((be)var1).eE, (Object)this.eE);
   }

   public int hashCode() {
      int var1 = 29;
      var1 = 31 * var1 + this.scheme.hashCode();
      var1 = 31 * var1 + this.eE.hashCode();
      return var1;
   }

   public String toString() {
      return this.scheme + " authParams=" + this.eE;
   }
}
