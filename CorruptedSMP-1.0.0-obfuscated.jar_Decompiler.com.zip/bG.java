import java.io.IOException;

public interface bG {
   dy bX() throws IOException;

   void bW();
}
