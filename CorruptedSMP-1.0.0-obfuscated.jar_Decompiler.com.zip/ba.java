import java.util.concurrent.TimeUnit;

public final class ba {
   public static final b et = new b((fP)null);
   private final boolean noCache;
   private final boolean noStore;
   private final int maxAgeSeconds;
   private final int eu;
   private final boolean ev;
   private final boolean ew;
   private final boolean ex;
   private final int maxStaleSeconds;
   private final int minFreshSeconds;
   private final boolean onlyIfCached;
   private final boolean noTransform;
   private final boolean immutable;
   private String ey;
   public static final ba ez = (new a()).ch().cj();
   public static final ba eA;

   private ba(boolean var1, boolean var2, int var3, int var4, boolean var5, boolean var6, boolean var7, int var8, int var9, boolean var10, boolean var11, boolean var12, String var13) {
      this.noCache = var1;
      this.noStore = var2;
      this.maxAgeSeconds = var3;
      this.eu = var4;
      this.ev = var5;
      this.ew = var6;
      this.ex = var7;
      this.maxStaleSeconds = var8;
      this.minFreshSeconds = var9;
      this.onlyIfCached = var10;
      this.noTransform = var11;
      this.immutable = var12;
      this.ey = var13;
   }

   public final boolean bY() {
      return this.noCache;
   }

   public final boolean bZ() {
      return this.noStore;
   }

   public final int ca() {
      return this.maxAgeSeconds;
   }

   public final boolean cb() {
      return this.ev;
   }

   public final boolean cc() {
      return this.ew;
   }

   public final boolean cd() {
      return this.ex;
   }

   public final int ce() {
      return this.maxStaleSeconds;
   }

   public final int cf() {
      return this.minFreshSeconds;
   }

   public final boolean cg() {
      return this.onlyIfCached;
   }

   public String toString() {
      String var1 = this.ey;
      if (var1 == null) {
         StringBuilder var2 = new StringBuilder();
         boolean var4 = false;
         if (this.noCache) {
            var2.append("no-cache, ");
         }

         if (this.noStore) {
            var2.append("no-store, ");
         }

         if (this.maxAgeSeconds != -1) {
            var2.append("max-age=").append(this.maxAgeSeconds).append(", ");
         }

         if (this.eu != -1) {
            var2.append("s-maxage=").append(this.eu).append(", ");
         }

         if (this.ev) {
            var2.append("private, ");
         }

         if (this.ew) {
            var2.append("public, ");
         }

         if (this.ex) {
            var2.append("must-revalidate, ");
         }

         if (this.maxStaleSeconds != -1) {
            var2.append("max-stale=").append(this.maxStaleSeconds).append(", ");
         }

         if (this.minFreshSeconds != -1) {
            var2.append("min-fresh=").append(this.minFreshSeconds).append(", ");
         }

         if (this.onlyIfCached) {
            var2.append("only-if-cached, ");
         }

         if (this.noTransform) {
            var2.append("no-transform, ");
         }

         if (this.immutable) {
            var2.append("immutable, ");
         }

         if (((CharSequence)var2).length() == 0) {
            return "";
         }

         var2.delete(var2.length() - 2, var2.length());
         String var10000 = var2.toString();
         fR.b(var10000, "");
         var1 = var10000;
         this.ey = var1;
      }

      return var1;
   }

   // $FF: synthetic method
   public ba(boolean var1, boolean var2, int var3, int var4, boolean var5, boolean var6, boolean var7, int var8, int var9, boolean var10, boolean var11, boolean var12, String var13, fP var14) {
      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13);
   }

   static {
      eA = (new a()).ci().a(Integer.MAX_VALUE, TimeUnit.SECONDS).cj();
   }

   public static final class a {
      private boolean noCache;
      private boolean noStore;
      private int maxAgeSeconds = -1;
      private int maxStaleSeconds = -1;
      private int minFreshSeconds = -1;
      private boolean onlyIfCached;
      private boolean noTransform;
      private boolean immutable;

      public final a ch() {
         a var2 = this;
         boolean var3 = false;
         var2.noCache = true;
         return this;
      }

      public final a a(int var1, TimeUnit var2) {
         fR.c(var2, (String)"");
         a var4 = this;
         boolean var5 = false;
         if (var1 < 0) {
            boolean var6 = false;
            String var9 = "maxStale < 0: " + var1;
            throw new IllegalArgumentException(var9.toString());
         } else {
            long var7 = var2.toSeconds((long)var1);
            var4.maxStaleSeconds = var4.c(var7);
            return this;
         }
      }

      public final a ci() {
         a var2 = this;
         boolean var3 = false;
         var2.onlyIfCached = true;
         return this;
      }

      private final int c(long var1) {
         return var1 > 2147483647L ? Integer.MAX_VALUE : (int)var1;
      }

      public final ba cj() {
         return new ba(this.noCache, this.noStore, this.maxAgeSeconds, -1, false, false, false, this.maxStaleSeconds, this.minFreshSeconds, this.onlyIfCached, this.noTransform, this.immutable, (String)null, (fP)null);
      }
   }

   public static final class b {
      private b() {
      }

      public final ba b(bq var1) {
         fR.c(var1, (String)"");
         boolean var2 = false;
         boolean var3 = false;
         int var4 = -1;
         int var5 = -1;
         boolean var6 = false;
         boolean var7 = false;
         boolean var8 = false;
         int var9 = -1;
         int var10 = -1;
         boolean var11 = false;
         boolean var12 = false;
         boolean var13 = false;
         boolean var14 = true;
         String var15 = null;
         int var16 = 0;

         for(int var17 = var1.cT(); var16 < var17; ++var16) {
            String var18 = var1.j(var16);
            String var19 = var1.k(var16);
            if (gA.a(var18, "Cache-Control", true)) {
               if (var15 != null) {
                  var14 = false;
               } else {
                  var15 = var19;
               }
            } else {
               if (!gA.a(var18, "Pragma", true)) {
                  continue;
               }

               var14 = false;
            }

            int var29 = 0;

            while(var29 < var19.length()) {
               int var21 = var29;
               var29 = this.a(var19, "=,;", var29);
               String var10000 = var19.substring(var21, var29);
               fR.b(var10000, "");
               String var22 = gA.c((CharSequence)var10000).toString();
               Object var23 = null;
               String var30;
               if (var29 != var19.length() && var19.charAt(var29) != ',' && var19.charAt(var29) != ';') {
                  ++var29;
                  var29 = bD.c(var19, var29);
                  if (var29 < var19.length() && var19.charAt(var29) == '"') {
                     ++var29;
                     var29 = gA.a((CharSequence)var19, '"', var29, false, 4, (Object)null);
                     var10000 = var19.substring(var29, var29);
                     fR.b(var10000, "");
                     var30 = var10000;
                     ++var29;
                  } else {
                     var29 = this.a(var19, ",;", var29);
                     var10000 = var19.substring(var29, var29);
                     fR.b(var10000, "");
                     var30 = gA.c((CharSequence)var10000).toString();
                  }
               } else {
                  ++var29;
                  var30 = null;
               }

               if (gA.a("no-cache", var22, true)) {
                  var2 = true;
               } else if (gA.a("no-store", var22, true)) {
                  var3 = true;
               } else if (gA.a("max-age", var22, true)) {
                  var4 = bD.d(var30, -1);
               } else if (gA.a("s-maxage", var22, true)) {
                  var5 = bD.d(var30, -1);
               } else if (gA.a("private", var22, true)) {
                  var6 = true;
               } else if (gA.a("public", var22, true)) {
                  var7 = true;
               } else if (gA.a("must-revalidate", var22, true)) {
                  var8 = true;
               } else if (gA.a("max-stale", var22, true)) {
                  var9 = bD.d(var30, Integer.MAX_VALUE);
               } else if (gA.a("min-fresh", var22, true)) {
                  var10 = bD.d(var30, -1);
               } else if (gA.a("only-if-cached", var22, true)) {
                  var11 = true;
               } else if (gA.a("no-transform", var22, true)) {
                  var12 = true;
               } else if (gA.a("immutable", var22, true)) {
                  var13 = true;
               }
            }
         }

         if (!var14) {
            var15 = null;
         }

         return new ba(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var15, (fP)null);
      }

      private final int a(String var1, String var2, int var3) {
         int var4 = var3;

         for(int var5 = var1.length(); var4 < var5; ++var4) {
            if (gA.a((CharSequence)var2, var1.charAt(var4), false, 2, (Object)null)) {
               return var4;
            }
         }

         return var1.length();
      }

      // $FF: synthetic method
      public b(fP var1) {
         this();
      }
   }
}
