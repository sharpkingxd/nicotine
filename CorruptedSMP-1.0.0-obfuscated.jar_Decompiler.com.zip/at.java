import java.lang.reflect.Type;

public final class at {
   public static boolean j(Type var0) {
      return var0 instanceof Class && ((Class)var0).isPrimitive();
   }

   public static <T> Class<T> j(Class<T> var0) {
      if (var0 == Integer.TYPE) {
         return Integer.class;
      } else if (var0 == Float.TYPE) {
         return Float.class;
      } else if (var0 == Byte.TYPE) {
         return Byte.class;
      } else if (var0 == Double.TYPE) {
         return Double.class;
      } else if (var0 == Long.TYPE) {
         return Long.class;
      } else if (var0 == Character.TYPE) {
         return Character.class;
      } else if (var0 == Boolean.TYPE) {
         return Boolean.class;
      } else if (var0 == Short.TYPE) {
         return Short.class;
      } else {
         return var0 == Void.TYPE ? Void.class : var0;
      }
   }
}
