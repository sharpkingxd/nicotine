import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public final class cS extends cM {
   public static final a pw = new a((fP)null);
   private final Class<? super SSLSocketFactory> px;
   private final Class<?> py;

   public cS(Class<? super SSLSocket> var1, Class<? super SSLSocketFactory> var2, Class<?> var3) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      super(var1);
      this.px = var2;
      this.py = var3;
   }

   public static final class a {
      private a() {
      }

      public final cR aK(String var1) {
         fR.c(var1, (String)"");

         cR var2;
         try {
            Class var10000 = Class.forName(var1 + ".OpenSSLSocketImpl");
            fR.m(var10000);
            Class var6 = var10000;
            var10000 = Class.forName(var1 + ".OpenSSLSocketFactoryImpl");
            fR.m(var10000);
            Class var3 = var10000;
            Class var4 = Class.forName(var1 + ".SSLParametersImpl");
            fR.b(var4, "");
            var2 = new cS(var6, var3, var4);
         } catch (Exception var5) {
            cH.oU.jZ().a("unable to load android socket classes", 5, (Throwable)var5);
            var2 = null;
         }

         return var2;
      }

      // $FF: synthetic method
      public static cR a(a var0, String var1, int var2, Object var3) {
         if ((var2 & 1) != 0) {
            var1 = "com.android.org.conscrypt";
         }

         return var0.aK(var1);
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
