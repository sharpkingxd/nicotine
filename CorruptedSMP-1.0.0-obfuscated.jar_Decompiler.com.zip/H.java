import java.lang.reflect.Field;
import java.util.Objects;

public final class H {
   private final Field at;

   public H(Field var1) {
      this.at = (Field)Objects.requireNonNull(var1);
   }

   public String toString() {
      return this.at.toString();
   }
}
