import java.util.Collections;
import java.util.Map;

class fg extends ff {
   public static final <K, V> Map<K, V> b(Map<? extends K, ? extends V> var0) {
      fR.c(var0, (String)"");
      Object var1 = var0.entrySet().iterator().next();
      Map.Entry var2 = (Map.Entry)var1;
      boolean var3 = false;
      Map var10000 = Collections.singletonMap(var2.getKey(), var2.getValue());
      fR.b(var10000, "");
      return var10000;
   }

   public static final int an(int var0) {
      return var0 < 0 ? var0 : (var0 < 3 ? var0 + 1 : (var0 < 1073741824 ? (int)((float)var0 / 0.75F + 1.0F) : Integer.MAX_VALUE));
   }
}
