import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;

class gJ extends gI {
   public static final boolean a(String var0, String var1, boolean var2) {
      if (var0 == null) {
         return var1 == null;
      } else {
         return !var2 ? var0.equals(var1) : var0.equalsIgnoreCase(var1);
      }
   }

   public static final String a(String var0, char var1, char var2, boolean var3) {
      fR.c(var0, (String)"");
      if (!var3) {
         String var14 = var0.replace(var1, var2);
         fR.b(var14, "");
         return var14;
      } else {
         int var4 = var0.length();
         StringBuilder var5 = new StringBuilder(var4);
         StringBuilder var6 = var5;
         boolean var7 = false;
         CharSequence var8 = (CharSequence)var0;
         boolean var9 = false;

         for(int var10 = 0; var10 < var8.length(); ++var10) {
            char var11 = var8.charAt(var10);
            boolean var13 = false;
            var6.append(gu.a(var11, var1, var3) ? var2 : var11);
         }

         String var10000 = var5.toString();
         fR.b(var10000, "");
         return var10000;
      }
   }

   // $FF: synthetic method
   public static String a(String var0, char var1, char var2, boolean var3, int var4, Object var5) {
      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.a(var0, var1, var2, var3);
   }

   public static final String a(String var0, String var1, String var2, boolean var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      String var5 = var0;
      boolean var6 = false;
      int var7 = gA.a((CharSequence)var0, var1, 0, var3);
      if (var7 < 0) {
         return var0;
      } else {
         int var8 = var1.length();
         int var9 = gg.m(var8, 1);
         int var10 = var0.length() - var8 + var2.length();
         if (var10 < 0) {
            throw new OutOfMemoryError();
         } else {
            StringBuilder var11 = new StringBuilder(var10);
            int var12 = 0;

            do {
               var11.append((CharSequence)var5, var12, var7).append(var2);
               var12 = var7 + var8;
               if (var7 >= var5.length()) {
                  break;
               }

               var7 = gA.a((CharSequence)var5, var1, var7 + var9, var3);
            } while(var7 > 0);

            String var10000 = var11.append((CharSequence)var5, var12, var5.length()).toString();
            fR.b(var10000, "");
            return var10000;
         }
      }
   }

   // $FF: synthetic method
   public static String a(String var0, String var1, String var2, boolean var3, int var4, Object var5) {
      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.a(var0, var1, var2, var3);
   }

   public static final String b(char[] var0) {
      fR.c(var0, (String)"");
      return new String(var0);
   }

   public static final String a(char[] var0, int var1, int var2) {
      fR.c(var0, (String)"");
      eG.sm.f(var1, var2, var0.length);
      return new String(var0, var1, var2 - var1);
   }

   public static final boolean b(String var0, String var1, boolean var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var2 ? var0.startsWith(var1) : gA.a(var0, 0, var1, 0, var1.length(), var2);
   }

   // $FF: synthetic method
   public static boolean a(String var0, String var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return gA.b(var0, var1, var2);
   }

   public static final boolean a(String var0, String var1, int var2, boolean var3) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var3 ? var0.startsWith(var1, var2) : gA.a(var0, var2, var1, 0, var1.length(), var3);
   }

   // $FF: synthetic method
   public static boolean a(String var0, String var1, int var2, boolean var3, int var4, Object var5) {
      if ((var4 & 4) != 0) {
         var3 = false;
      }

      return gA.a(var0, var1, var2, var3);
   }

   public static final boolean c(String var0, String var1, boolean var2) {
      fR.c(var0, (String)"");
      fR.c(var1, (String)"");
      return !var2 ? var0.endsWith(var1) : gA.a(var0, var0.length() - var1.length(), var1, 0, var1.length(), true);
   }

   // $FF: synthetic method
   public static boolean b(String var0, String var1, boolean var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = false;
      }

      return gA.c(var0, var1, var2);
   }

   public static final boolean b(CharSequence var0) {
      fR.c(var0, (String)"");
      boolean var7;
      if (var0.length() != 0) {
         Iterable var1 = gA.d(var0);
         boolean var2 = false;
         if (var1 instanceof Collection && ((Collection)var1).isEmpty()) {
            var7 = true;
         } else {
            Iterator var3 = var1.iterator();

            while(true) {
               if (!var3.hasNext()) {
                  var7 = true;
                  break;
               }

               int var4 = ((fd)var3).aR();
               boolean var6 = false;
               if (!gu.g(var0.charAt(var4))) {
                  var7 = false;
                  break;
               }
            }
         }

         if (!var7) {
            var7 = false;
            return var7;
         }
      }

      var7 = true;
      return var7;
   }

   public static final boolean a(String var0, int var1, String var2, int var3, int var4, boolean var5) {
      fR.c(var0, (String)"");
      fR.c(var2, (String)"");
      return !var5 ? var0.regionMatches(var1, var2, var3, var4) : var0.regionMatches(var5, var1, var2, var3, var4);
   }

   // $FF: synthetic method
   public static boolean a(String var0, int var1, String var2, int var3, int var4, boolean var5, int var6, Object var7) {
      if ((var6 & 16) != 0) {
         var5 = false;
      }

      return gA.a(var0, var1, var2, var3, var4, var5);
   }

   public static final String a(CharSequence var0, int var1) {
      fR.c(var0, (String)"");
      boolean var2 = var1 >= 0;
      if (!var2) {
         boolean var3 = false;
         String var10 = "Count 'n' must be non-negative, but was " + var1 + '.';
         throw new IllegalArgumentException(var10.toString());
      } else {
         String var10000;
         switch (var1) {
            case 0:
               var10000 = "";
               break;
            case 1:
               var10000 = var0.toString();
               break;
            default:
               switch (var0.length()) {
                  case 0:
                     var10000 = "";
                     break;
                  case 1:
                     char var4 = var0.charAt(0);
                     char var5 = var4;
                     boolean var6 = false;
                     int var7 = 0;

                     char[] var8;
                     for(var8 = new char[var1]; var7 < var1; ++var7) {
                        var8[var7] = var5;
                     }

                     var10000 = new String(var8);
                     break;
                  default:
                     StringBuilder var12 = new StringBuilder(var1 * var0.length());
                     fd var13 = (new gf(1, var1)).nF();

                     while(var13.hasNext()) {
                        int var14 = var13.aR();
                        var12.append(var0);
                     }

                     String var11 = var12.toString();
                     fR.b(var11, "");
                     var10000 = var11;
               }
         }

         return var10000;
      }
   }

   public static final Comparator<String> a(fW var0) {
      fR.c(var0, (String)"");
      Comparator var10000 = String.CASE_INSENSITIVE_ORDER;
      fR.b(var10000, "");
      return var10000;
   }
}
