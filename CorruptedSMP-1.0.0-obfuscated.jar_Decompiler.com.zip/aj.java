public final class aj {
   public static void e(boolean var0) {
      if (!var0) {
         throw new IllegalArgumentException();
      }
   }
}
