import java.util.Arrays;
import java.util.List;

class eN {
   static <T> List<T> c(T[] var0) {
      return Arrays.asList(var0);
   }
}
