import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class aH implements ad {
   private final al cb;
   private final J cc;
   private final am cd;
   private final aB ce;
   private final List<Z> cf;

   public aH(al var1, J var2, am var3, aB var4, List<Z> var5) {
      this.cb = var1;
      this.cc = var2;
      this.cd = var3;
      this.ce = var4;
      this.cf = var5;
   }

   private boolean b(Field var1, boolean var2) {
      return !this.cd.a(var1.getType(), var2) && !this.cd.a(var1, var2);
   }

   private List<String> b(Field var1) {
      ag var2 = (ag)var1.getAnnotation(ag.class);
      if (var2 == null) {
         String var6 = this.cc.a(var1);
         return Collections.singletonList(var6);
      } else {
         String var3 = var2.as();
         String[] var4 = var2.at();
         if (var4.length == 0) {
            return Collections.singletonList(var3);
         } else {
            ArrayList var5 = new ArrayList(var4.length + 1);
            var5.add(var3);
            Collections.addAll(var5, var4);
            return var5;
         }
      }
   }

   public <T> ac<T> a(K var1, aS<T> var2) {
      Class var3 = var2.bk();
      if (!Object.class.isAssignableFrom(var3)) {
         return null;
      } else {
         Z.a var4 = au.a(this.cf, var3);
         if (var4 == Z.a.BLOCK_ALL) {
            throw new Q("ReflectionAccessFilter does not permit using reflection for " + var3 + ". Register a TypeAdapter for this type or adjust the access filter.");
         } else {
            boolean var5 = var4 == Z.a.BLOCK_INACCESSIBLE;
            if (aN.q(var3)) {
               d var7 = new d(var3, this.a(var1, var2, var3, var5, true), var5);
               return var7;
            } else {
               ar var6 = this.cb.b(var2);
               return new c<T>(var6, this.a(var1, var2, var3, var5, false));
            }
         }
      }
   }

   private static <M extends AccessibleObject & Member> void a(Object var0, M var1) {
      if (!au.a(var1, Modifier.isStatic(((Member)var1).getModifiers()) ? null : var0)) {
         String var2 = aN.a(var1, true);
         throw new Q(var2 + " is not accessible and ReflectionAccessFilter does not permit making it accessible. Register a TypeAdapter for the declaring type, adjust the access filter or increase the visibility of the element and its declaring type.");
      }
   }

   private b a(final K var1, Field var2, final Method var3, String var4, final aS<?> var5, boolean var6, boolean var7, final boolean var8) {
      final boolean var9 = at.j(var5.bk());
      int var10 = var2.getModifiers();
      final boolean var11 = Modifier.isStatic(var10) && Modifier.isFinal(var10);
      af var12 = (af)var2.getAnnotation(af.class);
      final ac var13 = null;
      if (var12 != null) {
         var13 = this.ce.a(this.cb, var1, var5, var12);
      }

      final boolean var14 = var13 != null;
      if (var13 == null) {
         var13 = var1.a(var5);
      }

      return new b(var4, var2, var6, var7) {
         void a(aV var1x, Object var2) throws IOException, IllegalAccessException {
            if (this.serialized) {
               if (var8) {
                  if (var3 == null) {
                     aH.a((Object)var2, this.field);
                  } else {
                     aH.a((Object)var2, var3);
                  }
               }

               Object var3x;
               if (var3 != null) {
                  try {
                     var3x = var3.invoke(var2);
                  } catch (InvocationTargetException var6) {
                     String var5x = aN.a(var3, false);
                     throw new Q("Accessor " + var5x + " threw exception", var6.getCause());
                  }
               } else {
                  var3x = this.field.get(var2);
               }

               if (var3x != var2) {
                  var1x.s(this.name);
                  Object var4 = var14 ? var13 : new aK(var1, var13, var5.bl());
                  ((ac)var4).a(var1x, var3x);
               }
            }
         }

         void a(aT var1x, int var2, Object[] var3x) throws IOException, T {
            Object var4 = var13.b(var1x);
            if (var4 == null && var9) {
               throw new T("null is not allowed as value for record component '" + this.fieldName + "' of primitive type; at path " + var1x.aW());
            } else {
               var3x[var2] = var4;
            }
         }

         void a(aT var1x, Object var2) throws IOException, IllegalAccessException {
            Object var3x = var13.b(var1x);
            if (var3x != null || !var9) {
               if (var8) {
                  aH.a((Object)var2, this.field);
               } else if (var11) {
                  String var4 = aN.a(this.field, false);
                  throw new Q("Cannot set value of 'static final' " + var4);
               }

               this.field.set(var2, var3x);
            }

         }
      };
   }

   private Map<String, b> a(K var1, aS<?> var2, Class<?> var3, boolean var4, boolean var5) {
      LinkedHashMap var6 = new LinkedHashMap();
      if (var3.isInterface()) {
         return var6;
      } else {
         for(Class var7 = var3; var3 != Object.class; var3 = var2.bk()) {
            Field[] var8 = var3.getDeclaredFields();
            if (var3 != var7 && var8.length > 0) {
               Z.a var9 = au.a(this.cf, var3);
               if (var9 == Z.a.BLOCK_ALL) {
                  throw new Q("ReflectionAccessFilter does not permit using reflection for " + var3 + " (supertype of " + var7 + "). Register a TypeAdapter for this type or adjust the access filter.");
               }

               var4 = var9 == Z.a.BLOCK_INACCESSIBLE;
            }

            for(Field var12 : var8) {
               boolean var13 = this.b(var12, true);
               boolean var14 = this.b(var12, false);
               if (var13 || var14) {
                  Method var15 = null;
                  if (var5) {
                     if (Modifier.isStatic(var12.getModifiers())) {
                        var14 = false;
                     } else {
                        var15 = aN.a(var3, var12);
                        if (!var4) {
                           aN.a(var15);
                        }

                        if (var15.getAnnotation(ag.class) != null && var12.getAnnotation(ag.class) == null) {
                           String var25 = aN.a(var15, false);
                           throw new Q("@SerializedName on " + var25 + " is not supported");
                        }
                     }
                  }

                  if (!var4 && var15 == null) {
                     aN.a(var12);
                  }

                  Type var16 = ak.a(var2.bl(), var3, var12.getGenericType());
                  List var17 = this.b(var12);
                  b var18 = null;
                  int var19 = 0;

                  for(int var20 = var17.size(); var19 < var20; ++var19) {
                     String var21 = (String)var17.get(var19);
                     if (var19 != 0) {
                        var13 = false;
                     }

                     b var22 = this.a(var1, var12, var15, var21, aS.k(var16), var13, var14, var4);
                     b var23 = (b)var6.put(var21, var22);
                     if (var18 == null) {
                        var18 = var23;
                     }
                  }

                  if (var18 != null) {
                     throw new IllegalArgumentException("Class " + var7.getName() + " declares multiple JSON fields named '" + var18.name + "'; conflict is caused by fields " + aN.c(var18.field) + " and " + aN.c(var12));
                  }
               }
            }

            var2 = aS.k(ak.a(var2.bl(), var3, var3.getGenericSuperclass()));
         }

         return var6;
      }
   }

   public abstract static class a<T, A> extends ac<T> {
      final Map<String, b> boundFields;

      a(Map<String, b> var1) {
         this.boundFields = var1;
      }

      public void a(aV var1, T var2) throws IOException {
         if (var2 == null) {
            var1.be();
         } else {
            var1.bc();

            try {
               for(b var4 : this.boundFields.values()) {
                  var4.a((aV)var1, var2);
               }
            } catch (IllegalAccessException var5) {
               throw aN.a(var5);
            }

            var1.bd();
         }
      }

      public T b(aT var1) throws IOException {
         if (var1.aI() == aU.dY) {
            var1.aO();
            return null;
         } else {
            Object var2 = this.bf();

            try {
               var1.aG();

               while(var1.hasNext()) {
                  String var3 = var1.aL();
                  b var4 = (b)this.boundFields.get(var3);
                  if (var4 != null && var4.deserialized) {
                     this.a(var2, var1, var4);
                  } else {
                     var1.aT();
                  }
               }
            } catch (IllegalStateException var5) {
               throw new X(var5);
            } catch (IllegalAccessException var6) {
               throw aN.a(var6);
            }

            var1.aH();
            return (T)this.f(var2);
         }
      }

      abstract A bf();

      abstract void a(A var1, aT var2, b var3) throws IllegalAccessException, IOException;

      abstract T f(A var1);
   }

   abstract static class b {
      final String name;
      final Field field;
      final String fieldName;
      final boolean serialized;
      final boolean deserialized;

      protected b(String var1, Field var2, boolean var3, boolean var4) {
         this.name = var1;
         this.field = var2;
         this.fieldName = var2.getName();
         this.serialized = var3;
         this.deserialized = var4;
      }

      abstract void a(aV var1, Object var2) throws IOException, IllegalAccessException;

      abstract void a(aT var1, int var2, Object[] var3) throws IOException, T;

      abstract void a(aT var1, Object var2) throws IOException, IllegalAccessException;
   }

   static final class c<T> extends a<T, T> {
      private final ar<T> constructor;

      c(ar<T> var1, Map<String, b> var2) {
         super(var2);
         this.constructor = var1;
      }

      T bf() {
         return this.constructor.av();
      }

      void a(T var1, aT var2, b var3) throws IllegalAccessException, IOException {
         var3.a((aT)var2, var1);
      }

      T f(T var1) {
         return var1;
      }
   }

   static final class d<T> extends a<T, Object[]> {
      static final Map<Class<?>, Object> PRIMITIVE_DEFAULTS = bg();
      private final Constructor<T> constructor;
      private final Object[] constructorArgsDefaults;
      private final Map<String, Integer> componentIndices = new HashMap();

      d(Class<T> var1, Map<String, b> var2, boolean var3) {
         super(var2);
         this.constructor = aN.<T>s(var1);
         if (var3) {
            aH.a((Object)null, this.constructor);
         } else {
            aN.a(this.constructor);
         }

         String[] var4 = aN.r(var1);

         for(int var5 = 0; var5 < var4.length; ++var5) {
            this.componentIndices.put(var4[var5], var5);
         }

         Class[] var7 = this.constructor.getParameterTypes();
         this.constructorArgsDefaults = new Object[var7.length];

         for(int var6 = 0; var6 < var7.length; ++var6) {
            this.constructorArgsDefaults[var6] = PRIMITIVE_DEFAULTS.get(var7[var6]);
         }

      }

      private static Map<Class<?>, Object> bg() {
         HashMap var0 = new HashMap();
         var0.put(Byte.TYPE, (byte)0);
         var0.put(Short.TYPE, (short)0);
         var0.put(Integer.TYPE, 0);
         var0.put(Long.TYPE, 0L);
         var0.put(Float.TYPE, 0.0F);
         var0.put(Double.TYPE, (double)0.0F);
         var0.put(Character.TYPE, '\u0000');
         var0.put(Boolean.TYPE, false);
         return var0;
      }

      Object[] bh() {
         return this.constructorArgsDefaults.clone();
      }

      void a(Object[] var1, aT var2, b var3) throws IOException {
         Integer var4 = (Integer)this.componentIndices.get(var3.fieldName);
         if (var4 == null) {
            throw new IllegalStateException("Could not find the index in the constructor '" + aN.a(this.constructor) + "' for field with name '" + var3.fieldName + "', unable to determine which argument in the constructor the field corresponds to. This is unexpected behavior, as we expect the RecordComponents to have the same names as the fields in the Java class, and that the order of the RecordComponents is the same as the order of the canonical constructor parameters.");
         } else {
            var3.a(var2, var4, var1);
         }
      }

      T a(Object[] var1) {
         try {
            return (T)this.constructor.newInstance(var1);
         } catch (IllegalAccessException var3) {
            throw aN.a(var3);
         } catch (IllegalArgumentException | InstantiationException var4) {
            throw new RuntimeException("Failed to invoke constructor '" + aN.a(this.constructor) + "' with args " + Arrays.toString(var1), var4);
         } catch (InvocationTargetException var5) {
            throw new RuntimeException("Failed to invoke constructor '" + aN.a(this.constructor) + "' with args " + Arrays.toString(var1), var5.getCause());
         }
      }

      // $FF: synthetic method
      Object f(Object var1) {
         return this.a(var1);
      }

      // $FF: synthetic method
      Object bf() {
         return this.bh();
      }
   }
}
