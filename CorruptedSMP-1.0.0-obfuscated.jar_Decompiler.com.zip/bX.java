import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.URI;
import java.net.UnknownHostException;
import java.net.Proxy.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

public final class bX {
   public static final a lA = new a((fP)null);
   private final aX lB;
   private final bV lC;
   private final bb lD;
   private final bo lE;
   private List<? extends Proxy> lF;
   private int lG;
   private List<? extends InetSocketAddress> lH;
   private final List<bA> lI;

   public bX(aX var1, bV var2, bb var3, bo var4) {
      fR.c(var1, (String)"");
      fR.c(var2, (String)"");
      fR.c(var3, (String)"");
      fR.c(var4, (String)"");
      super();
      this.lB = var1;
      this.lC = var2;
      this.lD = var3;
      this.lE = var4;
      this.lF = eO.nk();
      this.lH = eO.nk();
      this.lI = (List)(new ArrayList());
      this.a(this.lB.bK(), this.lB.bI());
   }

   public final boolean hy() {
      return this.hA() || !((Collection)this.lI).isEmpty();
   }

   public final b hz() throws IOException {
      if (!this.hy()) {
         throw new NoSuchElementException();
      } else {
         List var1 = (List)(new ArrayList());

         while(this.hA()) {
            Proxy var2 = this.hB();

            for(InetSocketAddress var4 : this.lH) {
               bA var5 = new bA(this.lB, var2, var4);
               if (this.lC.c(var5)) {
                  ((Collection)this.lI).add(var5);
               } else {
                  ((Collection)var1).add(var5);
               }
            }

            if (!((Collection)var1).isEmpty()) {
               break;
            }
         }

         if (var1.isEmpty()) {
            eO.a((Collection)var1, (Iterable)this.lI);
            this.lI.clear();
         }

         return new b(var1);
      }
   }

   private final void a(br var1, Proxy var2) {
      this.lE.a(this.lD, var1);
      this.lF = a(var2, var1, this);
      this.lG = 0;
      this.lE.a(this.lD, var1, this.lF);
   }

   private final boolean hA() {
      return this.lG < this.lF.size();
   }

   private final Proxy hB() throws IOException {
      if (!this.hA()) {
         throw new SocketException("No route to " + this.lB.bK().cY() + "; exhausted proxy configurations: " + this.lF);
      } else {
         List var10000 = this.lF;
         int var2 = this.lG++;
         Proxy var1 = (Proxy)var10000.get(var2);
         this.a(var1);
         return var1;
      }
   }

   private final void a(Proxy var1) throws IOException {
      List var2 = (List)(new ArrayList());
      this.lH = var2;
      String var3 = null;
      int var4 = 0;
      if (var1.type() != Type.DIRECT && var1.type() != Type.SOCKS) {
         SocketAddress var5 = var1.address();
         if (!(var5 instanceof InetSocketAddress)) {
            boolean var12 = false;
            String var13 = "Proxy.address() is not an InetSocketAddress: " + var5.getClass();
            throw new IllegalArgumentException(var13.toString());
         }

         a var10000 = lA;
         fR.b(var5, "");
         var3 = var10000.a((InetSocketAddress)var5);
         var4 = ((InetSocketAddress)var5).getPort();
      } else {
         var3 = this.lB.bK().cY();
         var4 = this.lB.bK().cZ();
      }

      if (!(1 <= var4 ? var4 < 65536 : false)) {
         throw new SocketException("No route to " + var3 + ':' + var4 + "; port is out of range");
      } else {
         if (var1.type() == Type.SOCKS) {
            ((Collection)var2).add(InetSocketAddress.createUnresolved(var3, var4));
         } else {
            List var14;
            if (bD.aq(var3)) {
               var14 = eO.i(InetAddress.getByName(var3));
            } else {
               this.lE.a(this.lD, var3);
               List var6 = this.lB.bC().D(var3);
               if (var6.isEmpty()) {
                  throw new UnknownHostException(this.lB.bC() + " returned no addresses for " + var3);
               }

               this.lE.a(this.lD, var3, var6);
               var14 = var6;
            }

            for(InetAddress var7 : var14) {
               ((Collection)var2).add(new InetSocketAddress(var7, var4));
            }
         }

      }
   }

   private static final List<Proxy> a(Proxy var0, br var1, bX var2) {
      if (var0 != null) {
         return eO.i(var0);
      } else {
         URI var3 = var1.dc();
         if (var3.getHost() == null) {
            Proxy[] var6 = new Proxy[]{Proxy.NO_PROXY};
            return bD.b(var6);
         } else {
            List var4 = var2.lB.bJ().select(var3);
            Collection var5 = (Collection)var4;
            if (var5 == null || var5.isEmpty()) {
               Proxy[] var7 = new Proxy[]{Proxy.NO_PROXY};
               return bD.b(var7);
            } else {
               fR.b(var4, "");
               return bD.b(var4);
            }
         }
      }
   }

   public static final class a {
      private a() {
      }

      public final String a(InetSocketAddress var1) {
         fR.c(var1, (String)"");
         InetAddress var10000 = var1.getAddress();
         if (var10000 == null) {
            String var4 = var1.getHostName();
            fR.b(var4, "");
            return var4;
         } else {
            InetAddress var2 = var10000;
            String var3 = var2.getHostAddress();
            fR.b(var3, "");
            return var3;
         }
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public static final class b {
      private final List<bA> routes;
      private int nextRouteIndex;

      public b(List<bA> var1) {
         fR.c(var1, (String)"");
         super();
         this.routes = var1;
      }

      public final List<bA> hC() {
         return this.routes;
      }

      public final boolean hD() {
         return this.nextRouteIndex < this.routes.size();
      }

      public final bA hE() {
         if (!this.hD()) {
            throw new NoSuchElementException();
         } else {
            List var10000 = this.routes;
            int var1 = this.nextRouteIndex++;
            return (bA)var10000.get(var1);
         }
      }
   }
}
