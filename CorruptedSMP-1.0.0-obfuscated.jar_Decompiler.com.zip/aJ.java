import java.io.IOException;

public final class aJ<T> extends aI<T> {
   private final W<T> cg;
   private final O<T> ch;
   final K ci;
   private final aS<T> cj;
   private final ad ck;
   private final aJ<T>.a cl = new a();
   private final boolean cm;
   private volatile ac<T> delegate;

   public aJ(W<T> var1, O<T> var2, K var3, aS<T> var4, ad var5, boolean var6) {
      this.cg = var1;
      this.ch = var2;
      this.ci = var3;
      this.cj = var4;
      this.ck = var5;
      this.cm = var6;
   }

   public T b(aT var1) throws IOException {
      if (this.ch == null) {
         return (T)this.U().b(var1);
      } else {
         P var2 = av.k(var1);
         return (T)(this.cm && var2.ag() ? null : this.ch.a(var2, this.cj.bl(), this.cl));
      }
   }

   public void a(aV var1, T var2) throws IOException {
      if (this.cg == null) {
         this.U().a(var1, var2);
      } else if (this.cm && var2 == null) {
         var1.be();
      } else {
         P var3 = this.cg.a(var2, this.cj.bl(), this.cl);
         av.a(var3, var1);
      }
   }

   private ac<T> U() {
      ac var1 = this.delegate;
      return var1 != null ? var1 : (this.delegate = this.ci.a(this.ck, this.cj));
   }

   public ac<T> V() {
      return (ac<T>)(this.cg != null ? this : this.U());
   }

   final class a implements N, V {
      private a() {
      }
   }
}
