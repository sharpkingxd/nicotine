import java.util.Iterator;

public class gd implements fY, Iterable<Integer> {
   public static final a sU = new a((fP)null);
   private final int sV;
   private final int sW;
   private final int sX;

   public gd(int var1, int var2, int var3) {
      if (var3 == 0) {
         throw new IllegalArgumentException("Step must be non-zero.");
      } else if (var3 == Integer.MIN_VALUE) {
         throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
      } else {
         this.sV = var1;
         this.sW = fF.i(var1, var2, var3);
         this.sX = var3;
      }
   }

   public final int nC() {
      return this.sV;
   }

   public final int nD() {
      return this.sW;
   }

   public final int nE() {
      return this.sX;
   }

   public fd nF() {
      return new ge(this.sV, this.sW, this.sX);
   }

   public boolean isEmpty() {
      return this.sX > 0 ? this.sV > this.sW : this.sV < this.sW;
   }

   public boolean equals(Object var1) {
      return var1 instanceof gd && (this.isEmpty() && ((gd)var1).isEmpty() || this.sV == ((gd)var1).sV && this.sW == ((gd)var1).sW && this.sX == ((gd)var1).sX);
   }

   public int hashCode() {
      return this.isEmpty() ? -1 : 31 * (31 * this.sV + this.sW) + this.sX;
   }

   public String toString() {
      return this.sX > 0 ? this.sV + ".." + this.sW + " step " + this.sX : this.sV + " downTo " + this.sW + " step " + -this.sX;
   }

   // $FF: synthetic method
   public Iterator iterator() {
      return this.nF();
   }

   public static final class a {
      private a() {
      }

      public final gd j(int var1, int var2, int var3) {
         return new gd(var1, var2, var3);
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
