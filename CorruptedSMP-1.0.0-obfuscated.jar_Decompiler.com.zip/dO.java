import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class dO implements Listener {
   private final CorruptedSMPPlugin rh;

   public dO(CorruptedSMPPlugin var1) {
      this.rh = var1;
   }

   @EventHandler
   public void c(EntityDamageEvent var1) {
      if (var1.getEntity() instanceof Item) {
         Item var2 = (Item)var1.getEntity();
         ItemStack var3 = var2.getItemStack();
         if (this.a(var3)) {
            EntityDamageEvent.DamageCause var4 = var1.getCause();
            if (var4 == DamageCause.FIRE || var4 == DamageCause.FIRE_TICK || var4 == DamageCause.LAVA || var4 == DamageCause.CONTACT) {
               var1.setCancelled(true);
               if (var2.getFireTicks() > 0) {
                  var2.setFireTicks(0);
               }
            }

         }
      }
   }

   @EventHandler
   public void a(ItemSpawnEvent var1) {
      Item var2 = var1.getEntity();
      ItemStack var3 = var2.getItemStack();
      if (this.a(var3)) {
         var2.setGlowing(true);
      }
   }

   private boolean a(ItemStack var1) {
      if (var1 != null && var1.getType() == Material.FLOW_BANNER_PATTERN) {
         ItemMeta var2 = var1.getItemMeta();
         if (var2 != null && var2.hasCustomModelData()) {
            int var3 = var2.getCustomModelData();
            return var3 >= 401 && var3 <= 409;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }
}
