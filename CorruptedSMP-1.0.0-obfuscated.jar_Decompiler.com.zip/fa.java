import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public final class fa implements fY, Serializable, List, RandomAccess {
   public static final fa sw = new fa();
   private static final long serialVersionUID = -7390468764508069838L;

   private fa() {
   }

   public boolean equals(Object var1) {
      return var1 instanceof List && ((List)var1).isEmpty();
   }

   public int hashCode() {
      return 1;
   }

   public String toString() {
      return "[]";
   }

   public int getSize() {
      return 0;
   }

   public boolean isEmpty() {
      return true;
   }

   public boolean a(Void var1) {
      fR.c(var1, (String)"");
      return false;
   }

   public boolean containsAll(Collection var1) {
      fR.c(var1, (String)"");
      return var1.isEmpty();
   }

   public Void am(int var1) {
      throw new IndexOutOfBoundsException("Empty list doesn't contain element at index " + var1 + '.');
   }

   public int b(Void var1) {
      fR.c(var1, (String)"");
      return -1;
   }

   public int c(Void var1) {
      fR.c(var1, (String)"");
      return -1;
   }

   public Iterator iterator() {
      return (Iterator)eZ.sv;
   }

   public ListIterator listIterator() {
      return eZ.sv;
   }

   public ListIterator listIterator(int var1) {
      if (var1 != 0) {
         throw new IndexOutOfBoundsException("Index: " + var1);
      } else {
         return eZ.sv;
      }
   }

   public List subList(int var1, int var2) {
      if (var1 == 0 && var2 == 0) {
         return this;
      } else {
         throw new IndexOutOfBoundsException("fromIndex: " + var1 + ", toIndex: " + var2);
      }
   }

   private final Object readResolve() {
      return sw;
   }

   public boolean addAll(int var1, Collection var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean addAll(Collection var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public void clear() {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean remove(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean removeAll(Collection var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public Object remove(int var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public boolean retainAll(Collection var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public final int size() {
      return this.getSize();
   }

   public final boolean contains(Object var1) {
      return !(var1 instanceof Void) ? false : this.a((Void)var1);
   }

   // $FF: synthetic method
   public Object get(int var1) {
      return this.am(var1);
   }

   public final int indexOf(Object var1) {
      return !(var1 instanceof Void) ? -1 : this.b((Void)var1);
   }

   public final int lastIndexOf(Object var1) {
      return !(var1 instanceof Void) ? -1 : this.c((Void)var1);
   }

   // $FF: synthetic method
   public boolean add(Object var1) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public void add(int var1, Object var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   // $FF: synthetic method
   public Object set(int var1, Object var2) {
      throw new UnsupportedOperationException("Operation is not supported for read-only collection");
   }

   public <T> T[] toArray(T[] var1) {
      fR.c(var1, (String)"");
      return (T[])fO.b((Collection)this, var1);
   }

   public Object[] toArray() {
      return fO.c((Collection)this);
   }
}
