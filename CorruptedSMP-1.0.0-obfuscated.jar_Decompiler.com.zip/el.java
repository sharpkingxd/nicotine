import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class el {
   final CorruptedSMPPlugin rJ;
   final Player rK;
   private final l rL;
   private final Location rM;
   private final int rN;
   int rO;
   private BukkitTask task;
   private boolean completed;
   private BossBar rP;
   private ArmorStand rQ;
   private ArmorStand rR;
   private Item rS;
   private em rT;

   public el(CorruptedSMPPlugin var1, Player var2, l var3, Location var4, int var5, int var6) {
      this.rJ = var1;
      this.rK = var2;
      this.rL = var3;
      this.rM = new Location(var4.getWorld(), (double)var4.getBlockX(), (double)var4.getBlockY(), (double)var4.getBlockZ());
      this.rN = var5;
      this.rO = var5;
      this.completed = false;
   }

   public void mF() {
      this.mI();
      this.mG();
      this.mH();
      this.rT = new em(this.rJ);
      this.rT.a(this.rM, this.rN);
      this.mK();
      this.task = (new BukkitRunnable() {
         int particleAngle = 0;
         double hologramRotation = (double)0.0F;
         boolean fiveMinuteWarning = false;
         boolean twoMinuteLightning = false;

         public void run() {
            if (el.this.rJ.getConfig().getBoolean("rituals.particles-enabled", true)) {
               el.this.ak(this.particleAngle);
               this.particleAngle += 10;
            }

            this.hologramRotation += (double)72.0F;
            if (this.hologramRotation >= (double)360.0F) {
               this.hologramRotation -= (double)360.0F;
            }

            el.this.e(this.hologramRotation);
            el.this.f(this.hologramRotation);
            el.this.mJ();
            --el.this.rO;
            if (el.this.rO == 300 && !this.fiveMinuteWarning) {
               this.fiveMinuteWarning = true;
               el.this.mL();
            }

            if (el.this.rO <= 120 && !this.twoMinuteLightning) {
               this.twoMinuteLightning = true;
               el.this.mM();
            }

            if (el.this.rO <= 120 && el.this.rO % 5 == 0) {
               el.this.mN();
            }

            if (el.this.rO <= 0) {
               el.this.rJ.e().j(el.this.rK.getUniqueId());
               this.cancel();
            }

         }
      }).runTaskTimer(this.rJ, 0L, 20L);
   }

   private void mG() {
      World var1 = this.rM.getWorld();
      if (var1 != null) {
         Location var2 = this.rM.clone().add((double)0.5F, (double)2.5F, (double)0.5F);
         this.rQ = (ArmorStand)var1.spawnEntity(var2, EntityType.ARMOR_STAND);
         this.rQ.setVisible(false);
         this.rQ.setGravity(false);
         this.rQ.setInvulnerable(true);
         this.rQ.setCustomNameVisible(true);
         this.rQ.setCustomName(this.rL.o() + " §fRitual");
         this.rQ.setMarker(true);
         this.rQ.setPersistent(false);
         this.rQ.setGlowing(true);
      }
   }

   private void mH() {
      World var1 = this.rM.getWorld();
      if (var1 != null) {
         Location var2 = this.rM.clone().add((double)0.5F, (double)1.5F, (double)0.5F);
         this.rR = (ArmorStand)var1.spawnEntity(var2, EntityType.ARMOR_STAND);
         this.rR.setVisible(false);
         this.rR.setGravity(false);
         this.rR.setInvulnerable(true);
         this.rR.setCustomNameVisible(false);
         this.rR.setMarker(true);
         this.rR.setPersistent(false);
         this.rR.setSmall(false);
         ItemStack var3 = this.mT();
         this.rR.getEquipment().setHelmet(var3);
         this.rR.setGlowing(true);
      }
   }

   void e(double var1) {
      if (this.rQ != null && this.rQ.isValid()) {
         Location var3 = this.rQ.getLocation();
         var3.setYaw((float)var1);
         this.rQ.teleport(var3);
         double var4 = Math.sin(Math.toRadians(var1 * (double)2.0F)) * 0.1;
         Location var6 = this.rM.clone().add((double)0.5F, (double)2.5F + var4, (double)0.5F);
         var6.setYaw((float)var1);
         this.rQ.teleport(var6);
      }
   }

   void f(double var1) {
      if (this.rR != null && this.rR.isValid()) {
         double var3 = Math.sin(Math.toRadians(var1 * (double)2.0F)) * 0.15;
         Location var5 = this.rM.clone().add((double)0.5F, (double)1.5F + var3, (double)0.5F);
         var5.setYaw((float)(var1 * (double)2.0F));
         this.rR.teleport(var5);
      }
   }

   private void mI() {
      String var1 = String.format("§l%s §fRitual §7[X:%d Y:%d Z:%d]", this.rL.o(), this.rM.getBlockX(), this.rM.getBlockY(), this.rM.getBlockZ());
      BarColor var2 = this.mP();
      this.rP = Bukkit.createBossBar(var1, var2, BarStyle.SOLID, new BarFlag[0]);
      this.rP.setProgress((double)1.0F);

      for(Player var4 : Bukkit.getOnlinePlayers()) {
         this.rP.addPlayer(var4);
      }

   }

   void mJ() {
      if (this.rP != null) {
         double var1 = (double)this.rO / (double)this.rN;
         this.rP.setProgress(Math.max((double)0.0F, Math.min((double)1.0F, var1)));
         int var3 = this.rO / 60;
         int var4 = this.rO % 60;
         String var5 = String.format("%02d:%02d", var3, var4);
         String var6 = String.format("§l%s §fRitual §7[X:%d Y:%d Z:%d] §e%s", this.rL.o(), this.rM.getBlockX(), this.rM.getBlockY(), this.rM.getBlockZ(), var5);
         this.rP.setTitle(var6);
         if (this.rO % 60 == 0 && this.rO > 0) {
            for(Player var8 : Bukkit.getOnlinePlayers()) {
               var8.playSound(var8.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5F, 1.0F);
            }
         }

      }
   }

   private void mK() {
      String var1 = this.mZ();
      String var2 = String.format("§8§m                                                    §r\n§e§l⚠ RITUAL STARTED! ⚠\n§7Player: §f%s\n§7Corruption: %s\n§7World: §f%s\n§7Location: §fX:%d Y:%d Z:%d\n§7Duration: §e15 minutes\n§c§lAnyone can claim the corruption core!\n§8§m                                                    ", this.rK.getName(), this.rL.o(), var1, this.rM.getBlockX(), this.rM.getBlockY(), this.rM.getBlockZ());

      for(Player var4 : Bukkit.getOnlinePlayers()) {
         var4.sendMessage(var2);
         var4.playSound(var4.getLocation(), Sound.BLOCK_END_PORTAL_SPAWN, 1.0F, 1.0F);
         var4.playSound(var4.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7F, 0.8F);
         var4.playSound(var4.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5F, 1.2F);
         var4.playSound(var4.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8F, 0.8F);
      }

      World var16 = this.rM.getWorld();
      if (var16 != null) {
         Location var17 = this.rM.clone().add((double)0.5F, (double)1.0F, (double)0.5F);
         var16.playSound(var17, Sound.BLOCK_END_PORTAL_SPAWN, 3.0F, 1.0F);
         var16.playSound(var17, Sound.ENTITY_WITHER_SPAWN, 1.5F, 1.5F);
         Color var5 = this.mO();
         Particle.DustOptions var6 = new Particle.DustOptions(var5, 2.0F);
         var16.spawnParticle(Particle.EXPLOSION_EMITTER, var17, 2);
         var16.spawnParticle(Particle.DUST, var17, 100, (double)2.0F, (double)2.0F, (double)2.0F, (double)0.0F, var6);

         try {
            var16.spawnParticle(this.mQ(), var17, 50, (double)1.5F, (double)1.5F, (double)1.5F, 0.2);
         } catch (Exception var15) {
         }

         for(int var7 = 0; var7 < 20; ++var7) {
            double var8 = (Math.random() - (double)0.5F) * (double)3.0F;
            double var10 = (Math.random() - (double)0.5F) * (double)3.0F;
            double var12 = Math.random() * (double)3.0F;
            Location var14 = var17.clone().add(var8, var12, var10);
            var16.spawnParticle(Particle.PORTAL, var14, 10, 0.1, 0.1, 0.1, (double)0.5F);
         }
      }

   }

   void mL() {
      String var1 = this.mZ();
      String var2 = String.format("§8§m                                                    §r\n§c§l⚡ 5 MINUTES REMAINING! ⚡\n§e§lRACE TO THE RITUAL LOCATION!\n§7Corruption: %s\n§7World: §f%s\n§7Location: §f§lX:%d Y:%d Z:%d\n§6§lBe the first to claim the core!\n§8§m                                                    ", this.rL.o(), var1, this.rM.getBlockX(), this.rM.getBlockY(), this.rM.getBlockZ());

      for(Player var4 : Bukkit.getOnlinePlayers()) {
         var4.sendMessage(var2);
         var4.playSound(var4.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0F, 2.0F);
         var4.playSound(var4.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8F, 1.2F);
      }

   }

   void mM() {
      String var1 = this.mZ();
      String var2 = String.format("§8§m                                                    §r\n§4§l⚡ 2 MINUTES REMAINING! ⚡\n§c§lTHE RITUAL IS REACHING ITS CLIMAX!\n§7World: §f%s\n§7Location: §f§lX:%d Y:%d Z:%d\n§6§lHURRY! THE CORE WILL DROP SOON!\n§8§m                                                    ", var1, this.rM.getBlockX(), this.rM.getBlockY(), this.rM.getBlockZ());

      for(Player var4 : Bukkit.getOnlinePlayers()) {
         var4.sendMessage(var2);
         var4.playSound(var4.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0F, 0.8F);
         var4.playSound(var4.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5F, 1.5F);
      }

   }

   void mN() {
      World var1 = this.rM.getWorld();
      if (var1 != null) {
         for(int var2 = 0; var2 < 2; ++var2) {
            double var3 = Math.random() * (double)2.0F * Math.PI;
            double var5 = (double)5.0F + Math.random() * (double)10.0F;
            double var7 = Math.cos(var3) * var5;
            double var9 = Math.sin(var3) * var5;
            Location var11 = this.rM.clone().add(var7, (double)0.0F, var9);
            var11.setY((double)var1.getHighestBlockYAt(var11));
            var1.strikeLightningEffect(var11);
         }

      }
   }

   void ak(int var1) {
      World var2 = this.rM.getWorld();
      if (var2 != null) {
         Color var3 = this.mO();
         Particle.DustOptions var4 = new Particle.DustOptions(var3, 1.5F);
         double var5 = (double)5.0F;
         double var7 = this.rM.getX() + (double)0.5F;
         double var9 = this.rM.getY() + (double)0.9375F;
         double var11 = this.rM.getZ() + (double)0.5F;

         for(int var13 = 0; var13 < 360; var13 += 15) {
            double var14 = Math.toRadians((double)(var13 + var1));
            double var16 = var7 + var5 * Math.cos(var14);
            double var18 = var11 + var5 * Math.sin(var14);
            double var20 = var9 + 0.1;
            Location var22 = new Location(var2, var16, var20, var18);
            var2.spawnParticle(Particle.DUST, var22, 1, 0.02, 0.02, 0.02, (double)0.0F, var4);
         }

      }
   }

   private Color mO() {
      Color var10000;
      switch (this.rL) {
         case C -> var10000 = Color.fromRGB(255, 50, 50);
         case E -> var10000 = Color.fromRGB(30, 100, 200);
         case D -> var10000 = Color.fromRGB(192, 192, 192);
         case B -> var10000 = Color.fromRGB(255, 255, 0);
         case A -> var10000 = Color.fromRGB(255, 140, 0);
         case w -> var10000 = Color.fromRGB(230, 240, 255);
         case v -> var10000 = Color.fromRGB(128, 0, 128);
         case u -> var10000 = Color.fromRGB(30, 30, 30);
         case t -> var10000 = Color.fromRGB(255, 0, 255);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private BarColor mP() {
      BarColor var10000;
      switch (this.rL) {
         case C -> var10000 = BarColor.RED;
         case E -> var10000 = BarColor.BLUE;
         case D -> var10000 = BarColor.WHITE;
         case B -> var10000 = BarColor.YELLOW;
         case A -> var10000 = BarColor.RED;
         case w -> var10000 = BarColor.WHITE;
         case v -> var10000 = BarColor.PURPLE;
         case u -> var10000 = BarColor.PURPLE;
         case t -> var10000 = BarColor.PINK;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private Particle mQ() {
      Particle var10000;
      switch (this.rL) {
         case C -> var10000 = Particle.HEART;
         case E -> var10000 = Particle.DRIPPING_WATER;
         case D -> var10000 = Particle.ENCHANTED_HIT;
         case B -> var10000 = Particle.CLOUD;
         case A -> var10000 = Particle.FLAME;
         case w -> var10000 = Particle.GUST;
         case v -> var10000 = Particle.PORTAL;
         case u -> var10000 = Particle.LARGE_SMOKE;
         case t -> var10000 = Particle.ENCHANTED_HIT;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void mR() {
      if (!this.completed) {
         this.completed = true;
         if (this.task != null) {
            this.task.cancel();
         }

         this.rJ.i().e(this.rK, this.rL);
         this.mS();
         if (this.rP != null) {
            this.rP.removeAll();
            this.rP = null;
         }

         if (this.rQ != null && this.rQ.isValid()) {
            this.rQ.remove();
            this.rQ = null;
         }

         if (this.rR != null && this.rR.isValid()) {
            this.rR.remove();
            this.rR = null;
         }

         ItemStack var1 = this.mT();
         Location var2 = this.rM.clone().add((double)0.5F, (double)1.5F, (double)0.5F);
         this.rS = this.rM.getWorld().dropItem(var2, var1);
         if (this.rS != null) {
            this.rS.setGlowing(true);
            this.rS.setPickupDelay(20);
            this.rS.setVelocity(new Vector(0, 0, 0));
            this.rS.setCustomName(this.rL.o() + " §fCore");
            this.rS.setCustomNameVisible(true);
         }

         World var3 = this.rM.getWorld();
         if (var3 != null) {
            Location var4 = this.rM.clone().add((double)0.5F, (double)1.0F, (double)0.5F);

            for(Player var6 : Bukkit.getOnlinePlayers()) {
               var6.playSound(var6.getLocation(), Sound.ENTITY_ENDER_DRAGON_DEATH, 1.0F, 1.0F);
               var6.playSound(var6.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
               var6.playSound(var6.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
               var6.playSound(var6.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.0F, 1.5F);
            }

            var3.playSound(var4, Sound.ENTITY_ENDER_DRAGON_DEATH, 3.0F, 1.0F);
            var3.playSound(var4, Sound.ENTITY_WITHER_DEATH, 2.0F, 1.2F);
            var3.playSound(var4, Sound.ENTITY_GENERIC_EXPLODE, 2.0F, 0.8F);
            var3.playSound(var4, Sound.BLOCK_END_PORTAL_SPAWN, 2.0F, 1.5F);
            Color var19 = this.mO();
            Particle.DustOptions var21 = new Particle.DustOptions(var19, 2.0F);
            var3.spawnParticle(Particle.EXPLOSION, var4, 10, (double)1.0F, (double)1.0F, (double)1.0F, (double)0.0F);
            var3.spawnParticle(Particle.DUST, var4, 30, (double)2.0F, (double)2.0F, (double)2.0F, (double)0.0F, var21);

            try {
               var3.spawnParticle(this.mQ(), var4, 20, (double)1.5F, (double)1.5F, (double)1.5F, 0.3);
            } catch (Exception var17) {
               var3.spawnParticle(Particle.ENCHANTED_HIT, var4, 20, (double)1.5F, (double)1.5F, (double)1.5F, 0.1);
            }

            for(int var7 = 0; var7 < 360; var7 += 30) {
               double var8 = Math.toRadians((double)var7);
               double var10 = var4.getX() + (double)2.0F * Math.cos(var8);
               double var12 = var4.getZ() + (double)2.0F * Math.sin(var8);
               double var14 = var4.getY() + (double)2.0F;
               Location var16 = new Location(var3, var10, var14, var12);
               var3.spawnParticle(Particle.FLAME, var16, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
            }
         }

         String var18 = this.mZ();
         String var20 = String.format("§8§m                                                    §r\n§a§l✓ RITUAL COMPLETE! ✓\n§7Corruption: %s\n§7World: §f%s\n§7Location: §fX:%d Y:%d Z:%d\n§e§lThe corruption core has been dropped!\n§c§lFirst to pick it up claims it!\n§8§m                                                    ", this.rL.o(), var18, this.rM.getBlockX(), this.rM.getBlockY(), this.rM.getBlockZ());

         for(Player var23 : Bukkit.getOnlinePlayers()) {
            var23.sendMessage(var20);
         }

      }
   }

   private void mS() {
      if (this.rT != null) {
         try {
            this.rT.na();
         } catch (Exception var2) {
            this.rJ.getLogger().warning("Error stopping ritual beam: " + var2.getMessage());
         }

         this.rT = null;
      }

   }

   public void t() {
      this.mS();
      if (this.task != null && !this.task.isCancelled()) {
         this.task.cancel();
      }

      if (this.rP != null) {
         this.rP.removeAll();
         this.rP = null;
      }

      if (this.rQ != null && this.rQ.isValid()) {
         this.rQ.remove();
         this.rQ = null;
      }

      if (this.rR != null && this.rR.isValid()) {
         this.rR.remove();
         this.rR = null;
      }

      if (this.rS != null && this.rS.isValid()) {
         this.rS.remove();
         this.rS = null;
      }

   }

   private ItemStack mT() {
      ItemStack var1 = new ItemStack(Material.FLOW_BANNER_PATTERN);
      ItemMeta var2 = var1.getItemMeta();
      if (var2 != null) {
         var2.setDisplayName(this.rL.o() + " §fCore");
         var2.setLore(j.b(this.rL));
         var2.setCustomModelData(this.rL.n());
         var2.addEnchant(Enchantment.UNBREAKING, 1, true);
         var2.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         var1.setItemMeta(var2);
      }

      return var1;
   }

   public Player mU() {
      return this.rK;
   }

   public l mV() {
      return this.rL;
   }

   public int mW() {
      return this.rO;
   }

   public Location mX() {
      return this.rM;
   }

   public boolean mY() {
      return this.completed;
   }

   public void h(Player var1) {
      if (this.rP != null && !this.completed) {
         this.rP.addPlayer(var1);
      }

   }

   public void i(Player var1) {
      if (this.rP != null) {
         this.rP.removePlayer(var1);
      }

   }

   private String mZ() {
      World var1 = this.rM.getWorld();
      if (var1 == null) {
         return "Unknown";
      } else {
         String var10000;
         switch (var1.getEnvironment()) {
            case NORMAL -> var10000 = "Overworld";
            case NETHER -> var10000 = "Nether";
            case THE_END -> var10000 = "The End";
            default -> var10000 = var1.getName();
         }

         return var10000;
      }
   }
}
