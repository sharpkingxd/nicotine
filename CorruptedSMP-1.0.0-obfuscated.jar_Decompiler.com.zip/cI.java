import android.annotation.SuppressLint;
import android.net.ssl.SSLSockets;
import android.os.Build.VERSION;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;

@SuppressLint({"NewApi"})
public final class cI implements cR {
   public static final a oX = new a((fP)null);

   public boolean f(SSLSocket var1) {
      fR.c(var1, (String)"");
      return SSLSockets.isSupportedSocket(var1);
   }

   public boolean jB() {
      return oX.ki();
   }

   @SuppressLint({"NewApi"})
   public String d(SSLSocket var1) {
      fR.c(var1, (String)"");
      String var2 = var1.getApplicationProtocol();
      return (var2 == null ? true : fR.c(var2, (Object)"")) ? null : var2;
   }

   @SuppressLint({"NewApi"})
   public void a(SSLSocket var1, String var2, List<? extends bv> var3) {
      fR.c(var1, (String)"");
      fR.c(var3, (String)"");

      try {
         SSLSockets.setUseSessionTickets(var1, true);
         SSLParameters var4 = var1.getSSLParameters();
         Collection var5 = (Collection)cH.oU.h(var3);
         boolean var6 = false;
         var4.setApplicationProtocols((String[])var5.toArray(new String[0]));
         var1.setSSLParameters(var4);
      } catch (IllegalArgumentException var8) {
         throw new IOException("Android internal error", (Throwable)var8);
      }
   }

   public static final class a {
      private a() {
      }

      public final cR kh() {
         return this.ki() ? (cR)(new cI()) : null;
      }

      public final boolean ki() {
         return cH.oU.ka() && VERSION.SDK_INT >= 29;
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
