import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class k {
   private final CorruptedSMPPlugin q;
   private final Map<String, Long> r;
   private final Map<String, Boolean> s;

   public k(CorruptedSMPPlugin var1) {
      this.q = var1;
      this.r = new HashMap();
      this.s = new HashMap();
   }

   public void a(Player var1, l var2) {
      D var3 = this.q.f().g(var1.getUniqueId());
      var3.g(var2);
      var3.a(true);
      String var4 = this.q.getConfig().getString("messages.corruption-gained").replace("{corruption}", var2.o());
      var1.sendMessage(this.a(var4));
      this.c(var1, var2);
      this.q.h().j(var1);
   }

   public void a(Player var1) {
      D var2 = this.q.f().g(var1.getUniqueId());
      var2.g((l)null);
      var2.a(false);
      var2.R();
      String var3 = this.q.getConfig().getString("messages.corruption-reset");
      var1.sendMessage(this.a(var3));
      var1.getActivePotionEffects().forEach((var1x) -> var1.removePotionEffect(var1x.getType()));
      this.q.h().k(var1);
   }

   public boolean b(Player var1) {
      D var2 = this.q.f().g(var1.getUniqueId());
      return var2.B();
   }

   public l c(Player var1) {
      D var2 = this.q.f().g(var1.getUniqueId());
      return var2.A();
   }

   public boolean d(Player var1) {
      if (!this.b(var1)) {
         var1.sendMessage(this.a(this.q.getConfig().getString("messages.no-corruption")));
         return false;
      } else {
         l var2 = this.c(var1);
         if (var2 == null) {
            return false;
         } else {
            String var10000 = String.valueOf(var1.getUniqueId());
            String var3 = var10000 + "-" + var2.name();
            if (this.r.containsKey(var3)) {
               long var4 = ((Long)this.r.get(var3) - System.currentTimeMillis()) / 1000L;
               if (var4 > 0L) {
                  if (!(Boolean)this.s.getOrDefault(var3, false)) {
                     String var6 = this.q.getConfig().getString("messages.ability-cooldown").replace("{time}", String.valueOf(var4));
                     var1.sendMessage(this.a(var6));
                     this.s.put(var3, true);
                  }

                  return false;
               }

               this.s.remove(var3);
            }

            boolean var7 = this.b(var1, var2);
            if (var7) {
               int var5 = this.q.getConfig().getInt("corruptions." + var2.m().toLowerCase() + ".ability-cooldown", 120);
               this.r.put(var3, System.currentTimeMillis() + (long)var5 * 1000L);
               this.s.remove(var3);
            }

            return var7;
         }
      }
   }

   private boolean b(Player var1, l var2) {
      switch (var2) {
         case C -> {
            return s.a(var1, this.q);
         }
         case E -> {
            return w.a(var1, this.q);
         }
         case D -> {
            return u.a(var1, this.q);
         }
         case B -> {
            return y.a(var1, this.q);
         }
         case A -> {
            return q.a(var1, this.q);
         }
         case w -> {
            return f.a(var1, this.q);
         }
         case v -> {
            return o.a(var1, this.q);
         }
         case u -> {
            return m.a(var1, this.q);
         }
         case t -> {
            return h.a(var1, this.q);
         }
         default -> {
            return false;
         }
      }
   }

   public void l() {
      (new BukkitRunnable() {
         public void run() {
            for(Player var2 : Bukkit.getOnlinePlayers()) {
               if (k.this.b(var2)) {
                  l var3 = k.this.c(var2);
                  if (var3 != null) {
                     k.this.c(var2, var3);
                  }
               }
            }

         }
      }).runTaskTimer(this.q, 0L, 20L);
   }

   void c(Player var1, l var2) {
      switch (var2) {
         case C -> t.b(var1, this.q);
         case E -> x.b(var1, this.q);
         case D -> v.b(var1, this.q);
         case B -> z.b(var1, this.q);
         case A -> r.b(var1, this.q);
         case w -> g.b(var1, this.q);
         case v -> p.b(var1, this.q);
         case u -> n.b(var1, this.q);
         case t -> i.b(var1, this.q);
      }

   }

   public void a(UUID var1) {
      this.r.keySet().removeIf((var1x) -> var1x.startsWith(var1.toString()));
      this.s.keySet().removeIf((var1x) -> var1x.startsWith(var1.toString()));
   }

   public long b(UUID var1) {
      Player var2 = Bukkit.getPlayer(var1);
      if (var2 == null) {
         return 0L;
      } else {
         l var3 = this.c(var2);
         if (var3 == null) {
            return 0L;
         } else {
            String var10000 = String.valueOf(var1);
            String var4 = var10000 + "-" + var3.name();
            if (!this.r.containsKey(var4)) {
               return 0L;
            } else {
               long var5 = (Long)this.r.get(var4) - System.currentTimeMillis();
               return Math.max(0L, var5 / 1000L);
            }
         }
      }
   }

   private String a(String var1) {
      String var2 = this.q.getConfig().getString("messages.prefix", "");
      return (var2 + var1).replace("&", "§");
   }
}
