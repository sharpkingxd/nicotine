import java.util.Iterator;

public final class fN {
   public static final <T> Iterator<T> m(T[] var0) {
      fR.c(var0, (String)"");
      return new fM<T>(var0);
   }
}
