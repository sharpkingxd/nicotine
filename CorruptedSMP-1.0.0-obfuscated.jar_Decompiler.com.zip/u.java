import com.corruptedsmp.CorruptedSMPPlugin;
import java.util.HashSet;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class u {
   public static boolean a(final Player var0, CorruptedSMPPlugin var1) {
      final int var2 = var1.getConfig().getInt("corruptions.invincibility.ability-duration", 20);
      final D var3 = var1.f().g(var0.getUniqueId());
      var3.b(true);
      final HashSet var4 = new HashSet();
      var0.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, var2 * 20, 1, false, true));
      var0.sendMessage("§7§l✓ BULLETPROOF ACTIVATED!");
      var0.sendMessage("§7- Resistance II");
      var0.sendMessage("§7- Stealing armor durability from hits");
      var0.sendMessage("§7- Shields disabled within 12 blocks");
      (new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            if (this.ticks >= var2 * 20) {
               var3.b(false);
               var0.sendMessage("§c§lBulletproof ended!");
               this.cancel();
            } else {
               var0.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var0.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);

               for(Entity var2x : var0.getNearbyEntities((double)12.0F, (double)12.0F, (double)12.0F)) {
                  if (var2x instanceof Player) {
                     Player var3x = (Player)var2x;
                     if (!var3x.equals(var0) && !var4.contains(var3x.getUniqueId())) {
                        var3x.setCooldown(Material.SHIELD, var2 * 20);
                        var3x.sendMessage("§c§l✗ Your shield has been disabled by Bulletproof!");
                        var4.add(var3x.getUniqueId());
                     }
                  }
               }

               this.ticks += 10;
            }
         }
      }).runTaskTimer(var1, 0L, 10L);
      var0.playSound(var0.getLocation(), Sound.ITEM_ARMOR_EQUIP_NETHERITE, 1.0F, 0.8F);
      String var5 = var1.getConfig().getString("messages.ability-activated").replace("{ability}", "Bulletproof");
      var0.sendMessage(a(var5, var1));
      return true;
   }

   private static String a(String var0, CorruptedSMPPlugin var1) {
      String var2 = var1.getConfig().getString("messages.prefix", "");
      return (var2 + var0).replace("&", "§");
   }
}
