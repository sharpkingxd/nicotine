import com.corruptedsmp.CorruptedSMPPlugin;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class eg implements Listener {
   private final CorruptedSMPPlugin rD;
   private static final int[] rE = new int[]{10, 11, 12, 19, 20, 21, 28, 29, 30};

   public eg(CorruptedSMPPlugin var1) {
      this.rD = var1;
   }

   @EventHandler
   public void a(InventoryClickEvent var1) {
      HumanEntity var3 = var1.getWhoClicked();
      if (var3 instanceof Player var2) {
         String var15 = var1.getView().getTitle();
         if (var15.equals("§8§lRecipe Editor")) {
            var1.setCancelled(true);
            if (var1.getCurrentItem() != null && var1.getCurrentItem().getType() != Material.AIR) {
               ItemStack var16 = var1.getCurrentItem();
               if (var16.getType() == Material.FLOW_BANNER_PATTERN && var16.hasItemMeta()) {
                  String var17 = var16.getItemMeta().getDisplayName();

                  for(l var25 : l.values()) {
                     if (var17.equals(var25.o())) {
                        ep.a(var2, var25, this.rD);
                        return;
                     }
                  }
               }

            }
         } else {
            if (var15.startsWith("§8§lEdit: ")) {
               String var4 = var15.replace("§8§lEdit: ", "");
               l var5 = null;
               l[] var6 = l.values();
               int var7 = var6.length;
               int var8 = 0;

               while(true) {
                  if (var8 < var7) {
                     l var9 = var6[var8];
                     if (!var4.equals(var9.o())) {
                        ++var8;
                        continue;
                     }

                     var5 = var9;
                  }

                  if (var5 == null) {
                     return;
                  }

                  int var18 = var1.getRawSlot();
                  var7 = var1.getSlot();
                  if (this.aj(var18)) {
                     var1.setCancelled(false);
                     this.rD.getServer().getScheduler().runTask(this.rD, () -> {
                        ItemStack[] var4 = this.a(var1.getInventory());
                        ep.a(var2, var5, var4);
                     });
                     return;
                  }

                  if (var18 >= var1.getView().getTopInventory().getSize()) {
                     if (var1.isShiftClick()) {
                        var1.setCancelled(false);
                        this.rD.getServer().getScheduler().runTask(this.rD, () -> {
                           ItemStack[] var4 = this.a(var1.getInventory());
                           ep.a(var2, var5, var4);
                        });
                        return;
                     }

                     var1.setCancelled(false);
                     return;
                  }

                  var1.setCancelled(true);
                  ItemStack var22 = var1.getCurrentItem();
                  if (var22 == null || var22.getType() == Material.AIR) {
                     return;
                  }

                  if (var18 == 48 && var22.getType() == Material.LIME_CONCRETE) {
                     ItemStack[] var24 = this.a(var1.getInventory());
                     boolean var10 = false;

                     for(ItemStack var14 : var24) {
                        if (var14 != null && var14.getType() != Material.AIR) {
                           var10 = true;
                           break;
                        }
                     }

                     if (!var10) {
                        var2.sendMessage("§c§l✖ §cRecipe cannot be empty! Add at least one item.");
                        return;
                     }

                     B.a(var5, var24, this.rD);
                     ep.i(var2, var5);
                     var2.sendMessage("§a§l✔ §aRecipe saved successfully!");
                     var2.sendMessage("§7The recipe for §e" + var5.o() + " §7has been updated.");
                     var2.closeInventory();
                     return;
                  }

                  if (var18 == 49 && var22.getType() == Material.ORANGE_CONCRETE) {
                     B.a(var5, this.rD);
                     ep.i(var2, var5);
                     var2.sendMessage("§6§l↻ §6Recipe reset to default!");
                     var2.sendMessage("§7The recipe for §e" + var5.o() + " §7has been restored.");
                     ep.a(var2, var5, this.rD);
                     return;
                  }

                  if (var18 == 50 && var22.getType() == Material.RED_CONCRETE) {
                     ep.i(var2, var5);
                     var2.sendMessage("§c§l✖ §cChanges discarded.");
                     ep.e(var2, this.rD);
                     return;
                  }
                  break;
               }
            }

         }
      }
   }

   @EventHandler
   public void a(InventoryDragEvent var1) {
      String var2 = var1.getView().getTitle();
      if (var2.equals("§8§lRecipe Editor")) {
         var1.setCancelled(true);
      } else {
         if (var2.startsWith("§8§lEdit: ")) {
            boolean var3 = false;
            boolean var4 = false;

            for(int var6 : var1.getRawSlots()) {
               if (this.aj(var6)) {
                  var4 = true;
               } else if (var6 < var1.getView().getTopInventory().getSize()) {
                  var3 = true;
                  break;
               }
            }

            if (var3) {
               var1.setCancelled(true);
               return;
            }

            var1.setCancelled(false);
            if (var4) {
               HumanEntity var13 = var1.getWhoClicked();
               if (var13 instanceof Player) {
                  Player var12 = (Player)var13;
                  String var14 = var2.replace("§8§lEdit: ", "");
                  l var7 = null;

                  for(l var11 : l.values()) {
                     if (var14.equals(var11.o())) {
                        var7 = var11;
                        break;
                     }
                  }

                  if (var7 != null) {
                     this.rD.getServer().getScheduler().runTask(this.rD, () -> {
                        ItemStack[] var4 = this.a(var1.getInventory());
                        ep.a(var12, var7, var4);
                     });
                  }
               }
            }
         }

      }
   }

   private boolean aj(int var1) {
      for(int var5 : rE) {
         if (var1 == var5) {
            return true;
         }
      }

      return false;
   }

   private ItemStack[] a(Inventory var1) {
      ItemStack[] var2 = new ItemStack[]{var1.getItem(10) != null ? var1.getItem(10).clone() : new ItemStack(Material.AIR), var1.getItem(11) != null ? var1.getItem(11).clone() : new ItemStack(Material.AIR), var1.getItem(12) != null ? var1.getItem(12).clone() : new ItemStack(Material.AIR), var1.getItem(19) != null ? var1.getItem(19).clone() : new ItemStack(Material.AIR), var1.getItem(20) != null ? var1.getItem(20).clone() : new ItemStack(Material.AIR), var1.getItem(21) != null ? var1.getItem(21).clone() : new ItemStack(Material.AIR), var1.getItem(28) != null ? var1.getItem(28).clone() : new ItemStack(Material.AIR), var1.getItem(29) != null ? var1.getItem(29).clone() : new ItemStack(Material.AIR), var1.getItem(30) != null ? var1.getItem(30).clone() : new ItemStack(Material.AIR)};
      return var2;
   }
}
