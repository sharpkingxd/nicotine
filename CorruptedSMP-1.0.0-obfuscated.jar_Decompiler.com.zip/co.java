import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class co {
   public static final co mW = new co();
   private static final cn[] mX;
   private static final Map<dh, Integer> mY;

   private co() {
   }

   public final cn[] hY() {
      return mX;
   }

   public final Map<dh, Integer> hZ() {
      return mY;
   }

   private final Map<dh, Integer> ia() {
      LinkedHashMap var1 = new LinkedHashMap(mX.length);
      int var2 = 0;

      for(int var3 = mX.length; var2 < var3; ++var2) {
         if (!var1.containsKey(mX[var2].mN)) {
            Integer var4 = var2;
            ((Map)var1).put(mX[var2].mN, var4);
         }
      }

      Map var10000 = Collections.unmodifiableMap((Map)var1);
      fR.b(var10000, "");
      return var10000;
   }

   public final dh a(dh var1) throws IOException {
      fR.c(var1, (String)"");
      int var2 = 0;

      for(int var3 = var1.lm(); var2 < var3; ++var2) {
         byte var4 = var1.af(var2);
         if (65 <= var4 ? var4 < 91 : false) {
            throw new IOException("PROTOCOL_ERROR response malformed: mixed case name: " + var1.lf());
         }
      }

      return var1;
   }

   static {
      cn[] var0 = new cn[]{new cn(cn.mV, ""), new cn(cn.mS, "GET"), new cn(cn.mS, "POST"), new cn(cn.mT, "/"), new cn(cn.mT, "/index.html"), new cn(cn.mU, "http"), new cn(cn.mU, "https"), new cn(cn.mR, "200"), new cn(cn.mR, "204"), new cn(cn.mR, "206"), new cn(cn.mR, "304"), new cn(cn.mR, "400"), new cn(cn.mR, "404"), new cn(cn.mR, "500"), new cn("accept-charset", ""), new cn("accept-encoding", "gzip, deflate"), new cn("accept-language", ""), new cn("accept-ranges", ""), new cn("accept", ""), new cn("access-control-allow-origin", ""), new cn("age", ""), new cn("allow", ""), new cn("authorization", ""), new cn("cache-control", ""), new cn("content-disposition", ""), new cn("content-encoding", ""), new cn("content-language", ""), new cn("content-length", ""), new cn("content-location", ""), new cn("content-range", ""), new cn("content-type", ""), new cn("cookie", ""), new cn("date", ""), new cn("etag", ""), new cn("expect", ""), new cn("expires", ""), new cn("from", ""), new cn("host", ""), new cn("if-match", ""), new cn("if-modified-since", ""), new cn("if-none-match", ""), new cn("if-range", ""), new cn("if-unmodified-since", ""), new cn("last-modified", ""), new cn("link", ""), new cn("location", ""), new cn("max-forwards", ""), new cn("proxy-authenticate", ""), new cn("proxy-authorization", ""), new cn("range", ""), new cn("referer", ""), new cn("refresh", ""), new cn("retry-after", ""), new cn("server", ""), new cn("set-cookie", ""), new cn("strict-transport-security", ""), new cn("transfer-encoding", ""), new cn("user-agent", ""), new cn("vary", ""), new cn("via", ""), new cn("www-authenticate", "")};
      mX = var0;
      mY = mW.ia();
   }

   public static final class a {
      private final int headerTableSizeSetting;
      private int maxDynamicTableByteCount;
      private final List<cn> headerList;
      private final dg source;
      public cn[] dynamicTable;
      private int nextHeaderIndex;
      public int headerCount;
      public int dynamicTableByteCount;

      public a(dA var1, int var2, int var3) {
         fR.c(var1, (String)"");
         super();
         this.headerTableSizeSetting = var2;
         this.maxDynamicTableByteCount = var3;
         this.headerList = (List)(new ArrayList());
         this.source = do.c(var1);
         this.dynamicTable = new cn[8];
         this.nextHeaderIndex = this.dynamicTable.length - 1;
      }

      // $FF: synthetic method
      public a(dA var1, int var2, int var3, int var4, fP var5) {
         if ((var4 & 4) != 0) {
            var3 = var2;
         }

         this(var1, var2, var3);
      }

      public final List<cn> ib() {
         List var1 = eO.c((Iterable)this.headerList);
         this.headerList.clear();
         return var1;
      }

      private final void ic() {
         if (this.maxDynamicTableByteCount < this.dynamicTableByteCount) {
            if (this.maxDynamicTableByteCount == 0) {
               this.id();
            } else {
               this.v(this.dynamicTableByteCount - this.maxDynamicTableByteCount);
            }
         }

      }

      private final void id() {
         eI.a(this.dynamicTable, (Object)null, 0, 0, 6, (Object)null);
         this.nextHeaderIndex = this.dynamicTable.length - 1;
         this.headerCount = 0;
         this.dynamicTableByteCount = 0;
      }

      private final int v(int var1) {
         int var2 = var1;
         int var3 = 0;
         if (var1 > 0) {
            for(int var4 = this.dynamicTable.length - 1; var4 >= this.nextHeaderIndex && var2 > 0; --var4) {
               cn var10000 = this.dynamicTable[var4];
               fR.m(var10000);
               cn var5 = var10000;
               var2 -= var5.mP;
               this.dynamicTableByteCount -= var5.mP;
               int var6 = this.headerCount;
               this.headerCount = var6 + -1;
               ++var3;
            }

            System.arraycopy(this.dynamicTable, this.nextHeaderIndex + 1, this.dynamicTable, this.nextHeaderIndex + 1 + var3, this.headerCount);
            this.nextHeaderIndex += var3;
         }

         return var3;
      }

      public final void ie() throws IOException {
         while(!this.source.kK()) {
            int var1 = bD.a((byte)this.source.kN(), 255);
            if (var1 == 128) {
               throw new IOException("index == 0");
            }

            if ((var1 & 128) == 128) {
               int var4 = this.b(var1, 127);
               this.w(var4 - 1);
            } else if (var1 == 64) {
               this.ig();
            } else if ((var1 & 64) == 64) {
               int var3 = this.b(var1, 63);
               this.z(var3 - 1);
            } else if ((var1 & 32) == 32) {
               this.maxDynamicTableByteCount = this.b(var1, 31);
               if (this.maxDynamicTableByteCount < 0 || this.maxDynamicTableByteCount > this.headerTableSizeSetting) {
                  throw new IOException("Invalid dynamic table size update " + this.maxDynamicTableByteCount);
               }

               this.ic();
            } else if (var1 != 16 && var1 != 0) {
               int var2 = this.b(var1, 15);
               this.y(var2 - 1);
            } else {
               this.if();
            }
         }

      }

      private final void w(int var1) throws IOException {
         if (this.B(var1)) {
            cn var2 = co.mW.hY()[var1];
            this.headerList.add(var2);
         } else {
            int var3 = this.x(var1 - co.mW.hY().length);
            if (var3 < 0 || var3 >= this.dynamicTable.length) {
               throw new IOException("Header index too large " + (var1 + 1));
            }

            Collection var10000 = (Collection)this.headerList;
            cn var10001 = this.dynamicTable[var3];
            fR.m(var10001);
            var10000.add(var10001);
         }

      }

      private final int x(int var1) {
         return this.nextHeaderIndex + 1 + var1;
      }

      private final void y(int var1) throws IOException {
         dh var2 = this.A(var1);
         dh var3 = this.ii();
         this.headerList.add(new cn(var2, var3));
      }

      private final void if() throws IOException {
         dh var1 = co.mW.a(this.ii());
         dh var2 = this.ii();
         this.headerList.add(new cn(var1, var2));
      }

      private final void z(int var1) throws IOException {
         dh var2 = this.A(var1);
         dh var3 = this.ii();
         this.a(-1, new cn(var2, var3));
      }

      private final void ig() throws IOException {
         dh var1 = co.mW.a(this.ii());
         dh var2 = this.ii();
         this.a(-1, new cn(var1, var2));
      }

      private final dh A(int var1) throws IOException {
         dh var10000;
         if (this.B(var1)) {
            var10000 = co.mW.hY()[var1].mN;
         } else {
            int var2 = this.x(var1 - co.mW.hY().length);
            if (var2 < 0 || var2 >= this.dynamicTable.length) {
               throw new IOException("Header index too large " + (var1 + 1));
            }

            cn var3 = this.dynamicTable[var2];
            fR.m(var3);
            var10000 = var3.mN;
         }

         return var10000;
      }

      private final boolean B(int var1) {
         return var1 >= 0 && var1 <= co.mW.hY().length - 1;
      }

      private final void a(int var1, cn var2) {
         this.headerList.add(var2);
         int var4 = var2.mP;
         if (var1 != -1) {
            cn var10001 = this.dynamicTable[this.x(var1)];
            fR.m(var10001);
            var4 -= var10001.mP;
         }

         if (var4 > this.maxDynamicTableByteCount) {
            this.id();
         } else {
            int var5 = this.dynamicTableByteCount + var4 - this.maxDynamicTableByteCount;
            int var6 = this.v(var5);
            if (var1 == -1) {
               if (this.headerCount + 1 > this.dynamicTable.length) {
                  cn[] var7 = new cn[this.dynamicTable.length * 2];
                  System.arraycopy(this.dynamicTable, 0, var7, this.dynamicTable.length, this.dynamicTable.length);
                  this.nextHeaderIndex = this.dynamicTable.length - 1;
                  this.dynamicTable = var7;
               }

               int var8 = this.nextHeaderIndex;
               this.nextHeaderIndex = var8 + -1;
               this.dynamicTable[var8] = var2;
               var8 = this.headerCount++;
            } else {
               int var3 = var1 + this.x(var1) + var6;
               this.dynamicTable[var3] = var2;
            }

            this.dynamicTableByteCount += var4;
         }
      }

      private final int ih() throws IOException {
         return bD.a((byte)this.source.kN(), 255);
      }

      public final int b(int var1, int var2) throws IOException {
         int var3 = var1 & var2;
         if (var3 < var2) {
            return var3;
         } else {
            int var4 = var2;
            int var5 = 0;

            while(true) {
               int var6 = this.ih();
               if ((var6 & 128) == 0) {
                  var4 += var6 << var5;
                  return var4;
               }

               var4 += (var6 & 127) << var5;
               var5 += 7;
            }
         }
      }

      public final dh ii() throws IOException {
         int var1 = this.ih();
         boolean var2 = (var1 & 128) == 128;
         long var3 = (long)this.b(var1, 127);
         dh var10000;
         if (var2) {
            de var5 = new de();
            cv.ok.a(this.source, var3, var5);
            var10000 = var5.ii();
         } else {
            var10000 = this.source.w(var3);
         }

         return var10000;
      }
   }

   public static final class b {
      public int headerTableSizeSetting;
      private final boolean useCompression;
      private final de out;
      private int smallestHeaderTableSizeSetting;
      private boolean emitDynamicTableSizeUpdate;
      public int maxDynamicTableByteCount;
      public cn[] dynamicTable;
      private int nextHeaderIndex;
      public int headerCount;
      public int dynamicTableByteCount;

      public b(int var1, boolean var2, de var3) {
         fR.c(var3, (String)"");
         super();
         this.headerTableSizeSetting = var1;
         this.useCompression = var2;
         this.out = var3;
         this.smallestHeaderTableSizeSetting = Integer.MAX_VALUE;
         this.maxDynamicTableByteCount = this.headerTableSizeSetting;
         this.dynamicTable = new cn[8];
         this.nextHeaderIndex = this.dynamicTable.length - 1;
      }

      // $FF: synthetic method
      public b(int var1, boolean var2, de var3, int var4, fP var5) {
         if ((var4 & 1) != 0) {
            var1 = 4096;
         }

         if ((var4 & 2) != 0) {
            var2 = true;
         }

         this(var1, var2, var3);
      }

      private final void ij() {
         eI.a(this.dynamicTable, (Object)null, 0, 0, 6, (Object)null);
         this.nextHeaderIndex = this.dynamicTable.length - 1;
         this.headerCount = 0;
         this.dynamicTableByteCount = 0;
      }

      private final int C(int var1) {
         int var2 = var1;
         int var3 = 0;
         if (var1 > 0) {
            for(int var4 = this.dynamicTable.length - 1; var4 >= this.nextHeaderIndex && var2 > 0; --var4) {
               cn var10001 = this.dynamicTable[var4];
               fR.m(var10001);
               var2 -= var10001.mP;
               int var6 = this.dynamicTableByteCount;
               cn var10002 = this.dynamicTable[var4];
               fR.m(var10002);
               this.dynamicTableByteCount = var6 - var10002.mP;
               int var5 = this.headerCount;
               this.headerCount = var5 + -1;
               ++var3;
            }

            System.arraycopy(this.dynamicTable, this.nextHeaderIndex + 1, this.dynamicTable, this.nextHeaderIndex + 1 + var3, this.headerCount);
            Arrays.fill(this.dynamicTable, this.nextHeaderIndex + 1, this.nextHeaderIndex + 1 + var3, (Object)null);
            this.nextHeaderIndex += var3;
         }

         return var3;
      }

      private final void a(cn var1) {
         int var2 = var1.mP;
         if (var2 > this.maxDynamicTableByteCount) {
            this.ij();
         } else {
            int var3 = this.dynamicTableByteCount + var2 - this.maxDynamicTableByteCount;
            this.C(var3);
            if (this.headerCount + 1 > this.dynamicTable.length) {
               cn[] var4 = new cn[this.dynamicTable.length * 2];
               System.arraycopy(this.dynamicTable, 0, var4, this.dynamicTable.length, this.dynamicTable.length);
               this.nextHeaderIndex = this.dynamicTable.length - 1;
               this.dynamicTable = var4;
            }

            int var5 = this.nextHeaderIndex;
            this.nextHeaderIndex = var5 + -1;
            this.dynamicTable[var5] = var1;
            var5 = this.headerCount++;
            this.dynamicTableByteCount += var2;
         }
      }

      public final void g(List<cn> var1) throws IOException {
         fR.c(var1, (String)"");
         if (this.emitDynamicTableSizeUpdate) {
            if (this.smallestHeaderTableSizeSetting < this.maxDynamicTableByteCount) {
               this.a(this.smallestHeaderTableSizeSetting, 31, 32);
            }

            this.emitDynamicTableSizeUpdate = false;
            this.smallestHeaderTableSizeSetting = Integer.MAX_VALUE;
            this.a(this.maxDynamicTableByteCount, 31, 32);
         }

         int var2 = 0;

         for(int var3 = var1.size(); var2 < var3; ++var2) {
            cn var4 = (cn)var1.get(var2);
            dh var5 = var4.mN.ll();
            dh var6 = var4.mO;
            int var7 = -1;
            int var8 = -1;
            Integer var9 = (Integer)co.mW.hZ().get(var5);
            if (var9 != null) {
               var8 = var9 + 1;
               if (2 <= var8 ? var8 < 8 : false) {
                  if (fR.c(co.mW.hY()[var8 - 1].mO, (Object)var6)) {
                     var7 = var8;
                  } else if (fR.c(co.mW.hY()[var8].mO, (Object)var6)) {
                     var7 = var8 + 1;
                  }
               }
            }

            if (var7 == -1) {
               int var10 = this.nextHeaderIndex + 1;

               for(int var11 = this.dynamicTable.length; var10 < var11; ++var10) {
                  cn var10000 = this.dynamicTable[var10];
                  fR.m(var10000);
                  if (fR.c(var10000.mN, (Object)var5)) {
                     var10000 = this.dynamicTable[var10];
                     fR.m(var10000);
                     if (fR.c(var10000.mO, (Object)var6)) {
                        var7 = var10 - this.nextHeaderIndex + co.mW.hY().length;
                        break;
                     }

                     if (var8 == -1) {
                        var8 = var10 - this.nextHeaderIndex + co.mW.hY().length;
                     }
                  }
               }
            }

            if (var7 != -1) {
               this.a(var7, 127, 128);
            } else if (var8 == -1) {
               this.out.V(64);
               this.b(var5);
               this.b(var6);
               this.a(var4);
            } else if (var5.g(cn.mQ) && !fR.c(cn.mV, (Object)var5)) {
               this.a(var8, 15, 0);
               this.b(var6);
            } else {
               this.a(var8, 63, 64);
               this.b(var6);
               this.a(var4);
            }
         }

      }

      public final void a(int var1, int var2, int var3) {
         if (var1 < var2) {
            this.out.V(var3 | var1);
         } else {
            this.out.V(var3 | var2);

            int var4;
            for(var4 = var1 - var2; var4 >= 128; var4 >>>= 7) {
               int var5 = var4 & 127;
               this.out.V(var5 | 128);
            }

            this.out.V(var4);
         }
      }

      public final void b(dh var1) throws IOException {
         fR.c(var1, (String)"");
         if (this.useCompression && cv.ok.c(var1) < var1.lm()) {
            de var2 = new de();
            cv.ok.a(var1, var2);
            dh var3 = var2.ii();
            this.a(var3.lm(), 127, 128);
            this.out.d(var3);
         } else {
            this.a(var1.lm(), 127, 0);
            this.out.d(var1);
         }

      }

      public final void D(int var1) {
         this.headerTableSizeSetting = var1;
         int var2 = Math.min(var1, 16384);
         if (this.maxDynamicTableByteCount != var2) {
            if (var2 < this.maxDynamicTableByteCount) {
               this.smallestHeaderTableSizeSetting = Math.min(this.smallestHeaderTableSizeSetting, var2);
            }

            this.emitDynamicTableSizeUpdate = true;
            this.maxDynamicTableByteCount = var2;
            this.ik();
         }
      }

      private final void ik() {
         if (this.maxDynamicTableByteCount < this.dynamicTableByteCount) {
            if (this.maxDynamicTableByteCount == 0) {
               this.ij();
            } else {
               this.C(this.dynamicTableByteCount - this.maxDynamicTableByteCount);
            }
         }

      }
   }
}
