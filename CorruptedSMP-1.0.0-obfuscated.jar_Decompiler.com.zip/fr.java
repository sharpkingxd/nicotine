class fr extends fq {
}
