public final class dG {
   public static final int a(int[] var0, int var1, int var2, int var3) {
      fR.c(var0, (String)"");
      int var4 = var2;
      int var5 = var3 - 1;

      while(var4 <= var5) {
         int var6 = var4 + var5 >>> 1;
         int var7 = var0[var6];
         if (var7 < var1) {
            var4 = var6 + 1;
         } else {
            if (var7 <= var1) {
               return var6;
            }

            var5 = var6 - 1;
         }
      }

      return -var4 - 1;
   }

   public static final int a(dx var0, int var1) {
      fR.c(var0, (String)"");
      int var2 = a(var0.lN(), var1 + 1, 0, ((Object[])var0.lM()).length);
      return var2 >= 0 ? var2 : ~var2;
   }
}
