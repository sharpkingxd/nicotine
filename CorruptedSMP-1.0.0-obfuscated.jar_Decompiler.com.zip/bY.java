import java.io.IOException;
import java.util.Collection;
import java.util.List;

public final class bY implements bs {
   private final bk lJ;

   public bY(bk var1) {
      fR.c(var1, (String)"");
      super();
      this.lJ = var1;
   }

   public by a(bs.a var1) throws IOException {
      fR.c(var1, (String)"");
      bw var2 = var1.ds();
      bw.a var3 = var2.eO();
      bx var4 = var2.eL();
      if (var4 != null) {
         bt var5 = var4.bR();
         if (var5 != null) {
            var3.h("Content-Type", var5.toString());
         }

         long var6 = var4.bS();
         if (var6 != -1L) {
            var3.h("Content-Length", String.valueOf(var6));
            var3.ak("Transfer-Encoding");
         } else {
            var3.h("Transfer-Encoding", "chunked");
            var3.ak("Content-Length");
         }
      }

      if (var2.ah("Host") == null) {
         var3.h("Host", bD.a(var2.eI(), false, 1, (Object)null));
      }

      if (var2.ah("Connection") == null) {
         var3.h("Connection", "Keep-Alive");
      }

      boolean var13 = false;
      if (var2.ah("Accept-Encoding") == null && var2.ah("Range") == null) {
         var13 = true;
         var3.h("Accept-Encoding", "gzip");
      }

      List var14 = this.lJ.b(var2.eI());
      if (!((Collection)var14).isEmpty()) {
         var3.h("Cookie", this.f(var14));
      }

      if (var2.ah("User-Agent") == null) {
         var3.h("User-Agent", "okhttp/4.12.0");
      }

      by var7 = var1.c(var3.eQ());
      cc.a(this.lJ, var2.eI(), var7.eY());
      by.a var8 = var7.fh().e(var2);
      if (var13 && gA.a("gzip", by.a(var7, "Content-Encoding", (String)null, 2, (Object)null), true) && cc.n(var7)) {
         bz var9 = var7.eZ();
         if (var9 != null) {
            dl var10 = new dl(var9.bT());
            bq var11 = var7.eY().cU().H("Content-Encoding").H("Content-Length").cW();
            var8.d(var11);
            String var12 = by.a(var7, "Content-Type", (String)null, 2, (Object)null);
            var8.a(new cf(var12, -1L, do.c(var10)));
         }
      }

      return var8.fl();
   }

   private final String f(List<bj> var1) {
      StringBuilder var2 = new StringBuilder();
      StringBuilder var3 = var2;
      boolean var4 = false;
      Iterable var5 = (Iterable)var1;
      boolean var6 = false;
      int var7 = 0;

      for(Object var9 : var5) {
         int var10 = var7++;
         if (var10 < 0) {
            eO.nl();
         }

         bj var11 = (bj)var9;
         boolean var13 = false;
         if (var10 > 0) {
            var3.append("; ");
         }

         var3.append(var11.cD()).append('=').append(var11.cE());
      }

      String var14 = var2.toString();
      fR.b(var14, "");
      return var14;
   }
}
