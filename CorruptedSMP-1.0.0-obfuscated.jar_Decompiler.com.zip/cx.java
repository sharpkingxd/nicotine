public final class cx {
   public static final a oq = new a((fP)null);
   private int or;
   private final int[] os = new int[10];

   public final int jw() {
      byte var1 = 2;
      return (var1 & this.or) != 0 ? this.os[1] : -1;
   }

   public final int jx() {
      short var1 = 128;
      return (var1 & this.or) != 0 ? this.os[7] : '\uffff';
   }

   public final cx d(int var1, int var2) {
      if (var1 >= 0 && var1 < this.os.length) {
         int var3 = 1 << var1;
         this.or |= var3;
         this.os[var1] = var2;
         return this;
      } else {
         return this;
      }
   }

   public final boolean P(int var1) {
      int var2 = 1 << var1;
      return (this.or & var2) != 0;
   }

   public final int Q(int var1) {
      return this.os[var1];
   }

   public final int jy() {
      return Integer.bitCount(this.or);
   }

   public final int jz() {
      byte var1 = 16;
      return (var1 & this.or) != 0 ? this.os[4] : Integer.MAX_VALUE;
   }

   public final int R(int var1) {
      byte var2 = 32;
      return (var2 & this.or) != 0 ? this.os[5] : var1;
   }

   public final void d(cx var1) {
      fR.c(var1, (String)"");

      for(int var2 = 0; var2 < 10; ++var2) {
         if (var1.P(var2)) {
            this.d(var2, var1.Q(var2));
         }
      }

   }

   public static final class a {
      private a() {
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }
}
