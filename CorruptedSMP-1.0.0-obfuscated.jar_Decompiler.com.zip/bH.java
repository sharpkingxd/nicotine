import java.util.Date;
import java.util.concurrent.TimeUnit;

public final class bH {
   public static final a js = new a((fP)null);
   private final bw jt;
   private final by ju;

   public bH(bw var1, by var2) {
      this.jt = var1;
      this.ju = var2;
   }

   public final bw fv() {
      return this.jt;
   }

   public final by fw() {
      return this.ju;
   }

   public static final class a {
      private a() {
      }

      public final boolean a(by var1, bw var2) {
         fR.c(var1, (String)"");
         fR.c(var2, (String)"");
         switch (var1.eW()) {
            case 200:
            case 203:
            case 204:
            case 300:
            case 301:
            case 308:
            case 404:
            case 405:
            case 410:
            case 414:
            case 501:
               break;
            case 302:
            case 307:
               if (by.a(var1, "Expires", (String)null, 2, (Object)null) == null && var1.fj().ca() == -1 && !var1.fj().cc() && !var1.fj().cb()) {
                  return false;
               }
               break;
            default:
               return false;
         }

         return !var1.fj().bZ() && !var2.eP().bZ();
      }

      // $FF: synthetic method
      public a(fP var1) {
         this();
      }
   }

   public static final class b {
      private final long nowMillis;
      private final bw request;
      private final by cacheResponse;
      private Date servedDate;
      private String servedDateString;
      private Date lastModified;
      private String lastModifiedString;
      private Date expires;
      private long sentRequestMillis;
      private long receivedResponseMillis;
      private String etag;
      private int ageSeconds;

      public b(long var1, bw var3, by var4) {
         fR.c(var3, (String)"");
         super();
         this.nowMillis = var1;
         this.request = var3;
         this.cacheResponse = var4;
         this.ageSeconds = -1;
         if (this.cacheResponse != null) {
            this.sentRequestMillis = this.cacheResponse.fd();
            this.receivedResponseMillis = this.cacheResponse.fe();
            bq var5 = this.cacheResponse.eY();
            int var6 = 0;

            for(int var7 = var5.cT(); var6 < var7; ++var6) {
               String var8 = var5.j(var6);
               String var9 = var5.k(var6);
               if (gA.a(var8, "Date", true)) {
                  this.servedDate = ca.ay(var9);
                  this.servedDateString = var9;
               } else if (gA.a(var8, "Expires", true)) {
                  this.expires = ca.ay(var9);
               } else if (gA.a(var8, "Last-Modified", true)) {
                  this.lastModified = ca.ay(var9);
                  this.lastModifiedString = var9;
               } else if (gA.a(var8, "ETag", true)) {
                  this.etag = var9;
               } else if (gA.a(var8, "Age", true)) {
                  this.ageSeconds = bD.d(var9, -1);
               }
            }
         }

      }

      private final boolean fx() {
         by var10000 = this.cacheResponse;
         fR.m(var10000);
         return var10000.fj().ca() == -1 && this.expires == null;
      }

      public final bH fy() {
         bH var1 = this.fz();
         return var1.fv() != null && this.request.eP().cg() ? new bH((bw)null, (by)null) : var1;
      }

      private final bH fz() {
         if (this.cacheResponse == null) {
            return new bH(this.request, (by)null);
         } else if (this.request.eN() && this.cacheResponse.eX() == null) {
            return new bH(this.request, (by)null);
         } else if (!bH.js.a(this.cacheResponse, this.request)) {
            return new bH(this.request, (by)null);
         } else {
            ba var1 = this.request.eP();
            if (!var1.bY() && !this.f(this.request)) {
               ba var2 = this.cacheResponse.fj();
               long var3 = this.fB();
               long var5 = this.fA();
               if (var1.ca() != -1) {
                  var5 = Math.min(var5, TimeUnit.SECONDS.toMillis((long)var1.ca()));
               }

               long var7 = 0L;
               if (var1.cf() != -1) {
                  var7 = TimeUnit.SECONDS.toMillis((long)var1.cf());
               }

               long var9 = 0L;
               if (!var2.cd() && var1.ce() != -1) {
                  var9 = TimeUnit.SECONDS.toMillis((long)var1.ce());
               }

               if (!var2.bY() && var3 + var7 < var5 + var9) {
                  by.a var16 = this.cacheResponse.fh();
                  if (var3 + var7 >= var5) {
                     var16.l("Warning", "110 HttpURLConnection \"Response is stale\"");
                  }

                  long var18 = 86400000L;
                  if (var3 > var18 && this.fx()) {
                     var16.l("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
                  }

                  return new bH((bw)null, var16.fl());
               } else {
                  Object var11 = null;
                  Object var12 = null;
                  String var15;
                  String var17;
                  if (this.etag != null) {
                     var15 = "If-None-Match";
                     var17 = this.etag;
                  } else if (this.lastModified != null) {
                     var15 = "If-Modified-Since";
                     var17 = this.lastModifiedString;
                  } else {
                     if (this.servedDate == null) {
                        return new bH(this.request, (by)null);
                     }

                     var15 = "If-Modified-Since";
                     var17 = this.servedDateString;
                  }

                  bq.a var13 = this.request.eK().cU();
                  fR.m(var17);
                  var13.e(var15, var17);
                  bw var14 = this.request.eO().c(var13.cW()).eQ();
                  return new bH(var14, this.cacheResponse);
               }
            } else {
               return new bH(this.request, (by)null);
            }
         }
      }

      private final long fA() {
         by var10000 = this.cacheResponse;
         fR.m(var10000);
         ba var1 = var10000.fj();
         if (var1.ca() != -1) {
            return TimeUnit.SECONDS.toMillis((long)var1.ca());
         } else {
            Date var2 = this.expires;
            if (var2 != null) {
               Date var10 = this.servedDate;
               long var7 = var10 != null ? var10.getTime() : this.receivedResponseMillis;
               long var8 = var2.getTime() - var7;
               return var8 > 0L ? var8 : 0L;
            } else if (this.lastModified != null && this.cacheResponse.eT().eI().di() == null) {
               Date var9 = this.servedDate;
               long var3 = var9 != null ? var9.getTime() : this.sentRequestMillis;
               Date var10001 = this.lastModified;
               fR.m(var10001);
               long var5 = var3 - var10001.getTime();
               return var5 > 0L ? var5 / (long)10 : 0L;
            } else {
               return 0L;
            }
         }
      }

      private final long fB() {
         Date var1 = this.servedDate;
         long var2 = var1 != null ? Math.max(0L, this.receivedResponseMillis - var1.getTime()) : 0L;
         long var4 = this.ageSeconds != -1 ? Math.max(var2, TimeUnit.SECONDS.toMillis((long)this.ageSeconds)) : var2;
         long var6 = this.receivedResponseMillis - this.sentRequestMillis;
         long var8 = this.nowMillis - this.receivedResponseMillis;
         return var4 + var6 + var8;
      }

      private final boolean f(bw var1) {
         return var1.ah("If-Modified-Since") != null || var1.ah("If-None-Match") != null;
      }
   }
}
